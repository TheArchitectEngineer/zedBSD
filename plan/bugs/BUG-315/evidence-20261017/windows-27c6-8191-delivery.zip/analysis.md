# OLED タッチ USB 実測結果（2026-10-17、日本時間）

## 結論
04:10 の USBPcap で実際に列挙された USB Device Descriptor は Shenzhen Goodix Technology 27c6:8191、3 interface である。ただし Windows の過去の Kernel-PnP 履歴には、同じ物理 port path で 056a:8191 が 02:57:21 に開始され、02:57:25.162 に取り外され、27c6:8191 が 02:57:25.858 に開始された記録がある。したがって Pi 側の 056a:8191 という報告は Windows の履歴とも整合する。詳細は vid-transition-evidence.md。

Windows 標準 HID は interface 0 の Feature report ID 0x21 を2回「21 02 00」に設定した。interface 0 の HID report descriptor によると、この2 byte は Digitizers usage 0x52 Device Mode と 0x53 Device Identifier であり、値は Device Mode 0x02（multiple input）、Device Identifier 0x00（全 collection）である。Microsoft の説明でも mode 2 は multiple input、identifier 0 は全 collection を表す。続くタッチ操作で interface 0 の input report 0x0d（54 byte）は画面全幅に応じて X=0〜16382 を報告した。25%位置の X は約4960、中央は約8195、75%位置は約12379であり、左右の中央半分以外で飽和する現象は Windows の測定では見られなかった。Windows のカーソルが指と全幅で合うことはユーザーの目視確認である。

Windows の mode 設定が Pi との差の有力な説明である。ただし、Windows で mode 設定を省いた対照試験、Pi の初期化通信の採取、および VID 不一致の解消は行っていないため、それだけが原因だとは断定できない。推測したコマンドはデバイスに送っていない。

Microsoft 資料: https://learn.microsoft.com/en-us/windows-hardware/design/component-guidelines/using-report-descriptors-to-support-capability-discovery

## 採取範囲と切り出し
USBPcap1 と USBPcap2 の両 root hub を無フィルター、全長で 04:10:25 にキャプチャ開始した。対象ケーブルの接続はその後。対象の最初の記録は 04:10:42.962575 の GET_DESCRIPTOR DEVICE、最後の対象記録は 04:11:55.215181。キャプチャ停止は 04:12:07。USBPcap はアドレス割当て前の SET_ADDRESS を記録していない。最初に観測できた device-address 21 の descriptor 要求から操作終了までを収めた。

配布用 pcapng は bus 1 / device address 21 の 1,728 packet だけを切り出した。全 packet の bus/address を検証済み。他の USB device の転送は含まない。元の両 root hub キャプチャ（他機器の通信を含む）は PC ローカルの C:\Users\TabataKeiichi\AppData\Local\USBPcap-Wacom-8191-20261017\root-hubs-raw.pcapng に残しており、共有しない。配布用 pcapng の SHA-256 は 81a42e8941d968f6fddd0c89bfb6a751bca61e64f2ff9a284fadf6ec6719d874。

## HID 構成
- Interface 0: HID pen / touch / keyboard / input configuration、interrupt IN endpoint 0x81。report descriptor 946 byte。Windows の USB interface driver は Microsoft HidUsb (input.inf)、複合親は usbccgp (usb.inf)。child は HID-compliant pen、HID-compliant touch screen、HID Keyboard Device (kbdhid)、Microsoft Input Configuration Device (MTConfig)。
- Interface 1: vendor-defined usage page 0xff00、input ID 0x01、output ID 0x02、各63 data byte。interrupt IN 0x82。report descriptor 28 byte。driver は Microsoft HidUsb (input.inf)、child は HID-compliant vendor-defined device。
- Interface 2: mouse、interrupt IN 0x83。report descriptor 80 byte。driver は Microsoft HidUsb (input.inf)、child は HID-compliant mouse (mouhid, msmouse.inf)。
- HID report descriptors は interface-0-report-descriptor.bin などの binary と .hex.txt に全 byte を保存した。Windows driver の PnP 名、INF、バージョン、instance ID は windows-drivers.csv。

## 接続直後から初回タッチまでの指定転送
すべて USB control endpoint 0。setup packet と data stage は16進数で全 byte。結果はいずれも USBD_STATUS_SUCCESS。時刻は日本時間。

| 時刻 | IF | 方向/転送 | setup 8 byte | report ID | OUT data / IN response |
|---|---:|---|---|---|---|
| 04:10:42.976547 | 0 | OUT SET_IDLE | 21 0a 00 00 00 00 00 00 | 00 | なし |
| 04:10:42.992664 | 1 | OUT SET_IDLE | 21 0a 00 00 01 00 00 00 | 00 | なし |
| 04:10:42.998182 | 2 | OUT SET_IDLE | 21 0a 00 00 02 00 00 00 | 00 | なし |
| 04:10:43.006908 | 0 | IN GET_REPORT feature | a1 01 0a 03 00 00 02 00 | 0a | 応答 0a 0a（contact count maximum=10） |
| 04:10:43.007994 | 0 | OUT SET_REPORT output | 21 09 09 02 00 00 02 00 | 09 | 09 00（keyboard LED report） |
| 04:10:43.011890 | 0 | OUT SET_REPORT feature | 21 09 21 03 00 00 03 00 | 21 | 21 02 00 |
| 04:10:43.013464 | 0 | OUT SET_REPORT feature | 21 09 21 03 00 00 03 00 | 21 | 21 02 00 |

この間、vendor request と interrupt OUT は 0 件。interface 1 の output ID 0x02 に対する SET_REPORT または interrupt OUT は 0 件。initialization-transfers.csv には request/response frame、bmRequestType、bRequest、wValue、wIndex、wLength、report ID、setup/data の全 byte、完了 status を記載した。3 interface の report descriptor 取得要求と応答を含めたすべての target packet は pcapng と packets.csv にある。

## タッチ操作
interface 0 / endpoint 0x81 / report ID 0x0d。先頭から byte 2–3 が little-endian X、byte 4–5 が Y。各行は接触時間の中点付近の実 packet 1個の生値。範囲はその接触中に得た全 packet。時刻と frame の詳細は operation-times.csv、全837個の report 0x0d は touch-samples.csv。

| 操作 | 接触時刻（JST） | 代表 frame | 生 X | 生 Y | X 範囲 |
|---|---|---:|---:|---:|---|
| 左端 | 04:11:36.270–37.070 | 135 | 216 | 5155 | 216–300 |
| 幅25% | 04:11:37.821–38.710 | 311 | 4960 | 5214 | 4959–5007 |
| 中央 | 04:11:39.371–40.511 | 519 | 8195 | 5180 | 8195–8235 |
| 幅75% | 04:11:41.241–42.251 | 741 | 12379 | 5203 | 12379–12434 |
| 右端 | 04:11:42.992–44.032 | 951 | 16332 | 5573 | 16329–16367 |
| 左→右ドラッグ | 04:11:51.884–55.195 | 1393 | 8532 | 5222 | 0–16382 |

5点の保持時間はパケット上約0.8〜1.14秒で、依頼の「約2秒」より短かったが、各点で81〜115報告を記録できた。ドラッグは3.31秒、332報告。右端では Y が他点より高く、指の位置がやや低かった可能性がある。指の正確な物理座標や Windows の cursor 座標は USB capture には含まれず、幅25%等のラベルと全幅一致の確認はユーザーの操作・目視報告に基づく。

タッチ中、座標を伴う他 interface の input report はない。interface 1 0x82 と interface 2 0x83 は初期の0-byte interrupt completion のみで、payload はない。ペン報告は観測されていない。

## ファイル
- oled-touch-27c6-8191.pcapng: 対象のみの USBPcap/Wireshark capture
- operation-times.csv: 各操作の時刻・座標集計
- initialization-transfers.csv: 指定された初期化転送一覧
- packets.csv: 対象全1,728 packet の status と全 payload
- touch-samples.csv: ID 0x0d の全 report の X/Y
- interface-{0,1,2}-report-descriptor.bin と .hex.txt: 各 report descriptor 全 byte
- windows-drivers.csv: Windows PnP driver 名と INF

