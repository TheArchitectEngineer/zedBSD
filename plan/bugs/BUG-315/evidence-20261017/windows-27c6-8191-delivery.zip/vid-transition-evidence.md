# 同一 USB ポートでの VID 変化の証拠（2026-10-17 JST）

Windows の Kernel-PnP イベントには、USB\VID_056A&PID_8191\6&3a1c2386&0&1 の開始後、同じ instance suffix と port path で USB\VID_27C6&PID_8191\6&3a1c2386&0&1 が開始された履歴がある。Logicool USB\VID_046D&PID_C548 は別の接続経路である。

| JST | 記録 |
|---|---|
| 02:57:21.1401104 | 056a:8191 開始。Kernel-PnP/Configuration event 410、record 7037 |
| 02:57:25.1629550 | 056a:8191 がバス上から突然取り外された。Kernel-PnP/Device Management event 1010、record 8924 |
| 02:57:25.8582004 | 27c6:8191 開始。Kernel-PnP/Configuration event 410、record 7063 |

取り外しから後続の開始まで 0.6952454 秒。両者の PnP LocationPaths は PCIROOT(0)#PCI(1400)#USBROOT(0)#USB(1)#USB(1) および ACPI(_SB_)#ACPI(PC00)#ACPI(XHCI)#ACPI(RHUB)#ACPI(HS01)#USB(1)。Parent は両者とも USB\VID_1A40&PID_0801\5&1a594670&0&1、LocationInfo は Port_#0001.Hub_#0018、BusReportedDeviceDesc は HIDTOUCH。これは同じ下流ポートでの再列挙を強く示す。ただし、同じポートへの物理的な抜き差しをイベントだけで排除することはできない。

02:57 の USBPcap は存在しないため、その時の USB bus device address と 056a:8191 の生 Device Descriptor 18 byte、切り替え直前の control/vendor/output payload は取得されていない。Windows の PnP HardwareIds には USB\VID_056A&PID_8191&REV_0100 が記録されており、VID/PID と bcdDevice=0x0100 は確認できる。両デバイスの DEVPKEY_Device_Address=1 は接続ポート番号の情報であり、USBPcap の bus device address と同一視できない。

04:10 に接続前から開始した USBPcap では、最初に観測した対象の Device Descriptor 応答は 04:10:42.962897、bus 1 / device address 21、18 byte は 12 01 10 01 00 00 00 08 c6 27 91 81 00 01 01 02 00 01（VID=0x27c6、PID=0x8191）。04:10 の raw capture に VID=0x056a の Device Descriptor はない。interface 0 への SET_REPORT feature 21 02 00 は 04:10:43.011890 と 04:10:43.013464 であり、この Device Descriptor より後である。従って、今回記録された SET_REPORT が 056a→27c6 の VID 変更を起こしたことはない。04:10 以前の別の初期化による切替は未検証。

同じ raw capture の Logicool は VID:PID=046d:c548、bus 1 / device address 17 で、キャプチャ開始時の既存デバイスとして 04:10:33.009691 に descriptor が記録されている。PnP LocationPaths は PCIROOT(0)#PCI(1400)#USBROOT(0)#USB(3)#USB(2)#USB(4)#USB(2)#USB(2)。OLED の path と異なる。配布した対象 pcapng に Logicool の通信は含まない。

vid-transition-events.csv は上記2つの対象 USB device のイベントだけを抽出した。認証機器を含む他デバイスのイベントや転送は含まない。
