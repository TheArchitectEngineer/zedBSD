# 10秒間の root hub 再採取（2026-10-17 JST）

USBPcap1 と USBPcap2 をフィルターなし・全長で採取した。ユーザーへの開始合図後の区間は 04:30:47.7617866〜04:30:57.7796328（10.0178462秒）。この区間の全 root hub 転送は869 packet。最初の packet は04:30:47.843622、最後は04:30:57.514661。両端に転送がない時間があるため、packet の時刻幅は9.671秒。

対象 OLED の再接続では、04:30:50.978712 に bus 1 / device address 27 の Device Descriptor 応答で VID:PID=27c6:8191 を確認した。対象はこの区間に52 packet。最初の GET_DESCRIPTOR DEVICE から interface 0・1・2 の HID report descriptor、GET_REPORT、SET_REPORT までを含む。056a の Device Descriptor はこの区間にも、04:26:21からの連続原本全体にも観測されなかった。従って、この実験でも 056a に送られたコマンドは取得できていない。

10秒間の両 root hub 原本は PC ローカルの C:\Users\TabataKeiichi\AppData\Local\USBPcap-VID-transition-20261017\root-hubs-10s-raw.pcapng に保持した。他 USB 機器の転送を含むため納品物には入れていない。対象のみの52 packet を oled-touch-10s-27c6-8191.pcapng として納品する。元の連続キャプチャも同じローカルディレクトリに保持した。

USBPcap はホスト側で見えた USB 転送を記録する。アドレス割り当て前の SET_ADDRESS や電気的な接続事象など、USBPcap が観測しない事象まで含むものではない。
Raw 10s SHA-256: f3434e0bf1655408d2fad71a45daa1ab2a0770edf3425997b5fe11ef0eae511e
Target-only SHA-256: 84df266fd5a16023fddeb5cfb9ea5758346d0536bd5147e1772ec7e86a614c5b

