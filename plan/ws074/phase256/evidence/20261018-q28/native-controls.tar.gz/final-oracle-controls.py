from pathlib import Path
import os,importlib.util,json,subprocess,re,time
q=Path('build/ws074-20261018/q28');os.environ['WPT_GENERATED_CONTROL_ROOT']=str(q/'final-oracle-controls');os.environ['WPT_GENERATED_PROGRAM']=str((q/'final/engine/browser').resolve())
spec=importlib.util.spec_from_file_location('q28_real_error_controls','plan/ws074/tests/test-interop2025-generated.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
prior=json.loads(Path('build/ws074-20261018/q26/oracle-negative-result.json').read_text());old=Path(prior['generated']['raw_directory'],'source.js').read_bytes()
cases=[('timer-negative',b'''async_test(function(t){setTimeout(function(){assert_unreached("intentional timer failure must reach the global error listener");},0);t.step_timeout(t.step_func_done(function(){}),100);},"uncaught timer callback must not be PASS");''','harness_error'),('timer-positive',b'''async_test(function(t){setTimeout(t.step_func_done(function(){assert_true(true);}),0);},"normal timer callback completes");''','pass'),('observer-negative',old,'harness_error'),('observer-positive-captured',b'''async_test(function(t){performance.clearMarks();performance.mark('past-real');var observer=new PerformanceObserver(function(list,o,options){var receiver=this;t.step(function(){assert_equals(receiver,observer);assert_equals(o,observer);assert_true(list instanceof PerformanceObserverEntryList);var entries=list.getEntries();assert_equals(entries.length,1);assert_equals(entries[0].name,'future-real');assert_equals(entries[0].detail,42);assert_true(entries[0] instanceof PerformanceMark);o.disconnect();t.done();});});observer.observe({entryTypes:['mark'],buffered:true});performance.mark('future-real',{detail:42});},"actual future-only observer callback completes");''','pass')]
results=[]
for label,script,expected in cases:
 native=m.native(label,'any',script);(q/(label+'-final-native.json')).write_text(json.dumps(native,indent=2)+'\n');assert native['outcome']==expected,(label,native['outcome'],native.get('completion'))
 if expected=='harness_error':assert native['completion']['status']==1
 assert Path(native['generated']['raw_directory'],'source.js').read_bytes()==script
 root,row,server,context,tool,worker=m.fixture(label+'-chrome','any',script)
 command=['chromium','--headless','--no-sandbox','--disable-gpu','--enable-logging=stderr','--log-level=0','--user-data-dir=/tmp/ws074-q28-'+label+'-'+str(time.time_ns()),'--virtual-time-budget=5000','--dump-dom','http://127.0.0.1:%d%s'%(server.server_port,row['id'])]
 try:run=subprocess.run(command,capture_output=True,timeout=30)
 finally:m.stop(server,worker)
 (q/(label+'-final-chrome.html')).write_bytes(run.stdout);(q/(label+'-final-chrome.log')).write_bytes(run.stderr);messages=[]
 for line in run.stderr.decode('utf8',errors='replace').splitlines():
  match=re.search(r':CONSOLE(?:\(\d+\)|:\d+)\] "(.*)", source: ',line)
  if match:messages.append(match[1])
 chrome=m.RUNNER.classify_output('\n'.join(messages)+'\n',run.returncode);chrome['command']=command;(q/(label+'-final-chrome.json')).write_text(json.dumps(chrome,indent=2)+'\n');assert chrome['outcome']==expected,(label,chrome['outcome'],chrome.get('completion'))
 if expected=='harness_error':assert chrome['completion']['status']==1
 proof=dict(control=label,expected=expected,native=native['outcome'],chrome=chrome['outcome'],original_source_equal=Path(native['generated']['raw_directory'],'source.js').read_bytes()==script,prior_q26_source_identical=label!='observer-negative' or script==old);results.append(proof);print(proof,flush=True)
(q/'final-oracle-proof.json').write_text(json.dumps(results,indent=2)+'\n')
