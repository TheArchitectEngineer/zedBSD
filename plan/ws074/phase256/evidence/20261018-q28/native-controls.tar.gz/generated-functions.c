int bind_run_script(struct bind_window *window, const uint16_t *source, size_t length, const char *name);
int bind_run_script_source(struct bind_window *window, const uint16_t *source, size_t length, const char *name, int known_inline);
int bind_checkpoint(struct bind_window *window);
static struct vm_cell * window_exception_cell(vm_value value);
static void window_report_exception(struct bind_window *window, vm_value exception, const char *name);
static int window_report_event(struct bind_window *window, vm_value exception, vm_value source, const struct wb_buffer *message, uint32_t line, uint32_t column, int *canceled);
static void window_script_source_trace(struct vm_heap *heap, struct vm_cell *cell);
static int window_run_source(struct bind_window *window, const uint16_t *source, size_t length, int known_inline, vm_value *completion, struct js_syntax_error *syntax);
struct vm_function * vm_function_create_native(struct vm_realm *realm, const char *name, unsigned length, vm_native native);
struct vm_function * vm_function_create(struct vm_realm *realm, struct vm_code *code);
static void function_transfer_exception(struct vm_realm *caller, struct vm_realm *callee, int status);
static void function_trace(struct vm_heap *heap, struct vm_cell *cell);
static int realm_create(struct vm_heap *heap, int managed, struct vm_realm **realm);
static void realm_trace(struct vm_heap *heap, void *context);
static int interpreter_unwind(struct interpreter *run);

int
bind_run_script(
	struct bind_window *window,
	const uint16_t *source,
	size_t length,
	const char *name)
{
	int status;

	/* Unverified script origins retain no disclosure authority merely from a diagnostic name. */
	status = bind_run_script_source(window, source, length, name, 0);
	if (status != 0)
		return status;

	/* Succeeded: the script ran or its normal failure was reported. */
	return 0;
}

int
bind_run_script_source(
	struct bind_window *window,
	const uint16_t *source,
	size_t length,
	const char *name,
	int known_inline)
{
	struct js_syntax_error syntax;
	struct wb_buffer line;
	vm_value completion;
	const char *reason;
	int format_error;
	int status;

	/* Runs the script. */
	status = window_run_source(window, source, length, known_inline, &completion, &syntax);

	/* A script that does not parse, or uses what the engine does not support yet, is reported. */
	if (status == EINVAL) {
		wb_buffer_init(&line);
		status = wb_buffer_printf(&line, "Uncaught SyntaxError: %s (%s:%u:%u)", syntax.message, name,
					  (unsigned)syntax.line, (unsigned)syntax.column);
		if (status == 0)
			bind_console(window, BIND_CONSOLE_ERROR, wb_buffer_string(&line));
		wb_buffer_release(&line);
	} else if (status == VM_THROWN) {
		/* An exception is reported and cleared. */
		window_report_exception(window, window->realm->exception, name);
		window->realm->exception = VM_VALUE_UNDEFINED;
		status = 0;
	}

	/* Running out of memory stops the page. */
	if (status == ENOMEM)
		return status;

	/* Any other failure (the engine reached a limit it cannot report as an exception) ends the script; say so. */
	if (status != 0) {
		wb_buffer_init(&line);
		reason = strerror(status);
		format_error = wb_buffer_printf(&line, "Uncaught InternalError: the script stopped (%s) (%s)", reason, name);
		if (format_error == 0)
			bind_console(window, BIND_CONSOLE_ERROR, wb_buffer_string(&line));
		wb_buffer_release(&line);
	}

	/* The microtasks the script queued. */
	status = bind_checkpoint(window);
	if (status != 0)
		return status;

	/* Succeeded: the script ran, or its error was reported. */
	return 0;
}

int
bind_checkpoint(
	struct bind_window *window)
{
	struct vm_cell *realm_root;
	int registered;
	int queued;
	int status;

	/* A detached context never delivers work queued by later saved functions. */
	if (window->detached) {
		window->realm->jobs.count = 0;
		window->realm->rejections.count = 0;
		return 0;
	}

	/* HTML's checkpoint flag prevents an error listener from running the same active microtask again. */
	if (window->checkpoint_running)
		return 0;

	/* Foreign callbacks can retire this child while its native checkpoint still owns the Window record. */
	realm_root = NULL;
	registered = 0;
	if (window->realm->managed) {
		realm_root = &window->realm->cell;
		status = vm_heap_add_root(window->realm->heap, &realm_root);
		if (status != 0)
			return status;
		registered = 1;
	}

	/* Drain the real jobs once while nested checkpoints are suppressed. */
	window->checkpoint_running = 1;
	status = vm_run_jobs(window->realm, window_report_job, window);
	if (status != 0) {
		window_report_stop(window, status);
		goto cleanup;
	}

	/* Mutation delivery can queue more jobs, but cannot start another concurrent drain. */
	for (;;) {
		status = bind_environment_checkpoint(window, &queued);
		if (status != 0 || !queued)
			break;
		status = vm_run_jobs(window->realm, window_report_job, window);
		if (status != 0)
			break;
	}

	/* Host frame processing follows the completed checkpoint and may legitimately request another one. */
	window->checkpoint_running = 0;
	if (status == 0 &&
	    !window->detached &&
	    window->realm->depth == 0 &&
	    window->host.checkpoint != NULL)
		status = window->host.checkpoint(window->host.context);

cleanup:
	/* Every failure resets the guard and releases the same managed-owner edge. */
	window->checkpoint_running = 0;
	if (registered)
		vm_heap_remove_root(window->realm->heap, &realm_root);

	/* A failed job or host callback remains visible to the page driver. */
	if (status != 0)
		return status;

	/* Succeeded: no reentrant checkpoint ran the same pending work twice. */
	return 0;
}

static struct vm_cell *
window_exception_cell(
	vm_value value)
{
	int managed;

	/* A primitive contributes no collector edge. */
	managed = vm_value_is_cell(value);
	if (!managed)
		return NULL;

	/* Succeeded: the caller can protect the actual cell. */
	return vm_value_as_cell(value);
}

static void
window_report_exception(
	struct bind_window *window,
	vm_value exception,
	const char *name)
{
	struct vm_realm *realm;
	struct wb_buffer text;
	struct vm_cell *roots[5];
	vm_value saved_exception;
	vm_value saved_throw;
	vm_value saved_source;
	vm_value report_source;
	uint32_t site_line;
	uint32_t site_column;
	uint32_t saved_line;
	uint32_t saved_column;
	char saved_stack[sizeof(realm->throw_stack)];
	const char *stack_setting;
	unsigned index;
	unsigned registered;
	int saved_reporting;
	int promise;
	int known;
	int canceled;
	int error;
	int dispatched;

	/* Retired contexts cannot execute exception conversion getters or notify listeners. */
	if (window->detached)
		return;

	/* Snapshot native provenance before ToString, listeners or checkpoints can replace pending state. */
	realm = window->realm;
	saved_exception = realm->exception;
	saved_throw = realm->throw_value;
	saved_source = realm->throw_source;
	saved_line = realm->throw_line;
	saved_column = realm->throw_column;
	memcpy(saved_stack, realm->throw_stack, sizeof(saved_stack));
	saved_reporting = window->reporting_error;
	promise = realm->reporting_rejection;
	site_line = 0;
	site_column = 0;
	known = vm_throw_site(realm, exception, &site_line, &site_column);

	/* A stale or unrelated pending trace never grants disclosure to this exception. */
	report_source = VM_VALUE_UNDEFINED;
	if (known)
		report_source = saved_source;

	/* A managed child Window and every suspended value survive removal during arbitrary user conversion. */
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = window_exception_cell(exception);
	roots[2] = window_exception_cell(saved_exception);
	roots[3] = window_exception_cell(saved_throw);
	roots[4] = window_exception_cell(saved_source);
	registered = 0;
	wb_buffer_init(&text);
	for (index = 0; index < 5U; index++) {
		error = vm_heap_add_root(realm->heap, &roots[index]);
		if (error != 0) {
			bind_console(window, BIND_CONSOLE_ERROR, "Uncaught exception (error reporting could not retain its state)");
			goto cleanup;
		}

		/* Cleanup owns only successfully acquired root slots. */
		registered++;
	}

	/* Reentrant reporting neither dispatches another global error nor recursively converts the same object. */
	window->exception_reports++;
	window->reporting_error = 1;
	realm->exception = VM_VALUE_UNDEFINED;
	realm->throw_value = VM_VALUE_UNDEFINED;
	realm->throw_source = VM_VALUE_UNDEFINED;
	realm->throw_line = 0;
	realm->throw_column = 0;

	/* Promise rejection retains its separate diagnostic path and never becomes a Window error event. */
	if (promise) {
		error = wb_buffer_append_string(&text, "Uncaught (in promise) ");
	} else {
		error = wb_buffer_append_string(&text, "Uncaught ");
	}

	/* Convert once at the outer report; nested reports use a bounded script-free description. */
	if (error == 0) {
		if (window->exception_reports > 1U) {
			error = wb_buffer_append_string(&text, "(an exception reported recursively)");
		} else {
			error = js_exception_text(realm, exception, &text);
		}
	}

	/* Trusted native dispatch does not consult mutable ErrorEvent or dispatchEvent globals. */
	canceled = 0;
	if (error == 0 &&
	    !window->detached &&
	    !promise &&
	    !saved_reporting &&
	    window->exception_reports == 1U) {
		dispatched = window_report_event(window, exception, report_source, &text, site_line, site_column, &canceled);
		if (dispatched != 0)
			canceled = 0;
	}

	/* Preserve the established console location format independently of ErrorEvent disclosure. */
	if (error == 0 &&
	    known &&
	    name != NULL)
		error = wb_buffer_printf(&text, " (at %s:%u:%u)", name, (unsigned)site_line, (unsigned)site_column);

	/* Timer and native callback diagnostics retain their existing unnamed throw position. */
	if (error == 0 &&
	    known &&
	    name == NULL)
		error = wb_buffer_printf(&text, " (at %u:%u)", (unsigned)site_line, (unsigned)site_column);

	/* Optional developer stack text uses the saved original trace, never a listener's newer failure. */
	if (error == 0 && known) {
		stack_setting = getenv("BROWSER_STACK");
		if (stack_setting != NULL)
			error = wb_buffer_printf(&text, " [in %s]", saved_stack);
	}

	/* preventDefault and legacy onerror true suppress only this report's console default. */
	if (!canceled) {
		if (error == 0) {
			bind_console(window, BIND_CONSOLE_ERROR, wb_buffer_string(&text));
		} else {
			bind_console(window, BIND_CONSOLE_ERROR, "Uncaught exception (error reporting could not allocate storage)");
		}
	}

	/* Suspended pending state returns before roots are released, while consumed throw metadata cannot go stale. */
	realm->exception = saved_exception;
	realm->throw_value = saved_throw;
	realm->throw_source = saved_source;
	realm->throw_line = saved_line;
	realm->throw_column = saved_column;
	memcpy(realm->throw_stack, saved_stack, sizeof(saved_stack));
	if (saved_throw == exception) {
		realm->throw_value = VM_VALUE_UNDEFINED;
		realm->throw_source = VM_VALUE_UNDEFINED;
		realm->throw_line = 0;
		realm->throw_column = 0;
		realm->throw_stack[0] = '\0';
	}

	/* Restore the outer dispatch mode even when a listener retired this Window. */
	window->reporting_error = saved_reporting;
	window->exception_reports--;

cleanup:
	/* Both root registration failure and normal report completion release only owned roots. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Temporary diagnostic storage never owns a managed value. */
	wb_buffer_release(&text);

	/* Succeeded: the original exception was notified or retained for the caller's failure cleanup. */
	return;
}

static int
window_report_event(
	struct bind_window *window,
	vm_value exception,
	vm_value source,
	const struct wb_buffer *message,
	uint32_t line,
	uint32_t column,
	int *canceled)
{
	struct vm_realm *realm;
	struct vm_cell *event_root;
	struct vm_cell *cell;
	struct window_script_source *origin;
	struct bind_event *event;
	struct vm_string *type;
	struct vm_string *converted;
	vm_value wrapper;
	vm_value text;
	int status;
	int managed;

	/* Only this binding's immutable source cell supplies inline disclosure authority. */
	realm = window->realm;
	origin = NULL;
	managed = vm_value_is_cell(source);
	if (managed) {
		cell = vm_value_as_cell(source);
		if (cell->type == &window_script_source_type)
			origin = (struct window_script_source *)cell;
	}

	/* Protect the unpublished event before its message allocation or any listener can collect. */
	event_root = NULL;
	status = vm_heap_add_root(realm->heap, &event_root);
	if (status != 0)
		return status;
	type = vm_atom_from_ascii(realm->heap, "error");
	if (type == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The native interface and its pristine prototype remain valid after global constructors are replaced. */
	status = bind_event_create(window, BIND_ERROR_EVENT, type, &wrapper, &event);
	if (status != 0)
		goto cleanup;
	event_root = vm_value_as_cell(wrapper);
	event->trusted = 1;
	event->cancelable = 1;

	/* Unknown provenance is conservatively muted instead of guessing from a current script or URL. */
	if (origin == NULL) {
		status = bind_string(realm, "Script error.", &text);
		event->detail = VM_VALUE_NULL;
	} else {
		converted = vm_string_from_utf8(realm->heap, wb_buffer_string(message), message->length);
		status = 0;
		if (converted == NULL) {
			status = ENOMEM;
		} else {
			text = vm_value_cell(converted);
		}

		/* The message retains embedded NUL bytes rather than relying on a C string terminator. */
		event->detail = exception;
		event->error_filename = origin->filename;
		event->error_line = line;
		event->error_column = column;
	}

	/* The event owns its managed message before ordinary EventTarget dispatch invokes script. */
	if (status != 0)
		goto cleanup;
	event->error_message = (struct vm_string *)vm_value_as_cell(text);
	status = bind_dispatch(window, vm_value_cell(realm->global), wrapper, canceled);

cleanup:
	/* Successful dispatch and all earlier failures share the same event-root lifetime. */
	vm_heap_remove_root(realm->heap, &event_root);
	if (status != 0)
		return status;

	/* Succeeded: the caller knows whether the native report's default was canceled. */
	return 0;
}

static void
window_script_source_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct window_script_source *source;

	/* Source metadata owns only immutable text and never a raw Window or Document. */
	source = (struct window_script_source *)cell;
	if (source->filename != NULL)
		vm_heap_mark(heap, &source->filename->cell);

	/* Succeeded: retained closures preserve their defining source text safely. */
	return;
}

static int
window_run_source(
	struct bind_window *window,
	const uint16_t *source,
	size_t length,
	int known_inline,
	vm_value *completion,
	struct js_syntax_error *syntax)
{
	struct vm_realm *realm;
	struct vm_function *function;
	struct window_script_source *origin;
	struct js_program program;
	struct vm_cell *roots[3];
	struct wb_buffer filename;
	unsigned index;
	unsigned registered;
	int status;

	/* A retired owner cannot compile or run saved source. */
	*completion = VM_VALUE_UNDEFINED;
	if (window->detached)
		return 0;

	/* Register the managed owner, unpublished function and source cell before any managed allocation. */
	realm = window->realm;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = NULL;
	roots[2] = NULL;
	registered = 0;
	wb_buffer_init(&filename);
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Only completed registrations belong to this invocation's cleanup. */
		registered++;
	}

	/* The ordinary production parser and compiler remain unchanged. */
	status = js_parse(source, length, 0, &program, syntax);
	if (status != 0)
		goto cleanup;
	status = js_compile(realm, &program, &function, syntax);
	js_program_release(&program);
	if (status != 0)
		goto cleanup;
	roots[1] = &function->object.cell;

	/* Only actual inline loader paths create known source metadata, using the Document URL rather than base. */
	if (known_inline) {
		origin = vm_heap_alloc(realm->heap, &window_script_source_type, sizeof(*origin));
		if (origin == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The newborn metadata remains rooted while its actual URL is copied into managed storage. */
		roots[2] = &origin->cell;
		status = bind_document_url(window->document, 0, &filename);
		if (status != 0)
			goto cleanup;
		origin->filename = vm_string_from_utf8(realm->heap, wb_buffer_string(&filename), filename.length);
		if (origin->filename == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The immutable opaque value is attached before code can create any nested closures. */
		function->source = vm_value_cell(origin);
	}

	/* Classic top-level this remains the real Window global. */
	status = vm_call(realm, vm_value_cell(function), vm_value_cell(realm->global), NULL, 0, completion);

cleanup:
	/* Both a completed execution and an early parse/compile/allocation failure release temporary owners. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* The compiled closures retain their own metadata after this temporary URL storage is released. */
	wb_buffer_release(&filename);
	if (status != 0)
		return status;

	/* Succeeded: source ran through the ordinary VM with its actual defining context. */
	return 0;
}

struct vm_function *
vm_function_create_native(
	struct vm_realm *realm,
	const char *name,
	unsigned length,
	vm_native native)
{
	struct vm_heap *heap;
	struct vm_function *function;
	struct vm_string *text;
	struct vm_cell *roots[3];
	vm_value key;
	unsigned index;
	unsigned registered;
	int error;

	/* Retains a collectible realm before the first allocation and both unpublished cells. */
	heap = realm->heap;
	function = NULL;
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;

	/* Collectible realms need an explicit input edge before the function can own them. */
	if (realm->managed)
		roots[0] = &realm->cell;

	/* The acquisition count owns only slots successfully inserted into the heap registry. */
	registered = 0;
	for (index = 0; index < 3U; index++) {
		error = vm_heap_add_root(heap, &roots[index]);
		if (error != 0)
			goto cleanup;

		/* Cleanup owns this slot only after the heap registry has acquired it. */
		registered++;
	}

	/* Allocates the function before publishing its shape or native state. */
	function = vm_heap_alloc(heap, &vm_function_type, sizeof(*function));
	if (function == NULL) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Protects the newborn while initialization may allocate a cold root shape. */
	roots[1] = &function->object.cell;
	error = vm_object_init(heap, &function->object, realm->function_prototype);
	if (error != 0)
		goto cleanup;

	/* Retains only collectible realms without consulting retired manual owners. */
	function->realm = realm;

	/* The completed function supplies the durable edge only for collectible realms. */
	if (realm->managed)
		function->realm_owner = &realm->cell;

	/* Initializes the native entry point and its ordinary function state. */
	function->native = native;
	function->object.kind = VM_KIND_FUNCTION;
	function->data = VM_VALUE_UNDEFINED;
	function->source = VM_VALUE_UNDEFINED;

	/* Acquires the heap-owned length key before defining its configurable property. */
	key = vm_key_from_ascii(heap, "length");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Records the native argument count without writable or enumerable attributes. */
	error = vm_object_define(heap, &function->object, key, vm_value_int32((int32_t)length), VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

	/* Allocates the name before protecting it across subsequent key and shape allocations. */
	text = vm_string_from_utf8(heap, name, strlen(name));
	if (text == NULL) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Keeps the private name alive until its completed property owns it. */
	roots[2] = &text->cell;
	key = vm_key_from_ascii(heap, "name");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Publishes the name only after its key is available. */
	error = vm_object_define(heap, &function->object, key, vm_value_cell(text), VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

cleanup:
	/* Releases only registrations acquired by this invocation on every outcome. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(heap, &roots[registered]);
	}

	/* Failed construction publishes no partially initialized result. */
	if (error != 0)
		return NULL;

	/* Succeeded: the complete native function owns its realm and name. */
	return function;
}

struct vm_function *
vm_function_create(
	struct vm_realm *realm,
	struct vm_code *code)
{
	struct vm_heap *heap;
	struct vm_function *function;
	struct vm_cell *roots[3];
	vm_value key;
	vm_value name;
	uint32_t length;
	unsigned index;
	unsigned registered;
	int error;

	/* Retains the input code, collectible realm and unpublished function for the whole factory. */
	heap = realm->heap;
	function = NULL;
	roots[0] = &code->cell;
	roots[1] = NULL;
	roots[2] = NULL;

	/* A collectible input realm cannot rely on an unpublished function's future edge. */
	if (realm->managed)
		roots[1] = &realm->cell;

	/* Only completed registry insertions belong to the factory's cleanup path. */
	registered = 0;
	for (index = 0; index < 3U; index++) {
		error = vm_heap_add_root(heap, &roots[index]);
		if (error != 0)
			goto cleanup;

		/* Cleanup owns this slot only after the heap registry has acquired it. */
		registered++;
	}

	/* Allocates a function without borrowing conservative caller retention. */
	function = vm_heap_alloc(heap, &vm_function_type, sizeof(*function));
	if (function == NULL) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Protects the partially initialized cell before any shape allocation. */
	roots[2] = &function->object.cell;
	error = vm_object_init(heap, &function->object, realm->function_prototype);
	if (error != 0)
		goto cleanup;

	/* Retains only collectible realms without consulting retired manual owners. */
	function->realm = realm;

	/* The completed function supplies the durable edge only for collectible realms. */
	if (realm->managed)
		function->realm_owner = &realm->cell;

	/* Initializes the bytecode entry point and its ordinary function state. */
	function->code = code;
	function->object.kind = VM_KIND_FUNCTION;
	function->data = VM_VALUE_UNDEFINED;
	function->source = VM_VALUE_UNDEFINED;

	/* Uses the parameter count before a default or rest parameter when the code records it. */
	length = code->parameter_count;

	/* Explicit length metadata excludes parameters after the first default or rest. */
	if ((code->flags & VM_CODE_LENGTH) != 0U)
		length = code->length;
	key = vm_key_from_ascii(heap, "length");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Defines the ordinary configurable length after acquiring its heap-owned key. */
	error = vm_object_define(heap, &function->object, key, vm_value_int32((int32_t)length), VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

	/* Uses the code-owned name, creating an empty string only when necessary. */
	name = VM_VALUE_EMPTY;
	if (code->name != NULL)
		name = vm_value_cell(code->name);
	if (name == VM_VALUE_EMPTY) {
		code->name = vm_string_from_utf8(heap, "", 0);
		if (code->name == NULL) {
			error = ENOMEM;
			goto cleanup;
		}

		/* The already rooted code now owns the generated name. */
		name = vm_value_cell(code->name);
	}

	/* Acquires the property key before publishing the protected name. */
	key = vm_key_from_ascii(heap, "name");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Completes the bytecode function's name property. */
	error = vm_object_define(heap, &function->object, key, name, VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

cleanup:
	/* No input or partially initialized function remains pinned after return. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(heap, &roots[registered]);
	}

	/* Failed construction publishes no partially initialized result. */
	if (error != 0)
		return NULL;

	/* Succeeded: the function owns its checked code unit and name. */
	return function;
}

static void
function_transfer_exception(
	struct vm_realm *caller,
	struct vm_realm *callee,
	int status)
{
	/* Ordinary failures carry no JavaScript exception. */
	if (status != VM_THROWN)
		return;

	/* A same-realm call already published its exception in the right place. */
	if (caller == callee)
		return;

	/* Transfers the actual object rather than constructing a caller-realm copy. */
	caller->exception = callee->exception;
	caller->throw_value = callee->throw_value;
	caller->throw_source = callee->throw_source;
	caller->throw_line = callee->throw_line;
	caller->throw_column = callee->throw_column;
	memcpy(caller->throw_stack, callee->throw_stack, sizeof(caller->throw_stack));

	/* The caller now owns the pending throw; the callee no longer retains it. */
	callee->exception = VM_VALUE_UNDEFINED;
	callee->throw_value = VM_VALUE_UNDEFINED;
	callee->throw_source = VM_VALUE_UNDEFINED;
	callee->throw_line = 0;
	callee->throw_column = 0;
	callee->throw_stack[0] = '\0';

	/* Succeeded: the foreign exception is pending only in its caller. */
	return;
}

static void
function_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct vm_function *function;

	/* The object's shape, prototype, slots and elements. */
	vm_object_trace(heap, cell);

	/* The code unit it runs, the environment it runs in, and its data. */
	function = (struct vm_function *)cell;
	vm_heap_mark(heap, function->realm_owner);
	if (function->code != NULL)
		vm_heap_mark(heap, (struct vm_cell *)function->code);
	if (function->env != NULL)
		vm_heap_mark(heap, &function->env->cell);
	vm_heap_mark_value(heap, function->data);

	/* The embedding owns source interpretation; functions only retain its managed value. */
	vm_heap_mark_value(heap, function->source);

	/* Succeeded: the function's owned graph was marked. */
	return;
}

static int
realm_create(
	struct vm_heap *heap,
	int managed,
	struct vm_realm **realm)
{
	struct vm_realm *made;
	int error;

	/* Managed pointers must already denote cells during intrinsic creation. */
	*realm = NULL;
	if (managed) {
		made = vm_heap_alloc(heap, &realm_type, sizeof(*made));
	} else {
		made = calloc(1, sizeof(*made));
	}

	/* No state has been published if the realm record could not be made. */
	if (made == NULL)
		return ENOMEM;

	/* Initializes state that both partial and final cleanup can release. */
	made->heap = heap;
	made->managed = managed;
	made->exception = VM_VALUE_UNDEFINED;
	made->throw_value = VM_VALUE_UNDEFINED;
	made->throw_source = VM_VALUE_UNDEFINED;
	made->callee = VM_VALUE_UNDEFINED;
	made->new_target = VM_VALUE_UNDEFINED;
	wb_vector_init(&made->jobs, sizeof(struct vm_job));
	wb_vector_init(&made->rejections, sizeof(vm_value));

	/* Reserves the non-moving stack before any execution or tracing. */
	made->stack = calloc(REALM_STACK_SLOTS, sizeof(vm_value));
	if (made->stack == NULL) {
		if (!managed)
			free(made);
		return ENOMEM;
	}

	/* A manual realm needs a root; a managed realm is reached as a cell. */
	made->stack_capacity = REALM_STACK_SLOTS;
	if (!managed) {
		error = vm_heap_add_tracer(heap, realm_trace, made);
		if (error != 0) {
			realm_release(made);
			free(made);
			return error;
		}
	}

	/* Creates the existing globals and intrinsic skeleton in this realm. */
	error = realm_fill(made);
	if (error != 0) {
		if (managed) {
			realm_release(made);
		} else {
			vm_realm_destroy(made);
		}

		/* No partially initialized realm is published to the caller. */
		return error;
	}

	/* Saved globals and bare prototype objects retain their child's lifetime. */
	if (managed) {
		made->global->internal = vm_value_cell(made);
		made->object_prototype->internal = vm_value_cell(made);
	}

	/* Succeeded: the caller receives a fully initialized realm. */
	*realm = made;
	return 0;
}

static void
realm_trace(
	struct vm_heap *heap,
	void *context)
{
	struct vm_realm *realm;
	struct vm_job *job;
	uint32_t slot;
	uint32_t index;

	/* The intrinsic objects, where made. */
	realm = context;
	if (realm->object_prototype != NULL)
		vm_heap_mark(heap, &realm->object_prototype->cell);
	if (realm->function_prototype != NULL)
		vm_heap_mark(heap, &realm->function_prototype->cell);
	if (realm->array_prototype != NULL)
		vm_heap_mark(heap, &realm->array_prototype->cell);

	/* The other intrinsic objects the built-ins made. */
	for (index = 0; index < VM_INTRINSICS; index++) {
		if (realm->intrinsics[index] != NULL)
			vm_heap_mark(heap, &realm->intrinsics[index]->cell);
	}

	/* The well-known symbols. */
	for (index = 0; index < VM_SYMBOLS; index++) {
		if (realm->symbols[index] != NULL)
			vm_heap_mark(heap, &realm->symbols[index]->cell);
	}

	/* The global object, the exception being thrown, and the native call's callee and new.target. */
	if (realm->global != NULL)
		vm_heap_mark(heap, &realm->global->cell);
	vm_heap_mark_value(heap, realm->exception);
	vm_heap_mark_value(heap, realm->throw_value);
	vm_heap_mark_value(heap, realm->throw_source);
	if (realm->lexicals != NULL)
		vm_heap_mark(heap, &realm->lexicals->cell);
	vm_heap_mark_value(heap, realm->callee);
	vm_heap_mark_value(heap, realm->new_target);

	/* The microtasks waiting for a checkpoint. */
	for (index = 0; index < realm->jobs.count; index++) {
		job = wb_vector_at(&realm->jobs, index);
		vm_heap_mark_value(heap, job->callback);
		vm_heap_mark_value(heap, job->argument);
	}

	/* The promises rejected while unhandled, waiting for the checkpoint's report. */
	vm_promise_trace_rejections(heap, realm);

	/* Every word of the used stack that could point at a cell (boxed and raw values share it). */
	for (slot = 0; slot < realm->stack_top; slot++)
		vm_heap_mark_word(heap, (uintptr_t)realm->stack[slot]);

	/* Succeeded: all currently retained realm values were traced. */
	return;
}

static int
interpreter_unwind(
	struct interpreter *run)
{
	struct vm_realm *realm;
	struct vm_function *function;
	const struct vm_handler *handler;
	uint32_t throw_pc;
	uint32_t caller;
	uint32_t index;

	/* From the instruction that threw, frame by frame. */
	realm = run->realm;
	throw_pc = run->pc;

	/*
	 * A new exception's place is the instruction that threw it; an
	 * exception coming back out of a nested run keeps the place the inner
	 * run found.
	 */
	if (realm->throw_line == 0 || realm->throw_value != realm->exception) {
		realm->throw_value = realm->exception;
		realm->throw_line = 0;
		realm->throw_column = 0;

		/* Preserve defining-source metadata before any bytecode frame is removed. */
		function = interpreter_function(realm, run->base);
		realm->throw_source = function->source;
		vm_code_position(run->code, throw_pc, &realm->throw_line, &realm->throw_column);
		interpreter_note_stack(run);
	}

	/* Looks for a handler in each frame outwards. */
	for (;;) {
		/* A handler of this frame whose range holds the instruction. */
		for (index = 0; index < run->code->handler_count; index++) {
			handler = &run->code->handlers[index];
			if (throw_pc < handler->start || throw_pc >= handler->end)
				continue;

			/* It takes the exception, and the frame goes on there. */
			realm->stack[run->base + FRAME_HEADER + handler->exception_register] = realm->exception;
			realm->exception = VM_VALUE_UNDEFINED;
			run->pc = handler->handler;

			/* A caught exception's place is forgotten, so throwing it again records the new place. */
			realm->throw_value = VM_VALUE_UNDEFINED;
			realm->throw_source = VM_VALUE_UNDEFINED;
			realm->throw_line = 0;
			return 0;
		}

		/* Without one, the frame is popped; the entry frame's end leaves the run. */
		caller = (uint32_t)realm->stack[run->base + FRAME_CALLER];
		throw_pc = (uint32_t)realm->stack[run->base + FRAME_RETURN] - INTERPRETER_CALL_WORDS;
		realm->stack_top = run->base;
		if (caller == 0U)
			return VM_THROWN;

		/* The caller's call instruction is where the search goes on. */
		run->base = caller - 1U;
		function = interpreter_function(realm, run->base);
		run->code = function->code;
	}
}
