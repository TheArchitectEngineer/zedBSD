from pathlib import Path
import json,gzip,collections
q=Path('build/ws074-20261018/q28');root=q/'final/after-harness';oldroot=Path('build/ws074-20261018/q27/final/after-harness');old={};new={}
for r in json.loads((oldroot/'results.json').read_text()):old[r['id']]=json.loads(gzip.decompress((oldroot/r['report']).read_bytes()))
for p in root.glob('shard-*/report.json'):
 for r in json.loads(p.read_text())['results']:new[r['test_id']]=json.loads(gzip.decompress((p.parent/r['report']).read_bytes()))
changes=[]
for key,b in new.items():
 a=old[key]
 if a['outcome']!=b['outcome'] or a['result_callbacks']!=b['result_callbacks'] or a['completion']!=b['completion']:
  changes.append(dict(id=key,old_outcome=a['outcome'],new_outcome=b['outcome'],old_callbacks=dict(collections.Counter(str(c['status']) for c in a['result_callbacks'])),new_callbacks=dict(collections.Counter(str(c['status']) for c in b['result_callbacks'])),old_completion=a['completion'],new_completion=b['completion'],new_stdout_tail=b['stdout'][-2500:]))
proof=dict(completed=len(new),counts=dict(collections.Counter(r['outcome'] for r in new.values())),whole_pass_losses=[k for k,b in new.items() if old[k]['outcome']=='pass' and b['outcome']!='pass'],whole_pass_gains=[k for k,b in new.items() if old[k]['outcome']!='pass' and b['outcome']=='pass'],changes=changes)
(q/'harness-outcome-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print('completed',len(new),'changes',len(changes),'losses',proof['whole_pass_losses'],'gains',proof['whole_pass_gains']);print([(c['id'],c['old_outcome'],c['new_outcome']) for c in changes])
