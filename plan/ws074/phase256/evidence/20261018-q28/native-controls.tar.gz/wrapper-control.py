from pathlib import Path
import os,importlib.util,json,subprocess,re,time
q=Path('build/ws074-20261018/q28');os.environ['WPT_GENERATED_CONTROL_ROOT']=str(q/'wrapper-controls');spec=importlib.util.spec_from_file_location('q28_wrapper_control','plan/ws074/tests/test-interop2025-generated.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);prior=json.loads((q/'observer-positive-native.json').read_text());script=Path(prior['generated']['raw_directory'],'source.js').read_bytes();root,row,server,context,tool,worker=m.fixture('observer-wrapper-chrome','any',script);command=['chromium','--headless','--no-sandbox','--disable-gpu','--enable-logging=stderr','--log-level=0','--user-data-dir=/tmp/ws074-q28-wrapper-'+str(time.time_ns()),'--virtual-time-budget=5000','--dump-dom','http://127.0.0.1:%d%s'%(server.server_port,row['id'])]
try:run=subprocess.run(command,capture_output=True,timeout=30)
finally:m.stop(server,worker)
(q/'observer-wrapper-chrome.html').write_bytes(run.stdout);(q/'observer-wrapper-chrome.log').write_bytes(run.stderr);messages=[]
for line in run.stderr.decode('utf8',errors='replace').splitlines():
 match=re.search(r':CONSOLE(?:\(\d+\)|:\d+)\] "(.*)", source: ',line)
 if match:messages.append(match[1])
r=m.RUNNER.classify_output('\n'.join(messages)+'\n',run.returncode);(q/'observer-wrapper-chrome.json').write_text(json.dumps(r,indent=2)+'\n');assert r['outcome']==prior['outcome']=='fail';print('original step_func receiver assertion fails identically in native and Chrome')
