from pathlib import Path
import re,subprocess,shlex,json,hashlib,shutil
q=Path('build/ws074-20261018/q28');p=Path('userland/desktop/libbrowser/bind/environment.c');before=p.read_text();(q/'environment-pre-prototype-order.c').write_text(before)
start=before.index('static void environment_performance_observer_trace(');stop=before.index("/*\n * The screen's sizes");block=before[start:stop];decls=re.findall(r'^static [^\n]+;\n',block,re.M);assert len(decls)>30
pos=before.index('/*\n * Marks observer state retained by a window');tables=before[stop:pos];needed=[];other=[]
for d in decls:
 name=re.search(r'\b(\w+)\(',d)[1]
 if re.search(r'\b'+name+r'\b',tables):needed.append(d)
 else:other.append(d)
assert len(needed)+len(other)==len(decls)
after=before[:start]+''.join(needed)+'\n'+before[stop:pos]+'/* Helpers not referenced by constant initializers follow the file-scope tables. */\n'+''.join(other)+'\n'+before[pos:]
def remaining(s):
 s=re.sub(r'^static [^\n]+;\n','',s,flags=re.M);s=re.sub(r'/\*.*?\*/','',s,flags=re.S);return ''.join(s.split())
assert remaining(before)==remaining(after)
assert sorted(re.findall(r'^static [^\n]+;\n',before,re.M))==sorted(re.findall(r'^static [^\n]+;\n',after,re.M))
p.write_text(after)
args=shlex.split(Path('build/ws074-20261018/plain/flags').read_text())+['-c',str(p),'-o',str(q/'environment-prototype-order-host.o')];r=subprocess.run(args,capture_output=True);(q/'prototype-host-compile.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0 and not r.stderr
for label,src in [('frozen',Path('build/ws074-20261018/plain/obj/libbrowser_bind_environment.o')),('ordered',q/'environment-prototype-order-host.o')]:subprocess.run(['objcopy','--strip-debug',str(src),str(q/('environment-'+label+'-prototypes-runtime.o'))],check=True)
assert (q/'environment-frozen-prototypes-runtime.o').read_bytes()==(q/'environment-ordered-prototypes-runtime.o').read_bytes()
proof=dict(source_before_sha256=hashlib.sha256(before.encode()).hexdigest(),source_after_sha256=hashlib.sha256(after.encode()).hexdigest(),initializers_required_forward_declarations=len(needed),other_helpers_after_tables=len(other),declaration_multiset_unchanged=True,remaining_tokens_unchanged=True,host_runtime_object_identical=True,command=args)
(q/'prototype-order-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
