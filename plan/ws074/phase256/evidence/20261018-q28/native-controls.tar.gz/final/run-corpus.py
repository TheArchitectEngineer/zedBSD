from pathlib import Path
import subprocess,os,json,time
q=Path('build/ws074-20261018/q28');v=q/'final';engine=(v/'engine').resolve();runs=[];start=time.monotonic();manifest='plan/ws074/phase173/evidence/20261013-q1012/manifest.json'
controls=json.loads((q/'final-oracle-proof.json').read_text());assert len(controls)==4 and all(r['native']==r['expected']==r['chrome'] for r in controls)
commands=[('harness',['python3',str(v/'census.py'),'after',str(engine/'browser')]),('static',['python3','plan/ws074/tests/run-wpt-reftests.py','--program',str(engine/'browser'),'--root','.','--selection-manifest',manifest,'--limit','0','--render-timeout','20','--save-failures','2','--out',str(v/'after-static')]),('scripted',['python3','plan/ws074/tests/run-interop2025-scripted-reftests.py','--manifest',manifest,'--program',str(engine/'wpt-ready-render'),'--out',str(v/'scripted-413'),'--budget-seconds','1800']),('crash',['python3','plan/ws074/tests/run-interop2025-crashtests.py','--manifest',manifest,'--program',str(engine/'browser'),'--focus','all','--settle-ms','5000','--process-timeout','20','--out',str(v/'crash-report.json')])]
for label,command in commands:
 with (v/(label+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=log,env=dict(os.environ,XDG_DATA_HOME=str((v/(label+'-data')).resolve())),timeout=2400)
 row=dict(label=label,returncode=r.returncode,seconds=round(time.monotonic()-start,1),command=command);runs.append(row);(v/'corpus-runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(row,flush=True);assert r.returncode==0,label
