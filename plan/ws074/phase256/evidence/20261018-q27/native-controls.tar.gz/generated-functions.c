int bind_event_create(struct bind_window *window, int interface, struct vm_string *type, vm_value *value, struct bind_event **event);
static void event_trace(struct vm_heap *heap, struct vm_cell *cell);
static int event_construct_error(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int event_error_scalar(struct vm_realm *realm, vm_value given, struct vm_string **text);
static int event_error_this(struct vm_realm *realm, vm_value receiver, struct bind_event **event);
static int event_error_message(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int event_error_filename(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int event_error_line(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int event_error_column(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int event_error_value(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int event_is_window_error(struct bind_window *window, vm_value current, const struct bind_event *event, int handler);
static int event_invoke(struct bind_window *window, vm_value current, vm_value event_value, int phase, unsigned kinds);
static int event_call_listener(struct bind_window *window, vm_value callback, vm_value current, vm_value event_value, int legacy_error, vm_value *returned);
static int window_error_event_tag(struct vm_realm *realm, struct vm_object *prototype);
static int window_make_interface(struct bind_window *window, int index, struct vm_function **constructors);

int
bind_event_create(
	struct bind_window *window,
	int interface,
	struct vm_string *type,
	vm_value *value,
	struct bind_event **event)
{
	struct bind_event *state;
	struct vm_object *object;
	struct vm_cell *state_root;
	int status;

	/* The state, zeroed: no flags, no phase. */
	state = vm_heap_alloc(window->realm->heap, &event_type_cell, sizeof(*state));
	if (state == NULL)
		return ENOMEM;
	state->type = type;
	state->target = VM_VALUE_NULL;
	state->current_target = VM_VALUE_NULL;
	state->detail = VM_VALUE_NULL;

	/* A missing ErrorEventInit.error is undefined, including factory-created state. */
	if (interface == BIND_ERROR_EVENT)
		state->detail = VM_VALUE_UNDEFINED;

	/* Initialize the remaining native references before publishing the wrapper. */
	state->view = VM_VALUE_NULL;
	state->submitter = VM_VALUE_NULL;
	state->interface = interface;
	state->initialized = 1;

	/* UI-derived events start with numerical detail while custom payloads keep null. */
	if (interface == BIND_UI_EVENT ||
	    interface == BIND_MOUSE_EVENT ||
	    interface == BIND_KEYBOARD_EVENT ||
	    interface == BIND_FOCUS_EVENT ||
	    interface == BIND_WHEEL_EVENT)
		state->detail = vm_value_int32(0);

	/* Other message and dispatch references begin empty. */
	state->source = VM_VALUE_NULL;
	state->ports = VM_VALUE_NULL;
	state->time_stamp = window->now;

	/* The object with the interface's prototype. */
	state_root = &state->cell;
	status = vm_heap_add_root(window->realm->heap, &state_root);
	if (status != 0)
		return status;
	object = vm_object_create(window->realm->heap, window->prototypes[interface]);
	if (object == NULL) {
		vm_heap_remove_root(window->realm->heap, &state_root);
		return ENOMEM;
	}

	/* The wrapper now owns the event state through its internal slot. */
	object->kind = VM_KIND_PLATFORM;
	object->internal = vm_value_cell(state);
	vm_heap_remove_root(window->realm->heap, &state_root);

	/* Succeeded: the event is made. */
	*value = vm_value_cell(object);
	*event = state;
	return 0;
}

static void
event_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct bind_event *event;

	/* The type, the targets and the values carried by an event. */
	event = (struct bind_event *)cell;
	if (event->type != NULL)
		vm_heap_mark(heap, &event->type->cell);
	vm_heap_mark_value(heap, event->target);
	vm_heap_mark_value(heap, event->current_target);
	vm_heap_mark_value(heap, event->detail);
	vm_heap_mark_value(heap, event->view);
	vm_heap_mark_value(heap, event->submitter);
	vm_heap_mark_value(heap, event->source);
	vm_heap_mark_value(heap, event->ports);
	vm_heap_mark_value(heap, event->target_override);
	if (event->origin != NULL)
		vm_heap_mark(heap, &event->origin->cell);
	if (event->last_event_id != NULL)
		vm_heap_mark(heap, &event->last_event_id->cell);

	/* ErrorEvent strings remain reachable through every retained event wrapper. */
	if (event->error_message != NULL)
		vm_heap_mark(heap, &event->error_message->cell);

	/* Filename is independently converted to Unicode scalar text. */
	if (event->error_filename != NULL)
		vm_heap_mark(heap, &event->error_filename->cell);

	/* A key event's key and code. */
	if (event->key != NULL)
		vm_heap_mark(heap, &event->key->cell);
	if (event->code != NULL)
		vm_heap_mark(heap, &event->code->cell);
}

static int
event_construct_error(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct bind_event *event;
	struct vm_string *type;
	struct vm_cell *event_root;
	struct vm_object *wrapper;
	struct vm_object *prototype;
	vm_value init;
	vm_value member;
	int object;
	int present;
	int status;

	UNUSED_PARAMETER(this_value);

	/* A required type is converted before the optional dictionary is examined. */
	if (count < 1U) {
		status = vm_throw_type_error(realm, "ErrorEvent requires an event type.");
		return status;
	}

	/* Intern the converted type before allocating its traced native state. */
	status = bind_to_atom(realm, args[0], 0, &type);
	if (status != 0)
		return status;

	/* WebIDL dictionaries accept null and undefined, but reject other primitives. */
	init = js_argument(args, count, 1);
	object = vm_value_is_object(init);
	if (!object &&
	    init != VM_VALUE_NULL &&
	    init != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "ErrorEventInit must be a dictionary.");
		return status;
	}

	/* Retain the wrapper and its entire partially converted state through reentrant getters. */
	status = bind_event_create(bind_window_of(realm), BIND_ERROR_EVENT, type, result, &event);
	if (status != 0)
		return status;
	event_root = vm_value_as_cell(*result);
	status = vm_heap_add_root(realm->heap, &event_root);
	if (status != 0)
		return status;

	/* Convert inherited EventInit members in lexical order before derived members. */
	status = bind_get_option(realm, init, "bubbles", &present, &member);
	if (status != 0)
		goto cleanup;
	event->bubbles = vm_to_boolean(member);
	status = bind_get_option(realm, init, "cancelable", &present, &member);
	if (status != 0)
		goto cleanup;
	event->cancelable = vm_to_boolean(member);
	status = bind_get_option(realm, init, "composed", &present, &member);
	if (status != 0)
		goto cleanup;
	event->composed = vm_to_boolean(member);

	/* Derived members follow colno, error, filename, lineno, message. */
	status = bind_get_option(realm, init, "colno", &present, &member);
	if (status != 0)
		goto cleanup;

	/* Convert an explicitly supplied column number. */
	if (present) {
		status = vm_to_uint32(realm, member, &event->error_column);
		if (status != 0)
			goto cleanup;
	}

	/* Store the exact arbitrary error value before any later getter can collect. */
	status = bind_get_option(realm, init, "error", &present, &member);
	if (status != 0)
		goto cleanup;
	event->detail = member;

	/* Filename is a USVString rather than an unmodified DOMString. */
	status = bind_get_option(realm, init, "filename", &present, &member);
	if (status != 0)
		goto cleanup;

	/* Convert an explicitly supplied source filename. */
	if (present) {
		status = event_error_scalar(realm, member, &event->error_filename);
		if (status != 0)
			goto cleanup;
	}

	/* Line numbers use ordinary WebIDL unsigned-long modulo conversion. */
	status = bind_get_option(realm, init, "lineno", &present, &member);
	if (status != 0)
		goto cleanup;

	/* Convert an explicitly supplied line number. */
	if (present) {
		status = vm_to_uint32(realm, member, &event->error_line);
		if (status != 0)
			goto cleanup;
	}

	/* Message preserves DOMString code units, including unmatched surrogates. */
	status = bind_get_option(realm, init, "message", &present, &member);
	if (status != 0)
		goto cleanup;

	/* Convert an explicitly supplied message. */
	if (present) {
		status = bind_to_string(realm, member, &event->error_message);
		if (status != 0)
			goto cleanup;
	}

	/* Only after argument conversion does subclass construction consult new.target.prototype. */
	wrapper = (struct vm_object *)vm_value_as_cell(*result);
	status = vm_construct_prototype(realm, realm->new_target, wrapper->prototype, &prototype);
	if (status != 0)
		goto cleanup;
	wrapper->prototype = prototype;

cleanup:
	/* The returned wrapper owns its state; failure releases the same temporary root. */
	vm_heap_remove_root(realm->heap, &event_root);
	if (status != 0)
		return status;

	/* Succeeded: the native immutable payload is ready for normal EventTarget dispatch. */
	return 0;
}

static int
event_error_scalar(
	struct vm_realm *realm,
	vm_value given,
	struct vm_string **text)
{
	struct vm_string *converted;
	struct wb_buffer bytes;
	int status;

	/* Complete script conversion before extracting stable scalar bytes. */
	status = bind_to_string(realm, given, &converted);
	if (status != 0)
		return status;
	wb_buffer_init(&bytes);
	status = vm_string_to_utf8(converted, &bytes);
	if (status != 0) {
		wb_buffer_release(&bytes);
		return status;
	}

	/* The native state takes ownership before any later script getter runs. */
	*text = vm_string_from_utf8(realm->heap, wb_buffer_string(&bytes), bytes.length);
	wb_buffer_release(&bytes);
	if (*text == NULL)
		return ENOMEM;

	/* Succeeded: valid surrogate pairs survive and lone surrogates become U+FFFD. */
	return 0;
}

static int
event_error_this(
	struct vm_realm *realm,
	vm_value receiver,
	struct bind_event **event)
{
	int status;

	/* Event identity is recovered only from the platform wrapper's native cell. */
	*event = bind_event_of(receiver);
	if (*event == NULL) {
		status = bind_throw_illegal(realm);
		return status;
	}

	/* Other genuine Event subclasses cannot borrow ErrorEvent getters. */
	if ((*event)->interface != BIND_ERROR_EVENT) {
		status = bind_throw_illegal(realm);
		return status;
	}

	/* Succeeded: the payload belongs to this interface. */
	return 0;
}

static int
event_error_message(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct bind_event *event;
	struct vm_string *text;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Reject forged receivers before reading any native payload. */
	status = event_error_this(realm, this_value, &event);
	if (status != 0)
		return status;

	/* An omitted string member has the empty-string default. */
	text = event->error_message;
	if (text == NULL) {
		text = vm_atom_from_ascii(realm->heap, "");
		if (text == NULL)
			return ENOMEM;
	}

	/* Succeeded: the event retains the published string. */
	*result = vm_value_cell(text);
	return 0;
}

static int
event_error_filename(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct bind_event *event;
	struct vm_string *text;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Reject forged receivers before reading any native payload. */
	status = event_error_this(realm, this_value, &event);
	if (status != 0)
		return status;

	/* An omitted string member has the empty-string default. */
	text = event->error_filename;
	if (text == NULL) {
		text = vm_atom_from_ascii(realm->heap, "");
		if (text == NULL)
			return ENOMEM;
	}

	/* Succeeded: the event retains the published string. */
	*result = vm_value_cell(text);
	return 0;
}

static int
event_error_line(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct bind_event *event;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Reject forged receivers before reading any native payload. */
	status = event_error_this(realm, this_value, &event);
	if (status != 0)
		return status;

	/* Succeeded: the full unsigned range is represented exactly as a Number. */
	*result = vm_value_number((double)event->error_line);
	return 0;
}

static int
event_error_column(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct bind_event *event;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Reject forged receivers before reading any native payload. */
	status = event_error_this(realm, this_value, &event);
	if (status != 0)
		return status;

	/* Succeeded: the full unsigned range is represented exactly as a Number. */
	*result = vm_value_number((double)event->error_column);
	return 0;
}

static int
event_error_value(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct bind_event *event;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Reject forged receivers before reading any native payload. */
	status = event_error_this(realm, this_value, &event);
	if (status != 0)
		return status;

	/* Succeeded: arbitrary values preserve their original identity. */
	*result = event->detail;
	return 0;
}

static int
event_is_window_error(
	struct bind_window *window,
	vm_value current,
	const struct bind_event *event,
	int handler)
{
	vm_value global;
	int error_type;

	/* Ordinary listeners, element handlers and other event interfaces keep normal semantics. */
	global = vm_value_cell(window->realm->global);
	if (!handler ||
	    current != global ||
	    event->interface != BIND_ERROR_EVENT)
		return 0;

	/* Only the exact error event type invokes Window.onerror's legacy signature. */
	error_type = vm_string_equal_ascii(event->type, "error");
	if (!error_type)
		return 0;

	/* Succeeded: dispatch supplies five arguments and true cancellation. */
	return 1;
}

static int
event_invoke(
	struct bind_window *window,
	vm_value current,
	vm_value event_value,
	int phase,
	unsigned kinds)
{
	struct bind_event *event;
	struct bind_listeners *listeners;
	struct bind_listener *listener;
	struct vm_object *snapshot;
	struct vm_cell *snapshot_root;
	vm_value callback;
	vm_value returned;
	size_t index;
	size_t found;
	uint32_t item;
	int capture;
	int handler;
	int legacy_error;
	int present;
	int status;

	/* A stopped event reaches no further target. */
	event = bind_event_of(event_value);
	if (event->stop)
		return 0;
	event->current_target = current;
	event->phase = phase;

	/* A handler attribute (onclick="...") becomes the target's handler before the listeners run. */
	if ((kinds & EVENT_INVOKE_BUBBLE) != 0) {
		status = bind_handler_prepare(window, current, event->type);
		if (status != 0)
			return status;
	}

	/* The listeners of the event's type and the phase's kind as they are now (ones added while they run wait). */
	status = bind_listeners_of(window, current, 0, &listeners);
	if (status == EINVAL || listeners == NULL)
		return 0;
	if (status != 0)
		return status;
	status = bind_array_create(window->realm, &snapshot);
	if (status != 0)
		return status;
	snapshot_root = &snapshot->cell;
	status = vm_heap_add_root(window->realm->heap, &snapshot_root);
	if (status != 0)
		return status;
	for (index = 0; status == 0 && index < listeners->count; index++) {
		listener = &listeners->items[index];
		if (listener->type != event->type)
			continue;
		if (listener->capture && (kinds & EVENT_INVOKE_CAPTURE) == 0)
			continue;
		if (!listener->capture && (kinds & EVENT_INVOKE_BUBBLE) == 0)
			continue;
		if (listener->callback == VM_VALUE_NULL)
			continue;

		/* Each is kept as its callback and whether it is a handler. */
		status = vm_object_define(window->realm->heap, snapshot, vm_value_int32((int32_t)snapshot->length), listener->callback, VM_PROPERTY_DEFAULT);
		if (status == 0)
			status = vm_object_define(window->realm->heap, snapshot, vm_value_int32((int32_t)snapshot->length), vm_value_boolean(listener->handler), VM_PROPERTY_DEFAULT);
	}

	/* The copy may have run out of memory. */
	if (status != 0)
		goto cleanup;

	/* Each one that is still there, in order, until a listener stops the event at once. */
	capture = 0;
	if ((kinds & EVENT_INVOKE_CAPTURE) != 0)
		capture = 1;
	for (item = 0; item + 1U < snapshot->length && !event->stop_immediate; item += 2U) {
		callback = snapshot->elements[item];
		handler = 0;
		if (snapshot->elements[item + 1U] == VM_VALUE_TRUE)
			handler = 1;

		/* A listener removed by an earlier one does not run; a once listener is removed before it runs. */
		status = bind_listeners_of(window, current, 0, &listeners);
		if (status != 0)
			goto cleanup;
		present = bind_listeners_find(listeners, event->type, callback, capture, handler, &found);
		if (!present)
			continue;
		if (listeners->items[found].once)
			event_forget_listener(listeners, found);

		/* Window's ErrorEvent handler uses its legacy five arguments and true cancellation. */
		legacy_error = event_is_window_error(window, current, event, handler);
		status = event_call_listener(window, callback, current, event_value, legacy_error, &returned);
		if (status != 0)
			goto cleanup;

		/* Ordinary handlers retain false cancellation; addEventListener return values never cancel. */
		if (handler && event->cancelable) {
			/* Select the legacy inversion only for this actual Window ErrorEvent handler. */
			if (legacy_error) {
				/* Only the Boolean true suppresses the legacy default report. */
				if (returned == VM_VALUE_TRUE)
					event->canceled = 1;
			} else if (returned == VM_VALUE_FALSE) {
				event->canceled = 1;
			}
		}
	}

	/* The detached callback snapshot no longer spans user code. */
cleanup:
	vm_heap_remove_root(window->realm->heap, &snapshot_root);
	if (status != 0)
		return status;

	/* Succeeded: the target's listeners have run. */
	return 0;
}

static int
event_call_listener(
	struct bind_window *window,
	vm_value callback,
	vm_value current,
	vm_value event_value,
	int legacy_error,
	vm_value *returned)
{
	struct vm_realm *realm;
	vm_value method;
	vm_value key;
	vm_value this_value;
	vm_value arguments[5];
	struct bind_event *event;
	struct vm_string *empty;
	unsigned argument_count;
	int callable;
	int status;

	/* A function is called with the current target as this. */
	*returned = VM_VALUE_UNDEFINED;
	realm = window->realm;
	method = callback;
	this_value = current;
	callable = vm_value_is_callable(callback);

	/* An object's handleEvent is called with the object as this. */
	status = 0;
	if (!callable) {
		key = vm_key_from_ascii(realm->heap, "handleEvent");
		if (key == VM_VALUE_EMPTY)
			return ENOMEM;
		status = vm_get(realm, callback, key, &method);
		this_value = callback;
		if (status == 0) {
			callable = vm_value_is_callable(method);
			if (!callable)
				status = vm_throw_type_error(realm, "The listener's handleEvent is not a function.");
		}
	}

	/* A normal listener receives the event; only a Window error handler receives payload values. */
	arguments[0] = event_value;
	argument_count = 1;
	if (status == 0 && legacy_error) {
		event = bind_event_of(event_value);
		empty = vm_atom_from_ascii(realm->heap, "");
		if (empty == NULL)
			return ENOMEM;
		arguments[0] = vm_value_cell(empty);
		arguments[1] = vm_value_cell(empty);

		/* Native payloads override the empty defaults without consulting event expandos. */
		if (event->error_message != NULL)
			arguments[0] = vm_value_cell(event->error_message);

		/* The source string is separately retained by the event. */
		if (event->error_filename != NULL)
			arguments[1] = vm_value_cell(event->error_filename);

		/* Numeric positions and the arbitrary error retain their native payload values. */
		arguments[2] = vm_value_number((double)event->error_line);
		arguments[3] = vm_value_number((double)event->error_column);
		arguments[4] = event->detail;
		argument_count = 5;
	}

	/* Call with the exact native argument list after all defaults are ready. */
	if (status == 0)
		status = vm_call(realm, method, this_value, arguments, argument_count, returned);

	/* An exception is reported, and the dispatch goes on. */
	if (status == VM_THROWN) {
		bind_report_exception(window, realm->exception);
		realm->exception = VM_VALUE_UNDEFINED;
		status = 0;
	}

	/* Running out of memory stops the dispatch. */
	if (status != 0)
		return status;

	/* The microtasks run after each listener when no script is running. */
	if (realm->depth == 0) {
		status = bind_checkpoint(window);
		if (status != 0)
			return status;
	}

	/* Succeeded: the listener has run. */
	return 0;
}

static int
window_error_event_tag(
	struct vm_realm *realm,
	struct vm_object *prototype)
{
	struct vm_cell *root;
	vm_value label;
	vm_value key;
	int status;

	/* Register an empty root before creating the tag text. */
	root = NULL;
	status = vm_heap_add_root(realm->heap, &root);
	if (status != 0)
		return status;

	/* The native interface label is descriptive and supplies no receiver branding. */
	status = bind_string(realm, "ErrorEvent", &label);
	if (status == 0) {
		root = vm_value_as_cell(label);
		key = vm_symbol_key(realm, VM_SYMBOL_TO_STRING_TAG);
		status = vm_object_define(realm->heap, prototype, key, label, VM_PROPERTY_CONFIGURABLE);
	}

	/* Both publication and failure release the same temporary root. */
	vm_heap_remove_root(realm->heap, &root);
	if (status != 0)
		return status;

	/* Succeeded: Object.prototype.toString observes the native interface label. */
	return 0;
}

static int
window_make_interface(
	struct bind_window *window,
	int index,
	struct vm_function **constructors)
{
	const struct bind_interface *table;
	const struct bind_attribute *attribute;
	const struct bind_operation *operation;
	const struct bind_constant *constant;
	struct vm_realm *realm;
	struct vm_object *parent;
	struct vm_object *prototype;
	struct vm_function *constructor;
	vm_native construct;
	int error;

	/* The prototype inherits from the parent's, or from Object.prototype. */
	table = window_interfaces[index];
	realm = window->realm;
	parent = realm->object_prototype;
	if (table->parent != BIND_NO_PARENT)
		parent = window->prototypes[table->parent];

	/* DOMException's inherits from Error.prototype (ws074-p083), when the realm has it. */
	if (index == BIND_DOM_EXCEPTION && realm->intrinsics[VM_INTRINSIC_ERROR_PROTOTYPE] != NULL)
		parent = realm->intrinsics[VM_INTRINSIC_ERROR_PROTOTYPE];

	/* The Window retains each newly allocated interface prototype immediately. */
	prototype = vm_object_create(realm->heap, parent);
	if (prototype == NULL)
		return ENOMEM;
	window->prototypes[index] = prototype;

	/* The attributes, accessors on the prototype. */
	for (attribute = table->attributes; attribute != NULL && attribute->name != NULL; attribute++) {
		error = js_builtin_accessor(realm, prototype, attribute->name, attribute->getter, attribute->setter);
		if (error != 0)
			return error;

		/* Scoped native readonly IDL attributes enumerate on their relevant prototype. */
		if (index == BIND_ABSTRACT_RANGE ||
		    index == BIND_RANGE ||
		    index == BIND_ERROR_EVENT) {
			error = window_enumerate_dom_member(realm, prototype, attribute->name);
			if (error != 0)
				return error;
		}
	}

	/* ErrorEvent supplies its WebIDL class label on the actual native prototype. */
	if (index == BIND_ERROR_EVENT) {
		error = window_error_event_tag(realm, prototype);
		if (error != 0)
			return error;
	}

	/* The operations, methods on the prototype. */
	for (operation = table->operations; operation != NULL && operation->name != NULL; operation++) {
		error = js_builtin_method(realm, prototype, operation->name, operation->length, operation->method);
		if (error != 0)
			return error;

		/* Range and the concrete Text split use the enumerable writable configurable WebIDL descriptor. */
		if (index == BIND_RANGE || index == BIND_TEXT) {
			error = window_enumerate_dom_member(realm, prototype, operation->name);
			if (error != 0)
				return error;
		}
	}

	/* HTML elements, the document and the window have the event handler attributes. */
	if (index == BIND_HTML_ELEMENT ||
	    index == BIND_DOCUMENT ||
	    index == BIND_WINDOW) {
		error = bind_define_handlers(window, prototype);
		if (error != 0)
			return error;
	}

	/* The interface object: new runs the interface's constructor, or throws like a call does. */
	construct = table->construct;
	if (construct == NULL)
		construct = bind_illegal_constructor;
	error = js_builtin_constructor(realm, table->name, table->length, bind_illegal_constructor, construct, prototype, &constructor);
	if (error != 0)
		return error;
	constructors[index] = constructor;

	/* The interface object inherits from its parent's (Object.getPrototypeOf(HTMLElement) is Element). */
	if (table->parent != BIND_NO_PARENT)
		constructor->object.prototype = &constructors[table->parent]->object;

	/* The constants, on both the interface object and the prototype. */
	for (constant = table->constants; constant != NULL && constant->name != NULL; constant++) {
		error = js_builtin_value(realm, &constructor->object, constant->name, vm_value_int32(constant->value), VM_PROPERTY_ENUMERABLE);
		if (error != 0)
			return error;
		error = js_builtin_value(realm, prototype, constant->name, vm_value_int32(constant->value), VM_PROPERTY_ENUMERABLE);
		if (error != 0)
			return error;
	}

	/* Succeeded: the interface is on the global object. */
	return 0;
}
