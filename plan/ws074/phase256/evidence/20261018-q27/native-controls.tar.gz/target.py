from pathlib import Path
import shlex,subprocess,json
q=Path('build/ws074-20261018/q27');(q/'target').mkdir(exist_ok=True)
lines=Path('build/ws074-20261018/q02/target-dry-run.log').read_text().splitlines();commands=[]
for source in ['event','window']:
 matches=[shlex.split(line) for line in lines if ' -c userland/desktop/libbrowser/bind/'+source+'.c ' in line];assert len(matches)==1
 args=matches[0];args[args.index('-o')+1]=str(q/'target'/(source+'.o'));commands.append(args)
 with (q/('target-'+source+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=f)
 assert r.returncode==0,source
 assert (q/('target-'+source+'.log')).read_text()=='',source
(q/'target-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print('exact target event/window: warning0')
