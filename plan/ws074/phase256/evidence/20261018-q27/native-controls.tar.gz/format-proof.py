from pathlib import Path
import subprocess,json,hashlib,shlex
q=Path('build/ws074-20261018/q27');s=Path('userland/desktop/libbrowser/bind/event.c');before=(q/'event-preformat.c').read_text();after=s.read_text();assert ''.join(before.split())==''.join(after.split())
args=shlex.split(Path('build/ws074-20261018/plain/flags').read_text());args+=['-c',str(s),'-o',str(q/'event-postformat-host.o')];r=subprocess.run(args,capture_output=True);(q/'format-host-compile.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0 and not r.stderr
old=Path('build/ws074-20261018/plain/obj/libbrowser_bind_event.o')
for label,src in [('before',old),('after',q/'event-postformat-host.o')]:subprocess.run(['objcopy','--strip-debug',str(src),str(q/('event-'+label+'-runtime.o'))],check=True)
assert (q/'event-before-runtime.o').read_bytes()==(q/'event-after-runtime.o').read_bytes()
proof=dict(change='Only line breaks in an existing five-clause if restored per full C standard; no token or literal changes.',source_before_sha256=hashlib.sha256(before.encode()).hexdigest(),source_after_sha256=hashlib.sha256(after.encode()).hexdigest(),host_runtime_object_identical=True,host_command=args)
(q/'format-equivalence.json').write_text(json.dumps(proof,indent=2)+'\n')
p=q/'final/source-proof.json';data=json.loads(p.read_text());assert data[str(s)]==proof['source_before_sha256'];data[str(s)]=proof['source_after_sha256'];p.write_text(json.dumps(data,indent=2)+'\n');print('final source whitespace proof: native runtime object identical')
