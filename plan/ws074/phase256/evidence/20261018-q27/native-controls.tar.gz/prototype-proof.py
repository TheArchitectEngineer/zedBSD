from pathlib import Path
import re,subprocess,shlex,json,hashlib,shutil
q=Path('build/ws074-20261018/q27');p=Path('userland/desktop/libbrowser/bind/event.c');before=p.read_text();(q/'event-pre-prototype-order.c').write_text(before)
start=before.index('static void event_trace(');stop=before.index('/* The state of an event, which refers');block=before[start:stop];decls=re.findall(r'^static [^\n]+;\n',block,re.M);assert len(decls)>30
pos=before.index('/*\n * Reports the state of the event an Event object stands for');tables=before[stop:pos];needed=[];other=[]
for d in decls:
 name=re.search(r'\b(\w+)\(',d)[1]
 if re.search(r'\b'+name+r'\b',tables):needed.append(d)
 else:other.append(d)
assert len(needed)+len(other)==len(decls)
after=before[:start]+''.join(needed)+'\n'+before[stop:pos]+'/* Helpers not referenced by constant initializers follow the file-scope tables. */\n'+''.join(other)+'\n'+before[pos:]
def remaining(s):
 s=re.sub(r'^static [^\n]+;\n','',s,flags=re.M);s=re.sub(r'/\*.*?\*/','',s,flags=re.S);return ''.join(s.split())
assert remaining(before)==remaining(after)
assert sorted(re.findall(r'^static [^\n]+;\n',before,re.M))==sorted(re.findall(r'^static [^\n]+;\n',after,re.M))
p.write_text(after)
args=shlex.split(Path('build/ws074-20261018/plain/flags').read_text())+['-c',str(p),'-o',str(q/'event-prototype-order-host.o')];r=subprocess.run(args,capture_output=True);(q/'prototype-host-compile.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0 and not r.stderr
for label,src in [('frozen',Path('build/ws074-20261018/plain/obj/libbrowser_bind_event.o')),('ordered',q/'event-prototype-order-host.o')]:subprocess.run(['objcopy','--strip-debug',str(src),str(q/('event-'+label+'-prototypes-runtime.o'))],check=True)
assert (q/'event-frozen-prototypes-runtime.o').read_bytes()==(q/'event-ordered-prototypes-runtime.o').read_bytes()
proof=dict(source_before_sha256=hashlib.sha256(before.encode()).hexdigest(),source_after_sha256=hashlib.sha256(after.encode()).hexdigest(),initializers_required_forward_declarations=len(needed),other_helpers_after_tables=len(other),declaration_multiset_unchanged=True,remaining_tokens_unchanged=True,host_runtime_object_identical=True,command=args)
(q/'prototype-order-proof.json').write_text(json.dumps(proof,indent=2)+'\n');f=q/'final/source-proof.json';data=json.loads(f.read_text());shutil.copy2(f,q/'final/frozen-source-proof.json');assert data[str(p)]==proof['source_before_sha256'];data[str(p)]=proof['source_after_sha256'];f.write_text(json.dumps(data,indent=2)+'\n');print(proof)
