from pathlib import Path
import tarfile,hashlib,json,shutil
q=Path('build/ws074-20261018/q27');v=q/'final';out=Path('plan/ws074/phase256/evidence/20261018-q27');source=v/'acid';files=sorted(p for p in source.rglob('*') if p.is_file());archive=out/'acid-all-raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(source)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:assert tar.extractfile(member).read()==(source/member.name).read_bytes()
proof=dict(sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files),acid_comparison=json.loads((q/'acid-comparison.json').read_text()));(out/'acid-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name in ['target-commands.json','style-review.json','versions.json','acid-comparison.json','chrome-comparison.json','format-equivalence.json','primary-proof.json','pinned-html.idl','prototype-order-proof.json','declaration-review.json']:
 shutil.copy2(q/name,out/name)
for name in ['target-event.log','target-window.log']:
 shutil.copy2(q/name,out/name)
print(proof)

for name in ['event.c','window.c','internal.h']:shutil.copy2(Path('userland/desktop/libbrowser/bind')/name,out/name)
