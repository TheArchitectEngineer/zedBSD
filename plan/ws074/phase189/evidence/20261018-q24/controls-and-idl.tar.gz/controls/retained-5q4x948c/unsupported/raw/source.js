// META: script=helpers/dynamic.sub.js
test(function(){assert_equals(dynamicValue,1);}, "static fallback is unsupported");