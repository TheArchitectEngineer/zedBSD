// META: global=window,worker
// META: script=helpers/import.js
test(function() {
 assert_true(GLOBAL.isWindow()); assert_false(GLOBAL.isWorker()); assert_false(GLOBAL.isShadowRealm());
 assert_equals(order, "helper"); assert_equals(location.search, "?q=any");
 assert_true(!!document.getElementById("log"));
 assert_equals(document.currentScript.getAttribute("src"), "/any-positive.any.js");
}, "native any wrapper");