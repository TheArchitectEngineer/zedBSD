test(function() {
 assert_equals(typeof GLOBAL, "undefined"); assert_equals(self, window);
 assert_equals(document.currentScript.getAttribute("src"), "/window-positive.window.js");
 assert_true(!!document.getElementById("log"));
}, "native window wrapper");