// META: script=helpers/import.js
test(function() {}, "case");