/* global add_completion_callback */
/* global setup */

/*
 * This file is intended for vendors to implement code needed to integrate
 * testharness.js tests with their own test systems.
 *
 * Typically test system integration will attach callbacks when each test has
 * run, using add_result_callback(callback(test)), or when the whole test file
 * has completed, using
 * add_completion_callback(callback(tests, harness_status)).
 *
 * For more documentation about the callback functions and the
 * parameters they are called with see testharness.js
 */

/* If the parent window has a testharness_properties object,
 * we use this to provide the test settings. This is used by the
 * default in-browser runner to configure the timeout and the
 * rendering of results
 */
try {
    if (window.opener && "testharness_properties" in window.opener) {
        /* If we pass the testharness_properties object as-is here without
         * JSON stringifying and reparsing it, IE fails & emits the message
         * "Could not complete the operation due to error 80700019".
         */
        setup(JSON.parse(JSON.stringify(window.opener.testharness_properties)));
    }
} catch (e) {
}
// vim: set expandtab shiftwidth=4 tabstop=4:


(function () {
    function test_result(test) {
        return {name: String(test.name), status: test.status,
                message: test.message ? String(test.message) : ""};
    }
    add_result_callback(function (test) {
        console.log("WS074_WPT_RESULT " + JSON.stringify(test_result(test)));
    });
    add_completion_callback(function (tests, harness_status) {
        var results = [];
        for (var i = 0; i < tests.length; i++) {
            results.push(test_result(tests[i]));
        }
        console.log("WS074_WPT_COMPLETE " + JSON.stringify({
            tests: results,
            status: harness_status.status,
            message: harness_status.message ? String(harness_status.message) : ""
        }));
    });
}());

(function () {
    function test_result(test) {
        return {name: String(test.name), status: test.status,
                message: test.message ? String(test.message) : ""};
    }
    add_result_callback(function (test) {
        console.log("WS074_WPT_RESULT " + JSON.stringify(test_result(test)));
    });
    add_completion_callback(function (tests, harness_status) {
        var results = [];
        for (var i = 0; i < tests.length; i++) {
            results.push(test_result(tests[i]));
        }
        console.log("WS074_WPT_COMPLETE " + JSON.stringify({
            tests: results,
            status: harness_status.status,
            message: harness_status.message ? String(harness_status.message) : ""
        }));
    });
}());
