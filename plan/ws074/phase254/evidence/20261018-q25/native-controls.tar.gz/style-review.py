from pathlib import Path
import subprocess,re,json
q=Path('build/ws074-20261018/q25');p=q/'generated-functions.c';data=p.read_text();run=subprocess.run(['python3','plan/tools/style-check.py',str(p),'plan/ws074/tests/host-performance-marks.c'],capture_output=True,text=True)
(q/'style-generated.log').write_text(run.stdout+run.stderr)
flags=[line for line in run.stdout.splitlines() if re.search(r':\d+:',line)];assert flags and all(': goto: goto cleanup;' in line for line in flags)
functions=re.findall(r'static (?:int|void)\n(\w+)\(\n.*?\n\}',data,re.S);review=[]
for name in functions:
 m=re.search(r'static (?:int|void)\n'+name+r'\(\n.*?\n\}',data,re.S);code=m.group()
 targets=re.findall(r'\bgoto\s+(\w+);',code)
 if targets:
  assert set(targets)=={'cleanup'} and code.count('\ncleanup:')==1
  assert code.rindex('goto cleanup;') < code.index('\ncleanup:')
  review.append(dict(function=name,forward_cleanup_jumps=len(targets),labels=['cleanup'],backward_jumps=0))
assert sum(r['forward_cleanup_jumps'] for r in review)==len(flags)
proof=dict(full_standard='plan/coding-style.md section14 permits forward jumps to one shared cleanup label',checker_limitation='style-check.py flags every goto without recognizing the permitted forward cleanup pattern',raw_goto_flags=len(flags),other_generated_or_fixture_flags=0,manual_forward_cleanup_review=review,unresolved_generated_conformance_findings=0,functions=functions)
(q/'style-review.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof['raw_goto_flags'],'allowed forward cleanup flags; unresolved 0')
