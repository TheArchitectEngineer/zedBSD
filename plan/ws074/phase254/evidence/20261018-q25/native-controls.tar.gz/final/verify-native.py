from pathlib import Path
import subprocess,os,json,time
q=Path('build/ws074-20261018/q25/final');engine=(q/'engine').resolve();start=time.monotonic();runs=[]
commands=[('dom',['python3','plan/ws074/tests/run-dom-tests.py','--program',str(engine/'browser')]),('cssom',[str(engine/'host-cssom')]),('cssom-mutation',[str(engine/'host-cssom-mutation')]),('marks',[str(engine/'host-performance-marks')]),('crash',['python3','plan/ws074/tests/run-interop2025-crashtests.py','--manifest','plan/ws074/phase173/evidence/20261013-q1012/manifest.json','--program',str(engine/'browser'),'--focus','all','--settle-ms','5000','--process-timeout','20','--out',str(q/'crash-report.json')]),('acid',['python3','plan/ws074/tests/run-acid-tests.py','--program',str(engine/'browser'),'--out',str(q/'acid')])]
for label,command in commands:
 with (q/(label+'.log')).open('w') as log:run=subprocess.run(command,stdout=log,stderr=log,env=dict(os.environ,XDG_DATA_HOME=str((q/(label+'-data')).resolve())),timeout=300)
 runs.append(dict(label=label,command=command,returncode=run.returncode,seconds=round(time.monotonic()-start,1)));(q/'native-runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(runs[-1],flush=True)
 # Strict crash/Acid criteria are audited by exact report comparison, not their broad pass/fail exit.
 if label not in ['crash','acid']:assert run.returncode==0,label
