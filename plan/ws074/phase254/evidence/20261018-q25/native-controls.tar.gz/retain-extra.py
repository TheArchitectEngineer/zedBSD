from pathlib import Path
import tarfile,hashlib,json,shutil
q=Path('build/ws074-20261018/q25');v=q/'verified';out=Path('plan/ws074/phase254/evidence/20261018-q25');source=v/'acid';files=sorted(p for p in source.rglob('*') if p.is_file());archive=out/'acid-all-raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(source)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for p in files:assert tar.extractfile(str(p.relative_to(source))).read()==p.read_bytes()
proof=dict(sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files),acid_comparison=json.loads((q/'acid-comparison.json').read_text()));(out/'acid-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name in ['target-root-commands.json','style-review.json','versions.json','acid-comparison.json']:
 shutil.copy2(q/name,out/name)
for name in ['window.log','environment.log']:
 shutil.copy2(q/'target-root'/name,out/('target-'+name))
shutil.copy2(v/'early-harness-proof.json',out/'exact-harness-proof.json');shutil.copy2(v/'prereq.out',out/'native-observer-prereq.out');shutil.copy2(q/'observer-design.txt',out/'observer-design.txt');print(proof)
