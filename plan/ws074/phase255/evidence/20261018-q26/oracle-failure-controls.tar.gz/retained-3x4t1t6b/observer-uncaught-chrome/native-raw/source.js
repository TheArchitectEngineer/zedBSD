async_test(function(t) {
 var o=new PerformanceObserver(function(){assert_unreached("intentional observer callback error must fail harness");});
 o.observe({type:"mark"}); performance.mark("real-callback");
 t.step_timeout(t.step_func_done(function(){o.disconnect();}),100);
},"uncaught observer callback errors must not be PASS");