import os,importlib.util,json,subprocess,re
from pathlib import Path
os.environ['WPT_GENERATED_CONTROL_ROOT']='build/ws074-20261018/q26/oracle-controls'
spec=importlib.util.spec_from_file_location('observer_oracle_chrome','plan/ws074/tests/test-interop2025-generated.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=json.loads(Path('build/ws074-20261018/q26/oracle-negative-result.json').read_text());script=Path(r['generated']['raw_directory'],'source.js').read_bytes();root,row,server,context,tool,worker=m.fixture('observer-uncaught-chrome','any',script)
command=['chromium','--headless','--no-sandbox','--disable-gpu','--enable-logging=stderr','--log-level=0','--user-data-dir=/tmp/ws074-q26-oracle-chrome-1792313000','--virtual-time-budget=5000','--dump-dom','http://127.0.0.1:%d%s'%(server.server_port,row['id'])]
try:run=subprocess.run(command,capture_output=True,timeout=30)
finally:m.stop(server,worker)
q=Path('build/ws074-20261018/q26');(q/'oracle-chrome-dom.html').write_bytes(run.stdout);(q/'oracle-chrome.log').write_bytes(run.stderr)
messages=[]
for line in run.stderr.decode('utf-8',errors='replace').splitlines():
 match=re.search(r':CONSOLE(?:\(\d+\)|:\d+)\] "(.*)", source: ',line)
 if match:messages.append(match[1])
result=m.RUNNER.classify_output('\n'.join(messages)+'\n',run.returncode);result['command']=command;result['source_identical']=Path(r['generated']['raw_directory'],'source.js').read_bytes()==script;(q/'oracle-chrome-result.json').write_text(json.dumps(result,indent=2)+'\n');print(result['outcome']);print(result.get('completion'));assert result['outcome']!='pass'
