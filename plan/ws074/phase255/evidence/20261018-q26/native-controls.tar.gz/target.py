from pathlib import Path
import shlex,subprocess,json,hashlib
q=Path('build/ws074-20261018/q26');out=q/'target';out.mkdir(exist_ok=False);commands=[];sources={}
for path in ['userland/desktop/libbrowser/bind/window.c','userland/desktop/libbrowser/bind/environment.c']:
 matches=[line for line in Path('build/ws074-20261018/q02/target-dry-run.log').read_text().splitlines() if ' -c '+path+' -o ' in line];assert len(matches)==1
 command=shlex.split(matches[0]);idx=command.index('-o');command[idx+1]=str(out/(Path(path).stem+'.o'));commands.append(command)
 with (out/(Path(path).stem+'.log')).open('w') as log:run=subprocess.run(command,stdout=log,stderr=log,timeout=120)
 assert run.returncode==0;assert not (out/(Path(path).stem+'.log')).read_bytes();sources[path]=hashlib.sha256(Path(path).read_bytes()).hexdigest()
(q/'target-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(q/'target-source-proof.json').write_text(json.dumps(sources,indent=2)+'\n');print('target exact 2 source warning 0')
