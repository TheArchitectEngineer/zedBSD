import os,importlib.util,json
from pathlib import Path
os.environ['WPT_GENERATED_CONTROL_ROOT']='build/ws074-20261018/q26/oracle-controls'
os.environ['WPT_GENERATED_PROGRAM']='/home/awe/zedBSD-claude1/build/ws074-20261018/q26/final/engine/browser'
spec=importlib.util.spec_from_file_location('observer_oracle_control','plan/ws074/tests/test-interop2025-generated.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
script=b'''async_test(function(t) {
 var o=new PerformanceObserver(function(){assert_unreached("intentional observer callback error must fail harness");});
 o.observe({type:"mark"}); performance.mark("real-callback");
 t.step_timeout(t.step_func_done(function(){o.disconnect();}),100);
},"uncaught observer callback errors must not be PASS");'''
r=m.native('observer-uncaught-negative','any',script);Path('build/ws074-20261018/q26/oracle-negative-result.json').write_text(json.dumps(r,indent=2)+'\n');print(r['outcome']);print(r['generated']['raw_directory']);print(r.get('result_callbacks'));print(Path(r['generated']['raw_directory'],'stderr.bin').read_text())
