int vm_set(struct vm_realm *realm, vm_value base, vm_value key, vm_value value, int strict);
int vm_set_receiver(struct vm_realm *realm, struct vm_object *object, vm_value key, vm_value value, vm_value receiver, int *done);
int vm_define_own_property(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *done);
static int access_set_typed(struct vm_realm *realm, struct vm_object *object, vm_value key, vm_value value, vm_value receiver, int *done);
static int access_define_typed(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *handled, int *done);
static int typed_convert(struct vm_realm *realm, int type, vm_value value, double *number, uint64_t *big);
static int typed_define(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *handled, int *done);
static int typed_make_view(struct vm_realm *realm, int type, struct vm_object *prototype, vm_value buffer_object, uint32_t offset, uint32_t length, int data_view, vm_value *result);
static int typed_numeric_index(const struct typed_view *view, vm_value key, int *canonical, int *valid, uint32_t *index);
int main(int argc, char **argv);
static int typed_collect_get_own(struct vm_object *object, vm_value key, struct vm_property *property);
static int typed_forward_define(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *handled, int *done);
static int typed_storage_pressure(struct page *page);

int
vm_set(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	vm_value value,
	int strict)
{
	struct vm_property property;
	struct vm_accessor *accessor;
	struct vm_object *object;
	vm_value ignored;
	vm_value length_key;
	struct vm_descriptor descriptor;
	int handled;
	int is_object;
	int found;
	int done;
	int status;

	/* undefined and null have no properties. */
	if (base == VM_VALUE_UNDEFINED || base == VM_VALUE_NULL) {
		status = access_base_error(realm, base, key, "set", "setting");
		return status;
	}

	/* A primitive takes no property, but its prototype's setter is called with it. */
	is_object = vm_value_is_object(base);
	if (!is_object) {
		status = access_set_primitive(realm, base, key, value, strict);
		return status;
	}

	/* Direct Proxy and TypedArray assignment use their actual receiver-aware exotic operations. */
	object = (struct vm_object *)vm_value_as_cell(base);
	if (object->kind == VM_KIND_PROXY || object->kind == VM_KIND_TYPED_ARRAY) {
		status = vm_set_receiver(realm, object, key, value, base, &done);
		if (status != 0)
			return status;
		if (!done) {
			if (object->kind == VM_KIND_PROXY) {
				status = access_refuse(realm, strict, "Proxy set trap returned false");
			} else {
				status = access_refuse(realm, strict, "Cannot assign to read only property");
			}

			/* Strict refusal propagates its error while sloppy assignment remains silent. */
			if (status != 0)
				return status;

			/* Succeeded: sloppy assignment deliberately ignores Boolean refusal. */
			return 0;
		}

		/* Succeeded: the direct exotic operation accepted this assignment. */
		return 0;
	}

	/* An accessor on the chain: its setter is called with the value. */
	object = (struct vm_object *)vm_value_as_cell(base);
	found = vm_object_find(object, key, &property);
	if (found < 0)
		return -found;

	/* Present descriptors retain their ordinary accessor and attribute rules. */
	if (found && (property.attributes & VM_PROPERTY_ACCESSOR) != 0U) {
		accessor = (struct vm_accessor *)vm_value_as_cell(*property.value);
		if (accessor->setter == VM_VALUE_UNDEFINED) {
			status = access_refuse(realm, strict, "Cannot set property which has only a getter");
			return status;
		}

		/* The setter, called with the value. */
		status = vm_call(realm, accessor->setter, base, &value, 1, &ignored);
		if (status != 0)
			return status;
		return 0;
	}

	/* A read-only data property refuses. */
	if (found && (property.attributes & VM_PROPERTY_WRITABLE) == 0U) {
		status = access_refuse(realm, strict, "Cannot assign to read only property");
		return status;
	}

	/* An array's own length is set by its rules. */
	length_key = vm_key_from_ascii(realm->heap, "length");
	if (length_key == VM_VALUE_EMPTY)
		return ENOMEM;
	if (found &&
	    property.holder == object &&
	    key == length_key &&
	    (object->flags & VM_OBJECT_ARRAY) != 0U) {
		status = access_set_length(realm, object, value, strict);
		if (status != 0)
			return status;
		return 0;
	}

	/* A typed array converts the value in the realm (a valueOf may run, a wrong BigInt type throws). */
	if (object->kind == VM_KIND_TYPED_ARRAY &&
	    object->native_operations != NULL &&
	    object->native_operations->define != NULL) {
		memset(&descriptor, 0, sizeof(descriptor));
		descriptor.has = VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE;
		descriptor.value = value;
		descriptor.attributes = VM_PROPERTY_DEFAULT;
		handled = 0;
		done = 0;
		status = object->native_operations->define(realm, object, key, &descriptor, &handled, &done);
		if (status != 0)
			return status;
		if (handled)
			return 0;
	}

	/* Otherwise the ordinary assignment; an object that takes no new property refuses. */
	status = vm_object_set(realm->heap, object, key, value, &done);
	if (status != 0)
		return status;
	if (!done) {
		status = access_refuse(realm, strict, "Cannot add property, object is not extensible");
		return status;
	}

	/* Succeeded: the value is put. */
	return 0;
}

int
vm_set_receiver(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	vm_value value,
	vm_value receiver,
	int *done)
{
	struct access_write_roots roots;
	int status;

	/* Retain every input before either an exotic trap or ordinary descriptor callback can collect. */
	*done = 0;
	roots.read.realm = realm;
	roots.read.base = vm_value_cell(object);
	roots.read.key = key;
	roots.read.receiver = receiver;
	roots.value = value;
	status = vm_heap_add_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
		return status;
	}

	/* One native operation depth covers both Proxy and ordinary dispatch. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_set(realm, (struct vm_proxy *)object, key, value, receiver, done);
	} else if (object->kind == VM_KIND_TYPED_ARRAY) {
		status = access_set_typed(realm, object, key, value, receiver, done);
	} else {
		status = access_set_receiver(realm, object, key, value, receiver, done);
	}

	/* Neither a thrown trap nor a refused ordinary definition may leak depth or input ownership. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: done says whether the receiver accepted the property assignment. */
	return 0;
}

int
vm_define_own_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *done)
{
	struct vm_descriptor current;
	struct vm_accessor *accessor;
	struct vm_cell *accessor_root;
	vm_value length_key;
	vm_value getter;
	vm_value setter;
	vm_value value;
	uint32_t attributes;
	uint32_t index;
	int found;
	int allowed;
	int is_index;
	int is_accessor;
	int is_array;
	int status;
	int handled;

	/* Realm-aware Proxy definition owns its traps and leaves heap-only native policy unchanged. */
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_define(realm, (struct vm_proxy *)object, key, descriptor, done);
		if (status != 0)
			return status;
		return 0;
	}

	/* TypedArray value conversion belongs to this realm layer before pure native policy. */
	if (object->kind == VM_KIND_TYPED_ARRAY) {
		status = access_define_typed(realm, object, key, descriptor, &handled, done);
		if (status != 0)
			return status;
		if (handled)
			return 0;
	}

	/* Native policy may reject or handle a descriptor before ordinary validation. */
	*done = 0;
	if (object->native_operations != NULL && object->native_operations->define != NULL) {
		handled = 0;
		status = object->native_operations->define(realm, object, key, descriptor, &handled, done);
		if (status != 0)
			return status;
		if (handled)
			return 0;
	}

	/* The property there now. */
	*done = 0;
	found = vm_get_own_descriptor(object, key, &current);
	if (found < 0)
		return -found;

	/* Array descriptor handling resolves the separate length metadata key. */
	length_key = vm_key_from_ascii(realm->heap, "length");
	if (length_key == VM_VALUE_EMPTY)
		return ENOMEM;

	/* An array's length has rules of its own. */
	is_array = 0;
	if ((object->flags & VM_OBJECT_ARRAY) != 0U)
		is_array = 1;
	if (is_array && key == length_key) {
		status = access_define_length(realm, object, &current, descriptor, done);
		if (status != 0)
			return status;
		return 0;
	}

	/* An array takes no index past a length that cannot change. */
	is_index = vm_value_is_array_index(key, &index);
	if (is_array &&
	    is_index &&
	    !found &&
	    index >= object->length) {
		access_get_length_attributes(object, length_key, &attributes);
		if ((attributes & VM_PROPERTY_WRITABLE) == 0U)
			return 0;
	}

	/* Whether the change is allowed from what is there. */
	allowed = access_descriptor_allowed(object, found, &current, descriptor);
	if (!allowed)
		return 0;

	/* The kind after the change: the descriptor's, or (for a generic one) what is there. */
	is_accessor = 0;
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U)
		is_accessor = 1;
	if ((descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_GET | VM_HAS_SET)) == 0U &&
	    found &&
	    (current.has & VM_HAS_GET) != 0U)
		is_accessor = 1;

	/* The enumerability and configurability: given, or kept, or false. */
	attributes = 0;
	if (found)
		attributes = current.attributes & (VM_PROPERTY_ENUMERABLE | VM_PROPERTY_CONFIGURABLE);
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U)
		attributes = (attributes & ~VM_PROPERTY_ENUMERABLE) | (descriptor->attributes & VM_PROPERTY_ENUMERABLE);
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U)
		attributes = (attributes & ~VM_PROPERTY_CONFIGURABLE) | (descriptor->attributes & VM_PROPERTY_CONFIGURABLE);

	/* An accessor: the getter and setter given, or those it had. */
	if (is_accessor) {
		getter = VM_VALUE_UNDEFINED;
		setter = VM_VALUE_UNDEFINED;
		if (found && (current.has & VM_HAS_GET) != 0U) {
			getter = current.getter;
			setter = current.setter;
		}

		/* The ones given. */
		if ((descriptor->has & VM_HAS_GET) != 0U)
			getter = descriptor->getter;
		if ((descriptor->has & VM_HAS_SET) != 0U)
			setter = descriptor->setter;
		accessor = vm_accessor_create(realm->heap, getter, setter);
		if (accessor == NULL)
			return ENOMEM;

		/* The descriptor owns the pair only after the property is published. */
		accessor_root = &accessor->cell;
		status = vm_heap_add_root(realm->heap, &accessor_root);
		if (status != 0)
			return status;
		status = vm_object_define(realm->heap, object, key, vm_value_cell(accessor), attributes | VM_PROPERTY_ACCESSOR);
		vm_heap_remove_root(realm->heap, &accessor_root);
		if (status != 0)
			return status;
		*done = 1;
		return 0;
	}

	/* A data property: the value and writability given, or those it had. */
	value = VM_VALUE_UNDEFINED;
	if (found && (current.has & VM_HAS_VALUE) != 0U) {
		value = current.value;
		attributes |= current.attributes & VM_PROPERTY_WRITABLE;
	}

	/* The ones given. */
	if ((descriptor->has & VM_HAS_VALUE) != 0U)
		value = descriptor->value;
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U)
		attributes = (attributes & ~VM_PROPERTY_WRITABLE) | (descriptor->attributes & VM_PROPERTY_WRITABLE);
	status = vm_object_define(realm->heap, object, key, value, attributes);
	if (status != 0)
		return status;

	/* Succeeded: the property is defined. */
	*done = 1;
	return 0;
}

static int
access_set_typed(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	vm_value value,
	vm_value receiver,
	int *done)
{
	struct vm_cell *converted_root;
	struct vm_property property;
	struct vm_descriptor change;
	vm_value converted;
	double number;
	int canonical;
	int same;
	int present;
	int is_cell;
	int status;

	/* The outer write frame owns original inputs; this slot owns a fresh converted BigInt before native validity reads. */
	converted_root = NULL;
	status = vm_heap_add_root(realm->heap, &converted_root);
	if (status != 0)
		return status;
	status = vm_canonical_numeric_index(key, &number, &canonical);
	if (status != 0)
		goto cleanup;
	if (!canonical) {
		status = access_set_receiver(realm, object, key, value, receiver, done);
		goto cleanup;
	}

	/* A real TypedArray exposes pure integer-index validity through its own native policy. */
	if (object->native_operations == NULL || object->native_operations->get_own == NULL) {
		status = EINVAL;
		goto cleanup;
	}

	/* Identical receivers convert first, even when the numeric index is invalid or out of range. */
	same = vm_same_value(vm_value_cell(object), receiver);
	if (same) {
		converted = VM_VALUE_UNDEFINED;
		if ((object->flags & VM_OBJECT_TYPED_BIGINT) != 0U) {
			status = vm_to_bigint(realm, value, &converted);
			if (status != 0)
				goto cleanup;
		} else {
			status = vm_to_number(realm, value, &number);
			if (status != 0)
				goto cleanup;
			converted = vm_value_number(number);
		}

		/* Preserve the sole converted value through subsequent native collection and metadata observation. */
		is_cell = vm_value_is_cell(converted);
		if (is_cell)
			converted_root = vm_value_as_cell(converted);
		present = object->native_operations->get_own(object, key, &property);
		if (present < 0) {
			status = -present;
			goto cleanup;
		}

		/* An invalid integer index ignores the already converted value and still reports true. */
		if (!present) {
			*done = 1;
			status = 0;
			goto cleanup;
		}

		/* Native Define stores only the normalized primitive; no user conversion can occur inside the callback. */
		memset(&change, 0, sizeof(change));
		change.has = VM_HAS_VALUE;
		change.value = converted;
		status = vm_define_own_property(realm, object, key, &change, done);
		goto cleanup;
	}

	/* A distinct receiver checks integer-index validity before any value conversion. */
	present = object->native_operations->get_own(object, key, &property);
	if (present < 0) {
		status = -present;
		goto cleanup;
	}

	/* Invalid numeric keys accept assignment without consulting or creating a property on the receiver. */
	if (!present) {
		*done = 1;
		status = 0;
		goto cleanup;
	}

	/* Valid indices apply ordinary receiver reflection and definition to the original unconverted value. */
	status = access_set_receiver(realm, object, key, value, receiver, done);

cleanup:
	/* The temporary conversion owner retires before the surrounding write frame. */
	vm_heap_remove_root(realm->heap, &converted_root);
	if (status != 0)
		return status;

	/* Succeeded: done distinguishes ordinary refusal from accepted integer-index assignment. */
	return 0;
}

static int
access_define_typed(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *handled,
	int *done)
{
	struct access_descriptor_roots input_roots;
	struct access_descriptor_roots converted_roots;
	struct vm_descriptor converted;
	struct vm_property property;
	struct vm_cell *key_root;
	double number;
	int input_registered;
	int converted_registered;
	int canonical;
	int present;
	int native_handled;
	int is_cell;
	int status;

	/* A direct native caller can supply a sole target, key or flagged payload with no embedding roots. */
	*handled = 0;
	*done = 0;
	input_registered = 0;
	converted_registered = 0;
	key_root = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		key_root = vm_value_as_cell(key);
	status = vm_heap_add_root(realm->heap, &key_root);
	if (status != 0)
		return status;
	input_roots.realm = realm;
	input_roots.source = vm_value_cell(object);
	input_roots.descriptor = descriptor;
	input_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &input_roots);
	if (status != 0)
		goto cleanup;
	input_registered = 1;
	status = vm_canonical_numeric_index(key, &number, &canonical);
	if (status != 0)
		goto cleanup;
	if (!canonical) {
		status = 0;
		goto cleanup;
	}

	/* Canonical numeric keys belong exclusively to integer-index policy, even when missing. */
	*handled = 1;
	if (object->native_operations == NULL ||
	    object->native_operations->get_own == NULL ||
	    object->native_operations->define == NULL) {
		status = EINVAL;
		goto cleanup;
	}

	/* Index validity is observed before flags or user value conversion. */
	present = object->native_operations->get_own(object, key, &property);
	if (present < 0) {
		status = -present;
		goto cleanup;
	}

	/* An initially invalid index refuses without observing the value's primitive conversion. */
	if (!present) {
		status = 0;
		goto cleanup;
	}

	/* Integer-index properties cannot become nonconfigurable or nonenumerable. */
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U && (descriptor->attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		status = 0;
		goto cleanup;
	}

	/* Enumerability has the same mandatory true attribute. */
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U && (descriptor->attributes & VM_PROPERTY_ENUMERABLE) == 0U) {
		status = 0;
		goto cleanup;
	}

	/* Accessor descriptors are never integer-index data properties. */
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U) {
		status = 0;
		goto cleanup;
	}

	/* A writable:false claim is rejected before any value conversion. */
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U) {
		status = 0;
		goto cleanup;
	}

	/* An attribute-only descriptor needs no element conversion or native write. */
	if ((descriptor->has & VM_HAS_VALUE) == 0U) {
		*done = 1;
		status = 0;
		goto cleanup;
	}

	/* Copy only present metadata and initialize every payload before exposing the converted descriptor tracer. */
	memset(&converted, 0, sizeof(converted));
	converted.has = descriptor->has;
	converted.value = VM_VALUE_UNDEFINED;
	converted.getter = VM_VALUE_UNDEFINED;
	converted.setter = VM_VALUE_UNDEFINED;
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U)
		converted.attributes |= descriptor->attributes & VM_PROPERTY_WRITABLE;
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U)
		converted.attributes |= descriptor->attributes & VM_PROPERTY_ENUMERABLE;
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U)
		converted.attributes |= descriptor->attributes & VM_PROPERTY_CONFIGURABLE;
	converted_roots.realm = realm;
	converted_roots.source = VM_VALUE_UNDEFINED;
	converted_roots.descriptor = &converted;
	converted_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &converted_roots);
	if (status != 0)
		goto cleanup;
	converted_registered = 1;
	if ((object->flags & VM_OBJECT_TYPED_BIGINT) != 0U) {
		status = vm_to_bigint(realm, descriptor->value, &converted.value);
		if (status != 0)
			goto cleanup;
	} else {
		status = vm_to_number(realm, descriptor->value, &number);
		if (status != 0)
			goto cleanup;
		converted.value = vm_value_number(number);
	}

	/* Heap policy receives NULL realm and normalized primitives, so it cannot execute user conversion. */
	native_handled = 0;
	status = object->native_operations->define(NULL, object, key, &converted, &native_handled, done);
	if (status != 0)
		goto cleanup;
	if (!native_handled) {
		status = EINVAL;
		goto cleanup;
	}

	/* A conversion-time invalidation makes SetElement a no-op after the original valid Define was accepted. */
	*done = 1;
	status = 0;

cleanup:
	/* Retire converted and original descriptor owners before their stack storage leaves this operation. */
	if (converted_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &converted_roots);
	if (input_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &input_roots);
	vm_heap_remove_root(realm->heap, &key_root);
	if (status != 0)
		return status;

	/* Succeeded: handled distinguishes integer-index policy from ordinary fallback and done preserves refusal. */
	return 0;
}

static int
typed_convert(
	struct vm_realm *realm,
	int type,
	vm_value value,
	double *number,
	uint64_t *big)
{
	struct vm_bigint *bigint;
	vm_value converted;
	int status;

	/* Content type selects the language conversion, independently of element width or signedness. */
	*number = 0.0;
	*big = 0;
	if (type == TYPED_BIGINT64 || type == TYPED_BIGUINT64) {
		status = vm_to_bigint(realm, value, &converted);
		if (status != 0)
			return status;
		bigint = vm_value_as_bigint(converted);
		*big = vm_bigint_to_uint64(bigint);
		return 0;
	}

	/* Number content rejects BigInt and Symbol while honoring object conversion in the owning realm. */
	status = vm_to_number(realm, value, number);
	if (status != 0)
		return status;

	/* Succeeded: native storage receives scalar Number or modulo-64-bit BigInt content. */
	return 0;
}

static int
typed_define(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *handled,
	int *done)
{
	struct typed_view *view;
	struct vm_bigint *bigint;
	uint32_t index;
	uint64_t big;
	double number;
	int canonical;
	int valid;
	int is_number;
	int status;

	UNUSED_PARAMETER(realm);

	/* Realm-owned callers perform conversion before entering this immutable heap policy. */
	*handled = 0;
	*done = 0;
	view = (struct typed_view *)vm_value_as_cell(object->internal);
	status = typed_numeric_index(view, key, &canonical, &valid, &index);
	if (status != 0)
		return status;
	if (!canonical)
		return 0;
	*handled = 1;
	if (!valid)
		return 0;

	/* Integer-index descriptors keep their required configurable, enumerable and writable attributes. */
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U && (descriptor->attributes & VM_PROPERTY_CONFIGURABLE) == 0U)
		return 0;
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U && (descriptor->attributes & VM_PROPERTY_ENUMERABLE) == 0U)
		return 0;
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U)
		return 0;
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U)
		return 0;
	if ((descriptor->has & VM_HAS_VALUE) == 0U) {
		*done = 1;
		return 0;
	}

	/* Native storage accepts a normalized primitive of the view's content type and never invokes ToPrimitive. */
	number = 0.0;
	big = 0;
	if (view->type == TYPED_BIGINT64 || view->type == TYPED_BIGUINT64) {
		bigint = vm_value_as_bigint(descriptor->value);
		if (bigint == NULL)
			return EINVAL;
		big = vm_bigint_to_uint64(bigint);
	} else {
		is_number = vm_value_is_number(descriptor->value);
		if (!is_number)
			return EINVAL;
		number = vm_value_as_number(descriptor->value);
	}

	/* Existing fixed-view bounds and byte representation belong to the native storage implementation. */
	typed_store((int)view->type, view->buffer->data + view->offset + (size_t)index * typed_sizes[view->type], number, big);
	*done = 1;

	/* Succeeded: one already converted value was stored without executing script. */
	return 0;
}

static int
typed_make_view(
	struct vm_realm *realm,
	int type,
	struct vm_object *prototype,
	vm_value buffer_object,
	uint32_t offset,
	uint32_t length,
	int data_view,
	vm_value *result)
{
	struct typed_view *view;
	struct vm_object *object;
	struct vm_cell *roots[4];
	unsigned index;
	unsigned registered;
	int status;

	/* A direct native caller need not retain the managed owner, prototype or fresh backing buffer. */
	*result = VM_VALUE_UNDEFINED;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = NULL;
	if (prototype != NULL)
		roots[1] = &prototype->cell;
	roots[2] = vm_value_as_cell(buffer_object);
	roots[3] = NULL;
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The new view remains unpublished until an actual object takes ownership of it. */
	view = vm_heap_alloc(realm->heap, &typed_view_type, sizeof(*view));
	if (view == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Keep the view and its backing object live while allocating the final wrapper. */
	roots[3] = &view->cell;
	view->buffer_object = buffer_object;
	view->buffer = typed_buffer_of(buffer_object);
	view->offset = offset;
	view->length = length;
	view->type = (uint32_t)type;
	view->heap = realm->heap;
	object = vm_object_create(realm->heap, prototype);
	if (object == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Native storage metadata is immutable and independent of user-modifiable prototype properties. */
	object->internal = vm_value_cell(view);
	if (data_view) {
		object->kind = VM_KIND_DATA_VIEW;
	} else {
		object->kind = VM_KIND_TYPED_ARRAY;
		object->native_operations = &typed_operations;
		if (type == TYPED_BIGINT64 || type == TYPED_BIGUINT64)
			object->flags |= VM_OBJECT_TYPED_BIGINT;
	}

	/* The wrapper now owns its view and buffer graph, with no remaining fallible operation before publication. */
	*result = vm_value_cell(object);
	status = 0;

cleanup:
	/* No factory root may escape its actual native frame. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve failed construction without publishing a partial view. */
	if (status != 0)
		return status;

	/* Succeeded: the completed typed object owns every collectible storage component. */
	return 0;
}

static int
typed_numeric_index(
	const struct typed_view *view,
	vm_value key,
	int *canonical,
	int *valid,
	uint32_t *index)
{
	double number;
	double whole;
	int negative_zero;
	int status;

	/* Noncanonical names continue into ordinary property storage. */
	*valid = 0;
	*index = 0;
	status = vm_canonical_numeric_index(key, &number, canonical);
	if (status != 0)
		return status;
	if (!*canonical)
		return 0;
	if (number != number)
		return 0;

	/* Negative zero is an invalid integer index even though its numeric value equals zero. */
	negative_zero = 0;
	if (number == 0.0)
		negative_zero = signbit(number);
	if (negative_zero)
		return 0;
	if (number < 0.0 || number >= (double)view->length)
		return 0;

	/* Bounds exclude infinities before integral conversion. */
	whole = floor(number);
	if (whole != number)
		return 0;
	*index = (uint32_t)number;
	*valid = 1;

	/* Succeeded: the key is either ordinary, invalid numeric, or a valid fixed-view index. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
typed_collect_get_own(
	struct vm_object *object,
	vm_value key,
	struct vm_property *property)
{
	struct vm_cell *found;
	int present;

	/* The active Set frame must retain both the bare owner and a sole converted BigInt. */
	vm_heap_collect(typed_case_heap);
	found = vm_heap_find_cell(typed_case_heap, typed_case_realm_address);
	if (found != NULL)
		typed_case_collections++;
	present = typed_saved_operations->get_own(object, key, property);

	/* Preserve the real typed storage policy's found/missing/negative errno convention. */
	if (present < 0)
		return present;

	/* Succeeded: the original native descriptor decides validity. */
	return present;
}

static int
typed_forward_define(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *handled,
	int *done)
{
	struct vm_bigint *big;
	int status;

	/* Native policy must receive no script realm and an already converted BigInt value. */
	if (realm != NULL)
		return EINVAL;
	if ((descriptor->has & VM_HAS_VALUE) != 0U) {
		big = vm_value_as_bigint(descriptor->value);
		if (big == NULL)
			return EINVAL;
	}

	/* The original callback owns validation and actual byte storage; the fixture does not emulate it. */
	status = typed_saved_operations->define(NULL, object, key, descriptor, handled, done);
	if (status != 0)
		return status;

	/* Succeeded: actual native storage completed without a script-capable callback. */
	return 0;
}

static int
typed_storage_pressure(
	struct page *page)
{
	struct vm_cell *roots[4];
	struct vm_cell *found;
	struct vm_realm *realm;
	struct vm_object *object;
	struct vm_object *source;
	struct vm_object *buffer;
	struct vm_bigint *big;
	struct wb_buffer text;
	vm_value array;
	vm_value input;
	vm_value answer;
	vm_value key;
	uintptr_t object_address;
	uintptr_t source_address;
	uintptr_t view_address;
	uintptr_t buffer_address;
	uintptr_t storage_address;
	uintptr_t result_address;
	unsigned index;
	unsigned registered;
	int is_object;
	int done;
	int differs;
	int status;

	/* All saved addresses are observations; only the explicitly registered setup slots own cells. */
	memset(roots, 0, sizeof(roots));
	wb_buffer_init(&text);
	registered = 0;
	object_address = 0;
	typed_case_heap = page->heap;
	typed_case_realm_address = 0;
	typed_case_collections = 0;
	typed_saved_operations = NULL;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The public constructor must create the actual BigInt content metadata and backing graph. */
	status = proxy_script(page->realm, "new BigInt64Array(1)", &array);
	if (status != 0)
		goto cleanup;
	object = (struct vm_object *)vm_value_as_cell(array);
	roots[1] = &object->cell;
	object_address = (uintptr_t)object;
	view_address = (uintptr_t)vm_value_as_cell(object->internal);
	if ((object->flags & VM_OBJECT_TYPED_BIGINT) == 0U) {
		status = 1;
		goto cleanup;
	}

	/* Observe the real public backing object without inventing private typed-view layout in the fixture. */
	key = vm_key_from_ascii(page->heap, "buffer");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The typed object's own graph is the only owner of its buffer after this read. */
	status = vm_get(page->realm, array, key, &answer);
	if (status != 0)
		goto cleanup;
	buffer = (struct vm_object *)vm_value_as_cell(answer);
	buffer_address = (uintptr_t)buffer;
	storage_address = (uintptr_t)vm_value_as_cell(buffer->internal);
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	typed_case_realm_address = (uintptr_t)realm;
	source = vm_object_create(page->heap, NULL);
	if (source == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* This otherwise unowned source creates a fresh primitive and real subsequent conversion pressure. */
	roots[2] = &source->cell;
	source_address = (uintptr_t)source;
	status = js_builtin_method(page->realm, source, "valueOf", 0, conversion_primitive);
	if (status != 0)
		goto cleanup;
	input = vm_value_cell(source);
	typed_saved_operations = object->native_operations;
	object->native_operations = &typed_collect_operations;
	vm_heap_collect(page->heap);
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	status = vm_set_receiver(realm, object, vm_value_int32(0), input, array, &done);
	if (status != 0)
		goto cleanup;
	if (!done ||
	    typed_case_collections < 2U ||
	    realm->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* Restore ordinary embedding ownership only after the native collectors observed the original managed owner. */
	roots[1] = &object->cell;
	object->native_operations = typed_saved_operations;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, typed_case_realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Neither the typed result graph nor completed conversion may retain its original source object. */
	found = vm_heap_find_cell(page->heap, source_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The native valueOf primitive has no persistent owner after conversion and pure storage end. */
	found = vm_heap_find_cell(page->heap, conversion_primitive_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Read the actual stored bytes through the production typed descriptor path. */
	status = vm_get(page->realm, array, vm_value_int32(0), &answer);
	if (status != 0)
		goto cleanup;
	big = vm_value_as_bigint(answer);
	if (big == NULL) {
		status = 1;
		goto cleanup;
	}

	/* The sole converted BigInt must survive native validity collection rather than being replaced by a loaded zero. */
	roots[3] = vm_value_as_cell(answer);
	result_address = (uintptr_t)roots[3];
	status = vm_bigint_to_text(big, 10, &text);
	if (status != 0)
		goto cleanup;
	differs = strcmp(wb_buffer_string(&text), "9007199254740993");
	if (differs != 0) {
		status = 1;
		goto cleanup;
	}

	/* The last typed-object root must own its actual view and backing storage rather than an abandoned setup frame. */
	roots[1] = NULL;
	roots[3] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, object_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The view cell retires with its final typed wrapper. */
	found = vm_heap_find_cell(page->heap, view_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The actual public ArrayBuffer object has no residual constructor or conversion owner. */
	found = vm_heap_find_cell(page->heap, buffer_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Its native storage cell is also collectible after the complete view graph retires. */
	found = vm_heap_find_cell(page->heap, storage_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The loaded output BigInt has no accidental native root after the embedding releases it. */
	found = vm_heap_find_cell(page->heap, result_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Every observed production storage component met its independent ownership and retirement condition. */
	status = 0;

cleanup:
	/* Restore native policy only on a still-live object before retiring the fixture's saved immutable table. */
	if (object_address != 0U && typed_saved_operations != NULL) {
		found = vm_heap_find_cell(page->heap, object_address);
		if (found != NULL) {
			is_object = vm_value_is_object(vm_value_cell(found));
			if (is_object)
				((struct vm_object *)found)->native_operations = typed_saved_operations;
		}
	}

	/* The observational globals and callback have no lifecycle beyond this bounded native case. */
	typed_saved_operations = NULL;
	typed_case_heap = NULL;
	typed_case_realm_address = 0;
	typed_case_collections = 0;
	conversion_primitive_address = 0;
	conversion_primitive_collections = 0;
	wb_buffer_release(&text);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failed native observations after restoring policy and releasing every setup root. */
	if (status != 0)
		return status;

	/* Succeeded: actual pure native storage and its complete managed graph survived and retired correctly. */
	return 0;
}
