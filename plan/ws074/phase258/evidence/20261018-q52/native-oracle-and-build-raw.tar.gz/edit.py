from pathlib import Path
import re
p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();Path('build/ws074-20261018/q52/original-access.c').write_text(s)
a=s.index('/*\n * The state of one for-in loop:');b=s.index('\n};',a)+3;s=s[:a]+'''/*
 * One for-in iterator owns the current prototype level, its unprocessed own
 * keys and the names already seen.  Native vectors remain traced between
 * interpreter steps and are released with this private cell.
 */
struct access_for_in {
 struct vm_cell cell;
 vm_value object;
 struct wb_vector keys;
 struct wb_vector visited;
 size_t index;
 int loaded;
};'''+s[b:]
s=s.replace('static int access_collect(struct vm_heap *heap, struct vm_object *object, struct wb_vector *keys);\n','')
for decl in ['static int access_key_listed(const struct wb_vector *keys, size_t count, vm_value key);\n','static int access_is_symbol(vm_value value);\n']:
 assert s.count(decl)==1;s=s.replace(decl,'');pos=s.index('static void access_keys_trace(');s=s[:pos]+decl+s[pos:]
def replace(n,f):
 global s
 m=re.search(r'(?:static )?(?:int|void)\n'+n+r'\(\n.*?\n\}',s,re.S);assert m,n;s=s[:m.start()]+f+s[m.end():]
replace('vm_for_in_start','''int
vm_for_in_start(
 struct vm_realm *realm,
 vm_value value,
 vm_value *iterator)
{
 struct access_for_in *state;
 struct vm_cell *roots[3];
 vm_value object;
 unsigned index;
 unsigned registered;
 int is_cell;
 int status;

 /* Direct native inputs and the managed caller survive boxing and iterator allocation. */
 memset(roots, 0, sizeof(roots));
 if (realm->managed)
  roots[0] = &realm->cell;
 is_cell = vm_value_is_cell(value);
 if (is_cell)
  roots[1] = vm_value_as_cell(value);
 registered = 0;
 for (index = 0; index < 3U; index++) {
  status = vm_heap_add_root(realm->heap, &roots[index]);
  if (status != 0)
   goto cleanup;

  /* Cleanup owns the slot only after root registration succeeds. */
  registered++;
 }

 /* Nullish loop heads are empty; every other primitive includes its boxed prototype chain. */
 object = VM_VALUE_NULL;
 if (value != VM_VALUE_UNDEFINED && value != VM_VALUE_NULL) {
  status = vm_to_object(realm, value, &object);
  if (status != 0)
   goto cleanup;
  roots[1] = vm_value_as_cell(object);
 }

 /* Publish only a fully initialized private cell; property methods run when next first visits a level. */
 state = vm_heap_alloc(realm->heap, &access_for_in_type, sizeof(*state));
 if (state == NULL) {
  status = ENOMEM;
  goto cleanup;
 }

 /* Both empty vectors are safe to trace and finalize before any user trap is invoked. */
 state->object = object;
 wb_vector_init(&state->keys, sizeof(vm_value));
 wb_vector_init(&state->visited, sizeof(vm_value));
 state->index = 0;
 state->loaded = 0;
 roots[2] = &state->cell;
 *iterator = vm_value_cell(state);

 /* Every acquired registration retires on success and all allocation failures. */
cleanup:
 while (registered != 0U) {
  registered--;
  vm_heap_remove_root(realm->heap, &roots[registered]);
 }

 /* Report why boxing or state allocation could not finish. */
 if (status != 0)
  return status;

 /* Succeeded: the caller owns a lazy for-in iterator. */
 return 0;
}''')
replace('vm_for_in_next','''int
vm_for_in_next(
 struct vm_realm *realm,
 vm_value iterator,
 vm_value *key,
 int *done)
{
 struct access_for_in *state;
 struct vm_descriptor descriptor;
 struct vm_string *string;
 struct vm_cell *roots[2];
 vm_value candidate;
 vm_value canonical;
 vm_value prototype;
 unsigned index;
 unsigned registered;
 int is_cell;
 int is_symbol;
 int listed;
 int found;
 int status;

 /* Only the private iterator kind belongs in the bytecode's iterator register. */
 *done = 1;
 *key = VM_VALUE_UNDEFINED;
 is_cell = vm_value_is_cell(iterator);
 if (!is_cell)
  return EINVAL;
 state = (struct access_for_in *)vm_value_as_cell(iterator);
 if (state->cell.type != &access_for_in_type)
  return EINVAL;

 /* A bare native caller relies on this operation to retain its realm and all iterator-owned state. */
 roots[0] = NULL;
 if (realm->managed)
  roots[0] = &realm->cell;
 roots[1] = &state->cell;
 registered = 0;
 for (index = 0; index < 2U; index++) {
  status = vm_heap_add_root(realm->heap, &roots[index]);
  if (status != 0)
   goto cleanup;

  /* Cleanup may retire this root only after acquisition succeeds. */
  registered++;
 }

 /* Finish one own-key list before obtaining the next actual prototype. */
 while (state->object != VM_VALUE_NULL) {
  if (!state->loaded) {
   /* A fresh level collects keys once, while the state tracer retains every appended entry. */
   wb_vector_clear(&state->keys);
   state->index = 0;
   status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(state->object), &state->keys);
   if (status != 0)
    goto cleanup;

   /* Subsequent next calls resume this snapshot rather than invoking OwnPropertyKeys again. */
   state->loaded = 1;
  }

  /* A processed present name shadows prototypes even when its descriptor is not enumerable. */
  while (state->index < state->keys.count) {
   candidate = *(vm_value *)wb_vector_at(&state->keys, state->index);
   state->index++;
   is_symbol = access_is_symbol(candidate);
   if (is_symbol)
    continue;

   /* Canonical property keys compare by value even when a trap returned a fresh non-atom string. */
   status = vm_to_key(realm, candidate, &canonical);
   if (status != 0)
    goto cleanup;
   listed = access_key_listed(&state->visited, state->visited.count, canonical);
   if (listed)
    continue;

   /* Absence does not mark a name visited, so a prototype may still supply that name. */
   status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(state->object), canonical, &descriptor, &found);
   if (status != 0)
    goto cleanup;
   if (!found)
    continue;

   /* Native vector growth does not collect; only descriptor attributes remain relevant afterward. */
   status = wb_vector_push(&state->visited, &canonical);
   if (status != 0)
    goto cleanup;
   if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
    continue;

   /* The yielded name is a string, while its canonical key remains owned by the visited list. */
   status = vm_to_string(realm, canonical, &string);
   if (status != 0)
    goto cleanup;
   *key = vm_value_cell(string);
   *done = 0;
   goto cleanup;
  }

  /* A fresh prototype result transfers directly to the traced current-level slot before another callback. */
  status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(state->object), &prototype);
  if (status != 0)
   goto cleanup;
  state->object = prototype;

  /* The completed level no longer owns remaining keys; the next iteration must load its successor. */
  wb_vector_clear(&state->keys);
  state->index = 0;
  state->loaded = 0;
 }

 /* Reaching null produces the done result without consulting another property method. */
 status = 0;

 /* Return values need no allocation after the realm and iterator registrations are retired. */
cleanup:
 while (registered != 0U) {
  registered--;
  vm_heap_remove_root(realm->heap, &roots[registered]);
 }

 /* Preserve original property-method exceptions and native errno after cleanup. */
 if (status != 0)
  return status;

 /* Succeeded: key/done describe this one iterator step. */
 return 0;
}''')
replace('access_for_in_trace','''static void
access_for_in_trace(
 struct vm_heap *heap,
 struct vm_cell *cell)
{
 struct access_for_in *state;

 /* Current prototypes and initialized native key entries remain owned between interpreter steps. */
 state = (struct access_for_in *)cell;
 vm_heap_mark_value(heap, state->object);
 access_keys_trace(heap, &state->keys);
 access_keys_trace(heap, &state->visited);
}''')
replace('access_for_in_finalize','''static void
access_for_in_finalize(
 struct vm_heap *heap,
 struct vm_cell *cell)
{
 struct access_for_in *state;

 UNUSED_PARAMETER(heap);

 /* Neither native vector outlives the private iterator cell which owns its storage. */
 state = (struct access_for_in *)cell;
 wb_vector_release(&state->keys);
 wb_vector_release(&state->visited);
}''')
m=re.search(r'/\* Lists the enumerable string keys of an object and its chain, each once, the nearest first\. \*/\nstatic int\naccess_collect\(\n.*?\n\}\n\n',s,re.S);assert m;s=s[:m.start()]+s[m.end():]
s=s.replace(''' * Starts a for-in loop over a value: lists the enumerable string keys of
 * an object and its chain (a key shadowed by a nearer property is listed
 * once, by the nearer one), or a string's indices; undefined, null and the
 * other primitives list nothing.''',''' * Starts a lazy for-in loop over the boxed value and its prototype chain.
 * Undefined and null produce an empty iterator.  Each next call checks
 * actual descriptors before yielding an enumerable string name once.''')
p.write_text(s)
