int vm_for_in_start(struct vm_realm *realm, vm_value value, vm_value *iterator);
int vm_for_in_next(struct vm_realm *realm, vm_value iterator, vm_value *key, int *done);
static void access_for_in_trace(struct vm_heap *heap, struct vm_cell *cell);
static void access_for_in_finalize(struct vm_heap *heap, struct vm_cell *cell);
int main(int argc, char **argv);
static int for_in_descriptor(struct vm_object *object, vm_value key, struct vm_property *property);
static int for_in_pressure(struct page *page);

int
vm_for_in_start(
	struct vm_realm *realm,
	vm_value value,
	vm_value *iterator)
{
	struct access_for_in *state;
	struct vm_cell *roots[3];
	vm_value object;
	unsigned index;
	unsigned registered;
	int is_cell;
	int status;

	/* Direct native inputs and the managed caller survive boxing and iterator allocation. */
	memset(roots, 0, sizeof(roots));
	if (realm->managed)
		roots[0] = &realm->cell;
	is_cell = vm_value_is_cell(value);
	if (is_cell)
		roots[1] = vm_value_as_cell(value);
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup owns the slot only after root registration succeeds. */
		registered++;
	}

	/* Nullish loop heads are empty; every other primitive includes its boxed prototype chain. */
	object = VM_VALUE_NULL;
	if (value != VM_VALUE_UNDEFINED && value != VM_VALUE_NULL) {
		status = vm_to_object(realm, value, &object);
		if (status != 0)
			goto cleanup;
		roots[1] = vm_value_as_cell(object);
	}

	/* Publish only a fully initialized private cell; property methods run when next first visits a level. */
	state = vm_heap_alloc(realm->heap, &access_for_in_type, sizeof(*state));
	if (state == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Both empty vectors are safe to trace and finalize before any user trap is invoked. */
	state->object = object;
	wb_vector_init(&state->keys, sizeof(vm_value));
	wb_vector_init(&state->visited, sizeof(vm_value));
	state->index = 0;
	state->loaded = 0;
	roots[2] = &state->cell;
	*iterator = vm_value_cell(state);

	/* Every acquired registration retires on success and all allocation failures. */
cleanup:
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Report why boxing or state allocation could not finish. */
	if (status != 0)
		return status;

	/* Succeeded: the caller owns a lazy for-in iterator. */
	return 0;
}

int
vm_for_in_next(
	struct vm_realm *realm,
	vm_value iterator,
	vm_value *key,
	int *done)
{
	struct access_for_in *state;
	struct vm_descriptor descriptor;
	struct vm_string *string;
	struct vm_cell *roots[2];
	vm_value candidate;
	vm_value canonical;
	vm_value prototype;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_symbol;
	int listed;
	int found;
	int status;

	/* Only the private iterator kind belongs in the bytecode's iterator register. */
	*done = 1;
	*key = VM_VALUE_UNDEFINED;
	is_cell = vm_value_is_cell(iterator);
	if (!is_cell)
		return EINVAL;
	state = (struct access_for_in *)vm_value_as_cell(iterator);
	if (state->cell.type != &access_for_in_type)
		return EINVAL;

	/* A bare native caller relies on this operation to retain its realm and all iterator-owned state. */
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &state->cell;
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup may retire this root only after acquisition succeeds. */
		registered++;
	}

	/* Finish one own-key list before obtaining the next actual prototype. */
	while (state->object != VM_VALUE_NULL) {
		if (!state->loaded) {
			/* A fresh level collects keys once, while the state tracer retains every appended entry. */
			wb_vector_clear(&state->keys);
			state->index = 0;
			status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(state->object), &state->keys);
			if (status != 0)
				goto cleanup;

			/* Subsequent next calls resume this snapshot rather than invoking OwnPropertyKeys again. */
			state->loaded = 1;
		}

		/* A processed present name shadows prototypes even when its descriptor is not enumerable. */
		while (state->index < state->keys.count) {
			candidate = *(vm_value *)wb_vector_at(&state->keys, state->index);
			state->index++;
			is_symbol = access_is_symbol(candidate);
			if (is_symbol)
				continue;

			/* Canonical property keys compare by value even when a trap returned a fresh non-atom string. */
			status = vm_to_key(realm, candidate, &canonical);
			if (status != 0)
				goto cleanup;
			listed = access_key_listed(&state->visited, state->visited.count, canonical);
			if (listed)
				continue;

			/* Absence does not mark a name visited, so a prototype may still supply that name. */
			status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(state->object), canonical, &descriptor, &found);
			if (status != 0)
				goto cleanup;
			if (!found)
				continue;

			/* Native vector growth does not collect; only descriptor attributes remain relevant afterward. */
			status = wb_vector_push(&state->visited, &canonical);
			if (status != 0)
				goto cleanup;
			if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
				continue;

			/* The yielded name is a string, while its canonical key remains owned by the visited list. */
			status = vm_to_string(realm, canonical, &string);
			if (status != 0)
				goto cleanup;
			*key = vm_value_cell(string);
			*done = 0;
			goto cleanup;
		}

		/* A fresh prototype result transfers directly to the traced current-level slot before another callback. */
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(state->object), &prototype);
		if (status != 0)
			goto cleanup;
		state->object = prototype;

		/* The completed level no longer owns remaining keys; the next iteration must load its successor. */
		wb_vector_clear(&state->keys);
		state->index = 0;
		state->loaded = 0;
	}

	/* Reaching null produces the done result without consulting another property method. */
	status = 0;

	/* Return values need no allocation after the realm and iterator registrations are retired. */
cleanup:
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve original property-method exceptions and native errno after cleanup. */
	if (status != 0)
		return status;

	/* Succeeded: key/done describe this one iterator step. */
	return 0;
}

static void
access_for_in_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct access_for_in *state;

	/* Current prototypes and initialized native key entries remain owned between interpreter steps. */
	state = (struct access_for_in *)cell;
	vm_heap_mark_value(heap, state->object);
	access_keys_trace(heap, &state->keys);
	access_keys_trace(heap, &state->visited);
}

static void
access_for_in_finalize(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct access_for_in *state;

	UNUSED_PARAMETER(heap);

	/* Neither native vector outlives the private iterator cell which owns its storage. */
	state = (struct access_for_in *)cell;
	wb_vector_release(&state->keys);
	wb_vector_release(&state->visited);
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* The parser probe reaches the unchanged production allocation threshold without editing heap policy. */
	status = js_builtin_method(page->realm, page->realm->global, "pressureReadProxy", 0, proxy_parse_pressure);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fresh coercion text must survive a later parser allocation after the toString call frame has retired. */
	status = proxy_script(page->realm,
			      "(function(){var before,r=JSON.parse({toString:function(){var text=['{','\"a\":[1,{\"b\":2}]}'].join('');before=pressureReadProxy();return text;}});return r.a[1].b===2&&pressureReadProxy(true)>before;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Publish only the actual threshold-counter and parsed-value gate after both have passed. */
	puts("native JSON parser threshold collection: passed");

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* A direct CopyDataProperties call must own its bare native inputs and a fresh getter result through target policy. */
	status = spread_copy_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native object copy collection and reclamation: passed");

	/* Direct start and next calls must own their managed caller, private state and source without embedding roots. */
	status = for_in_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native for-in collection and reclamation: passed");

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A primitive receiver's temporary source box must survive later depth conversion and then become reclaimable. */
	status = flat_source_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
for_in_descriptor(
	struct vm_object *object,
	vm_value key,
	struct vm_property *property)
{
	struct vm_cell *cell;
	unsigned index;

	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(key);
	UNUSED_PARAMETER(property);

	/* No allocation after collection can reuse a dead participant address before these liveness checks. */
	vm_heap_collect(for_in_case.heap);
	for (index = 0; index < 3U; index++) {
		cell = vm_heap_find_cell(for_in_case.heap, for_in_case.addresses[index]);
		if (cell == NULL)
			return -EFAULT;
	}

	/* The callback count records a policy that observed all three actual live participants. */
	for_in_case.calls++;

	/* Deliberately preserve a native descriptor errno after observing successful ownership. */
	return -EACCES;
}

static int
for_in_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *source;
	struct vm_cell *roots[3];
	struct vm_cell *pressure;
	struct vm_cell *cell;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value iterator;
	vm_value key;
	vm_value value;
	unsigned index;
	unsigned registered;
	int done;
	int outcome;
	int status;

	/* Register empty setup slots before creating an independent managed caller and a source without realm backedges. */
	memset(roots, 0, sizeof(roots));
	memset(&for_in_case, 0, sizeof(for_in_case));
	for_in_case.heap = page->heap;
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup owns only successfully acquired registry slots. */
		registered++;
	}

	/* The independent realm has no source-object or embedding owner after setup finishes. */
	status = vm_realm_create_managed(page->heap, &caller);
	if (status != 0)
		goto cleanup;
	roots[0] = &caller->cell;
	source = vm_object_create(page->heap, NULL);
	if (source == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A plain stored own key is visible to OwnPropertyKeys without invoking the later descriptor policy. */
	roots[1] = &source->cell;
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The initial ordinary property creates an own-key snapshot before the pure error policy is installed. */
	value = vm_value_int32(1);
	status = vm_object_define(page->heap, source, key, value, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	source->native_operations = &for_in_operations;
	for_in_case.addresses[0] = (uintptr_t)caller;
	for_in_case.addresses[1] = (uintptr_t)source;

	/* The next iterator-cell allocation must collect after the direct start operation accepts ownership. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* No embedding slot or conservative C stack can retain the bare caller and source now. */
	for (index = 0; index < 3U; index++)
		roots[index] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_for_in_start(caller, vm_value_cell(source), &iterator);
	vm_heap_stats(page->heap, &after);
	if (status != 0)
		goto cleanup;
	/* Start must cross the real allocation threshold with its direct inputs retained. */
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* The newly returned private state has no embedding root before next accepts it. */
	for_in_case.addresses[2] = (uintptr_t)vm_value_as_cell(iterator);
	vm_heap_stats(page->heap, &before);
	outcome = vm_for_in_next(caller, iterator, &key, &done);
	vm_heap_stats(page->heap, &after);
	if (outcome != EACCES) {
		status = 1;
		goto cleanup;
	}

	/* The descriptor error must originate from exactly one actual native policy invocation. */
	if (for_in_case.calls != 1U) {
		status = 1;
		goto cleanup;
	}

	/* Next must observe another collection while its private state is its only source owner. */
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* Native descriptor failure must leave the managed caller outside any property-recursion frame. */
	if (caller->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* The error path leaves all three actual cells live until this post-call collection. */
	for (index = 0; index < 3U; index++) {
		cell = vm_heap_find_cell(page->heap, for_in_case.addresses[index]);
		if (cell == NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* The iterator finalizer releases both vectors and no root may keep any participant alive afterward. */
	vm_heap_collect(page->heap);
	for (index = 0; index < 3U; index++) {
		cell = vm_heap_find_cell(page->heap, for_in_case.addresses[index]);
		if (cell != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* Both ownership intervals and final graph reclamation were actually observed. */
	status = 0;

cleanup:
	memset(&for_in_case, 0, sizeof(for_in_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failures after retiring all temporary registry slots. */
	if (status != 0)
		return status;

	/* Succeeded: start and next retained their direct inputs only as long as required. */
	return 0;
}
