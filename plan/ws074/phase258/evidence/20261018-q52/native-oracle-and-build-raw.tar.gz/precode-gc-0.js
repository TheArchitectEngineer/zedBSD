(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 function forInReadKeys(v){var a=[];for(var k in v)a.push(k);return a.join(',');}
 check('forin-gc-in-ownkeys-and-descriptor',function(){var p=makeReadProxy({a:1,b:2},{ownKeys:function(){collectReadProxy();return ['a','b'];},getOwnPropertyDescriptor:function(t,k){collectReadProxy();return Object.getOwnPropertyDescriptor(t,k);}});return forInReadKeys(p)==='a,b';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
