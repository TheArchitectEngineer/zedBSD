(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('forin-native-step '+name+': '+(ok?'PASS':'FAIL'));}
 function keys(v){var a=[];for(var k in v)a.push(k);return a.join(',');}
 check('per-level-lazy-trap-body-sequence',function(){var log=[],p=makeReadProxy({a:1,b:2},{ownKeys:function(){log.push('keys');return ['a','b'];},getOwnPropertyDescriptor:function(t,k){log.push('own:'+k);return Object.getOwnPropertyDescriptor(t,k);},getPrototypeOf:function(){log.push('proto');return null;}});for(var k in p)log.push('body:'+k);return log.join(',')==='keys,own:a,body:a,own:b,body:b,proto';});
 check('absent-own-name-does-not-suppress-prototype',function(){var p=makeReadProxy({},{ownKeys:function(){return ['a'];},getOwnPropertyDescriptor:function(){},getPrototypeOf:function(){return {a:1};}});return keys(p)==='a';});
 check('finite-repeated-prototype-identity-is-not-rejected',function(){var calls=0,p=makeReadProxy({},{ownKeys:function(){return [];},getPrototypeOf:function(){calls++;return calls<4?p:null;}});return keys(p)===''&&calls===4;});
 console.log('forin-native-step controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
