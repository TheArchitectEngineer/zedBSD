from pathlib import Path
import ast,subprocess,json,re,time
q=Path('build/ws074-20261018/q52');tree=ast.parse((q/'protocol.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='helper' for t in n.targets)];assert len(nodes)==1;helper=ast.literal_eval(nodes[0].value);source=(q/'native-step-controls.js').read_bytes();html=q/'step-chrome-controls.html';html.write_bytes(b'<!doctype html><html><body><script>'+helper+b'\n'+source+b'</script></body></html>');cmd=['chromium','--headless','--no-sandbox','--disable-gpu','--allow-file-access-from-files','--user-data-dir=/tmp/ws074-q52-step-'+str(time.time_ns()),'--enable-logging=stderr','--v=0','--virtual-time-budget=5000','--dump-dom',html.resolve().as_uri()];r=subprocess.run(cmd,capture_output=True,timeout=30);(q/'step-chrome.html').write_bytes(r.stdout);(q/'step-chrome.err').write_bytes(r.stderr);rows=[]
for line in r.stderr.decode(errors='replace').splitlines():
 m=re.search(r':CONSOLE(?:\(\d+\)|:\d+)\] "(.*)", source: ',line)
 if m:rows.append(m[1])
(q/'step-chrome.out').write_text('\n'.join(rows)+'\n');proof=dict(command=cmd,returncode=r.returncode,failed=[l for l in rows if l.endswith(': FAIL')],control=rows[-1:]);(q/'step-chrome-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
