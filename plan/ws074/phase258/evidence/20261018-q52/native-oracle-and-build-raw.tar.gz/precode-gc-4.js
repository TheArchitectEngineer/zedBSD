(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 function forInReadKeys(v){var a=[];for(var k in v)a.push(k);return a.join(',');}
 check('forin-gc-ordinary-loop-body-state',function(){var a=[],t={x:1,y:2};for(var k in t){collectReadProxy();a.push(k);}return a.join(',')==='x,y';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
