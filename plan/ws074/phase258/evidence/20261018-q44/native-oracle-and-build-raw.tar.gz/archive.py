from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
q=Path('build/ws074-20261018/q44');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q44');out.mkdir(parents=True,exist_ok=False)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in source.items())
h=json.loads((q/'harness-outcome-audit.json').read_text());assert h['completed']==1508 and not h['whole_pass_losses'] and not h['whole_pass_gains'] and not h['old_pass_callback_losses'] and not h['changes']
p=json.loads((q/'final-protocol.json').read_text());assert p['conditions']==552 and p['native_matches'] and not p['chrome_matches'] and p['chrome_qualified_comparison_complete'] and p['chrome_matching_individual_conditions']==550 and len(p['known_huge_length_differences'])==2 and p['native_global_not_exposed_and_ownership']
public=json.loads((q/'public-precode-final-proof.json').read_text());assert public['native_public_conditions_fixed']==42 and public['new51_genuine_chrome_conditions_all_match']
runs=json.loads((v/'native-runs.json').read_text());assert len(runs)==12 and all(x['returncode']==0 for x in runs)
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
n=json.loads((q/'native-proof.json').read_text());old=json.loads(Path('build/ws074-20261018/q38/native-proof.json').read_text());assert len(n['runs'])==4
for a,b in zip(n['runs'],old['runs']):assert a['callbacks']==b['callbacks'] and a['source_sha256']==b['source_sha256'] and a['returncode']==0 and a['ownership'] and a['end']
validator=json.loads((q/'webidl-validator-proof.json').read_text());a,b=validator['runs'];assert a['callbacks']==b['callbacks'] and [r['status'] for r in a['callbacks']]==[0,0,1] and a['returncode']==b['returncode']==0 and b['ownership']
assert not any(x in (q/'host-build.log').read_text() for x in ['warning:','error:'])
for file in q.glob('target-*.log'):assert not file.read_bytes()
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
style=json.loads((q/'source-audit.json').read_text());assert style['raw_allowed_cleanup']==83 and style['other_checker_findings']==0
archives={}
def archive(label,paths,base):
 mapping={str(p.resolve().relative_to(base.resolve())):p for p in paths};path=out/(label+'.tar.gz')
 with tarfile.open(path,'w:gz') as t:
  for name,p in sorted(mapping.items()):t.add(p,arcname=name,recursive=False)
 with tarfile.open(path,'r:gz') as t:
  count=0
  for member in t:assert t.extractfile(member).read()==mapping[member.name].read_bytes();count+=1
 assert count==len(mapping);archives[label]=dict(sha256=digest(path),members=count,readback_all_members=True)
archive('harness-all-raw',[Path(p) for p in json.loads((q/'harness-files.json').read_text())],v/'after-harness')
paths=[f for f in q.rglob('*') if f.is_file() and f.suffix in ['.py','.sh','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'after-harness' not in f.parts and 'engine' not in f.parts and 'target' not in f.parts and not any(x.endswith('-data') or x=='data' for x in f.parts)];paths.append(v/'engine/proxy-read.js');archive('native-oracle-and-build-raw',paths,q)
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),explicit_source_commit='19b9b9ed6',selection='b7477a764',source_hash_count=len(source),conditions=552,native_pass=552,chrome_pass=550,new_public_conditions=51,native_public_precode_fixed=42,new51_genuine_chrome_match=True,old501_prefix_unchanged=True,all_chrome_equality=False,oracle='q36 classifier primitive filter inherited; q43 huge2 native/primary versus Chrome153 pre-index RangeError retained. All new51 genuine Chrome rows match. No source/expectation/oracle shim edits.',native_pressure=['fresh never-stored Symbol returned by real native ToPrimitive string-hint method; temporary callback root removed before real receiver-boxing allocation triggers strictly later collection','actual installed hasOwnProperty/propertyIsEnumerable keep sole fresh key through boxing, return false, then actual caller/keyObject/Symbol reclamation after VM call','actual installed isFrozen/isSealed propagate native keys EACCES and descriptor negative EACCES through realm APIs while real callback GC retains managed caller/argument, then both actually reclaimed','old own-key accumulated Symbol/prefix/rollback stale-capacity, prototype independent input/output, Delete/extent/IsArray/ToBigInt/typed storage tests maintained'],full_changed_C=style,native_gates=runs,acid3_score=100,acid3_inventory=100,acid3_pixels=0,acid2_existing_pixels=873,original_webidl_q38_same_callbacks=True,additional_validator_negative_rule_callbacks=a['callbacks'],additional_validator_original_intentional_failure_reached=True,additional_validator_q43_before_not_measured=True,harness=h,harness_seconds=json.loads((v/'after-harness/runs.json').read_text())[-1]['seconds'],archives=archives,official_score=1482,denominator=3805,held=0,unattempted=275,static_scripted_crash_reused='q28',all_image_crash_current_pair_not_measured=True,remaining=['for-in/spread/JSON and AnnexB lookup/isPrototypeOf/instanceof realm dispatch','normal target Set with exotic prototype routing','existing internal invariant realm-aware snapshots/nested/call/construct/global Proxy/revocable','array IsArray consumers/immutable-prototype/typed backing and remaining exotic limitations','p258/p100/full target/WS100% incomplete; shared global projections pending','runtime binaries kept at hashed build paths, not embedded in archives'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for path in [q/'approval-snapshot.md',q/'source-audit.json',q/'final-protocol.json',q/'old-prefix-proof.json',q/'public-precode-final-proof.json',q/'precode-native-proof.json',q/'target-commands-1.json',q/'versions.json',q/'harness-outcome-audit.json',q/'webidl-validator-proof.json',v/'native-runs.json',v/'source-proof.json',v/'source-commit.txt',v/'shared-input-comparison.json',v/'acid/report.json']:
 shutil.copy2(path,out/('acid-report.json' if path.name=='report.json' else path.name))
print('source',summary['source_commit'],'harness changes0',h['counts'],h['callbacks']);print('archives',archives)
