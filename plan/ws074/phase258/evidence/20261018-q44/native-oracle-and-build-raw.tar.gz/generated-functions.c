static int object_own_keys(struct vm_realm *realm, struct vm_object *object, int symbols, struct wb_vector *keys);
static int object_list(struct vm_realm *realm, vm_value value, int what, vm_value *result);
static int object_assign(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_define_properties(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_get_own_property_descriptors(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_has_own(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_has_own_property(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_property_is_enumerable(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_set_integrity(struct vm_realm *realm, struct vm_object *object, int level);
static int object_test_integrity(struct vm_realm *realm, struct vm_object *object, int level, int *holds);
static int object_is_frozen(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_is_sealed(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static void object_trace_descriptor(struct vm_heap *heap, void *context);
int main(int argc, char **argv);
static int consumer_key_primitive(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int consumer_error_keys(struct vm_heap *heap, struct vm_object *object, struct wb_vector *keys);
static int consumer_error_descriptor(struct vm_object *object, vm_value key, struct vm_property *property);
static int object_consumers_pressure(struct page *page);

static int
object_own_keys(
	struct vm_realm *realm,
	struct vm_object *object,
	int symbols,
	struct wb_vector *keys)
{
	struct wb_vector all;
	vm_value key;
	size_t item;
	int is_int32;
	int is_string;
	int status;

	/* Every own key in order (indices, strings, symbols). */
	wb_vector_init(&all, sizeof(vm_value));
	status = vm_own_property_keys(realm, object, &all);

	/* Those wanted. */
	for (item = 0; status == 0 && item < all.count; item++) {
		key = *(vm_value *)wb_vector_at(&all, item);
		is_int32 = vm_value_is_int32(key);
		is_string = vm_value_is_string(key);
		if (!is_int32 && !is_string && !symbols)
			continue;
		status = wb_vector_push(keys, &key);
	}

	/* The full list is no longer needed. */
	wb_vector_release(&all);
	if (status != 0)
		return status;

	/* Succeeded: the keys. */
	return 0;
}

static int
object_list(
	struct vm_realm *realm,
	vm_value value,
	int what,
	vm_value *result)
{
	struct wb_vector keys;
	struct wb_vector items;
	struct vm_descriptor descriptor;
	struct vm_cell *roots[3];
	vm_value object;
	vm_value key;
	vm_value name;
	vm_value property;
	vm_value pair[2];
	vm_value item;
	size_t index;
	unsigned registered;
	int found;
	int keys_traced;
	int items_traced;
	int is_cell;
	int status;

	/* The object and its own string keys. */
	status = vm_to_object(realm, value, &object);
	if (status != 0)
		return status;
	roots[0] = vm_value_as_cell(object);
	roots[1] = NULL;
	roots[2] = NULL;
	registered = 0;

	/* Empty native vectors make root-registration failures share the same ownership cleanup. */
	wb_vector_init(&keys, sizeof(vm_value));
	wb_vector_init(&items, sizeof(vm_value));
	keys_traced = 0;
	items_traced = 0;

	/* Register each temporary object/value slot before enumeration begins. */
	while (registered < 3U) {
		status = vm_heap_add_root(realm->heap, &roots[registered]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Native vectors retain keys and entries across property getters. */
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	keys_traced = 1;
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &items);
	if (status != 0)
		goto cleanup;
	items_traced = 1;
	status = object_own_keys(realm, (struct vm_object *)vm_value_as_cell(object), 0, &keys);

	/* Each one still there and enumerable. */
	for (index = 0; status == 0 && index < keys.count; index++) {
		key = *(vm_value *)wb_vector_at(&keys, index);
		status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
		if (status != 0)
			break;

		/* Absent or nonenumerable properties contribute no copied entry. */
		if (!found || (descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
			continue;
		status = object_key_value(realm, key, &name);
		if (status != 0)
			break;
		roots[1] = NULL;
		is_cell = vm_value_is_cell(name);
		if (is_cell)
			roots[1] = vm_value_as_cell(name);

		/* The key, the value, or both. */
		item = name;
		if (what != OBJECT_LIST_KEYS) {
			status = vm_get(realm, object, key, &property);
			if (status != 0)
				break;
			roots[2] = NULL;
			is_cell = vm_value_is_cell(property);
			if (is_cell)
				roots[2] = vm_value_as_cell(property);
			item = property;
		}

		/* An entry is a pair. */
		if (what == OBJECT_LIST_ENTRIES) {
			pair[0] = name;
			pair[1] = property;
			status = js_builtin_array(realm, pair, 2, &item);
			if (status != 0)
				break;
		}

		/* It joins the list. */
		status = wb_vector_push(&items, &item);
	}

	/* The array. */
	if (status == 0)
		status = js_builtin_array(realm, items.items, (uint32_t)items.count, result);

cleanup:
	/* Native key and item vectors stop tracing after result publication. */
	if (items_traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &items);
	if (keys_traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);
	wb_vector_release(&items);

	/* Converted object and temporary values leave the root set. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Failed enumeration does not publish a partial array. */
	if (status != 0)
		return status;

	/* Succeeded: the array. */
	return 0;
}

static int
object_assign(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_cell *roots[3];
	vm_value target;
	vm_value source;
	vm_value key;
	vm_value value;
	unsigned index;
	unsigned registered;
	size_t item;
	int found;
	int traced;
	int is_cell;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The target as an object. */
	status = vm_to_object(realm, js_argument(args, count, 0), &target);
	if (status != 0)
		return status;
	roots[0] = vm_value_as_cell(target);
	roots[1] = NULL;
	roots[2] = NULL;
	registered = 0;

	/* Empty native vectors make root-registration failures share the same ownership cleanup. */
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;

	/* Register each temporary input slot before any callback can collect it. */
	while (registered < 3U) {
		status = vm_heap_add_root(realm->heap, &roots[registered]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Copied source key lists remain rooted while descriptor, read and write callbacks run. */
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* Visit nonnull sources in argument order, with one complete key snapshot per source. */
	for (index = 1; index < count; index++) {
		if (args[index] == VM_VALUE_UNDEFINED || args[index] == VM_VALUE_NULL)
			continue;
		status = vm_to_object(realm, args[index], &source);
		if (status == 0) {
			roots[1] = vm_value_as_cell(source);
			wb_vector_clear(&keys);
			status = object_own_keys(realm, (struct vm_object *)vm_value_as_cell(source), 1, &keys);
		}

		/* Each own enumerable property, read and set (strictly: a refusal throws). */
		for (item = 0; status == 0 && item < keys.count; item++) {
			key = *(vm_value *)wb_vector_at(&keys, item);
			status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(source), key, &descriptor, &found);
			if (status != 0)
				break;

			/* Absent or nonenumerable properties contribute no copied entry. */
			if (!found || (descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
				continue;
			status = vm_get(realm, source, key, &value);
			if (status == 0) {
				roots[2] = NULL;
				is_cell = vm_value_is_cell(value);
				if (is_cell)
					roots[2] = vm_value_as_cell(value);
				status = vm_set(realm, target, key, value, 1);
			}
		}

		/* A failure leaves the rest. */
		if (status != 0) {
			goto cleanup;
		}
	}

cleanup:
	/* Releases copied keys before converted sources and target leave scope. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);

	/* Every registered input root is removed after the final property write. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* A failed read or write does not publish a target result. */
	if (status != 0)
		return status;

	/* Succeeded: the target. */
	*result = target;
	return 0;
}

static int
object_define_properties(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct wb_vector keys;
	struct wb_vector descriptors;
	struct vm_descriptor descriptor;
	struct vm_descriptor own;
	struct vm_object *object;
	struct vm_cell *properties_root;
	vm_value properties;
	vm_value key;
	vm_value value;
	size_t item;
	int found;
	int keys_traced;
	int descriptors_traced;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The object, and the properties as an object. */
	status = object_require(realm, js_argument(args, count, 0), "Object.defineProperties called on non-object", &object);
	if (status != 0)
		return status;
	status = vm_to_object(realm, js_argument(args, count, 1), &properties);
	if (status != 0)
		return status;
	properties_root = vm_value_as_cell(properties);
	status = vm_heap_add_root(realm->heap, &properties_root);
	if (status != 0)
		return status;

	/* All the descriptors first (a bad one defines nothing), then each definition. */
	wb_vector_init(&keys, sizeof(vm_value));
	wb_vector_init(&descriptors, sizeof(struct vm_descriptor));
	keys_traced = 0;
	descriptors_traced = 0;
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	keys_traced = 1;
	status = vm_heap_add_tracer(realm->heap, object_trace_descriptors, &descriptors);
	if (status != 0)
		goto cleanup;
	descriptors_traced = 1;
	status = object_own_keys(realm, (struct vm_object *)vm_value_as_cell(properties), 1, &keys);

	/* Convert every enumerable descriptor before any definition can change the target. */
	for (item = 0; status == 0 && item < keys.count; item++) {
		key = *(vm_value *)wb_vector_at(&keys, item);
		status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(properties), key, &own, &found);
		if (status != 0)
			break;

		/* Skipped keys retain an empty sentinel so snapshot positions remain aligned. */
		if (!found || (own.attributes & VM_PROPERTY_ENUMERABLE) == 0U) {
			memset(&descriptor, 0, sizeof(descriptor));
			descriptor.has = 0xffffffffU;
			status = wb_vector_push(&descriptors, &descriptor);
			continue;
		}

		/* An enumerable one's descriptor. */
		status = vm_get(realm, properties, key, &value);
		if (status == 0)
			status = object_to_descriptor(realm, value, &descriptor);
		if (status == 0)
			status = wb_vector_push(&descriptors, &descriptor);
	}

	/* Then each definition. */
	for (item = 0; status == 0 && item < keys.count; item++) {
		key = *(vm_value *)wb_vector_at(&keys, item);
		descriptor = *(struct vm_descriptor *)wb_vector_at(&descriptors, item);
		if (descriptor.has == 0xffffffffU)
			continue;
		status = object_define_or_throw(realm, object, key, &descriptor);
	}

cleanup:
	/* All native copies and converted property input leave the root set. */
	if (descriptors_traced)
		vm_heap_remove_tracer(realm->heap, object_trace_descriptors, &descriptors);
	if (keys_traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	vm_heap_remove_root(realm->heap, &properties_root);
	wb_vector_release(&keys);
	wb_vector_release(&descriptors);
	if (status != 0)
		return status;

	/* Succeeded: the object. */
	*result = vm_value_cell(object);
	return 0;
}

static int
object_get_own_property_descriptors(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_object *made;
	struct vm_cell *roots[3];
	vm_value object;
	vm_value key;
	vm_value value;
	size_t item;
	unsigned registered;
	int found;
	int traced;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The object and the result. */
	status = vm_to_object(realm, js_argument(args, count, 0), &object);
	if (status != 0)
		return status;
	roots[0] = vm_value_as_cell(object);
	status = vm_heap_add_root(realm->heap, &roots[0]);
	if (status != 0)
		return status;
	made = vm_object_create(realm->heap, realm->object_prototype);
	if (made == NULL) {
		vm_heap_remove_root(realm->heap, &roots[0]);
		return ENOMEM;
	}

	/* The new descriptor map stays live until every property is published. */
	roots[1] = &made->cell;
	roots[2] = NULL;
	registered = 1;

	/* Empty native vectors make root-registration failures share the same ownership cleanup. */
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;

	/* Register each temporary input slot before any callback can collect it. */
	while (registered < 3U) {
		status = vm_heap_add_root(realm->heap, &roots[registered]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Each own property's descriptor. */
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;
	status = object_own_keys(realm, (struct vm_object *)vm_value_as_cell(object), 1, &keys);

	/* Each still-existing own property contributes one independently rooted descriptor representation. */
	for (item = 0; status == 0 && item < keys.count; item++) {
		key = *(vm_value *)wb_vector_at(&keys, item);
		status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
		if (status != 0)
			break;

		/* Keys whose properties disappeared contribute no descriptor map entry. */
		if (!found)
			continue;
		status = object_from_descriptor(realm, &descriptor, &value);
		if (status == 0) {
			roots[2] = vm_value_as_cell(value);
			status = vm_object_define(realm->heap, made, key, value, VM_PROPERTY_DEFAULT);
		}
	}

cleanup:
	/* The native key list stops tracing after the definitions finish. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);

	/* The converted source and unpublished result no longer need roots. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* A failed descriptor conversion leaves no published map. */
	if (status != 0)
		return status;

	/* Succeeded: the descriptors. */
	*result = vm_value_cell(made);
	return 0;
}

static int
object_has_own(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *object_root;
	vm_value object;
	vm_value key;
	int found;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The object, then the key. */
	status = vm_to_object(realm, js_argument(args, count, 0), &object);
	if (status != 0)
		return status;
	object_root = vm_value_as_cell(object);
	status = vm_heap_add_root(realm->heap, &object_root);
	if (status != 0)
		return status;
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	if (status != 0)
		goto cleanup;

	/* Ask the actual internal own-property method without invoking its value getter. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
	if (status != 0)
		goto cleanup;

	/* Successful descriptor inspection now supplies the requested presence or flag result. */
	*result = vm_value_boolean(found);

cleanup:
	/* The converted source remains live through key conversion and every descriptor trap. */
	vm_heap_remove_root(realm->heap, &object_root);
	if (status != 0)
		return status;

	/* Succeeded: the completed own-property operation supplied the Boolean. */
	return 0;
}

static int
object_has_own_property(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *key_root;
	vm_value object;
	vm_value key;
	int found;
	int is_cell;
	int status;

	/* The key, then the object. */
	status = vm_to_key(realm, js_argument(args, count, 0), &key);
	if (status != 0)
		return status;
	/* A newly returned Symbol key must survive any receiver-boxing allocation. */
	key_root = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		key_root = vm_value_as_cell(key);
	status = vm_heap_add_root(realm->heap, &key_root);
	if (status != 0)
		return status;
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		goto cleanup;

	/* Ask the actual internal own-property method without invoking its value getter. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
	if (status != 0)
		goto cleanup;

	/* Successful descriptor inspection now supplies the requested presence or flag result. */
	*result = vm_value_boolean(found);

cleanup:
	/* The converted key stops being a native owner after the complete inspection. */
	vm_heap_remove_root(realm->heap, &key_root);
	if (status != 0)
		return status;

	/* Succeeded: the completed descriptor operation supplied the Boolean. */
	return 0;
}

static int
object_property_is_enumerable(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *key_root;
	vm_value object;
	vm_value key;
	int found;
	int is_cell;
	int enumerable;
	int status;

	/* The key, then the object. */
	status = vm_to_key(realm, js_argument(args, count, 0), &key);
	if (status != 0)
		return status;
	/* A newly returned Symbol key must survive any receiver-boxing allocation. */
	key_root = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		key_root = vm_value_as_cell(key);
	status = vm_heap_add_root(realm->heap, &key_root);
	if (status != 0)
		return status;
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		goto cleanup;

	/* Ask the actual own descriptor before inspecting its scalar enumerable flag. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
	if (status != 0)
		goto cleanup;

	/* Successful descriptor inspection now supplies the requested presence or flag result. */
	enumerable = 0;
	if (found && (descriptor.attributes & VM_PROPERTY_ENUMERABLE) != 0U)
		enumerable = 1;
	*result = vm_value_boolean(enumerable);

cleanup:
	/* The converted key stops being a native owner after the complete inspection. */
	vm_heap_remove_root(realm->heap, &key_root);
	if (status != 0)
		return status;

	/* Succeeded: the completed descriptor operation supplied the Boolean. */
	return 0;
}

static int
object_set_integrity(
	struct vm_realm *realm,
	struct vm_object *object,
	int level)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_descriptor change;
	struct vm_cell *object_root;
	vm_value key;
	size_t item;
	int found;
	int done;
	int traced;
	int status;

	/* The original object remains live across every separate trap and partial definition. */
	object_root = &object->cell;
	status = vm_heap_add_root(realm->heap, &object_root);
	if (status != 0)
		return status;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* PreventExtensions runs before enumeration or any property definition. */
	status = vm_prevent_extensions(realm, object, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		status = vm_throw_type_error(realm, "The object refuses changing its integrity.");
		goto cleanup;
	}

	/* Sealing defines configurable:false directly; only freezing first asks each key for its current descriptor. */
	status = object_own_keys(realm, object, 1, &keys);
	if (status != 0)
		goto cleanup;
	for (item = 0; item < keys.count; item++) {
		key = ((vm_value *)keys.items)[item];
		memset(&change, 0, sizeof(change));
		change.has = VM_HAS_CONFIGURABLE;
		if (level == OBJECT_FROZEN) {
			status = vm_get_own_property(realm, object, key, &descriptor, &found);
			if (status != 0)
				goto cleanup;
			if (!found)
				continue;

			/* Freezing a data property adds writable:false without copying its value or any accessor payload. */
			if ((descriptor.has & VM_HAS_VALUE) != 0U)
				change.has |= VM_HAS_WRITABLE;
		}

		/* Each partial definition uses actual Proxy or ordinary policy and throws on Boolean refusal. */
		status = vm_define_own_property(realm, object, key, &change, &done);
		if (status != 0)
			goto cleanup;
		if (!done) {
			status = vm_throw_type_error(realm, "A property refuses changing its integrity.");
			goto cleanup;
		}
	}

	/* All definitions completed in their original key order. */
	status = 0;

cleanup:
	/* Neither copied keys nor the converted input object remain rooted after completion. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(realm->heap, &object_root);
	if (status != 0)
		return status;

	/* Succeeded: every actual own property has the requested integrity level. */
	return 0;
}

static int
object_test_integrity(
	struct vm_realm *realm,
	struct vm_object *object,
	int level,
	int *holds)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_cell *object_root;
	vm_value key;
	size_t item;
	int found;
	int extensible;
	int traced;
	int status;

	/* The original input and every copied key survive reentrant extent, key and descriptor traps. */
	*holds = 0;
	object_root = &object->cell;
	status = vm_heap_add_root(realm->heap, &object_root);
	if (status != 0)
		return status;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* An extensible object fails without enumerating or inspecting any property. */
	status = vm_is_extensible(realm, object, &extensible);
	if (status != 0)
		goto cleanup;
	if (extensible)
		goto cleanup;

	/* Inspect own descriptors in order and stop at the first violation of the requested level. */
	*holds = 1;
	status = object_own_keys(realm, object, 1, &keys);
	if (status != 0)
		goto cleanup;
	for (item = 0; item < keys.count; item++) {
		key = ((vm_value *)keys.items)[item];
		status = vm_get_own_property(realm, object, key, &descriptor, &found);
		if (status != 0)
			goto cleanup;
		if (!found)
			continue;

		/* Configurable properties violate both sealing and freezing. */
		if ((descriptor.attributes & VM_PROPERTY_CONFIGURABLE) != 0U) {
			*holds = 0;
			break;
		}

		/* Only freezing constrains writable data properties; accessor payloads are not inspected. */
		if (level == OBJECT_FROZEN &&
		    (descriptor.has & VM_HAS_VALUE) != 0U &&
		    (descriptor.attributes & VM_PROPERTY_WRITABLE) != 0U) {
			*holds = 0;
			break;
		}
	}

	/* A false integrity result is a successful operation, distinct from any thrown trap or errno. */
	status = 0;

cleanup:
	/* Copied keys and the original object cease to be native owners on every exit. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(realm->heap, &object_root);
	if (status != 0)
		return status;

	/* Succeeded: holds reports the completed internal integrity inspection. */
	return 0;
}

static int
object_is_frozen(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value value;
	int is_object;
	int frozen;
	int status;

	UNUSED_PARAMETER(this_value);

	/* A primitive is. */
	value = js_argument(args, count, 0);
	*result = VM_VALUE_TRUE;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* The actual integrity operation reports status separately from its Boolean. */
	status = object_test_integrity(realm, (struct vm_object *)vm_value_as_cell(value), OBJECT_FROZEN, &frozen);
	if (status != 0)
		return status;

	/* Successful integrity inspection reports the requested boolean. */
	*result = vm_value_boolean(frozen);
	return 0;
}

static int
object_is_sealed(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value value;
	int is_object;
	int sealed;
	int status;

	UNUSED_PARAMETER(this_value);

	/* A primitive is. */
	value = js_argument(args, count, 0);
	*result = VM_VALUE_TRUE;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* The actual integrity operation reports status separately from its Boolean. */
	status = object_test_integrity(realm, (struct vm_object *)vm_value_as_cell(value), OBJECT_SEALED, &sealed);
	if (status != 0)
		return status;

	/* Successful integrity inspection reports the requested boolean. */
	*result = vm_value_boolean(sealed);
	return 0;
}

static void
object_trace_descriptor(
	struct vm_heap *heap,
	void *context)
{
	struct vm_descriptor *descriptor;

	/* Skipped nonenumerable entries use an empty sentinel rather than a meaningful descriptor. */
	descriptor = context;
	if (descriptor->has == 0xffffffffU)
		return;

	/* Presence flags alone decide which payload slots contain actual language values. */
	if ((descriptor->has & VM_HAS_VALUE) != 0U)
		vm_heap_mark_value(heap, descriptor->value);
	if ((descriptor->has & VM_HAS_GET) != 0U)
		vm_heap_mark_value(heap, descriptor->getter);
	if ((descriptor->has & VM_HAS_SET) != 0U)
		vm_heap_mark_value(heap, descriptor->setter);
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
consumer_key_primitive(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_symbol *symbol;
	struct vm_cell *root;
	struct vm_cell *pressure;
	struct vm_heap_stats stats;
	int status;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Only this callback temporarily owns the fresh Symbol before ToPropertyKey hands it to its caller. */
	root = NULL;
	status = vm_heap_add_root(realm->heap, &root);
	if (status != 0)
		return status;
	symbol = vm_symbol_create(realm->heap, VM_VALUE_UNDEFINED);
	if (symbol == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Its integer address is an observation, never a registry or shape-cache edge. */
	root = &symbol->cell;
	object_consumer_case.key_address = (uintptr_t)symbol;
	vm_heap_collect(realm->heap);
	pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A strictly later collection must occur after this callback's local Symbol root retires. */
	vm_heap_stats(realm->heap, &stats);
	object_consumer_case.callback_collections = stats.collections;
	object_consumer_case.calls++;
	*result = vm_value_cell(symbol);
	status = 0;

cleanup:
	/* The returned value has no callback-owned root while the prototype method boxes its receiver. */
	vm_heap_remove_root(realm->heap, &root);
	if (status != 0)
		return status;

	/* Succeeded: the caller must now retain the fresh Symbol across its next real allocation. */
	return 0;
}

static int
consumer_error_keys(
	struct vm_heap *heap,
	struct vm_object *object,
	struct wb_vector *keys)
{
	struct vm_cell *found;

	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(keys);

	/* Native policy never invokes user script; VM call ownership must retain its managed caller and argument. */
	vm_heap_collect(heap);
	found = vm_heap_find_cell(heap, object_consumer_case.caller_address);
	if (found == NULL)
		return EFAULT;
	found = vm_heap_find_cell(heap, object_consumer_case.input_address);
	if (found == NULL)
		return EFAULT;
	object_consumer_case.calls++;

	/* The explicit native errno is expected, without a Boolean result or synthetic language exception. */
	return EACCES;
}

static int
consumer_error_descriptor(
	struct vm_object *object,
	vm_value key,
	struct vm_property *property)
{
	struct vm_cell *found;

	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(key);
	UNUSED_PARAMETER(property);

	/* Native descriptors may collect but cannot run script or retire their current execution owner. */
	vm_heap_collect(object_consumer_case.heap);
	found = vm_heap_find_cell(object_consumer_case.heap, object_consumer_case.caller_address);
	if (found == NULL)
		return -EFAULT;
	found = vm_heap_find_cell(object_consumer_case.heap, object_consumer_case.input_address);
	if (found == NULL)
		return -EFAULT;
	object_consumer_case.calls++;

	/* The realm descriptor API must preserve this errno instead of negating a language throw status. */
	return -EACCES;
}

static int
object_consumers_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *input;
	struct vm_cell *roots[2];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value owner;
	vm_value function;
	vm_value key;
	vm_value argument;
	vm_value receiver;
	vm_value answer;
	const char *name;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int done;
	int status;

	/* No static observation records a managed pointer or supplies a collector edge. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Prototype key boxing, key-list errno and descriptor errno each use actual installed native methods. */
	for (mode = 0; mode < 4U; mode++) {
		memset(&object_consumer_case, 0, sizeof(object_consumer_case));
		object_consumer_case.heap = page->heap;
		status = vm_realm_create_managed(page->heap, &caller);
		if (status != 0)
			goto cleanup;
		roots[0] = &caller->cell;
		object_consumer_case.caller_address = (uintptr_t)caller;
		input = vm_object_create(page->heap, page->realm->object_prototype);
		if (input == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The argument is rooted only until the production VM call accepts ownership. */
		roots[1] = &input->cell;
		object_consumer_case.input_address = (uintptr_t)input;
		if (mode < 2U) {
			status = js_builtin_method(page->realm, input, "toString", 0, consumer_key_primitive);
			if (status != 0)
				goto cleanup;
			owner = vm_value_cell(page->realm->object_prototype);
			name = "hasOwnProperty";
			if (mode == 1U)
				name = "propertyIsEnumerable";
			receiver = vm_value_int32(1);
			argument = vm_value_cell(input);
		} else {
			key = vm_key_from_ascii(page->heap, "x");
			if (key == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}

			/* A real stored property is present before the target becomes nonextensible. */
			status = vm_object_define(page->heap, input, key, VM_VALUE_TRUE, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
			if (mode == 2U)
				input->native_operations = &consumer_error_keys_operations;
			else
				input->native_operations = &consumer_error_descriptor_operations;
			status = vm_prevent_extensions(page->realm, input, &done);
			if (status != 0)
				goto cleanup;
			if (!done) {
				status = 1;
				goto cleanup;
			}

			/* Integrity functions are fetched from the real installed Object constructor. */
			key = vm_key_from_ascii(page->heap, "Object");
			if (key == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}

			/* The intrinsic constructor already owns these methods; lookup adds no fixture implementation. */
			status = vm_get(page->realm, vm_value_cell(page->realm->global), key, &owner);
			if (status != 0)
				goto cleanup;
			name = "isFrozen";
			if (mode == 3U)
				name = "isSealed";
			receiver = owner;
			argument = vm_value_cell(input);
		}

		/* Direct native invocation still uses vm_call, whose contract retains caller realm, callee and arguments. */
		key = vm_key_from_ascii(page->heap, name);
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The same production function is invoked after every temporary setup root is dropped. */
		status = vm_get(page->realm, owner, key, &function);
		if (status != 0)
			goto cleanup;
		roots[0] = NULL;
		roots[1] = NULL;
		vm_heap_stats(page->heap, &before);
		status = vm_call(caller, function, receiver, &argument, 1, &answer);
		vm_heap_stats(page->heap, &after);
		if (mode >= 2U) {
			if (status != EACCES) {
				status = 1;
				goto cleanup;
			}

			/* Native errors remain status values and never become successful integrity Booleans. */
			status = 0;
		}

		/* Every mode must reach exactly its one genuine native callback and collect during the call. */
		if (status != 0)
			goto cleanup;
		if (object_consumer_case.calls != 1U || after.collections <= before.collections) {
			status = 1;
			goto cleanup;
		}

		/* The two prototype methods report missing Symbol keys after boxing the primitive receiver. */
		if (mode < 2U) {
			if (answer != VM_VALUE_FALSE || after.collections <= object_consumer_case.callback_collections) {
				status = 1;
				goto cleanup;
			}

			/* This Symbol survived a strictly later boxing collection after the callback-local root had retired. */
			found = vm_heap_find_cell(page->heap, object_consumer_case.key_address);
			if (found == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* Managed caller and source argument remain present after their collection-bearing native call. */
		found = vm_heap_find_cell(page->heap, object_consumer_case.caller_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* No returned Boolean or errno may retain the former input object. */
		found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* Completion retires both VM-call ownership and each consumer's native temporary roots. */
		vm_heap_collect(page->heap);
		found = vm_heap_find_cell(page->heap, object_consumer_case.caller_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* The argument is actually reclaimed while only intrinsic methods remain globally owned. */
		found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* Never-stored fresh Symbol keys also become actually reclaimable after the public operation ends. */
		if (mode < 2U) {
			found = vm_heap_find_cell(page->heap, object_consumer_case.key_address);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}
	}

	/* All native and language statuses preserved their proper outcome and ownership conventions. */
	status = 0;

cleanup:
	/* Observation addresses never survive this synchronous native consumer case. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve a failure only after retiring every setup registration. */
	if (status != 0)
		return status;

	/* Succeeded: fresh-key boxing, native errors and all completed input/key reclamations were observed. */
	return 0;
}
