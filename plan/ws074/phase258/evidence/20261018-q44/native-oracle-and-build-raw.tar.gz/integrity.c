/* Seals or freezes an object through its actual realm-aware internal methods. */
static int
object_set_integrity(
	struct vm_realm *realm,
	struct vm_object *object,
	int level)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_descriptor change;
	struct vm_cell *object_root;
	vm_value key;
	size_t item;
	int found;
	int done;
	int traced;
	int status;

	/* The original object remains live across every separate trap and partial definition. */
	object_root = &object->cell;
	status = vm_heap_add_root(realm->heap, &object_root);
	if (status != 0)
		return status;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* PreventExtensions runs before enumeration or any property definition. */
	status = vm_prevent_extensions(realm, object, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		status = vm_throw_type_error(realm, "The object refuses changing its integrity.");
		goto cleanup;
	}

	/* Sealing defines configurable:false directly; only freezing first asks each key for its current descriptor. */
	status = object_own_keys(realm, object, 1, &keys);
	if (status != 0)
		goto cleanup;
	for (item = 0; item < keys.count; item++) {
		key = ((vm_value *)keys.items)[item];
		memset(&change, 0, sizeof(change));
		change.has = VM_HAS_CONFIGURABLE;
		if (level == OBJECT_FROZEN) {
			status = vm_get_own_property(realm, object, key, &descriptor, &found);
			if (status != 0)
				goto cleanup;
			if (!found)
				continue;

			/* Freezing a data property adds writable:false without copying its value or any accessor payload. */
			if ((descriptor.has & VM_HAS_VALUE) != 0U)
				change.has |= VM_HAS_WRITABLE;
		}

		/* Each partial definition uses actual Proxy or ordinary policy and throws on Boolean refusal. */
		status = vm_define_own_property(realm, object, key, &change, &done);
		if (status != 0)
			goto cleanup;
		if (!done) {
			status = vm_throw_type_error(realm, "A property refuses changing its integrity.");
			goto cleanup;
		}
	}

	/* All definitions completed in their original key order. */
	status = 0;

cleanup:
	/* Neither copied keys nor the converted input object remain rooted after completion. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(realm->heap, &object_root);
	if (status != 0)
		return status;

	/* Succeeded: every actual own property has the requested integrity level. */
	return 0;
}

/* Reports actual integrity with an explicit Boolean output and unchanged abrupt-completion status. */
static int
object_test_integrity(
	struct vm_realm *realm,
	struct vm_object *object,
	int level,
	int *holds)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_cell *object_root;
	vm_value key;
	size_t item;
	int found;
	int extensible;
	int traced;
	int status;

	/* The original input and every copied key survive reentrant extent, key and descriptor traps. */
	*holds = 0;
	object_root = &object->cell;
	status = vm_heap_add_root(realm->heap, &object_root);
	if (status != 0)
		return status;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, object_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* An extensible object fails without enumerating or inspecting any property. */
	status = vm_is_extensible(realm, object, &extensible);
	if (status != 0)
		goto cleanup;
	if (extensible)
		goto cleanup;

	/* Inspect own descriptors in order and stop at the first violation of the requested level. */
	*holds = 1;
	status = object_own_keys(realm, object, 1, &keys);
	if (status != 0)
		goto cleanup;
	for (item = 0; item < keys.count; item++) {
		key = ((vm_value *)keys.items)[item];
		status = vm_get_own_property(realm, object, key, &descriptor, &found);
		if (status != 0)
			goto cleanup;
		if (!found)
			continue;

		/* Configurable properties violate both sealing and freezing. */
		if ((descriptor.attributes & VM_PROPERTY_CONFIGURABLE) != 0U) {
			*holds = 0;
			break;
		}

		/* Only freezing constrains writable data properties; accessor payloads are not inspected. */
		if (level == OBJECT_FROZEN &&
		    (descriptor.has & VM_HAS_VALUE) != 0U &&
		    (descriptor.attributes & VM_PROPERTY_WRITABLE) != 0U) {
			*holds = 0;
			break;
		}
	}

	/* A false integrity result is a successful operation, distinct from any thrown trap or errno. */
	status = 0;

cleanup:
	/* Copied keys and the original object cease to be native owners on every exit. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, object_trace_values, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(realm->heap, &object_root);
	if (status != 0)
		return status;

	/* Succeeded: holds reports the completed internal integrity inspection. */
	return 0;
}
