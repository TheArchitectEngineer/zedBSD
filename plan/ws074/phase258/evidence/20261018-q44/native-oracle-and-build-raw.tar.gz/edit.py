from pathlib import Path
import re
q=Path('build/ws074-20261018/q44');p=Path('userland/desktop/libbrowser/js/builtin_object.c');s=p.read_text()
def replace_function(name,transform):
 global s
 m=re.search(r'static (?:int|void)\n'+name+r'\(\n.*?\n\}',s,re.S);assert m,name
 f=transform(m.group());s=s[:m.start()]+f+s[m.end():]
# Own-key callers delegate to the fully verified realm operation, without changing the filtering order.
replace_function('object_own_keys',lambda f:f.replace('vm_object_own_keys(realm->heap, object, &all)','vm_own_property_keys(realm, object, &all)'))
for name in ['object_assign','object_define_properties','object_get_own_property_descriptors','object_list']:
 def convert(f):
  pattern=r'found = vm_get_own_descriptor\((.*?), key, &(descriptor|own)\);\n(\s*)if \(found < 0\) \{\n\s*status = -found;\n\s*break;\n\s*\}'
  f,n=re.subn(pattern,lambda m:'status = vm_get_own_property(realm, '+m[1]+', key, &'+m[2]+', &found);\n'+m[3]+'if (status != 0)\n'+m[3]+'\tbreak;',f);assert n==1,name
  return f
 replace_function(name,convert)
# A single cleanup target is safe because every vector is initialized before any root registration can fail.
for name in ['object_assign','object_list','object_get_own_property_descriptors']:
 def cleanup(f):
  if name=='object_assign':
   init='\twb_vector_init(&keys, sizeof(vm_value));\n\ttraced = 0;\n'
  elif name=='object_list':
   init='\twb_vector_init(&keys, sizeof(vm_value));\n\twb_vector_init(&items, sizeof(vm_value));\n\tkeys_traced = 0;\n\titems_traced = 0;\n'
  else:init='\twb_vector_init(&keys, sizeof(vm_value));\n\ttraced = 0;\n'
  assert init in f,name;f=f.replace(init,'',1);pos=f.index('\twhile (registered <');f=f[:pos]+'\t/* Empty native vectors make root-registration failures share the same ownership cleanup. */\n'+init+f[pos:];f=f.replace('goto roots_cleanup;','goto cleanup;').replace('\nroots_cleanup:\n','\n');return f
 replace_function(name,cleanup)
# Object.hasOwn keeps its converted object through the realm descriptor inspection.
def has_own(f):
 f=f.replace('\tvm_heap_remove_root(realm->heap, &object_root);\n\tif (status != 0)\n\t\treturn status;', '\tif (status != 0)\n\t\tgoto cleanup;')
 f=f.replace('found = vm_get_own_descriptor((struct vm_object *)vm_value_as_cell(object), key, &descriptor);\n\tif (found < 0)\n\t\treturn -found;', 'status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);\n\tif (status != 0)\n\t\tgoto cleanup;')
 f=f.replace('\treturn 0;\n}', '\ncleanup:\n\t/* The converted source remains live through key conversion and every descriptor trap. */\n\tvm_heap_remove_root(realm->heap, &object_root);\n\tif (status != 0)\n\t\treturn status;\n\n\t/* Succeeded: the completed own-property operation supplied the Boolean. */\n\treturn 0;\n}');return f
replace_function('object_has_own',has_own)
# Prototype methods coerce the key first and must retain a fresh Symbol while boxing their receiver.
for name in ['object_has_own_property','object_property_is_enumerable']:
 def prototype_own(f):
  f=f.replace('\tstruct vm_descriptor descriptor;','\tstruct vm_descriptor descriptor;\n\tstruct vm_cell *key_root;').replace('\tint found;','\tint found;\n\tint is_cell;')
  needle='\tstatus = vm_to_object(realm, this_value, &object);\n\tif (status != 0)\n\t\treturn status;'
  assert needle in f
  f=f.replace(needle,'''\t/* A newly returned Symbol key must survive any receiver-boxing allocation. */
	key_root = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		key_root = vm_value_as_cell(key);
	status = vm_heap_add_root(realm->heap, &key_root);
	if (status != 0)
		return status;
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		goto cleanup;''')
  f=f.replace('found = vm_get_own_descriptor((struct vm_object *)vm_value_as_cell(object), key, &descriptor);\n\tif (found < 0)\n\t\treturn -found;', 'status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);\n\tif (status != 0)\n\t\tgoto cleanup;')
  f=f.replace('\treturn 0;\n}', '\ncleanup:\n\t/* The converted key stops being a native owner after the complete inspection. */\n\tvm_heap_remove_root(realm->heap, &key_root);\n\tif (status != 0)\n\t\treturn status;\n\n\t/* Succeeded: the completed descriptor operation supplied the Boolean. */\n\treturn 0;\n}');return f
 replace_function(name,prototype_own)
# Integrity must distinguish VM_THROWN from false instead of negating an abrupt status into a Boolean.
for name,output,level in [('object_is_frozen','frozen','OBJECT_FROZEN'),('object_is_sealed','sealed','OBJECT_SEALED')]:
 def test_wrapper(f):
  f=f.replace('\tint '+output+';','\tint '+output+';\n\tint status;')
  old=output+' = object_test_integrity(realm, (struct vm_object *)vm_value_as_cell(value), '+level+');\n\tif ('+output+' < 0)\n\t\treturn -'+output+';'
  assert old in f
  f=f.replace(old,'status = object_test_integrity(realm, (struct vm_object *)vm_value_as_cell(value), '+level+', &'+output+');\n\tif (status != 0)\n\t\treturn status;');return f
 replace_function(name,test_wrapper)
for name in ['object_set_integrity','object_test_integrity']:
 raw=(q/'integrity.c').read_text();m=re.search(r'static int\n'+name+r'\(\n.*?\n\}',raw,re.S);assert m
 replace_function(name,lambda f,m=m:m.group())
def trace_descriptor(f):
 a=f.index('{');return f[:a]+'''{
	struct vm_descriptor *descriptor;

	/* Skipped nonenumerable entries use an empty sentinel rather than a meaningful descriptor. */
	descriptor = context;
	if (descriptor->has == 0xffffffffU)
		return;

	/* Presence flags alone decide which payload slots contain actual language values. */
	if ((descriptor->has & VM_HAS_VALUE) != 0U)
		vm_heap_mark_value(heap, descriptor->value);
	if ((descriptor->has & VM_HAS_GET) != 0U)
		vm_heap_mark_value(heap, descriptor->getter);
	if ((descriptor->has & VM_HAS_SET) != 0U)
		vm_heap_mark_value(heap, descriptor->setter);
}'''
replace_function('object_trace_descriptor',trace_descriptor)
# Changed normal helper declarations belong after all constant method tables.
names=['object_own_keys','object_list','object_set_integrity','object_test_integrity','object_trace_descriptor'];decls=[]
for name in names:
 m=re.search(r'^static (?:int|void) '+name+r'\([^\n]*;\n',s,re.M);assert m,name;d=m.group();s=s[:m.start()]+s[m.end():]
 if name=='object_test_integrity':d=d.replace('int level);','int level, int *holds);')
 decls.append(d)
i=s.index('static int object_to_descriptor(');s=s[:i]+''.join(decls)+s[i:];p.write_text(s)
