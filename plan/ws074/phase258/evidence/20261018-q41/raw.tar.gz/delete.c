/*
 * Deletes an own property through realm-aware Proxy handling or the existing pure native policy.
 */
int
vm_delete_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	int *deleted)
{
	struct access_read_roots roots;
	int status;

	/* The input and managed owner must survive even a recursion-limit error allocation. */
	*deleted = 0;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = key;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* The ordinary path retains its exact native policy and deletion semantics. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY)
		status = access_proxy_delete(realm, (struct vm_proxy *)object, key, deleted);
	else
		status = vm_object_delete(realm->heap, object, key, deleted);
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: refusal remains a Boolean for the caller's strict-mode policy to interpret. */
	return 0;
}
