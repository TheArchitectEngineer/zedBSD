int vm_delete(struct vm_realm *realm, vm_value base, vm_value key, int strict, vm_value *result);
int vm_delete_property(struct vm_realm *realm, struct vm_object *object, vm_value key, int *deleted);
static int access_proxy_delete(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, int *deleted);
int main(int argc, char **argv);
static int proxy_delete_property(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int delete_collect_participants(void);
static int delete_collect_get_own(struct vm_object *object, vm_value key, struct vm_property *property);
static int delete_collect_native(struct vm_heap *heap, struct vm_object *object, vm_value key, int *handled, int *deleted);
static int delete_pressure(struct page *page);

int
vm_delete(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	int strict,
	vm_value *result)
{
	struct vm_object *object;
	struct vm_string *string;
	vm_value ignored;
	int is_string;
	int is_object;
	int found;
	int deleted;
	int status;

	/* undefined and null have no properties. */
	*result = VM_VALUE_TRUE;
	if (base == VM_VALUE_UNDEFINED || base == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot convert undefined or null to object");
		return status;
	}

	/* A string's length and characters stay; any other property of a primitive is not there. */
	is_object = vm_value_is_object(base);
	if (!is_object) {
		is_string = vm_value_is_string(base);
		found = 0;
		if (is_string) {
			string = (struct vm_string *)vm_value_as_cell(base);
			status = access_string_property(realm, string, key, &ignored, &found);
			if (status != 0)
				return status;
		}

		/* A string keeps its own properties. */
		if (found) {
			*result = VM_VALUE_FALSE;
			status = access_refuse(realm, strict, "Cannot delete property of a string");
			return status;
		}

		/* Any other property of a primitive is not there. */
		return 0;
	}

	/* An object's own property, unless it is not configurable. */
	object = (struct vm_object *)vm_value_as_cell(base);
	status = vm_delete_property(realm, object, key, &deleted);
	if (status != 0)
		return status;
	if (!deleted) {
		*result = VM_VALUE_FALSE;
		status = access_refuse(realm, strict, "Cannot delete property");
		return status;
	}

	/* Succeeded: the property is gone. */
	return 0;
}

int
vm_delete_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	int *deleted)
{
	struct access_read_roots roots;
	int status;

	/* The input and managed owner must survive even a recursion-limit error allocation. */
	*deleted = 0;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = key;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* The ordinary path retains its exact native policy and deletion semantics. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY)
		status = access_proxy_delete(realm, (struct vm_proxy *)object, key, deleted);
	else
		status = vm_object_delete(realm->heap, object, key, deleted);
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: refusal remains a Boolean for the caller's strict-mode policy to interpret. */
	return 0;
}

static int
access_proxy_delete(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	int *deleted)
{
	struct vm_cell *roots[5];
	struct vm_descriptor current;
	struct vm_object *target_object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value args[2];
	vm_value produced;
	unsigned registered;
	unsigned index;
	int is_cell;
	int is_symbol;
	int truth;
	int present;
	int extensible;
	int status;

	/* The outer operation owns realm and original input; these snapshots survive reentrant revocation. */
	target = proxy->target;
	handler = proxy->handler;
	memset(roots, 0, sizeof(roots));
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[0] = vm_value_as_cell(target);
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[1] = vm_value_as_cell(handler);
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[2] = vm_value_as_cell(key);
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Revocation fails before any handler lookup or target observation. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot delete a property of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod preserves getter exceptions, null fallback and noncallable rejection. */
	method_key = vm_key_from_ascii(realm->heap, "deleteProperty");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A missing current method forwards to the original target's actual internal deletion. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_delete_property(realm, (struct vm_object *)vm_value_as_cell(target), key, deleted);
		goto cleanup;
	}

	/* Retain a fresh method before converting the internal numeric representation of a property key. */
	roots[3] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[4] = &string->cell;
	}

	/* The handler receives exactly its original target and string-or-symbol key. */
	args[0] = target;
	args[1] = trap_key;
	status = vm_call(realm, method, handler, args, 2, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (!truth) {
		/* Refusal never observes the target after the trap. */
		status = 0;
		goto cleanup;
	}

	/* A trap may actually delete or reconfigure its target before this post-trap observation. */
	target_object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_get_own_property(realm, target_object, key, &current, &present);
	if (status != 0)
		goto cleanup;
	if (!present) {
		*deleted = 1;
		status = 0;
		goto cleanup;
	}

	/* Only the descriptor's scalar attributes are needed after this point, never any unrooted payload. */
	if ((current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		status = vm_throw_type_error(realm, "Proxy deleteProperty trap concealed a fixed own property");
		goto cleanup;
	}

	/* Existing configurable properties of a nonextensible target cannot be concealed either. */
	status = vm_is_extensible(realm, target_object, &extensible);
	if (status != 0)
		goto cleanup;
	if (!extensible) {
		status = vm_throw_type_error(realm, "Proxy deleteProperty trap concealed a nonextensible target's own property");
		goto cleanup;
	}

	/* A configurable own property on an extensible target may legally remain despite a true trap result. */
	*deleted = 1;
	status = 0;

cleanup:
	/* Retire only acquired snapshots and transient key/method roots on all completion paths. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original error after releasing the helper's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: deleted reports the actual internal operation's Boolean. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_delete_property(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value object;
	vm_value key;
	int is_object;
	int deleted;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Reflection rejects a primitive target before coercing its property key. */
	object = js_argument(args, count, 0);
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Delete target must be an object");
		return status;
	}

	/* The production API owns the completed key before any subsequent allocation or trap. */
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	if (status != 0)
		return status;
	status = vm_delete_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &deleted);
	if (status != 0)
		return status;

	/* Succeeded: report internal refusal directly, without the delete operator's strict policy. */
	*result = vm_value_boolean(deleted);
	return 0;
}

static int
delete_collect_participants(
	void)
{
	struct vm_cell *found;
	unsigned index;

	/* Pure native policy may collect but never runs user script. */
	vm_heap_collect(delete_case.heap);
	for (index = 0; index < 5U; index++) {
		found = vm_heap_find_cell(delete_case.heap, delete_case.addresses[index]);
		if (found == NULL)
			return EFAULT;
	}

	/* Succeeded: owner, target, handler, original Proxy and fresh Symbol all survived this collection. */
	return 0;
}

static int
delete_collect_get_own(
	struct vm_object *object,
	vm_value key,
	struct vm_property *property)
{
	int status;
	int found;

	/* Negative errno remains the get-own callback's distinct failure convention. */
	status = delete_collect_participants();
	if (status != 0)
		return -status;
	delete_case.get_collections++;
	found = vm_object_get_own_ordinary(object, key, property);
	if (found < 0)
		return found;

	/* Succeeded: ordinary descriptor policy reports absence or presence unchanged. */
	return found;
}

static int
delete_collect_native(
	struct vm_heap *heap,
	struct vm_object *object,
	vm_value key,
	int *handled,
	int *deleted)
{
	int status;

	UNUSED_PARAMETER(heap);
	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(key);

	/* The caller must retain its whole operation frame through a native callback collection. */
	*handled = 0;
	*deleted = 0;
	status = delete_collect_participants();
	if (status != 0)
		return status;
	delete_case.delete_collections++;
	if (delete_case.mode == 3U)
		return EACCES;

	/* Succeeded: the unchanged ordinary deletion path now performs the actual mutation. */
	return 0;
}

static int
delete_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_symbol *symbol;
	struct vm_cell *roots[6];
	struct vm_cell *found;
	struct vm_property property;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value proxy;
	vm_value method;
	vm_value key;
	vm_value method_key;
	vm_value owner_key;
	vm_value stored_key;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int deleted;
	int present;
	int status;

	/* This synchronous observer borrows a heap and stores no managed pointer edges. */
	memset(&delete_case, 0, sizeof(delete_case));
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Actual trap deletion, false trap, native fallback and native errno need independent input graphs. */
	for (mode = 0; mode < 4U; mode++) {
		status = vm_realm_create_managed(page->heap, &realm);
		if (status != 0)
			goto cleanup;
		roots[0] = &realm->cell;
		delete_case.heap = page->heap;
		delete_case.mode = mode;
		delete_case.get_collections = 0;
		delete_case.delete_collections = 0;
		delete_case.addresses[0] = (uintptr_t)realm;
		target = vm_object_create(page->heap, NULL);
		if (target == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The native table only observes collection and forwards real ordinary storage policy. */
		roots[1] = &target->cell;
		delete_case.addresses[1] = (uintptr_t)target;
		target->native_operations = &delete_collect_operations;
		handler = vm_object_create(page->heap, NULL);
		if (handler == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* A never-stored fresh Symbol has no registry or shape-cache owner outside the operation frame. */
		roots[2] = &handler->cell;
		delete_case.addresses[2] = (uintptr_t)handler;
		symbol = vm_symbol_create(page->heap, VM_VALUE_UNDEFINED);
		if (symbol == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Temporary setup ownership ends before the tested production operation begins. */
		roots[5] = &symbol->cell;
		delete_case.addresses[4] = (uintptr_t)symbol;
		key = vm_value_cell(symbol);
		stored_key = vm_key_from_ascii(page->heap, "owned");
		if (stored_key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Actual deletion uses an independent ordinary key so the observed Symbol never enters a heap-owned shape. */
		status = vm_object_define(page->heap, target, stored_key, VM_VALUE_TRUE, VM_PROPERTY_DEFAULT);
		if (status != 0)
			goto cleanup;
		method_key = vm_key_from_ascii(page->heap, "deleteProperty");
		owner_key = vm_key_from_ascii(page->heap, "owner");
		if (method_key == VM_VALUE_EMPTY || owner_key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Reentrant revocation makes the helper snapshots responsible for the original target and handler. */
		if (mode == 0U) {
			status = proxy_script(page->realm, "(function(t,k){delete t.owned;revokeReadProxy(this.owner);collectReadProxy();return true;})", &method);
		} else if (mode == 1U) {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return false;})", &method);
		} else {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return undefined;})", &method);
		}

		/* Trap methods and accessor getters use the same real script evaluator and normal handler storage. */
		if (status != 0)
			goto cleanup;
		roots[3] = vm_value_as_cell(method);
		if (mode < 2U)
			status = vm_object_define(page->heap, handler, method_key, method, VM_PROPERTY_DEFAULT);
		else
			status = vm_define_accessor(realm, vm_value_cell(handler), method_key, method, 0);
		if (status != 0)
			goto cleanup;
		roots[3] = NULL;
		status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
		if (status != 0)
			goto cleanup;
		roots[4] = vm_value_as_cell(proxy);
		delete_case.addresses[3] = (uintptr_t)roots[4];
		status = vm_object_define(page->heap, handler, owner_key, proxy, VM_PROPERTY_DEFAULT);
		if (status != 0)
			goto cleanup;

		/* Neither embedding roots nor C stack scanning may retain any operation participant. */
		vm_heap_stats(page->heap, &before);
		for (index = 0; index < 6U; index++)
			roots[index] = NULL;
		status = vm_delete_property(realm, (struct vm_object *)vm_value_as_cell(proxy), key, &deleted);
		vm_heap_stats(page->heap, &after);
		if (mode == 3U) {
			if (status != EACCES) {
				status = 1;
				goto cleanup;
			}

			/* Preserve the native errno without inventing a language exception or successful deletion. */
			status = 0;
		}

		/* Every path must collect while active and restore its native recursion counter. */
		if (status != 0)
			goto cleanup;
		if (after.collections <= before.collections || realm->property_depth != 0U) {
			status = 1;
			goto cleanup;
		}

		/* Successful actual removal is distinct from false trap refusal and native errno. */
		if (mode == 0U || mode == 2U) {
			if (!deleted) {
				status = 1;
				goto cleanup;
			}
		} else if (deleted) {
			status = 1;
			goto cleanup;
		}

		/* Only the true trap reads a target descriptor after returning; the false trap skips it entirely. */
		if (mode == 0U) {
			if (delete_case.get_collections != 1U) {
				status = 1;
				goto cleanup;
			}
		} else if (delete_case.get_collections != 0U) {
			status = 1;
			goto cleanup;
		}

		/* Ordinary native storage policy runs once for actual trap deletion or fallback, never for a false trap. */
		if (mode == 1U) {
			if (delete_case.delete_collections != 0U) {
				status = 1;
				goto cleanup;
			}
		} else if (delete_case.delete_collections != 1U) {
			status = 1;
			goto cleanup;
		}

		/* Observe all five live participants before checking actual ordinary storage without calling policy hooks. */
		for (index = 0; index < 5U; index++) {
			found = vm_heap_find_cell(page->heap, delete_case.addresses[index]);
			if (found == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* Actual trap mutation removes its independent property; native fallback on the missing Symbol preserves it. */
		present = vm_object_get_own_ordinary(target, stored_key, &property);
		if (mode == 0U) {
			if (present != 0) {
				status = 1;
				goto cleanup;
			}
		} else if (present != 1) {
			status = 1;
			goto cleanup;
		}

		/* Completed operation frames must actually release every participant, including the sole fresh Symbol. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 5U; index++) {
			found = vm_heap_find_cell(page->heap, delete_case.addresses[index]);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}
	}

	/* All independent paths preserved policy, post-trap ordering and complete ownership retirement. */
	status = 0;

cleanup:
	/* The observation context is borrowed only for this synchronous fixture call. */
	memset(&delete_case, 0, sizeof(delete_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failures after releasing every temporary setup registration. */
	if (status != 0)
		return status;

	/* Succeeded: post-trap sole-key and native fallback collections retained and then released all participants. */
	return 0;
}
