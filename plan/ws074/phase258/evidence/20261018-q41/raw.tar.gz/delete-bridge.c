/* Compares the real realm deletion operation with genuine reflection without replacing its semantics. */
static int
proxy_delete_property(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value object;
	vm_value key;
	int is_object;
	int deleted;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Reflection rejects a primitive target before coercing its property key. */
	object = js_argument(args, count, 0);
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Delete target must be an object");
		return status;
	}

	/* The production API owns the completed key before any subsequent allocation or trap. */
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	if (status != 0)
		return status;
	status = vm_delete_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &deleted);
	if (status != 0)
		return status;

	/* Succeeded: report internal refusal directly, without the delete operator's strict policy. */
	*result = vm_value_boolean(deleted);
	return 0;
}
