from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
q=Path('build/ws074-20261018/q41');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q41');out.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in proof.items())
p=json.loads((q/'final-protocol.json').read_text());assert p['conditions']==406 and p['native_matches'] and p['chrome_matches'] and p['native_global_not_exposed_and_ownership']
runs=json.loads((v/'native-runs.json').read_text());assert len(runs)==12 and all(x['returncode']==0 for x in runs)
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
n=json.loads((q/'native-proof.json').read_text());old=json.loads(Path('build/ws074-20261018/q38/native-proof.json').read_text());assert len(n['runs'])==4
for a,b in zip(n['runs'],old['runs']):assert a['callbacks']==b['callbacks'] and a['source_sha256']==b['source_sha256'] and a['returncode']==0 and a['ownership'] and a['end']
assert not any('warning:' in (q/name).read_text() or 'error:' in (q/name).read_text() for name in ['host-build.log','helper-rebuild.log'])
for file in q.glob('target-*.log'):assert not file.read_bytes()
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
paths=[f for f in q.rglob('*') if f.is_file() and f.suffix in ['.py','.sh','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'engine' not in f.parts and 'target' not in f.parts and not any(x.endswith('-data') or x=='data' for x in f.parts)];paths.append(v/'engine/proxy-read.js');mapping={str(p.relative_to(q)):p for p in paths};a=out/'raw.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for name,path in sorted(mapping.items()):t.add(path,arcname=name,recursive=False)
with tarfile.open(a,'r:gz') as t:
 count=0
 for m in t:assert t.extractfile(m).read()==mapping[m.name].read_bytes();count+=1
assert count==len(mapping)
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),explicit_source_commit='980acd47c',selection='f17d49444',source_hash_count=len(proof),conditions=406,old372_prefix_unchanged=True,oracle='q36 negative-zero primitive filter inherited for original classifier conditions; new34 deletion cases genuine Chromium; no pure exotic full406 equality claim',native_pressure='four independent modes: true trap deletes independent ordinary property, false trap skips target descriptor/native deletion, null fallback uses collecting pure native delete policy on missing fresh Symbol, native EACCES preserved. Reentrant revocation plus real script/native GC retain managed realm/original target/handler/Proxy/never-stored fresh Symbol; post-trap get-own collection verifies sole Symbol after trap frame retired; all5 then actually reclaimed. Initial stored Symbol test failed because global shape cache retained key; original failure/debugger readback retained and fixture corrected without product changes. Native callbacks never run user script; conservative stack scan disabled',native_gates=runs,acid3_score=100,acid3_inventory=100,acid3_pixels=0,acid2_existing_pixels=873,original_webidl_same_callbacks_q38=True,public_global_proxy=False,full_changed_C=json.loads((q/'source-audit.json').read_text()),archive=dict(sha256=digest(a),members=count,readback_all_members=True),official_score=1482,denominator=3805,held=0,unattempted=275,all1508_reused='q37',static_scripted_crash_reused='q28',full_census_new_pair_not_measured=True,remaining=['Object isSealed/isFrozen/seal/freeze and internal concat/flatten IsArray consumers not changed','keys/prototype/call/construct/global constructor/revocable; existing Get/Has/GetOwn/Define/Set extensibility snapshots still direct flags until nested scope','nested/callable factory targets still rejected','TypedArray remaining exotic/prototype/backing semantics','p258/p100/full target/WS100% incomplete','runtime binaries retained at hashed build paths, not embedded in archive'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for p in [q/'approval-snapshot.md',q/'source-audit.json',q/'final-protocol.json',q/'old-prefix-proof.json',q/'target-commands-1.json',v/'source-proof.json',v/'source-commit.txt',v/'shared-input-comparison.json',v/'acid/report.json']:
 shutil.copy2(p,out/('acid-report.json' if p.name=='report.json' else p.name))
print('archive',count,digest(a),'source',summary['source_commit'])
