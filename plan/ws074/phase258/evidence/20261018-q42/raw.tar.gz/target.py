from pathlib import Path
import shlex,subprocess,json,sys
q=Path('build/ws074-20261018/q42');(q/'target').mkdir(exist_ok=True);lines=Path('build/ws074-20261018/q02/target-dry-run.log').read_text().splitlines();sources=sys.argv[1:] or ['bind/environment.c','bind/window.c','bind/document.c','page/script.c','vm/function.c','vm/realm.c','vm/interpreter.c'];commands=[]
for source in sources:
 matches=[shlex.split(line) for line in lines if ' -c userland/desktop/libbrowser/'+source+' ' in line];assert len(matches)==1;args=matches[0];label=source.replace('/','_').removesuffix('.c');args[args.index('-o')+1]=str(q/'target'/(label+'.o'));commands.append(args)
 with (q/('target-'+label+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=f)
 assert r.returncode==0,source
 assert (q/('target-'+label+'.log')).read_text()=='',source
(q/('target-commands-'+str(len(sources))+'.json')).write_text(json.dumps(commands,indent=2)+'\n');print('exact target',len(sources),'source warning0')
