/*
 * Gets an object's actual prototype through ordinary storage or native Proxy internal methods.
 */
int
vm_get_prototype(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value *prototype)
{
	struct access_read_roots roots;
	int status;

	/* The managed owner and original input must survive all trap and depth-error allocations. */
	*prototype = VM_VALUE_NULL;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Ordinary prototype storage never invokes a native property callback or user script. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_get_prototype(realm, (struct vm_proxy *)object, prototype);
	} else {
		status = 0;
		if (object->prototype != NULL)
			*prototype = vm_value_cell(object->prototype);
	}

	/* Retire both native recursion depth and collector ownership on every completion path. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the returned object or null belongs to the completed prototype operation. */
	return 0;
}

/*
 * Sets an object's actual prototype while preserving original input ownership and Boolean refusal.
 */
int
vm_set_prototype(
	struct vm_realm *realm,
	struct vm_object *object,
	struct vm_object *prototype,
	int *done)
{
	struct access_read_roots roots;
	int status;

	/* A requested prototype may otherwise be owned only by the embedding call, even during method lookup. */
	*done = 0;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_NULL;
	if (prototype != NULL)
		roots.receiver = vm_value_cell(prototype);
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Proxy handling is realm-aware, while ordinary prototype policy remains a pure storage operation. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_set_prototype(realm, (struct vm_proxy *)object, roots.receiver, done);
	} else {
		status = 0;
		*done = access_set_prototype(object, prototype);
	}

	/* An abrupt trap cannot leak requested-prototype ownership or native recursion depth. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: done reports actual acceptance without applying a caller's throwing policy. */
	return 0;
}
