/* Sets an object's prototype when allowed (OrdinarySetPrototypeOf): not for a non-extensible object, and never into a cycle. */
static int
access_set_prototype(
	struct vm_object *object,
	struct vm_object *prototype)
{
	struct vm_object *walk;

	/* The same prototype is no change. */
	if (object->prototype == prototype)
		return 1;

	/* A non-extensible object keeps its prototype. */
	if ((object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
		return 0;

	/* The object must not be on the new prototype's chain. */
	for (walk = prototype; walk != NULL; walk = walk->prototype) {
		if (walk == object)
			return 0;
		if (walk->kind == VM_KIND_PROXY)
			break;
	}

	/* Allowed: the new prototype. */
	object->prototype = prototype;
	return 1;
}
