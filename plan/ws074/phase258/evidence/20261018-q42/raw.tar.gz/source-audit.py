from pathlib import Path
import subprocess,re,json,hashlib
q=Path('build/ws074-20261018/q42');base='980acd47c';checks={}
def strip(s):return re.sub(r'\s+','',re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S))
def fn(s,n):
 m=re.search(r'(?:static )?int\n'+n+r'\(\n.*?\n\}',s,re.S);assert m,n;return m
for file,names in {'vm/access.c':['vm_get_prototype','vm_set_prototype','access_set_prototype','access_proxy_get_prototype','access_proxy_set_prototype'],'js/builtin_object.c':['object_get_prototype_of','object_set_prototype_of','object_proto_get','object_proto_set','object_set_prototype']}.items():
 p=Path('userland/desktop/libbrowser',file);old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);new=p.read_text()
 for name in names:
  pat=r'(?:static )?int\n'+name+r'\(\n.*?\n\}';old=re.sub(pat,'',old,flags=re.S);new=re.sub(pat,'',new,flags=re.S)
  pat=r'^static int '+name+r'\([^\n]*;\n';old=re.sub(pat,'',old,flags=re.M);new=re.sub(pat,'',new,flags=re.M)
 assert strip(old)==strip(new),file
 checks[file]='all tokens outside selected functions/declarations unchanged'
old=subprocess.check_output(['git','show',base+':userland/desktop/libbrowser/js/builtin_object.c'],text=True);old=fn(old,'object_set_prototype').group();new=fn(Path('userland/desktop/libbrowser/vm/access.c').read_text(),'access_set_prototype').group().replace('access_set_prototype(\n','object_set_prototype(\n');new=re.sub(r'\n\t\tif \(walk->kind == VM_KIND_PROXY\)\n\t\t\tbreak;','',new);assert strip(old)==strip(new)
p=Path('userland/desktop/libbrowser/vm/vm.h');old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);new=p.read_text();new=re.sub(r'^int vm_(?:get_prototype|set_prototype)\([^\n]*;\n','',new,flags=re.M);assert strip(old)==strip(new)
raw=(q/'style-raw.log').read_text().splitlines();assert len(raw)==70 and all(': goto: goto cleanup;' in x for x in raw)
oldjs=Path('build/ws074-20261018/q41/final/engine/proxy-read.js').read_bytes();prefix=oldjs.split(b" console.log('read-proxy controls:")[0];current=Path('plan/ws074/tests/proxy-read.js').read_bytes();assert current.startswith(prefix)
checks.update(ordinary_set_tokens_identical_except_nonordinary_proxy_cycle_stop=True,header_tokens_except_two_declarations_unchanged=True,native_operations_definition_comment_unchanged=True,old406_prefix_unchanged=True,added_conditions=current.count(b" check('")-406,full_changed_functions=json.loads((q/'function-review-scope.json').read_text()),raw_allowed_cleanup=70,other_checker_findings=0,manual_review=['ANSI declaration-first, public/static order, ordinary helper prototypes after tables and initializer exception retained','realm/input/requested prototype rooted before depth error; original target/handler/fresh method/Get result explicit roots','Get output type checked before target extent; nonextensible target identity checked after target changes','Set false skips target query; true on nonextensible target compares actual prototype; ordinary policy moved to VM without VM-to-JS dependency','Object and AnnexB validation/coercion/result ordering retained; immutable-prototype exotic baseline remains a separate limitation','private factory/global/API2/Wayland/native callback contract unchanged','later nested-target script collection through target extent/Get will revalidate Get fresh-result root; not claimed exercised now'])
(q/'source-audit.json').write_text(json.dumps(checks,indent=2)+'\n');(q/'old-prefix-proof.json').write_text(json.dumps({'old_source_sha256':hashlib.sha256(oldjs).hexdigest(),'old406_prefix_sha256':hashlib.sha256(prefix).hexdigest(),'unchanged_prefix':True,'added_conditions':checks['added_conditions']},indent=2)+'\n');print('boundary/ordinary move/70 allowed cleanup/other0/added',checks['added_conditions'])
