int vm_get_prototype(struct vm_realm *realm, struct vm_object *object, vm_value *prototype);
int vm_set_prototype(struct vm_realm *realm, struct vm_object *object, struct vm_object *prototype, int *done);
static int access_set_prototype(struct vm_object *object, struct vm_object *prototype);
static int access_proxy_get_prototype(struct vm_realm *realm, struct vm_proxy *proxy, vm_value *prototype);
static int access_proxy_set_prototype(struct vm_realm *realm, struct vm_proxy *proxy, vm_value prototype, int *done);
static int object_get_prototype_of(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_set_prototype_of(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_proto_get(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_proto_set(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
int main(int argc, char **argv);
static int prototype_pressure(struct page *page);

int
vm_get_prototype(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value *prototype)
{
	struct access_read_roots roots;
	int status;

	/* The managed owner and original input must survive all trap and depth-error allocations. */
	*prototype = VM_VALUE_NULL;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Ordinary prototype storage never invokes a native property callback or user script. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_get_prototype(realm, (struct vm_proxy *)object, prototype);
	} else {
		status = 0;
		if (object->prototype != NULL)
			*prototype = vm_value_cell(object->prototype);
	}

	/* Retire both native recursion depth and collector ownership on every completion path. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the returned object or null belongs to the completed prototype operation. */
	return 0;
}

int
vm_set_prototype(
	struct vm_realm *realm,
	struct vm_object *object,
	struct vm_object *prototype,
	int *done)
{
	struct access_read_roots roots;
	int status;

	/* A requested prototype may otherwise be owned only by the embedding call, even during method lookup. */
	*done = 0;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_NULL;
	if (prototype != NULL)
		roots.receiver = vm_value_cell(prototype);
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Proxy handling is realm-aware, while ordinary prototype policy remains a pure storage operation. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_set_prototype(realm, (struct vm_proxy *)object, roots.receiver, done);
	} else {
		status = 0;
		*done = access_set_prototype(object, prototype);
	}

	/* An abrupt trap cannot leak requested-prototype ownership or native recursion depth. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: done reports actual acceptance without applying a caller's throwing policy. */
	return 0;
}

static int
access_set_prototype(
	struct vm_object *object,
	struct vm_object *prototype)
{
	struct vm_object *walk;

	/* The same prototype is no change. */
	if (object->prototype == prototype)
		return 1;

	/* A non-extensible object keeps its prototype. */
	if ((object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
		return 0;

	/* The object must not be on the new prototype's chain. */
	for (walk = prototype; walk != NULL; walk = walk->prototype) {
		if (walk == object)
			return 0;

		/* Ordinary cycle detection stops before any nonordinary GetPrototypeOf implementation. */
		if (walk->kind == VM_KIND_PROXY)
			break;
	}

	/* Succeeded: the ordinary object now uses its accepted prototype. */
	object->prototype = prototype;
	return 1;
}

static int
access_proxy_get_prototype(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value *prototype)
{
	struct vm_cell *roots[4];
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value produced;
	vm_value actual;
	unsigned registered;
	unsigned index;
	int is_cell;
	int is_object;
	int extensible;
	int same;
	int status;

	/* Original participants remain snapshots even if method lookup revokes their Proxy. */
	target = proxy->target;
	handler = proxy->handler;
	memset(roots, 0, sizeof(roots));
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[0] = vm_value_as_cell(target);
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[1] = vm_value_as_cell(handler);
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Reject revoked input before reading its handler. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot get the prototype of a revoked Proxy");
		goto cleanup;
	}

	/* Lookup follows the normal GetMethod rules, including null fallback and noncallable rejection. */
	method_key = vm_key_from_ascii(realm->heap, "getPrototypeOf");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* An absent trap forwards to the original target's actual internal method. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(target), prototype);
		goto cleanup;
	}

	/* Both fresh methods and their sole returned object need native frame ownership. */
	roots[2] = vm_value_as_cell(method);
	status = vm_call(realm, method, handler, &target, 1, &produced);
	if (status != 0)
		goto cleanup;
	is_object = vm_value_is_object(produced);
	if (!is_object && produced != VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Proxy getPrototypeOf trap must return an object or null");
		goto cleanup;
	}

	/* A target's own extensibility operation may execute script, so retain the sole returned object. */
	if (is_object)
		roots[3] = vm_value_as_cell(produced);
	status = vm_is_extensible(realm, (struct vm_object *)vm_value_as_cell(target), &extensible);
	if (status != 0)
		goto cleanup;
	if (!extensible) {
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(target), &actual);
		if (status != 0)
			goto cleanup;
		same = vm_same_value(produced, actual);
		if (!same) {
			status = vm_throw_type_error(realm, "Proxy getPrototypeOf trap disagreed with its nonextensible target");
			goto cleanup;
		}
	}

	/* An extensible target permits any object or null; fixed targets require the identity already checked. */
	*prototype = produced;
	status = 0;

cleanup:
	/* Release only snapshots and results whose root registrations were acquired. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve a failed trap or invariant after retiring native ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the caller now owns the returned prototype value. */
	return 0;
}

static int
access_proxy_set_prototype(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value prototype,
	int *done)
{
	struct vm_cell *roots[3];
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value args[2];
	vm_value produced;
	vm_value actual;
	unsigned registered;
	unsigned index;
	int is_cell;
	int truth;
	int extensible;
	int same;
	int status;

	/* Reentrant lookup or trap revocation cannot replace the original target or handler. */
	target = proxy->target;
	handler = proxy->handler;
	memset(roots, 0, sizeof(roots));
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[0] = vm_value_as_cell(target);
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[1] = vm_value_as_cell(handler);
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked input fails before handler lookup. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot set the prototype of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod observes the current handler and handles null fallback. */
	method_key = vm_key_from_ascii(realm->heap, "setPrototypeOf");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Missing traps delegate the actual transition to the original target. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		if (prototype == VM_VALUE_NULL)
			status = vm_set_prototype(realm, (struct vm_object *)vm_value_as_cell(target), NULL, done);
		else
			status = vm_set_prototype(realm, (struct vm_object *)vm_value_as_cell(target), (struct vm_object *)vm_value_as_cell(prototype), done);
		goto cleanup;
	}

	/* The trap receives exactly the original target and requested object-or-null prototype. */
	roots[2] = vm_value_as_cell(method);
	args[0] = target;
	args[1] = prototype;
	status = vm_call(realm, method, handler, args, 2, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (!truth) {
		/* A refused transition never queries its target after the trap. */
		status = 0;
		goto cleanup;
	}

	/* Only nonextensible targets constrain a true trap result to the actual target prototype. */
	status = vm_is_extensible(realm, (struct vm_object *)vm_value_as_cell(target), &extensible);
	if (status != 0)
		goto cleanup;
	if (!extensible) {
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(target), &actual);
		if (status != 0)
			goto cleanup;
		same = vm_same_value(prototype, actual);
		if (!same) {
			status = vm_throw_type_error(realm, "Proxy setPrototypeOf trap disagreed with its nonextensible target");
			goto cleanup;
		}
	}

	/* A true result has passed the actual target's post-trap constraints. */
	*done = 1;
	status = 0;

cleanup:
	/* Retire every acquired snapshot and fresh method root regardless of outcome. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve failures after releasing all helper ownership. */
	if (status != 0)
		return status;

	/* Succeeded: done reports the accepted or refused transition. */
	return 0;
}

static int
object_get_prototype_of(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *object;
	vm_value value;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The object's prototype, or null. */
	status = vm_to_object(realm, js_argument(args, count, 0), &value);
	if (status != 0)
		return status;
	object = (struct vm_object *)vm_value_as_cell(value);
	status = vm_get_prototype(realm, object, result);
	if (status != 0)
		return status;

	/* Succeeded: the prototype. */
	return 0;
}

static int
object_set_prototype_of(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *prototype;
	vm_value value;
	vm_value proto;
	int is_object;
	int done;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The object must not be undefined or null; the prototype must be an object or null. */
	value = js_argument(args, count, 0);
	proto = js_argument(args, count, 1);
	if (value == VM_VALUE_UNDEFINED || value == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Object.setPrototypeOf called on null or undefined");
		return status;
	}

	/* The prototype must be an object or null. */
	is_object = vm_value_is_object(proto);
	if (!is_object && proto != VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Object prototype may only be an Object or null");
		return status;
	}

	/* A primitive is returned as it is. */
	*result = value;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* The change must be allowed. */
	prototype = NULL;
	if (proto != VM_VALUE_NULL)
		prototype = (struct vm_object *)vm_value_as_cell(proto);
	status = vm_set_prototype(realm, (struct vm_object *)vm_value_as_cell(value), prototype, &done);
	if (status != 0)
		return status;
	if (!done) {
		status = vm_throw_type_error(realm, "Cannot set the prototype");
		return status;
	}

	/* Succeeded: the object. */
	return 0;
}

static int
object_proto_get(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *object;
	vm_value value;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* This as an object. */
	status = vm_to_object(realm, this_value, &value);
	if (status != 0)
		return status;

	/* Query the actual internal prototype, including native Proxy traps. */
	object = (struct vm_object *)vm_value_as_cell(value);
	status = vm_get_prototype(realm, object, result);
	if (status != 0)
		return status;

	/* Succeeded: the object or null is its completed internal prototype. */
	return 0;
}

static int
object_proto_set(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *prototype;
	vm_value proto;
	int is_object;
	int done;
	int status;

	/* undefined and null cannot have one. */
	*result = VM_VALUE_UNDEFINED;
	if (this_value == VM_VALUE_UNDEFINED || this_value == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Object.prototype.__proto__ called on null or undefined");
		return status;
	}

	/* Only an object or null is taken, and only by an object. */
	proto = js_argument(args, count, 0);
	is_object = vm_value_is_object(proto);
	if (!is_object && proto != VM_VALUE_NULL)
		return 0;
	is_object = vm_value_is_object(this_value);
	if (!is_object)
		return 0;

	/* The change must be allowed. */
	prototype = NULL;
	if (proto != VM_VALUE_NULL)
		prototype = (struct vm_object *)vm_value_as_cell(proto);
	status = vm_set_prototype(realm, (struct vm_object *)vm_value_as_cell(this_value), prototype, &done);
	if (status != 0)
		return status;
	if (!done) {
		status = vm_throw_type_error(realm, "Cannot set the prototype");
		return status;
	}

	/* Succeeded: the prototype is set. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
prototype_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_object *requested;
	struct vm_cell *roots[6];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	uintptr_t addresses[5];
	vm_value proxy;
	vm_value getter;
	vm_value key;
	vm_value owner_key;
	vm_value prototype;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int is_object;
	int done;
	int status;

	/* Only temporary setup roots precede the production frame's ownership. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Fresh Get output, Set input, Set fallback and Get fallback exercise distinct ownership transfers. */
	for (mode = 0; mode < 4U; mode++) {
		status = vm_realm_create_managed(page->heap, &realm);
		if (status != 0)
			goto cleanup;
		roots[0] = &realm->cell;
		addresses[0] = (uintptr_t)realm;
		target = vm_object_create(page->heap, NULL);
		if (target == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Original targets and handlers lose their Proxy owner during reentrant method lookup. */
		roots[1] = &target->cell;
		addresses[1] = (uintptr_t)target;
		handler = vm_object_create(page->heap, NULL);
		if (handler == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Requested prototypes have no shape, registry or other external owner. */
		roots[2] = &handler->cell;
		addresses[2] = (uintptr_t)handler;
		requested = NULL;
		if (mode != 0U) {
			requested = vm_object_create(page->heap, NULL);
			if (requested == NULL) {
				status = ENOMEM;
				goto cleanup;
			}

			/* Set's requested object must remain alive during the later getter before it reaches a script argument. */
			roots[5] = &requested->cell;
		}

		/* Get fallback starts from a real target prototype configured through the production ordinary API. */
		if (mode == 3U) {
			status = vm_set_prototype(realm, target, requested, &done);
			if (status != 0)
				goto cleanup;
			if (!done) {
				status = 1;
				goto cleanup;
			}
		}

		/* The getter revokes its own original Proxy and returns either a fresh trap or actual fallback. */
		if (mode == 0U) {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return function(){collectReadProxy();return {};};})", &getter);
		} else if (mode == 1U) {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return function(target,proto){collectReadProxy();return proto!==null;};})", &getter);
		} else {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return undefined;})", &getter);
		}

		/* Accessor storage must own the fresh getter before the setup frame retires it. */
		if (status != 0)
			goto cleanup;
		roots[3] = vm_value_as_cell(getter);
		if (mode == 0U || mode == 3U)
			key = vm_key_from_ascii(page->heap, "getPrototypeOf");
		else
			key = vm_key_from_ascii(page->heap, "setPrototypeOf");
		owner_key = vm_key_from_ascii(page->heap, "owner");
		if (key == VM_VALUE_EMPTY || owner_key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Both the accessor and original managed Proxy use the normal language and factory implementations. */
		status = vm_define_accessor(realm, vm_value_cell(handler), key, getter, 0);
		if (status != 0)
			goto cleanup;
		roots[3] = NULL;
		status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
		if (status != 0)
			goto cleanup;
		roots[4] = vm_value_as_cell(proxy);
		addresses[3] = (uintptr_t)roots[4];
		status = vm_object_define(page->heap, handler, owner_key, proxy, VM_PROPERTY_DEFAULT);
		if (status != 0)
			goto cleanup;

		/* No conservative scan or embedding root may supply the participants or requested prototype. */
		vm_heap_stats(page->heap, &before);
		for (index = 0; index < 6U; index++)
			roots[index] = NULL;
		if (mode == 0U || mode == 3U) {
			status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(proxy), &prototype);
		} else {
			status = vm_set_prototype(realm, (struct vm_object *)vm_value_as_cell(proxy), requested, &done);
			prototype = vm_value_cell(requested);
		}

		/* Production frames must preserve normal completion and retire their native recursion count. */
		if (status != 0)
			goto cleanup;
		vm_heap_stats(page->heap, &after);
		if (after.collections <= before.collections || realm->property_depth != 0U) {
			status = 1;
			goto cleanup;
		}

		/* This independent root now owns only the final output or original requested prototype. */
		is_object = vm_value_is_object(prototype);
		if (!is_object) {
			status = 1;
			goto cleanup;
		}

		/* Fresh Get results and requested Set inputs must be genuine plain objects, never reused freed cells. */
		roots[5] = vm_value_as_cell(prototype);
		addresses[4] = (uintptr_t)roots[5];
		if (roots[5]->type != &vm_object_type) {
			status = 1;
			goto cleanup;
		}

		/* All otherwise unowned operation participants survived the getter and trap collections. */
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, addresses[index]);
			if (found == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* Set fallback really changes target storage; a true extensible trap may legally leave it unchanged. */
		if (mode == 1U || mode == 2U) {
			if (!done) {
				status = 1;
				goto cleanup;
			}

			/* The two Set paths are distinguished by actual target prototype storage. */
			if (mode == 2U) {
				if (target->prototype != requested) {
					status = 1;
					goto cleanup;
				}
			} else if (target->prototype != NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* Keeping only the returned/requested prototype must not keep its former owner or Proxy participants. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, addresses[index]);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* The independent prototype must remain alive after its former protocol graph has actually disappeared. */
		found = vm_heap_find_cell(page->heap, addresses[4]);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* Dropping the last output/input root must actually reclaim that prototype too. */
		roots[5] = NULL;
		vm_heap_collect(page->heap);
		found = vm_heap_find_cell(page->heap, addresses[4]);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* All independent Get and Set ownership transfers were observed through actual collections. */
	status = 0;

cleanup:
	/* Retire only the setup registrations acquired by this synchronous fixture frame. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failures after releasing every setup or output root. */
	if (status != 0)
		return status;

	/* Succeeded: prototypes and original protocol graphs were independently retained and then reclaimed. */
	return 0;
}
