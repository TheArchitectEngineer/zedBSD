int vm_define_own_property(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *done);
static int access_proxy_define(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, const struct vm_descriptor *descriptor, int *done);
int main(int argc, char **argv);
static int proxy_define_descriptor(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_gc_edges(struct page *page);

int
vm_define_own_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *done)
{
	struct vm_descriptor current;
	struct vm_accessor *accessor;
	struct vm_cell *accessor_root;
	vm_value length_key;
	vm_value getter;
	vm_value setter;
	vm_value value;
	uint32_t attributes;
	uint32_t index;
	int found;
	int allowed;
	int is_index;
	int is_accessor;
	int is_array;
	int status;
	int handled;

	/* Realm-aware Proxy definition owns its traps and leaves heap-only native policy unchanged. */
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_define(realm, (struct vm_proxy *)object, key, descriptor, done);
		if (status != 0)
			return status;
		return 0;
	}

	/* Native policy may reject or handle a descriptor before ordinary validation. */
	*done = 0;
	if (object->native_operations != NULL && object->native_operations->define != NULL) {
		handled = 0;
		status = object->native_operations->define(realm, object, key, descriptor, &handled, done);
		if (status != 0)
			return status;
		if (handled)
			return 0;
	}

	/* The property there now. */
	*done = 0;
	found = vm_get_own_descriptor(object, key, &current);
	if (found < 0)
		return -found;

	/* Array descriptor handling resolves the separate length metadata key. */
	length_key = vm_key_from_ascii(realm->heap, "length");
	if (length_key == VM_VALUE_EMPTY)
		return ENOMEM;

	/* An array's length has rules of its own. */
	is_array = 0;
	if ((object->flags & VM_OBJECT_ARRAY) != 0U)
		is_array = 1;
	if (is_array && key == length_key) {
		status = access_define_length(realm, object, &current, descriptor, done);
		if (status != 0)
			return status;
		return 0;
	}

	/* An array takes no index past a length that cannot change. */
	is_index = vm_value_is_array_index(key, &index);
	if (is_array &&
	    is_index &&
	    !found &&
	    index >= object->length) {
		access_get_length_attributes(object, length_key, &attributes);
		if ((attributes & VM_PROPERTY_WRITABLE) == 0U)
			return 0;
	}

	/* Whether the change is allowed from what is there. */
	allowed = access_descriptor_allowed(object, found, &current, descriptor);
	if (!allowed)
		return 0;

	/* The kind after the change: the descriptor's, or (for a generic one) what is there. */
	is_accessor = 0;
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U)
		is_accessor = 1;
	if ((descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_GET | VM_HAS_SET)) == 0U &&
	    found &&
	    (current.has & VM_HAS_GET) != 0U)
		is_accessor = 1;

	/* The enumerability and configurability: given, or kept, or false. */
	attributes = 0;
	if (found)
		attributes = current.attributes & (VM_PROPERTY_ENUMERABLE | VM_PROPERTY_CONFIGURABLE);
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U)
		attributes = (attributes & ~VM_PROPERTY_ENUMERABLE) | (descriptor->attributes & VM_PROPERTY_ENUMERABLE);
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U)
		attributes = (attributes & ~VM_PROPERTY_CONFIGURABLE) | (descriptor->attributes & VM_PROPERTY_CONFIGURABLE);

	/* An accessor: the getter and setter given, or those it had. */
	if (is_accessor) {
		getter = VM_VALUE_UNDEFINED;
		setter = VM_VALUE_UNDEFINED;
		if (found && (current.has & VM_HAS_GET) != 0U) {
			getter = current.getter;
			setter = current.setter;
		}

		/* The ones given. */
		if ((descriptor->has & VM_HAS_GET) != 0U)
			getter = descriptor->getter;
		if ((descriptor->has & VM_HAS_SET) != 0U)
			setter = descriptor->setter;
		accessor = vm_accessor_create(realm->heap, getter, setter);
		if (accessor == NULL)
			return ENOMEM;

		/* The descriptor owns the pair only after the property is published. */
		accessor_root = &accessor->cell;
		status = vm_heap_add_root(realm->heap, &accessor_root);
		if (status != 0)
			return status;
		status = vm_object_define(realm->heap, object, key, vm_value_cell(accessor), attributes | VM_PROPERTY_ACCESSOR);
		vm_heap_remove_root(realm->heap, &accessor_root);
		if (status != 0)
			return status;
		*done = 1;
		return 0;
	}

	/* A data property: the value and writability given, or those it had. */
	value = VM_VALUE_UNDEFINED;
	if (found && (current.has & VM_HAS_VALUE) != 0U) {
		value = current.value;
		attributes |= current.attributes & VM_PROPERTY_WRITABLE;
	}

	/* The ones given. */
	if ((descriptor->has & VM_HAS_VALUE) != 0U)
		value = descriptor->value;
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U)
		attributes = (attributes & ~VM_PROPERTY_WRITABLE) | (descriptor->attributes & VM_PROPERTY_WRITABLE);
	status = vm_object_define(realm->heap, object, key, value, attributes);
	if (status != 0)
		return status;

	/* Succeeded: the property is defined. */
	*done = 1;
	return 0;
}

static int
access_proxy_define(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *done)
{
	struct vm_cell *roots[8];
	struct access_descriptor_roots input_roots;
	struct vm_descriptor current;
	struct vm_object *target_object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value representation;
	vm_value produced;
	vm_value args[3];
	unsigned index;
	unsigned registered;
	int input_registered;
	int depth_owned;
	int is_cell;
	int is_symbol;
	int truth;
	int present;
	int extensible;
	int setting_fixed;
	int allowed;
	int status;

	/* Snapshot protocol participants and clear the Boolean output before any observable method read. */
	*done = 0;
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[4] = vm_value_as_cell(key);
	roots[5] = NULL;
	roots[6] = NULL;
	roots[7] = NULL;
	registered = 0;
	input_registered = 0;
	depth_owned = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Retain flagged original input values independently of the separately mutable trap argument object. */
	input_roots.realm = realm;
	input_roots.source = VM_VALUE_UNDEFINED;
	input_roots.descriptor = descriptor;
	input_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &input_roots);
	if (status != 0)
		goto cleanup;
	input_registered = 1;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		goto cleanup;
	}

	/* This frame owns one property depth until its normal or abrupt completion. */
	realm->property_depth++;
	depth_owned = 1;
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot define a property of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod observes the current define trap and treats null as absence. */
	method_key = vm_key_from_ascii(realm->heap, "defineProperty");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Missing traps delegate the unchanged partial descriptor to the original target. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, descriptor, done);
		goto cleanup;
	}

	/* Retain a fresh method and normalize internal indices without altering symbol identity. */
	roots[5] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[6] = &string->cell;
	}

	/* A trap sees exactly the present descriptor fields as ordinary writable data properties. */
	status = vm_from_property_descriptor(realm, descriptor, &representation);
	if (status != 0)
		goto cleanup;
	roots[7] = vm_value_as_cell(representation);
	args[0] = target;
	args[1] = trap_key;
	args[2] = representation;
	status = vm_call(realm, method, handler, args, 3, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (!truth) {
		status = 0;
		goto cleanup;
	}

	/* Successful traps are constrained by the original target's state after the trap has run. */
	target_object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_get_own_property(realm, target_object, key, &current, &present);
	if (status != 0)
		goto cleanup;
	extensible = 1;
	if ((target_object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
		extensible = 0;
	setting_fixed = 0;
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U && (descriptor->attributes & VM_PROPERTY_CONFIGURABLE) == 0U)
		setting_fixed = 1;
	if (!present) {
		if (!extensible || setting_fixed) {
			status = vm_throw_type_error(realm, "Proxy define trap cannot invent this property");
			goto cleanup;
		}
	} else {
		/* Existing properties use the original input fields rather than the trap's mutable object. */
		allowed = access_descriptor_compatible(extensible, present, &current, descriptor);
		if (!allowed) {
			status = vm_throw_type_error(realm, "Proxy define trap accepted an incompatible descriptor");
			goto cleanup;
		}

		/* An explicit fixed claim must already hold on the target after the trap. */
		if (setting_fixed && (current.attributes & VM_PROPERTY_CONFIGURABLE) != 0U) {
			status = vm_throw_type_error(realm, "Proxy define trap invented a nonconfigurable property");
			goto cleanup;
		}

		/* A nonconfigurable data property must already be read-only before a false writable claim succeeds. */
		if ((current.has & VM_HAS_VALUE) != 0U &&
		    (current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U &&
		    (current.attributes & VM_PROPERTY_WRITABLE) != 0U) {
			if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U) {
				status = vm_throw_type_error(realm, "Proxy define trap invented a fixed read-only property");
				goto cleanup;
			}
		}
	}

	/* Report success only after every post-trap invariant agrees with the unchanged input descriptor. */
	*done = 1;
	status = 0;

cleanup:
	/* The original descriptor pointer and depth ownership end with this native frame. */
	if (depth_owned)
		realm->property_depth--;
	if (input_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &input_roots);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve errors without changing refusal into successful definition. */
	if (status != 0)
		return status;

	/* Succeeded: done distinguishes a valid truthy trap result from ordinary refusal. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_define_descriptor(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *key_root;
	vm_value object;
	vm_value key;
	int is_object;
	int is_cell;
	int done;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Match reflection's target validation before any key or descriptor coercion. */
	object = js_argument(args, count, 0);
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Define target must be an object");
		return status;
	}

	/* A freshly returned symbol key must survive later descriptor getters. */
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	if (status != 0)
		return status;
	key_root = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		key_root = vm_value_as_cell(key);
	status = vm_heap_add_root(realm->heap, &key_root);
	if (status != 0)
		return status;
	status = vm_to_property_descriptor(realm, js_argument(args, count, 2), &descriptor);
	if (status != 0)
		goto cleanup;
	status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &done);
	if (status != 0)
		goto cleanup;
	*result = vm_value_boolean(done);

cleanup:
	/* The fixture does not retain a converted key beyond the product operation. */
	vm_heap_remove_root(realm->heap, &key_root);
	if (status != 0)
		return status;

	/* Succeeded: the actual internal definition produced the Boolean result. */
	return 0;
}

static int
proxy_gc_edges(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[6];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_descriptor own;
	struct vm_descriptor change;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value answer;
	vm_value made;
	vm_value key;
	vm_value get_key;
	vm_value descriptor_key;
	vm_value payload;
	uintptr_t realm_address;
	uintptr_t descriptor_address;
	uintptr_t define_address;
	unsigned index;
	unsigned registered;
	int status;
	int same;
	int present;
	int done;

	/* Setup ownership is retired deliberately before each product operation takes responsibility. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The temporary managed realm has no embedding Document or explicit lifetime. */
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	realm_address = (uintptr_t)realm;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated target while allocating the remaining protocol participants. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated handler until the private factory takes ownership. */
	roots[2] = &handler->cell;

	/* Intern keys before obtaining a transient function returned only to this native frame. */
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Intern the trap key before creating a transient method function. */
	get_key = vm_key_from_ascii(page->heap, "get");
	if (get_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Create the ordinary configurable descriptor used by the post-trap invariant read. */
	status = vm_object_define(page->heap, target, key, VM_VALUE_UNDEFINED, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = proxy_script(page->realm, "(function(){return {sole:74};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, get_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* A separate fresh descriptor result must cross the same native post-trap collector. */
	descriptor_key = vm_key_from_ascii(page->heap, "getOwnPropertyDescriptor");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* The fixture trap returns a descriptor and object payload with no persistent script owner. */
	status = proxy_script(page->realm, "(function(){return {value:{sole:75},writable:true,enumerable:true,configurable:true};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, descriptor_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Define's trap erases its argument value before returning, leaving only the original native descriptor owner. */
	descriptor_key = vm_key_from_ascii(page->heap, "defineProperty");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Script collection precedes the separate post-trap native descriptor collection. */
	status = proxy_script(page->realm, "(function(t,k,d){var v=d.value;delete d.value;collectReadProxy();return v!==77;})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, descriptor_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Genuine allocation pressure makes the private factory retain all otherwise unrooted inputs. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Drop every setup owner before the factory must survive threshold collection. */
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &made);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(made);
	vm_heap_stats(page->heap, &after);
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* This native descriptor hook may collect but never executes script, preserving the production hook contract. */
	target->native_operations = &proxy_sole_operations;
	sole_heap = page->heap;
	sole_realm_address = realm_address;
	sole_realm_alive = 0;
	status = vm_get_receiver(realm, made, key, VM_VALUE_NULL, &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);

	/* Has fallback must independently retain the managed realm through the same native descriptor collector. */
	status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &present);
	if (status != 0)
		goto cleanup;
	if (!present) {
		status = 1;
		goto cleanup;
	}

	/* GetOwn retains its managed realm and otherwise unowned trap descriptor during target collection. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &own, &present);
	if (status != 0)
		goto cleanup;
	if (!present || own.has != (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE)) {
		status = 1;
		goto cleanup;
	}

	/* The complete descriptor owns the original fresh object until the embedding takes it. */
	roots[0] = vm_value_as_cell(own.value);
	descriptor_address = (uintptr_t)roots[0];
	descriptor_key = vm_key_from_ascii(page->heap, "sole");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read a real field from the payload that had no owner during the target policy collection. */
	status = vm_get(page->realm, own.value, descriptor_key, &payload);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(payload, vm_value_int32(75));
	if (!same) {
		status = 1;
		goto cleanup;
	}

	/* Protect setup only while allocating a new object that no target or trap closure will own. */
	roots[1] = &realm->cell;
	found = (struct vm_cell *)vm_object_create(page->heap, NULL);
	if (found == NULL) {
		status = 2;
		goto cleanup;
	}

	/* The temporary setup root is removed immediately before production Define takes responsibility. */
	roots[5] = found;
	define_address = (uintptr_t)found;
	status = vm_object_define(page->heap, (struct vm_object *)found, descriptor_key, vm_value_int32(76), VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	memset(&change, 0, sizeof(change));
	change.has = VM_HAS_VALUE | VM_HAS_CONFIGURABLE;
	change.attributes = VM_PROPERTY_CONFIGURABLE;
	change.value = vm_value_cell(found);
	roots[1] = NULL;
	roots[5] = NULL;
	status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &change, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		status = 1;
		goto cleanup;
	}

	/* The sole input payload must survive even after the trap deleted its representation field and returned. */
	found = vm_heap_find_cell(page->heap, define_address);
	if (found == NULL) {
		status = 1;
		goto cleanup;
	}

	/* Let the embedding retain the completed result only after the native ownership observation. */
	roots[5] = found;
	status = vm_get(page->realm, vm_value_cell(found), descriptor_key, &payload);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(payload, vm_value_int32(76));
	if (!same) {
		status = 1;
		goto cleanup;
	}

	/* A false trap result must not query the target's native descriptor hook. */
	change.value = vm_value_int32(77);
	status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &change, &done);
	if (status != 0)
		goto cleanup;
	if (done || sole_realm_alive != 4U) {
		status = 1;
		goto cleanup;
	}

	/* The sole result from Get must also survive the subsequent Has collection. */
	key = vm_key_from_ascii(page->heap, "sole");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read the actual sole-result payload after the native policy collection. */
	status = vm_get(page->realm, answer, key, &answer);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(answer, vm_value_int32(74));
	if (!same ||
	    sole_realm_alive != 4U ||
	    realm->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* No surviving protocol participant references the temporary realm once the native Get frame ends. */
	roots[0] = NULL;
	roots[3] = NULL;
	roots[4] = NULL;
	roots[5] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The fresh descriptor payload must also be actually reclaimed after its last embedding root ends. */
	found = vm_heap_find_cell(page->heap, descriptor_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The original Define input payload has no owner once the completed embedding root ends. */
	found = vm_heap_find_cell(page->heap, define_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Record the successful native ownership observations before releasing setup roots. */
	status = 0;

cleanup:
	/* Fixture observations are not collector roots and never survive the independent case. */
	sole_heap = NULL;
	sole_realm_address = 0;
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: allocation, native descriptor collection and later realm reclamation all used real ownership. */
	return 0;
}
