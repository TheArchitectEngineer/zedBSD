from pathlib import Path
import subprocess,re,json,hashlib
q=Path('build/ws074-20261018/q39');before='0c8033f4b';files=['userland/desktop/libbrowser/vm/access.c','userland/desktop/libbrowser/js/builtin_array.c','userland/desktop/libbrowser/vm/vm.h'];proof={}
def strip(s):return re.sub(r'\s+','',re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S))
for path in files:
 old=subprocess.check_output(['git','show',before+':'+path],text=True);new=Path(path).read_text()
 if path.endswith('access.c'):
  m=re.search(r'/\*\n \* Determines array identity.*?\nint\nvm_is_array\(\n.*?\n\}\n\n',new,re.S);assert m;new=new[:m.start()]+new[m.end():]
 elif path.endswith('builtin_array.c'):
  pattern=r'static int\narray_is_array\(\n.*?\n\}'
  old=re.sub(pattern,'',old,flags=re.S);new=re.sub(pattern,'',new,flags=re.S)
 else:new=new.replace('int vm_is_array(struct vm_realm *realm, vm_value value, int *is_array);','')
 assert strip(old)==strip(new),path
 proof[path]={'old_tokens_except_selected_functions_equal':True}
raw=(q/'style-raw.log').read_text().splitlines();assert len(raw)==35 and all(': goto: goto cleanup;' in x for x in raw)
scope=json.loads((q/'function-review-scope.json').read_text());proof['full_changed_functions']=scope;proof['allowed_forward_cleanup_gotos']=len(raw);proof['other_checker_findings']=0;proof['formatter']='clang-format-19 / InheritParentConfig / ColumnLimit0, multiline signatures and compound conditions restored';proof['manual_review']=['C89 leading declarations, public/static order, existing table-required prototypes retained','no calls in conditions or Boolean expression assignments','immutable target traversal, no user script/prototype/handler access','managed realm and original input traced through error; registrations retired on all outcomes','private factory callable/nested bounds and native_operations definition/comment unchanged','public ABI2 and Wayland boundaries unchanged','unselected array concat/flatten consumers unchanged; whole conformance p100 pending'];(q/'source-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print('selected function boundary,35 allowed cleanup,other0')
