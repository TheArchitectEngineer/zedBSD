from pathlib import Path
p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();i=s.index('/*\n * Gets a property of any value:');f='''/* Determines array identity through immutable Proxy targets without invoking any script operation. */
int
vm_is_array(
	struct vm_realm *realm,
	vm_value value,
	int *is_array)
{
	struct access_read_roots roots;
	struct vm_object *object;
	struct vm_proxy *proxy;
	int is_object;
	int status;

	/* Primitives never coerce, and ordinary array identity requires no allocation. */
	*is_array = 0;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;
	object = (struct vm_object *)vm_value_as_cell(value);
	if (object->kind != VM_KIND_PROXY) {
		if ((object->flags & VM_OBJECT_ARRAY) != 0U)
			*is_array = 1;
		return 0;
	}

	/* A revoked-target error may collect both its managed realm and otherwise unowned original Proxy. */
	roots.realm = realm;
	roots.base = value;
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Targets are existing objects fixed at allocation, so the chain cannot form a cycle. */
	while (object->kind == VM_KIND_PROXY) {
		proxy = (struct vm_proxy *)object;
		if (proxy->target == VM_VALUE_NULL) {
			status = vm_throw_type_error(realm, "Cannot determine array identity of a revoked Proxy");
			break;
		}

		/* Neither handler properties nor prototype access participates in IsArray. */
		object = (struct vm_object *)vm_value_as_cell(proxy->target);
	}

	/* Only a successfully reached target contributes its immutable array identity. */
	if (status == 0) {
		if ((object->flags & VM_OBJECT_ARRAY) != 0U)
			*is_array = 1;
	}
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the original Proxy frame no longer owns any collector edge. */
	return 0;
}

''';s=s[:i]+f+s[i:];s=s.replace('with the built-ins (ws074-p026); until then their','with the built-ins; until then their');p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/vm.h');s=p.read_text();i=s.index('int vm_has_property(');s=s[:i]+'/* Array identity unwraps native Proxy targets and rejects revoked records. */\nint vm_is_array(struct vm_realm *realm, vm_value value, int *is_array);\n'+s[i:];p.write_text(s)
p=Path('userland/desktop/libbrowser/js/builtin_array.c');s=p.read_text();a=s.index('static int\narray_is_array(\n');b=s.index('\n}\n',a)+2;f=s[a:b];f=f.replace('int is_array;','int is_array;\n\tint status;').replace('\tUNUSED_PARAMETER(realm);\n','').replace('/* An array object. */\n\tis_array = array_is_array_value(js_argument(args, count, 0));','/* Native Proxy targets preserve array identity and revoked records throw. */\n\tstatus = vm_is_array(realm, js_argument(args, count, 0), &is_array);\n\tif (status != 0)\n\t\treturn status;\n\n\t/* Succeeded: publish only the completed abstract operation\'s Boolean. */');s=s[:a]+f+s[b:];p.write_text(s)
p=Path('plan/ws074/tests/proxy-read.js');s=p.read_text();i=s.index(" console.log('read-proxy controls:");s=s[:i]+''' check('isarray-native-array-target',function(){return Array.isArray(makeReadProxy([],{}));});
 check('isarray-native-object-target',function(){return !Array.isArray(makeReadProxy({},{}));});
 check('isarray-native-typed-target',function(){return !Array.isArray(makeReadProxy(new Uint8Array(1),{}));});
 check('isarray-revoked-array-throws',function(){var p=makeReadProxy([],{});revokeReadProxy(p);return raises(function(){Array.isArray(p);},TypeError);});
 check('isarray-revoked-object-throws',function(){var p=makeReadProxy({},{});revokeReadProxy(p);return raises(function(){Array.isArray(p);},TypeError);});
 check('isarray-does-not-read-handler',function(){var calls=0,h={};Object.defineProperty(h,'get',{get:function(){calls++;throw 1;}});var p=makeReadProxy([],h);return Array.isArray(p)&&calls===0;});
 check('isarray-does-not-call-get-trap',function(){var calls=0,p=makeReadProxy([],{get:function(){calls++;throw 1;}});return Array.isArray(p)&&calls===0;});
 check('isarray-does-not-call-getprototype-trap',function(){var calls=0,p=makeReadProxy([],{getPrototypeOf:function(){calls++;throw 1;}});return Array.isArray(p)&&calls===0;});
 check('isarray-changed-array-prototype',function(){var a=[];Object.setPrototypeOf(a,null);return Array.isArray(makeReadProxy(a,{}));});
 check('isarray-array-prototype-imitation',function(){return !Array.isArray(makeReadProxy(Object.create(Array.prototype),{}));});
 check('isarray-all-primitives-false',function(){return !Array.isArray()&&!Array.isArray(null)&&!Array.isArray(true)&&!Array.isArray(1)&&!Array.isArray('a')&&!Array.isArray(Symbol('a'))&&!Array.isArray(1n);});
 check('isarray-no-coercion',function(){var calls=0,o={valueOf:function(){calls++;return [];},toString:function(){calls++;return '';}};return !Array.isArray(o)&&calls===0;});
 check('isarray-handler-revoked-proxy-not-read',function(){var h=makeReadProxy({},{});revokeReadProxy(h);return Array.isArray(makeReadProxy([],h));});
'''+s[i:];p.write_text(s)
