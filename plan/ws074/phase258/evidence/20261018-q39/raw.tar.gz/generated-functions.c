int vm_is_array(struct vm_realm *realm, vm_value value, int *is_array);
static int array_is_array(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
int main(int argc, char **argv);
static int array_identity_pressure(struct page *page);

int
vm_is_array(
	struct vm_realm *realm,
	vm_value value,
	int *is_array)
{
	struct access_read_roots roots;
	struct vm_object *object;
	struct vm_proxy *proxy;
	int is_object;
	int status;

	/* Primitives never coerce, and ordinary array identity requires no allocation. */
	*is_array = 0;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;
	object = (struct vm_object *)vm_value_as_cell(value);
	if (object->kind != VM_KIND_PROXY) {
		if ((object->flags & VM_OBJECT_ARRAY) != 0U)
			*is_array = 1;
		return 0;
	}

	/* A revoked-target error may collect both its managed realm and otherwise unowned original Proxy. */
	roots.realm = realm;
	roots.base = value;
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Targets are existing objects fixed at allocation, so the chain cannot form a cycle. */
	while (object->kind == VM_KIND_PROXY) {
		proxy = (struct vm_proxy *)object;
		if (proxy->target == VM_VALUE_NULL) {
			status = vm_throw_type_error(realm, "Cannot determine array identity of a revoked Proxy");
			break;
		}

		/* Neither handler properties nor prototype access participates in IsArray. */
		object = (struct vm_object *)vm_value_as_cell(proxy->target);
	}

	/* Only a successfully reached target contributes its immutable array identity. */
	if (status == 0) {
		if ((object->flags & VM_OBJECT_ARRAY) != 0U)
			*is_array = 1;
	}

	/* Retire the native ownership frame before propagating an abrupt outcome. */
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the original Proxy frame no longer owns any collector edge. */
	return 0;
}

static int
array_is_array(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	int is_array;
	int status;

	UNUSED_PARAMETER(this_value);

	/* Native Proxy targets preserve array identity and revoked records throw. */
	status = vm_is_array(realm, js_argument(args, count, 0), &is_array);
	if (status != 0)
		return status;

	/* Succeeded: publish only the completed abstract operation's Boolean. */
	*result = vm_value_boolean(is_array);
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
array_identity_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[4];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value proxy;
	uintptr_t realm_address;
	uintptr_t proxy_address;
	unsigned registered;
	unsigned index;
	int is_array;
	int status;

	/* Setup ownership is temporary and is retired before the operation under observation. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A bare managed realm reaches the real bootstrap TypeError allocation path. */
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	realm_address = (uintptr_t)realm;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The factory requires real target and handler objects before its genuine native record is revoked. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The revoked record must survive solely through the production IsArray frame during the throw. */
	roots[2] = &handler->cell;
	status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(proxy);
	proxy_address = (uintptr_t)roots[3];
	status = vm_proxy_revoke(realm, proxy);
	if (status != 0)
		goto cleanup;

	/* Ordinary threshold collection is triggered by the next actual error string allocation. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* No embedding root or conservative stack scan may supply the realm or Proxy edge. */
	for (index = 0; index < 4U; index++)
		roots[index] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_is_array(realm, proxy, &is_array);
	vm_heap_stats(page->heap, &after);
	if (status != VM_THROWN ||
	    is_array != 0 ||
	    after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* Both otherwise unowned inputs must still exist after the collection inside the error path. */
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found == NULL) {
		status = 1;
		goto cleanup;
	}

	/* A rooted owner alone would not keep the revoked record, so observe the input independently. */
	found = vm_heap_find_cell(page->heap, proxy_address);
	if (found == NULL) {
		status = 1;
		goto cleanup;
	}

	/* A completed abrupt operation leaves neither input retained by its former native frame. */
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The revoked record must be actually reclaimed as well as its managed owner. */
	found = vm_heap_find_cell(page->heap, proxy_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Both the pressure collection and later release were independently observed. */
	status = 0;

cleanup:
	/* Retire every setup registration on normal and abrupt completion. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failures after releasing all embedding registrations. */
	if (status != 0)
		return status;

	/* Succeeded: the actual error path retained and then released both inputs. */
	return 0;
}
