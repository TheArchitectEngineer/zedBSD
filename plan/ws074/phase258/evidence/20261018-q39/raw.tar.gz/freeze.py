from pathlib import Path
import hashlib,json,shutil,subprocess
q=Path('build/ws074-20261018/q39');out=q/'final';pair=out/'engine';pair.mkdir(parents=True,exist_ok=True)
names=['browser','libbrowser.so','host-proxy-read','host-generator-delegation','host-interp','host-vm-factory','host-cssom','host-cssom-mutation','host-performance-marks','host-performance-observer','host-error-events','host-error-reporting']
for name in names:shutil.copy2(Path('build/ws074-20261018/plain',name),pair/name)
shutil.copy2('plan/ws074/tests/proxy-read.js',pair/'proxy-read.js')
files=[p for p in Path('userland/desktop/libbrowser').rglob('*') if p.is_file() and p.suffix in ['.c','.h']]
files += list(Path('plan/ws074/tests/dom').glob('*'))+[Path('plan/ws074/tests/host-proxy-read.c'),Path('plan/ws074/tests/proxy-read.js'),Path('plan/ws074/phase173/evidence/20261013-q1012/manifest.json')]+list(pair.iterdir())+list(Path('userland/desktop/fonts').glob('*.ttf'))
files += [Path('plan/ws074/tests',n) for n in ['run-interop2025-census.py','run-interop2025-harness.py','run-interop2025-batch.py','run-dom-tests.py','run-acid-tests.py']]
proof={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};(out/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'source-commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True));print('frozen',len(proof),'files')
# Only the already-selected source changes differ from q28; all rendering and runner/font inputs are byte identical.
old=json.loads(Path('build/ws074-20261018/q37/final/source-proof.json').read_text());shared={p:d for p,d in old.items() if p in proof and not p.startswith('build/')};(out/'shared-input-comparison.json').write_text(json.dumps({p:{'old':d,'new':proof[p]} for p,d in shared.items() if d!=proof[p]},indent=2)+'\n')
