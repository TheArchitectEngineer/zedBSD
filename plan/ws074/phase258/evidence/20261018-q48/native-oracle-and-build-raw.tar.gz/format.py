from pathlib import Path
import subprocess,re,json
q=Path('build/ws074-20261018/q48');mapping={'userland/desktop/libbrowser/js/builtin_object.c': ['object_to_string'], 'userland/desktop/libbrowser/js/builtin_array.c': ['array_concat', 'array_flat', 'array_flat_map', 'array_flatten', 'array_is_concat_spreadable'], 'plan/ws074/tests/host-proxy-read.c': ['main', 'flat_source_length', 'flat_source_depth', 'flat_source_pressure']};chunks=[];protos=[]
for file,names in mapping.items():
 p=Path(file);s=p.read_text()
 for name in names:
  m=re.search(r'(?:static )?(?:int|void|double)\n'+name+r'\(\n.*?\n\}',s,re.S);assert m,name
  f=subprocess.check_output(['clang-format-19','--assume-filename='+file,'--style={BasedOnStyle: InheritParentConfig, ColumnLimit: 0}'],input=m.group().encode()).decode().rstrip();i=f.index('{');h=re.match(r'([^\n]+)\n(\w+)\((.*)\)',f[:i].strip(),re.S);assert h,name;f=h[1]+'\n'+h[2]+'(\n'+',\n'.join('\t'+a.strip() for a in h[3].split(','))+')\n'+f[i:]
  for slot,flag in [('getter','GET'),('setter','SET')]:f=f.replace('if ((descriptor->has & VM_HAS_'+flag+') != 0U && !callable && descriptor->'+slot+' != VM_VALUE_UNDEFINED)', 'if ((descriptor->has & VM_HAS_'+flag+') != 0U &&\n\t    !callable &&\n\t    descriptor->'+slot+' != VM_VALUE_UNDEFINED)')
  f=f.replace('if (is_array && is_index && !found && index >= object->length)', 'if (is_array &&\n\t    is_index &&\n\t    !found &&\n\t    index >= object->length)')
  f=f.replace('if ((descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_GET | VM_HAS_SET)) == 0U && found && (current.has & VM_HAS_GET) != 0U)', 'if ((descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_GET | VM_HAS_SET)) == 0U &&\n\t    found &&\n\t    (current.has & VM_HAS_GET) != 0U)')
  f=f.replace('if (found && property.holder == object && key == length_key && (object->flags & VM_OBJECT_ARRAY) != 0U)', 'if (found &&\n\t    property.holder == object &&\n\t    key == length_key &&\n\t    (object->flags & VM_OBJECT_ARRAY) != 0U)')
  f=f.replace('if (object->kind == VM_KIND_TYPED_ARRAY && object->native_operations != NULL && object->native_operations->define != NULL)', 'if (object->kind == VM_KIND_TYPED_ARRAY &&\n\t    object->native_operations != NULL &&\n\t    object->native_operations->define != NULL)')
  f=f.replace('if (!done || typed_case_collections < 2U || realm->property_depth != 0U)', 'if (!done ||\n\t    typed_case_collections < 2U ||\n\t    realm->property_depth != 0U)')
  f=f.replace('if (level == OBJECT_FROZEN && (descriptor.has & VM_HAS_VALUE) != 0U && (descriptor.attributes & VM_PROPERTY_WRITABLE) != 0U)', 'if (level == OBJECT_FROZEN &&\n\t\t    (descriptor.has & VM_HAS_VALUE) != 0U &&\n\t\t    (descriptor.attributes & VM_PROPERTY_WRITABLE) != 0U)')
  f=f.replace('if (status != EPERM || object_consumer_case.calls != 2U || after.collections < before.collections + 2U || array->length != 3U)', 'if (status != EPERM ||\n\t    object_consumer_case.calls != 2U ||\n\t    after.collections < before.collections + 2U ||\n\t    array->length != 3U)')
  s=s[:m.start()]+f+s[m.end():];chunks.append(f);protos.append(re.sub(r'\s+',' ',f[:f.index('{')].strip()).replace('( ','(')+';')
 p.write_text(s)
(q/'generated-functions.c').write_text('\n'.join(protos)+'\n\n'+'\n\n'.join(chunks)+'\n');(q/'function-review-scope.json').write_text(json.dumps(mapping,indent=2)+'\n')
