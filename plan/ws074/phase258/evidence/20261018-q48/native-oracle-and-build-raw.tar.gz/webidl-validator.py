from pathlib import Path
import subprocess,json,re,time,hashlib
q=Path('build/ws074-20261018/q48');base=Path('build/ws074-20261018/q29/webidl-controls/retained-3v3c9hcp/actual-webidl-negative');harness=(base/'resources/testharness.js').read_bytes();library=(base/'resources/webidl2/lib/webidl2.js').read_bytes();assert hashlib.sha256(library).hexdigest()=='954444f6daf0f8068d2fce513eac8e6a5d53189a910b9a5675e8d8e8a2808070'
tests=b'''test(function(){var errors=WebIDL2.validate(WebIDL2.parse('interface Missing {};'));assert_true(Array.isArray(errors));assert_true(errors.some(function(e){return e.ruleName==='require-exposed';}));},'original interface validator yields missing Exposed rule');
test(function(){var errors=WebIDL2.validate(WebIDL2.parse('namespace Missing {};'));assert_true(Array.isArray(errors));assert_true(errors.some(function(e){return e.ruleName==='require-exposed';}));},'original namespace validator yields missing Exposed rule');
test(function(){var errors=WebIDL2.validate(WebIDL2.parse('interface Missing {};'));assert_true(errors.some(function(e){return e.ruleName==='require-exposed';}));assert_equals(errors.length,0,'intentional failure after original validator rule');},'validator rule detection does not mask intentional failure');'''
prefix=b'var validatorOriginalProxy=globalThis.Proxy;if(typeof Proxy==="undefined"){globalThis.Proxy=function Proxy(t,h){return makeReadProxy(t,h);};}\n';logger=b'\nsetup({output:false,explicit_done:true});add_result_callback(function(t){console.log("WEBIDL-VALIDATOR "+JSON.stringify({name:t.name,status:t.status,message:t.message||""}));});\n';suffix=b'\nconsole.log("WEBIDL-VALIDATOR-END");if(typeof validatorOriginalProxy==="undefined"){delete globalThis.Proxy;}true;\n';source=prefix+harness+b'\n'+library+logger+tests+suffix;p=q/'webidl-validator.js';p.write_bytes(source);rows=[]
for kind in ['chrome','native']:
 if kind=='native':command=[str((q/'final/engine/host-proxy-read').resolve()),str(p.resolve())]
 else:
  html=q/'webidl-validator.html';html.write_bytes(b'<!doctype html><html><body><script>'+source+b'</script></body></html>');command=['chromium','--headless','--no-sandbox','--disable-gpu','--user-data-dir=/tmp/ws074-q48-validator-'+str(time.time_ns()),'--enable-logging=stderr','--v=0','--virtual-time-budget=5000','--dump-dom',html.resolve().as_uri()]
 run=subprocess.run(command,capture_output=True,timeout=40);(q/('validator-'+kind+'.out')).write_bytes(run.stdout);(q/('validator-'+kind+'.err')).write_bytes(run.stderr);callbacks=[]
 for line in (run.stdout+run.stderr).decode(errors='replace').splitlines():
  if 'WEBIDL-VALIDATOR {' in line:
   value=line[line.index('WEBIDL-VALIDATOR ')+17:]
   if kind=='chrome':value=value.split('", source: ')[0]
   callbacks.append(json.loads(value))
 rows.append(dict(kind=kind,returncode=run.returncode,callbacks=callbacks,ownership=kind=='native' and b'native proxy read ownership: passed' in run.stdout,command=command));print(rows[-1],flush=True)
(q/'webidl-validator-proof.json').write_text(json.dumps(dict(shared_source_sha256=hashlib.sha256(source).hexdigest(),test_source_sha256=hashlib.sha256(tests).hexdigest(),original_library_sha256=hashlib.sha256(library).hexdigest(),runs=rows),indent=2)+'\n');assert rows[0]['callbacks']==rows[1]['callbacks'] and [r['status'] for r in rows[0]['callbacks']]==[0,0,1] and all(r['returncode']==0 for r in rows) and rows[1]['ownership'];assert 'intentional failure after original validator rule' in rows[0]['callbacks'][2]['message']
