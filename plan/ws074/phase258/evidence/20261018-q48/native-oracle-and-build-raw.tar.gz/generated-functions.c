static int object_to_string(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int array_concat(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int array_flat(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int array_flat_map(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int array_flatten(struct vm_realm *realm, vm_value target, vm_value source, uint32_t source_length, double depth, vm_value mapper, vm_value this_arg);
static int array_is_concat_spreadable(struct vm_realm *realm, vm_value value, int *spreadable);
int main(int argc, char **argv);
static int flat_source_length(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int flat_source_depth(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int flat_source_pressure(struct page *page);

static int
object_to_string(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *object;
	struct vm_string *text_string;
	struct vm_cell *roots[4];
	vm_value value;
	vm_value named;
	vm_value prefix;
	char text[64];
	const char *tag;
	unsigned registered;
	int is_array;
	int is_string;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* undefined and null have their own tags. */
	object = NULL;
	registered = 0;
	if (this_value == VM_VALUE_UNDEFINED) {
		tag = "Undefined";
	} else if (this_value == VM_VALUE_NULL) {
		tag = "Null";
	} else {
		status = vm_to_object(realm, this_value, &value);
		if (status != 0)
			return status;
		object = (struct vm_object *)vm_value_as_cell(value);
		roots[0] = &object->cell;
		roots[1] = NULL;
		roots[2] = NULL;
		roots[3] = NULL;
		registered = 0;
		while (registered < 4U) {
			status = vm_heap_add_root(realm->heap, &roots[registered]);
			if (status != 0)
				goto cleanup;
			registered++;
		}

		/* Actual array identity is determined before observing a custom tag, including revoked Proxy errors. */
		status = vm_is_array(realm, value, &is_array);
		if (status != 0)
			goto cleanup;
		if (is_array)
			tag = "Array";
		else
			tag = object_tag(value, object);

		/* A string Symbol.toStringTag names it instead. */
		status = vm_get(realm, value, vm_symbol_key(realm, VM_SYMBOL_TO_STRING_TAG), &named);
		if (status != 0)
			goto cleanup;
		is_string = vm_value_is_string(named);
		if (is_string) {
			roots[1] = vm_value_as_cell(named);
			status = js_builtin_string(realm, "[object ", &prefix);
			if (status != 0)
				goto cleanup;
			roots[2] = vm_value_as_cell(prefix);
			text_string = vm_string_concat(realm->heap, (struct vm_string *)vm_value_as_cell(prefix), (struct vm_string *)vm_value_as_cell(named));
			if (text_string == NULL) {
				status = ENOMEM;
				goto cleanup;
			}

			/* The first concatenation must survive suffix allocation. */
			roots[3] = &text_string->cell;
			status = js_builtin_string(realm, "]", &prefix);
			if (status != 0)
				goto cleanup;
			roots[2] = vm_value_as_cell(prefix);
			text_string = vm_string_concat(realm->heap, text_string, (struct vm_string *)vm_value_as_cell(prefix));
			if (text_string == NULL) {
				status = ENOMEM;
				goto cleanup;
			}

			/* The custom tag is the result after roots are released. */
			*result = vm_value_cell(text_string);
			goto cleanup;
		}
	}

	/* Succeeded: the text. */
	snprintf(text, sizeof(text), "[object %s]", tag);
	status = js_builtin_string(realm, text, result);

cleanup:
	/* Any wrapper and transient tag strings leave the root set. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Conversion or string allocation failure has no usable result. */
	if (status != 0)
		return status;

	/* Succeeded: the object tag string is published. */
	return 0;
}

static int
array_concat(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[4];
	vm_value object;
	vm_value item;
	vm_value value;
	uint32_t length;
	uint32_t index;
	uint32_t next;
	unsigned argument;
	unsigned registered;
	unsigned root_index;
	int found;
	int spreadable;
	int is_cell;
	int status;

	/* The converted source, result, current element and current item survive all protocol callbacks. */
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		return status;
	memset(roots, 0, sizeof(roots));
	roots[0] = vm_value_as_cell(object);
	registered = 0;
	for (root_index = 0; root_index < 4U; root_index++) {
		status = vm_heap_add_root(realm->heap, &roots[root_index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Keep the plain newly created destination alive before any item can run getters. */
	status = array_new(realm, result);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(*result);

	/* Each source item first observes its actual spreadability, then either contributes itself or its present elements. */
	next = 0;
	for (argument = 0; argument <= count; argument++) {
		item = object;
		if (argument > 0)
			item = args[argument - 1U];
		roots[3] = NULL;
		is_cell = vm_value_is_cell(item);
		if (is_cell)
			roots[3] = vm_value_as_cell(item);
		status = array_is_concat_spreadable(realm, item, &spreadable);
		if (status != 0)
			goto cleanup;
		if (!spreadable) {
			/* A result element is an own default data property and cannot invoke an inherited setter. */
			status = vm_object_define(realm->heap, (struct vm_object *)roots[1], vm_value_int32((int32_t)next), item, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
			next++;
			continue;
		}

		/* Snapshot length before testing each index; absent properties retain holes in the result. */
		status = js_builtin_length(realm, item, &length);
		if (status != 0)
			goto cleanup;
		for (index = 0; index < length; index++) {
			status = array_has(realm, item, index, &found);
			if (status != 0)
				goto cleanup;
			if (!found)
				continue;

			/* A newly returned element needs ownership before destination property creation may collect. */
			status = array_get(realm, item, index, &value);
			if (status != 0)
				goto cleanup;
			roots[2] = NULL;
			is_cell = vm_value_is_cell(value);
			if (is_cell)
				roots[2] = vm_value_as_cell(value);
			status = vm_object_define(realm->heap, (struct vm_object *)roots[1], vm_value_int32((int32_t)(next + index)), value, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
		}

		/* Logical position includes skipped holes, even when no own destination element was created. */
		next += length;
	}

	/* Publish the final logical length, including any trailing holes. */
	status = array_set_length(realm, *result, (double)next);

cleanup:
	/* All partially registered roots and abrupt source operations retire through the same ownership exit. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Propagate the source's original abrupt completion or allocation error. */
	if (status != 0)
		return status;

	/* Succeeded: the plain result contains own data elements with source holes preserved. */
	return 0;
}

static int
array_flat(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[2];
	vm_value object;
	vm_value depth_value;
	double depth;
	uint32_t length;
	unsigned registered;
	unsigned index;
	int status;

	/* Box the receiver and read its length before depth conversion or mapper validation. */
	status = array_this(realm, this_value, &object, &length);
	if (status != 0)
		return status;

	/* A newly boxed source and unpublished result remain independently rooted through every later callback. */
	roots[0] = vm_value_as_cell(object);
	roots[1] = NULL;
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Depth conversion may run arbitrary script and collect the temporary boxed source. */
	depth = 1.0;
	depth_value = js_argument(args, count, 0);
	if (depth_value != VM_VALUE_UNDEFINED) {
		status = js_builtin_integer(realm, depth_value, &depth);
		if (status != 0)
			goto cleanup;
	}

	/* Create the plain destination only after source conversions finish. */
	status = array_new(realm, result);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(*result);
	status = array_flatten(realm, *result, object, length, depth, VM_VALUE_UNDEFINED, VM_VALUE_UNDEFINED);

cleanup:
	/* Neither conversion failure nor a recursive source exception may leak native source or result ownership. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original abrupt completion from conversion, mapper or nested array inspection. */
	if (status != 0)
		return status;

	/* Succeeded: the plain destination contains the requested flattened values. */
	return 0;
}

static int
array_flat_map(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[2];
	vm_value object;
	vm_value mapper;
	uint32_t length;
	unsigned registered;
	unsigned index;
	int status;

	/* Box the receiver and read its length before depth conversion or mapper validation. */
	status = array_this(realm, this_value, &object, &length);
	if (status != 0)
		return status;

	/* A newly boxed source and unpublished result remain independently rooted through every later callback. */
	roots[0] = vm_value_as_cell(object);
	roots[1] = NULL;
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Mapper validation follows source length retrieval, while the converted source remains owned. */
	status = array_callback(realm, args, count, &mapper);
	if (status != 0)
		goto cleanup;

	/* Create the plain destination only after source conversions finish. */
	status = array_new(realm, result);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(*result);
	status = array_flatten(realm, *result, object, length, 1.0, mapper, js_argument(args, count, 1));

cleanup:
	/* Neither conversion failure nor a recursive source exception may leak native source or result ownership. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original abrupt completion from conversion, mapper or nested array inspection. */
	if (status != 0)
		return status;

	/* Succeeded: the plain destination contains the requested flattened values. */
	return 0;
}

static int
array_flatten(
	struct vm_realm *realm,
	vm_value target,
	vm_value source,
	uint32_t source_length,
	double depth,
	vm_value mapper,
	vm_value this_arg)
{
	struct vm_cell *value_root;
	vm_value value;
	vm_value call_args[3];
	uint32_t index;
	uint32_t length;
	int found;
	int is_array;
	int is_cell;
	int status;

	/* Each present element. */
	value_root = NULL;
	status = vm_heap_add_root(realm->heap, &value_root);
	if (status != 0)
		return status;
	for (index = 0; index < source_length; index++) {
		status = array_has(realm, source, index, &found);
		if (status == 0 && found)
			status = array_get(realm, source, index, &value);
		if (status != 0)
			goto cleanup;
		if (!found)
			continue;
		value_root = NULL;
		is_cell = vm_value_is_cell(value);
		if (is_cell)
			value_root = vm_value_as_cell(value);
		if (mapper != VM_VALUE_UNDEFINED) {
			call_args[0] = value;
			call_args[1] = vm_value_int32((int32_t)index);
			call_args[2] = source;
			status = vm_call(realm, mapper, this_arg, call_args, 3, &value);
			if (status != 0)
				goto cleanup;
			value_root = NULL;
			is_cell = vm_value_is_cell(value);
			if (is_cell)
				value_root = vm_value_as_cell(value);
		}

		/* An array within the depth is flattened; anything else appended. */
		is_array = 0;
		if (depth > 0.0) {
			status = vm_is_array(realm, value, &is_array);
			if (status != 0)
				goto cleanup;
		}

		/* Zero or negative depth appends even a revoked Proxy without testing its array identity. */
		if (is_array) {
			status = js_builtin_length(realm, value, &length);
			if (status == 0)
				status = array_flatten(realm, target, value, length, depth - 1.0, VM_VALUE_UNDEFINED, VM_VALUE_UNDEFINED);
		} else {
			status = array_append(realm, target, value);
		}

		/* A failure ends the flattening. */
		if (status != 0)
			goto cleanup;
	}

	/* The mapped value no longer spans another getter or recursive call. */
cleanup:
	vm_heap_remove_root(realm->heap, &value_root);
	return status;
}

static int
array_is_concat_spreadable(
	struct vm_realm *realm,
	vm_value value,
	int *spreadable)
{
	vm_value override;
	int is_object;
	int status;

	/* Primitives contribute one item and cannot supply a spreadability override. */
	*spreadable = 0;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* A present override is converted only to Boolean, without coercing any returned object. */
	status = vm_get(realm, value, vm_symbol_key(realm, VM_SYMBOL_IS_CONCAT_SPREADABLE), &override);
	if (status != 0)
		return status;
	if (override != VM_VALUE_UNDEFINED) {
		*spreadable = vm_to_boolean(override);
		return 0;
	}

	/* Without an override, actual array identity unwraps nested Proxies and preserves revoked-record errors. */
	status = vm_is_array(realm, value, spreadable);
	if (status != 0)
		return status;

	/* Succeeded: the explicit override or actual array identity supplied spreadability. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A primitive receiver's temporary source box must survive later depth conversion and then become reclaimable. */
	status = flat_source_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
flat_source_length(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *box;
	int is_object;

	UNUSED_PARAMETER(realm);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* The native length getter must receive the actual converted Number object, not the original primitive. */
	is_object = vm_value_is_object(receiver);
	if (!is_object)
		return EFAULT;
	box = (struct vm_object *)vm_value_as_cell(receiver);
	if (box->kind != VM_KIND_NUMBER)
		return EFAULT;
	flat_source_case.box_address = (uintptr_t)box;
	flat_source_case.length_calls++;
	*result = vm_value_int32(1);

	/* Succeeded: only an integer observation survives the length getter's VM-call frame. */
	return 0;
}

static int
flat_source_depth(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Depth conversion occurs after the earlier length getter and temporary array_this frame have returned. */
	vm_heap_stats(realm->heap, &before);
	vm_heap_collect(realm->heap);
	vm_heap_stats(realm->heap, &after);
	if (after.collections <= before.collections)
		return EFAULT;
	found = vm_heap_find_cell(realm->heap, flat_source_case.box_address);
	if (found == NULL)
		return EFAULT;
	flat_source_case.depth_collections++;
	*result = vm_value_int32(1);

	/* Succeeded: the outer consumer retained its sole boxed source through an actual later collection. */
	return 0;
}

static int
flat_source_pressure(
	struct page *page)
{
	struct vm_object *depth;
	struct vm_cell *roots[2];
	struct vm_cell *found;
	struct vm_descriptor prior;
	vm_value key;
	vm_value function;
	vm_value argument;
	vm_value answer;
	uintptr_t depth_address;
	uintptr_t output_address;
	unsigned registered;
	unsigned index;
	int present;
	int deleted;
	int installed;
	int status;
	int restore;

	/* Only construction and the eventual output use embedding roots; the source box is never one of them. */
	memset(roots, 0, sizeof(roots));
	memset(&flat_source_case, 0, sizeof(flat_source_case));
	registered = 0;
	installed = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The isolated page's Number prototype must have no existing length property for this temporary getter. */
	key = vm_key_from_ascii(page->heap, "length");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* No preexisting descriptor is replaced or silently lost by this lifetime fixture. */
	status = vm_get_own_property(page->realm, page->realm->intrinsics[VM_INTRINSIC_NUMBER_PROTOTYPE], key, &prior, &present);
	if (status != 0)
		goto cleanup;
	if (present) {
		status = EFAULT;
		goto cleanup;
	}

	/* A real inherited getter observes the fresh box created only inside the production flat consumer. */
	status = js_builtin_accessor(page->realm, page->realm->intrinsics[VM_INTRINSIC_NUMBER_PROTOTYPE], "length", flat_source_length, NULL);
	if (status != 0)
		goto cleanup;
	installed = 1;
	depth = vm_object_create(page->heap, NULL);
	if (depth == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Actual depth coercion uses the ordinary native valueOf method and cannot access the source through a closure. */
	roots[0] = &depth->cell;
	depth_address = (uintptr_t)depth;
	status = js_builtin_method(page->realm, depth, "valueOf", 0, flat_source_depth);
	if (status != 0)
		goto cleanup;
	key = vm_key_from_ascii(page->heap, "flat");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Invoke the actual installed Array.prototype.flat with a primitive Number receiver and the coercible depth. */
	status = vm_get(page->realm, vm_value_cell(page->realm->array_prototype), key, &function);
	if (status != 0)
		goto cleanup;
	argument = vm_value_cell(depth);
	roots[0] = NULL;
	status = vm_call(page->realm, function, vm_value_int32(1), &argument, 1, &answer);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(answer);
	output_address = (uintptr_t)roots[1];
	if (flat_source_case.length_calls != 1U || flat_source_case.depth_collections != 1U) {
		status = EFAULT;
		goto cleanup;
	}

	/* Output-only ownership permits the earlier source box and depth argument to be actually reclaimed. */
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, flat_source_case.box_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* The depth object's former call ownership also ends with the real consumer invocation. */
	found = vm_heap_find_cell(page->heap, depth_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* Dropping the independent result root leaves the ordinary output array reclaimable as well. */
	roots[1] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, output_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* The actual flat wrapper retained its sole box across later script and released both input and output ownership. */
	status = 0;

cleanup:
	/* Restore the isolated intrinsic before another fixture or page teardown can observe the temporary length getter. */
	if (installed) {
		key = vm_key_from_ascii(page->heap, "length");
		if (key == VM_VALUE_EMPTY) {
			if (status == 0)
				status = ENOMEM;
		} else {
			deleted = 0;
			restore = vm_object_delete(page->heap, page->realm->intrinsics[VM_INTRINSIC_NUMBER_PROTOTYPE], key, &deleted);
			if (restore != 0 && status == 0)
				status = restore;
			if (!deleted && status == 0)
				status = EFAULT;
		}
	}

	/* Weak observations and partial setup roots never outlive the synchronous lifetime case. */
	memset(&flat_source_case, 0, sizeof(flat_source_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve lifetime, restoration or native-call errors after all cleanup. */
	if (status != 0)
		return status;

	/* Succeeded: the actual temporary source, depth argument and final result were independently reclaimed. */
	return 0;
}
