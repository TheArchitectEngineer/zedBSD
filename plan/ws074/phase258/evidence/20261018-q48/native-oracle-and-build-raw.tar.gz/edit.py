from pathlib import Path
import re,json
q=Path('build/ws074-20261018/q48');p=Path('userland/desktop/libbrowser/js/builtin_object.c');s=p.read_text();a=s.index('static int\nobject_to_string(');b=s.index('\n}\n',a)+2;t=s[a:b].replace('\n\tint is_string;','\n\tint is_array;\n\tint is_string;').replace('\n\t\ttag = object_tag(value, object);','');i=t.index('\n\t\t/* A string Symbol.toStringTag');t=t[:i]+'''
		/* Actual array identity is determined before observing a custom tag, including revoked Proxy errors. */
		status = vm_is_array(realm, value, &is_array);
		if (status != 0)
			goto cleanup;
		if (is_array)
			tag = "Array";
		else
			tag = object_tag(value, object);
'''+t[i:];s=s[:a]+t+s[b:];p.write_text(s)
p=Path('userland/desktop/libbrowser/js/builtin_array.c');s=p.read_text()
def replace(name,body):
 global s
 pat=r'static int\n'+name+r'\(\n.*?\n\}';s,n=re.subn(pat,lambda m:body,s,flags=re.S);assert n==1,name
replace('array_concat','''static int
array_concat(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[4];
	vm_value object;
	vm_value item;
	vm_value value;
	uint32_t length;
	uint32_t index;
	uint32_t next;
	unsigned argument;
	unsigned registered;
	unsigned root_index;
	int found;
	int spreadable;
	int is_cell;
	int status;

	/* The converted source, result, current element and current item survive all protocol callbacks. */
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		return status;
	memset(roots, 0, sizeof(roots));
	roots[0] = vm_value_as_cell(object);
	registered = 0;
	for (root_index = 0; root_index < 4U; root_index++) {
		status = vm_heap_add_root(realm->heap, &roots[root_index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Keep the plain newly created destination alive before any item can run getters. */
	status = array_new(realm, result);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(*result);

	/* Each source item first observes its actual spreadability, then either contributes itself or its present elements. */
	next = 0;
	for (argument = 0; argument <= count; argument++) {
		item = object;
		if (argument > 0)
			item = args[argument - 1U];
		roots[3] = NULL;
		is_cell = vm_value_is_cell(item);
		if (is_cell)
			roots[3] = vm_value_as_cell(item);
		status = array_is_concat_spreadable(realm, item, &spreadable);
		if (status != 0)
			goto cleanup;
		if (!spreadable) {
			/* A result element is an own default data property and cannot invoke an inherited setter. */
			status = vm_object_define(realm->heap, (struct vm_object *)roots[1], vm_value_int32((int32_t)next), item, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
			next++;
			continue;
		}

		/* Snapshot length before testing each index; absent properties retain holes in the result. */
		status = js_builtin_length(realm, item, &length);
		if (status != 0)
			goto cleanup;
		for (index = 0; index < length; index++) {
			status = array_has(realm, item, index, &found);
			if (status != 0)
				goto cleanup;
			if (!found)
				continue;

			/* A newly returned element needs ownership before destination property creation may collect. */
			status = array_get(realm, item, index, &value);
			if (status != 0)
				goto cleanup;
			roots[2] = NULL;
			is_cell = vm_value_is_cell(value);
			if (is_cell)
				roots[2] = vm_value_as_cell(value);
			status = vm_object_define(realm->heap, (struct vm_object *)roots[1], vm_value_int32((int32_t)(next + index)), value, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
		}

		/* Logical position includes skipped holes, even when no own destination element was created. */
		next += length;
	}

	/* Publish the final logical length, including any trailing holes. */
	status = array_set_length(realm, *result, (double)next);

cleanup:
	/* All partially registered roots and abrupt source operations retire through the same ownership exit. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Propagate the source's original abrupt completion or allocation error. */
	if (status != 0)
		return status;

	/* Succeeded: the plain result contains own data elements with source holes preserved. */
	return 0;
}''')
for name,flatmap in [('array_flat',False),('array_flat_map',True)]:
 head='''static int
NAME(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[2];
	vm_value object;
'''.replace('NAME',name)
 decl='\tvm_value mapper;\n' if flatmap else '\tvm_value depth_value;\n\tdouble depth;\n'
 body=head+decl+'''	uint32_t length;
	unsigned registered;
	unsigned index;
	int status;

	/* Box the receiver and read its length before depth conversion or mapper validation. */
	status = array_this(realm, this_value, &object, &length);
	if (status != 0)
		return status;

	/* A newly boxed source and unpublished result remain independently rooted through every later callback. */
	roots[0] = vm_value_as_cell(object);
	roots[1] = NULL;
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}
'''
 if flatmap:body+='''
	/* Mapper validation follows source length retrieval, while the converted source remains owned. */
	status = array_callback(realm, args, count, &mapper);
	if (status != 0)
		goto cleanup;
'''
 else:body+='''
	/* Depth conversion may run arbitrary script and collect the temporary boxed source. */
	depth = 1.0;
	depth_value = js_argument(args, count, 0);
	if (depth_value != VM_VALUE_UNDEFINED) {
		status = js_builtin_integer(realm, depth_value, &depth);
		if (status != 0)
			goto cleanup;
	}
'''
 body+='''
	/* Create the plain destination only after source conversions finish. */
	status = array_new(realm, result);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(*result);
'''
 if flatmap:body+='\tstatus = array_flatten(realm, *result, object, length, 1.0, mapper, js_argument(args, count, 1));\n'
 else:body+='\tstatus = array_flatten(realm, *result, object, length, depth, VM_VALUE_UNDEFINED, VM_VALUE_UNDEFINED);\n'
 body+='''
cleanup:
	/* Neither conversion failure nor a recursive source exception may leak native source or result ownership. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original abrupt completion from conversion, mapper or nested array inspection. */
	if (status != 0)
		return status;

	/* Succeeded: the plain destination contains the requested flattened values. */
	return 0;
}''';replace(name,body)
a=s.index('static int\narray_flatten(');b=s.index('\n}\n',a)+2;t=s[a:b];x='''		is_array = array_is_array_value(value);
		if (is_array && depth > 0.0) {''';assert x in t;t=t.replace(x,'''		is_array = 0;
		if (depth > 0.0) {
			status = vm_is_array(realm, value, &is_array);
			if (status != 0)
				goto cleanup;
		}

		/* Zero or negative depth appends even a revoked Proxy without testing its array identity. */
		if (is_array) {''');s=s[:a]+t+s[b:]
replace('array_is_array_value','''static int
array_is_concat_spreadable(
	struct vm_realm *realm,
	vm_value value,
	int *spreadable)
{
	vm_value override;
	int is_object;
	int status;

	/* Primitives contribute one item and cannot supply a spreadability override. */
	*spreadable = 0;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* A present override is converted only to Boolean, without coercing any returned object. */
	status = vm_get(realm, value, vm_symbol_key(realm, VM_SYMBOL_IS_CONCAT_SPREADABLE), &override);
	if (status != 0)
		return status;
	if (override != VM_VALUE_UNDEFINED) {
		*spreadable = vm_to_boolean(override);
		return 0;
	}

	/* Without an override, actual array identity unwraps nested Proxies and preserves revoked-record errors. */
	status = vm_is_array(realm, value, spreadable);
	if (status != 0)
		return status;

	/* Succeeded: the explicit override or actual array identity supplied spreadability. */
	return 0;
}''')
s,n=re.subn(r'^static int array_is_array_value\([^\n]*;\n','',s,flags=re.M);assert n==1
m=re.search(r'^static int array_flatten\([^\n]*;\n',s,re.M);assert m;decl=m.group();s=s[:m.start()]+s[m.end():];i=s.index('/*\n * Installs Array.\n */');s=s[:i]+decl+'static int array_is_concat_spreadable(struct vm_realm *realm, vm_value value, int *spreadable);\n\n'+s[i:];p.write_text(s)
(q/'function-review-scope.json').write_text(json.dumps({'userland/desktop/libbrowser/js/builtin_object.c':['object_to_string'],'userland/desktop/libbrowser/js/builtin_array.c':['array_concat','array_flat','array_flat_map','array_flatten','array_is_concat_spreadable']},indent=2)+'\n')
s=Path('build/ws074-20261018/q47/format.py').read_text();a=s.index(';mapping=');b=s.index(';chunks=[]',a);s=s[:a]+';mapping='+repr(json.loads((q/'function-review-scope.json').read_text()))+s[b:];s=s.replace('q47','q48');(q/'format.py').write_text(s)
