from pathlib import Path
import subprocess,re,json,hashlib
q=Path('build/ws074-20261018/q48');mapping=json.loads((q/'function-review-scope.json').read_text());base='0fb5a4c85'
def strip(t):return re.sub(r'\s+','',re.sub(r'/\*.*?\*/|//[^\n]*','',t,flags=re.S))
for path,names in mapping.items():
 a=subprocess.check_output(['git','show',base+':'+path],text=True);b=Path(path).read_text();selected=list(names)
 if path.endswith('builtin_array.c'):selected.append('array_is_array_value')
 for n in selected:
  pat=r'(?:static )?(?:int|void)\n'+n+r'\(\n.*?\n\}';a=re.sub(pat,'',a,flags=re.S);b=re.sub(pat,'',b,flags=re.S)
  pat=r'^static (?:int|void) '+n+r'\([^\n]*;\n';a=re.sub(pat,'',a,flags=re.M);b=re.sub(pat,'',b,flags=re.M)
 if path.endswith('host-proxy-read.c'):
  b=re.sub(r'struct flat_source_observation \{.*?\n\};','',b,flags=re.S);b=re.sub(r'^static struct flat_source_observation flat_source_case;\n','',b,flags=re.M)
 assert strip(a)==strip(b),path
lines=(q/'style-raw.log').read_text().splitlines();assert len(lines)==77 and all(': goto: goto cleanup;' in l for l in lines)
generated=(q/'generated-functions.c').read_text();functions=re.findall(r'(?:static )?(?:int|void)\n\w+\(\n.*?\n\}',generated,re.S)
for f in functions:
 jumps=[m.start() for m in re.finditer('goto cleanup;',f)]
 if jumps:assert f.count('\ncleanup:')==1 and max(jumps)<f.index('\ncleanup:')
oldjs=Path('build/ws074-20261018/q47/final/engine/proxy-read.js').read_bytes();prefix=oldjs.split(b" console.log('read-proxy controls:")[0];current=Path('plan/ws074/tests/proxy-read.js').read_bytes();assert current.startswith(prefix)
old=json.loads(Path('build/ws074-20261018/q47/final/source-proof.json').read_text());unchanged={p:d for p,d in old.items() if p.startswith('userland/desktop/libbrowser/') and p not in mapping};assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==d for p,d in unchanged.items())
proof=dict(tokens_outside_selected_product_and_fixture_functions_identical=True,other_engine_source_and_headers_unchanged=True,all_VM_source_and_headers_unchanged=True,native_operations_definition_comment_unchanged=True,old658_prefix_unchanged=True,added_conditions=32,precode_failed_conditions=23,full_changed_functions=mapping,removed_old_kind_helper='array_is_array_value',normal_helpers_after_tables=['array_flatten','array_is_concat_spreadable'],raw_allowed_cleanup=77,only_single_forward_cleanup_proved=True,other_checker_findings=0,manual_review=['ANSI declarations first/multiline/public-static order/semantic paragraphs and compound clauses','ObjectToString roots converted receiver then actual IsArray before custom tag Get; revoked errors propagate; saved builtin tag unaffected by later revocation','IsConcatSpreadable only objects Get symbol override, ToBoolean without object coercion; undefined only fallback IsArray','concat converted receiver/current item/fresh output element/result separate roots, own default data definitions bypass inherited setters and preserve holes','concat registration initializes placeholders before acquisition and uses one forward cleanup for partial registration/abrupt source/length operations','flat and flatMap root freshly boxed source after array_this until depth conversion/mapper/flatten completes; result placeholder rooted before allocation','flatten retains mapped fresh values, tests depth before actual IsArray, zero/negative depth never inspects revoked item identity; recursion source held by parent temporary root','new native weak observer sees actual Number wrapper during inherited length getter, later actual depth valueOf GC proves source box alive after array_this/length frames retire; output-only then source/depth reclaim then output reclaim, temporary Number intrinsic getter restored','Species/custom result/upper-index storage/wide lengths/general recursion resource policy/JSON/for-in/call/global/p100 remain pending','main source/terminal containment and conflicts verified separately; master.md never in owned staged paths'])
(q/'source-audit.json').write_text(json.dumps(proof,indent=2)+'\n');(q/'old-prefix-proof.json').write_text(json.dumps(dict(old_source_sha256=hashlib.sha256(oldjs).hexdigest(),old658_prefix_sha256=hashlib.sha256(prefix).hexdigest(),unchanged_prefix=True,added_conditions=32),indent=2)+'\n');print('10 functions, bounded changes; 77 single forward cleanup, other0')
