int js_builtin_install_proxy(struct vm_realm *realm);
static int proxy_construct(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int proxy_revocable(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int proxy_revoke(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
int js_install_builtins(struct vm_realm *realm);
int main(int argc, char **argv);
static int public_installer_pressure(struct page *page);
static int public_revoker_pressure(struct page *page);

int
js_builtin_install_proxy(
	struct vm_realm *realm)
{
	struct vm_cell *roots[3];
	struct vm_function *constructor;
	struct vm_function *method;
	unsigned index;
	unsigned registered;
	int status;

	/* Acquire empty placeholders before the first function or cold property-key allocation. */
	memset(roots, 0, sizeof(roots));
	roots[0] = &realm->cell;
	if (!realm->managed)
		roots[0] = NULL;
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup owns only registrations that reached the heap registry. */
		registered++;
	}

	/* The function factory creates only name and length, so Proxy gains no own prototype property. */
	status = js_builtin_function(realm, "Proxy", 2, proxy_construct, proxy_construct, &constructor);
	if (status != 0)
		goto cleanup;
	roots[1] = &constructor->object.cell;
	status = js_builtin_function(realm, "revocable", 2, proxy_revocable, NULL, &method);
	if (status != 0)
		goto cleanup;

	/* The method must survive key creation before its constructor property owns it. */
	roots[2] = &method->object.cell;
	status = js_builtin_value(realm, &constructor->object, "revocable", vm_value_cell(method), JS_BUILTIN_METHOD);
	if (status != 0)
		goto cleanup;
	status = js_builtin_value(realm, realm->global, "Proxy", vm_value_cell(constructor), JS_BUILTIN_METHOD);
	if (status != 0)
		goto cleanup;

cleanup:
	/* All unpublished function and input-realm edges retire only after installation finishes or fails. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve allocation, key-definition and registration errors. */
	if (status != 0)
		return status;

	/* Succeeded: the realm's global object owns the complete Proxy surface. */
	return 0;
}

static int
proxy_construct(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	int status;

	UNUSED_PARAMETER(this_value);

	/* A direct function call refuses before touching either user-provided input. */
	if (realm->new_target == VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Proxy constructor requires new");
		return status;
	}

	/* ProxyCreate validates both arguments without reading any user-visible property. */
	status = vm_proxy_create(realm, js_argument(args, count, 0), js_argument(args, count, 1), result);
	if (status != 0)
		return status;

	/* Succeeded: return the actual managed native Proxy. */
	return 0;
}

static int
proxy_revocable(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[4];
	struct vm_function *revoker;
	struct vm_object *pair;
	vm_value proxy;
	unsigned index;
	unsigned registered;
	int status;

	UNUSED_PARAMETER(this_value);

	/* Root the input realm and all fresh results before any factory can collect. */
	memset(roots, 0, sizeof(roots));
	if (realm->managed)
		roots[0] = &realm->cell;
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Only completed registry insertions belong to the shared cleanup path. */
		registered++;
	}

	/* Both native creation entry points share the same actual validation and internal methods. */
	status = vm_proxy_create(realm, js_argument(args, count, 0), js_argument(args, count, 1), &proxy);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(proxy);
	status = js_builtin_function(realm, "", 0, proxy_revoke, NULL, &revoker);
	if (status != 0)
		goto cleanup;

	/* The revoker's normal traced native data represents its private RevocableProxy slot. */
	roots[2] = &revoker->object.cell;
	revoker->data = proxy;
	pair = vm_object_create(realm->heap, realm->object_prototype);
	if (pair == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Publish proxy before revoke, with ordinary writable/enumerable/configurable own properties. */
	roots[3] = &pair->cell;
	status = js_builtin_value(realm, pair, "proxy", proxy, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = js_builtin_value(realm, pair, "revoke", vm_value_cell(revoker), VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	*result = vm_value_cell(pair);

cleanup:
	/* No collector registry entry may outlive its native placeholder storage. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* A failed factory never publishes a partially initialized result pair. */
	if (status != 0)
		return status;

	/* Succeeded: the pair owns both native results until the caller takes over. */
	return 0;
}

static int
proxy_revoke(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_function *function;
	vm_value proxy;
	int status;

	UNUSED_PARAMETER(this_value);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Undefined data represents the cleared internal slot and makes every subsequent invocation inert. */
	*result = VM_VALUE_UNDEFINED;
	function = js_builtin_callee(realm);
	proxy = function->data;
	if (proxy == VM_VALUE_UNDEFINED)
		return 0;

	/* Clear the revoker's ownership edge before the actual Proxy record releases target and handler. */
	function->data = VM_VALUE_UNDEFINED;
	status = vm_proxy_revoke(realm, proxy);
	if (status != 0)
		return status;

	/* Succeeded: all later operations observe the actual revoked internal slots. */
	return 0;
}

int
js_install_builtins(
	struct vm_realm *realm)
{
	int error;

	/* Installs Error constructors before later failures need native exception objects. */
	error = js_builtin_install_error(realm);
	if (error != 0)
		return error;

	/* Installs the Object prototype foundation used by ordinary builtin objects. */
	error = js_builtin_install_object(realm);
	if (error != 0)
		return error;

	/* Installs callable Function objects after their ordinary object foundation. */
	error = js_builtin_install_function(realm);
	if (error != 0)
		return error;

	/* Installs Symbol keys before subsequent collections use symbolic protocols. */
	error = js_builtin_install_symbol(realm);
	if (error != 0)
		return error;

	/* Installs Array construction and indexed storage operations. */
	error = js_builtin_install_array(realm);
	if (error != 0)
		return error;

	/* Installs String wrappers and native UTF16 operations. */
	error = js_builtin_install_string(realm);
	if (error != 0)
		return error;

	/* Installs regular expression objects after their String inputs are available. */
	error = js_builtin_install_regexp(realm);
	if (error != 0)
		return error;

	/* Installs Date objects and their established native time operations. */
	error = js_builtin_install_date(realm);
	if (error != 0)
		return error;

	/* Installs structured JSON conversion after its object and string dependencies. */
	error = js_builtin_install_json(realm);
	if (error != 0)
		return error;

	/* Installs Boolean wrappers and their primitive conversions. */
	error = js_builtin_install_boolean(realm);
	if (error != 0)
		return error;

	/* Installs Number wrappers and numeric conversion methods. */
	error = js_builtin_install_number(realm);
	if (error != 0)
		return error;

	/* Installs BigInt beside Number. */
	error = js_builtin_install_bigint(realm);
	if (error != 0)
		return error;

	/* Installs ArrayBuffer, the typed arrays and DataView (their prelude needs Array, Object and Symbol). */
	error = js_builtin_install_typed(realm);
	if (error != 0)
		return error;

	/* Installs the shared Math operations after numeric objects are ready. */
	error = js_builtin_install_math(realm);
	if (error != 0)
		return error;

	/* Installs ordinary global conversion and evaluation functions. */
	error = js_builtin_install_global(realm);
	if (error != 0)
		return error;

	/* Installs URI encoding and decoding on the completed global object. */
	error = js_builtin_install_uri(realm);
	if (error != 0)
		return error;

	/* Installs the iterator prototype foundation for iterable builtin protocols. */
	error = js_builtin_install_iterator(realm);
	if (error != 0)
		return error;

	/* Installs Promise objects and their existing microtask protocol. */
	error = js_builtin_install_promise(realm);
	if (error != 0)
		return error;

	/* Installs generator objects and their suspended execution protocol. */
	error = js_builtin_install_generator(realm);
	if (error != 0)
		return error;

	/* Installs keyed collections after iterator and Symbol foundations. */
	error = js_builtin_install_collection(realm);
	if (error != 0)
		return error;

	/* Installs native Proxy after its callable, Array and property-protocol foundations are complete. */
	error = js_builtin_install_proxy(realm);
	if (error != 0)
		return error;

	/* Publishes builtin type tags only after all referenced objects exist. */
	error = js_builtin_install_tags(realm);
	if (error != 0)
		return error;

	/* Succeeded: the realm has its built-ins. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* Private construction and foreign-realm bridges leave the product globals unpublished. */
	status = js_builtin_method(page->realm, page->realm->global, "constructReadProxy", 2, proxy_construct);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeForeignReadConstructor", 0, proxy_foreign_constructor);
	if (status != 0)
		goto cleanup;

	/* The parser probe reaches the unchanged production allocation threshold without editing heap policy. */
	status = js_builtin_method(page->realm, page->realm->global, "pressureReadProxy", 0, proxy_parse_pressure);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* The product now publishes its actual constructor while private bridges retain independent core controls. */
	status = proxy_script(page->realm, "typeof Proxy==='function'&&Proxy.length===2&&!Object.prototype.hasOwnProperty.call(Proxy,'prototype')&&"
					   "(function(){var p=makeReadProxy(function(){return 7;},{});return typeof p==='function'&&p()===7;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fresh coercion text must survive a later parser allocation after the toString call frame has retired. */
	status = proxy_script(page->realm,
			      "(function(){var before,r=JSON.parse({toString:function(){var text=['{','\"a\":[1,{\"b\":2}]}'].join('');before=pressureReadProxy();return text;}});return r.a[1].b===2&&pressureReadProxy(true)>before;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Publish only the actual threshold-counter and parsed-value gate after both have passed. */
	puts("native JSON parser threshold collection: passed");

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 ||
	    !done) {
		status = 1;
		goto cleanup;
	}

	/* A direct CopyDataProperties call must own its bare native inputs and a fresh getter result through target policy. */
	status = spread_copy_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native object copy collection and reclamation: passed");

	/* Direct start and next calls must own their managed caller, private state and source without embedding roots. */
	status = for_in_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native for-in collection and reclamation: passed");

	/* Public installation and detached revocation exercise actual builtin graph ownership. */
	status = public_installer_pressure(page);
	if (status != 0)
		goto cleanup;
	status = public_revoker_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native public Proxy installation and revoker reclamation: passed");

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Direct native invocation must own revoked snapshots, fresh methods and argument Arrays during actual GC. */
	status = invoke_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native proxy invocation snapshots and reclamation: passed");

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A primitive receiver's temporary source box must survive later depth conversion and then become reclaimable. */
	status = flat_source_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
public_installer_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_cell *root;
	struct vm_cell *pressure;
	struct vm_cell *cell;
	struct vm_property property;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	uintptr_t addresses[3];
	vm_value constructor;
	vm_value global_key;
	vm_value method_key;
	unsigned index;
	int found;
	int status;

	/* Root setup only until the direct installer accepts its otherwise unowned managed realm. */
	root = NULL;
	status = vm_heap_add_root(page->heap, &root);
	if (status != 0)
		return status;
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	root = &realm->cell;
	global_key = vm_key_from_ascii(page->heap, "Proxy");
	if (global_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Preintern both observation keys so post-call liveness checks cannot allocate or reuse a dead cell. */
	method_key = vm_key_from_ascii(page->heap, "revocable");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Force the first real function allocation past the unchanged production collection threshold. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The production installer must supply every ownership edge during its own allocations. */
	addresses[0] = (uintptr_t)realm;
	root = NULL;
	vm_heap_stats(page->heap, &before);
	status = js_builtin_install_proxy(realm);
	vm_heap_stats(page->heap, &after);
	if (status != 0)
		goto cleanup;
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* Both public functions must be present in the newly installed real realm. */
	found = vm_object_get_own(realm->global, global_key, &property);
	if (found != 1) {
		status = 1;
		goto cleanup;
	}

	/* Read the installed constructor without another heap allocation. */
	constructor = *property.value;
	addresses[1] = (uintptr_t)vm_value_as_cell(constructor);
	found = vm_object_get_own((struct vm_object *)vm_value_as_cell(constructor), method_key, &property);
	if (found != 1) {
		status = 1;
		goto cleanup;
	}

	/* The constructor and method only own this unrooted managed realm through their actual function edges. */
	addresses[2] = (uintptr_t)vm_value_as_cell(*property.value);
	vm_heap_collect(page->heap);
	for (index = 0; index < 3U; index++) {
		cell = vm_heap_find_cell(page->heap, addresses[index]);
		if (cell != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* Installation did not leave any hidden permanent root for its independently collectible realm. */
	status = 0;

cleanup:
	/* The one acquired placeholder never outlives this direct native frame. */
	vm_heap_remove_root(page->heap, &root);
	if (status != 0)
		return status;

	/* Succeeded: the installer owns its realm during allocation and releases that ownership on return. */
	return 0;
}

static int
public_revoker_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_function *revoker;
	struct vm_cell *roots[5];
	struct vm_cell *pressure;
	struct vm_cell *cell;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	uintptr_t addresses[6];
	vm_value method;
	vm_value args[2];
	vm_value pair;
	vm_value proxy;
	vm_value revoke;
	vm_value answer;
	vm_value proxy_key;
	vm_value revoke_key;
	unsigned index;
	unsigned registered;
	int status;

	/* The method is the real installed public builtin, permanently owned by the Page global. */
	status = proxy_script(page->realm, "Proxy.revocable", &method);
	if (status != 0)
		return status;
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Only acquired setup placeholders belong to cleanup. */
		registered++;
	}

	/* The direct caller has no realm backedge from the Page-owned builtin or its ordinary input objects. */
	status = vm_realm_create_managed(page->heap, &caller);
	if (status != 0)
		goto cleanup;
	roots[0] = &caller->cell;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The input handler also has no managed-caller prototype or function owner. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Preintern observation keys before all setup ownership retires. */
	roots[2] = &handler->cell;
	proxy_key = vm_key_from_ascii(page->heap, "proxy");
	if (proxy_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The second observation key is also acquired before direct input ownership ends. */
	revoke_key = vm_key_from_ascii(page->heap, "revoke");
	if (revoke_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The first production proxy allocation must collect with only direct API ownership. */
	addresses[0] = (uintptr_t)caller;
	addresses[1] = (uintptr_t)target;
	addresses[2] = (uintptr_t)handler;
	args[0] = vm_value_cell(target);
	args[1] = vm_value_cell(handler);
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* No embedding setup slot or conservative stack root retains the direct caller or inputs. */
	memset(roots, 0, sizeof(roots));
	vm_heap_stats(page->heap, &before);
	status = vm_call(caller, method, VM_VALUE_UNDEFINED, args, 2, &pair);
	vm_heap_stats(page->heap, &after);
	if (status != 0)
		goto cleanup;
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* Protect the returned pair only while extracting its actual public properties. */
	roots[3] = vm_value_as_cell(pair);
	addresses[5] = (uintptr_t)roots[3];
	status = vm_get(page->realm, pair, proxy_key, &proxy);
	if (status != 0)
		goto cleanup;
	status = vm_get(page->realm, pair, revoke_key, &revoke);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(revoke);
	revoker = (struct vm_function *)roots[4];
	addresses[3] = (uintptr_t)vm_value_as_cell(proxy);
	addresses[4] = (uintptr_t)revoker;
	roots[3] = NULL;
	vm_heap_collect(page->heap);

	/* With only the revoker rooted, the caller and result container must be collectible independently. */
	cell = vm_heap_find_cell(page->heap, addresses[0]);
	if (cell != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The ordinary result pair has no owner after its temporary slot retires. */
	cell = vm_heap_find_cell(page->heap, addresses[5]);
	if (cell != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The revoker's real traced data edge alone keeps target, handler and native record alive. */
	for (index = 1; index < 5U; index++) {
		cell = vm_heap_find_cell(page->heap, addresses[index]);
		if (cell == NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* Invoke the actual public revoker with an irrelevant receiver and confirm its result and captured-slot release. */
	status = vm_call(page->realm, revoke, VM_VALUE_TRUE, NULL, 0, &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_UNDEFINED ||
	    revoker->data != VM_VALUE_UNDEFINED) {
		status = 1;
		goto cleanup;
	}

	/* Idempotent invocation must remain harmless after both the revoker and Proxy edges have been cleared. */
	status = vm_call(page->realm, revoke, VM_VALUE_NULL, NULL, 0, &answer);
	if (status != 0)
		goto cleanup;
	vm_heap_collect(page->heap);
	for (index = 1; index < 4U; index++) {
		cell = vm_heap_find_cell(page->heap, addresses[index]);
		if (cell != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* The revoker remains live solely because its embedding result root has not yet retired. */
	cell = vm_heap_find_cell(page->heap, addresses[4]);
	if (cell == NULL) {
		status = 1;
		goto cleanup;
	}

	/* Retire the final revoker owner before observing its own reclamation. */
	roots[4] = NULL;
	vm_heap_collect(page->heap);
	cell = vm_heap_find_cell(page->heap, addresses[4]);
	if (cell != NULL) {
		status = 1;
		goto cleanup;
	}

	/* All direct-call, captured-graph and detached-result reclamation observations succeeded. */
	status = 0;

cleanup:
	/* No registry slot remains after this synchronous fixture returns. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve the actual API failure or independent lifetime failure. */
	if (status != 0)
		return status;

	/* Succeeded: the captured graph lives until revocation, and the detached revoker lives until its last owner retires. */
	return 0;
}
