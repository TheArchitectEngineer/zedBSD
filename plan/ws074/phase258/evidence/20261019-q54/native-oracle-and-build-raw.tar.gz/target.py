from pathlib import Path
import subprocess,shlex,json
q=Path('build/ws074-20261019/q54');(q/'target').mkdir(exist_ok=True);lines=Path('build/ws074-20261018/q02/target-dry-run.log').read_text().splitlines();commands=[]
for source,template in [('js/builtin.c','js/builtin.c'),('js/builtin_proxy.c','js/builtin_function.c')]:
 matches=[shlex.split(l) for l in lines if ' -c userland/desktop/libbrowser/'+template+' ' in l];assert len(matches)==1;args=matches[0];base=list(args);args[args.index('-o')+1]=str(q/'target'/(source.replace('/','_')+'.o'));args[args.index('-c')+1]='userland/desktop/libbrowser/'+source
 with (q/('target-'+source.replace('/','_')+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=f)
 assert r.returncode==0 and not (q/('target-'+source.replace('/','_')+'.log')).read_bytes(),source
 commands.append(dict(source=source,template=template,exact_existing_o_only=source==template,derived_new_module=source!=template,original=base,command=args))
(q/'target-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print('existing exact1/new source-derived1 warning0')
