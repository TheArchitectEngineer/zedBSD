from pathlib import Path
import subprocess,re,json
q=Path('build/ws074-20261019/q54')
mapping={'userland/desktop/libbrowser/js/builtin_proxy.c': ['js_builtin_install_proxy', 'proxy_construct', 'proxy_revocable', 'proxy_revoke'], 'userland/desktop/libbrowser/js/builtin.c': ['js_install_builtins'], 'plan/ws074/tests/host-proxy-read.c': ['main', 'public_installer_pressure', 'public_revoker_pressure']}
chunks=[];protos=[]
for file,names in mapping.items():
 p=Path(file);s=p.read_text()
 for name in names:
  m=re.search(r'(?:static )?(?:int|void|double|struct vm_function \*)\n'+name+r'\(\n.*?\n\}',s,re.S);assert m,name
  f=subprocess.check_output(['clang-format-19','--assume-filename='+file,'--style={BasedOnStyle: InheritParentConfig, ColumnLimit: 0}'],input=m.group().encode()).decode().rstrip();i=f.index('{');h=re.match(r'([^\n]+)\n(\w+)\((.*)\)',f[:i].strip(),re.S);assert h,name;f=h[1]+'\n'+h[2]+'(\n'+',\n'.join('\t'+a.strip() for a in h[3].split(','))+')\n'+f[i:]
  for before,after in [
   ('if (function->code != NULL && (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U)', 'if (function->code != NULL &&\n\t    (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U)'),
   ('if (function->code != NULL && (function->code->flags & VM_CODE_CLASS) != 0U)', 'if (function->code != NULL &&\n\t    (function->code->flags & VM_CODE_CLASS) != 0U)'),
   ('if (method != VM_VALUE_UNDEFINED && !ordinary)', 'if (method != VM_VALUE_UNDEFINED &&\n\t\t    !ordinary)'),
   ('if (status != 0 || !done)', 'if (status != 0 ||\n\t    !done)'),
   ('if (invoke_case.gets != 1U || invoke_case.traps != 1U || after.collections < before.collections + 3U)', 'if (invoke_case.gets != 1U ||\n\t\t    invoke_case.traps != 1U ||\n\t\t    after.collections < before.collections + 3U)')]:f=f.replace(before,after)
  f=f.replace('if (answer != VM_VALUE_UNDEFINED || revoker->data != VM_VALUE_UNDEFINED)', 'if (answer != VM_VALUE_UNDEFINED ||\n\t    revoker->data != VM_VALUE_UNDEFINED)')
  for match in list(re.finditer(r'status = interpreter_push\((.*?)\);',f,re.S))[::-1]:
   args=match[1].split(',');call='status = interpreter_push(\n'+',\n'.join('\t\t    '+a.strip() for a in args)+');';f=f[:match.start()]+call+f[match.end():]
  f=re.sub(r'(\n[ \t]*\}\n)(?=[ \t]*(?!else\b|\}|cleanup:)[^\s])',r'\1\n',f)
  s=s[:m.start()]+f+s[m.end():];chunks.append(f);protos.append(re.sub(r'\s+',' ',f[:f.index('{')].strip()).replace('( ','(')+';')
 p.write_text(s)
(q/'generated-functions.c').write_text('\n'.join(protos)+'\n\n'+'\n\n'.join(chunks)+'\n');(q/'function-review-scope.json').write_text(json.dumps(mapping,indent=2)+'\n')
