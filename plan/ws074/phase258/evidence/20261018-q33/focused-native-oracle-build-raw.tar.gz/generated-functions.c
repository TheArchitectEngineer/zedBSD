int vm_get_own_property(struct vm_realm *realm, struct vm_object *object, vm_value key, struct vm_descriptor *descriptor, int *found);
static int access_proxy_get_own(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, struct vm_descriptor *descriptor, int *found);
static int access_descriptor_allowed(const struct vm_object *object, int found, const struct vm_descriptor *current, const struct vm_descriptor *descriptor);
static int access_descriptor_compatible(int extensible, int found, const struct vm_descriptor *current, const struct vm_descriptor *descriptor);
static int object_get_own_property_descriptor(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int proxy_gc_edges(struct page *page);

int
vm_get_own_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	struct vm_descriptor *descriptor,
	int *found)
{
	struct access_read_roots roots;
	int present;
	int status;

	/* No descriptor is published before a successful complete internal operation. */
	*found = 0;
	memset(descriptor, 0, sizeof(*descriptor));
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		return status;
	}

	/* Retain the owner and key before any trap, native hook or nested operation can collect. */
	realm->property_depth++;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = key;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0) {
		realm->property_depth--;
		return status;
	}

	/* Proxy lookup can run script; ordinary descriptors keep the original heap-only protocol. */
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_get_own(realm, (struct vm_proxy *)object, key, descriptor, found);
	} else {
		present = vm_get_own_descriptor(object, key, descriptor);
		status = 0;
		if (present < 0) {
			status = -present;
		} else {
			*found = present;
		}
	}

	/* Balance native depth and frame ownership on normal and abrupt returns. */
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	realm->property_depth--;
	if (status != 0)
		return status;

	/* Succeeded: the descriptor and its independent presence result belong to the caller. */
	return 0;
}

static int
access_proxy_get_own(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	struct vm_descriptor *descriptor,
	int *found)
{
	struct vm_cell *roots[8];
	struct access_descriptor_roots current_roots;
	struct access_descriptor_roots result_roots;
	struct vm_descriptor current;
	struct vm_object *target_object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value produced;
	vm_value args[2];
	unsigned index;
	unsigned registered;
	int current_registered;
	int result_registered;
	int is_cell;
	int is_object;
	int is_symbol;
	int present;
	int extensible;
	int allowed;
	int status;

	/* Preserve the original target and handler even if a getter or trap revokes the record. */
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[4] = vm_value_as_cell(key);
	roots[5] = NULL;
	roots[6] = NULL;
	roots[7] = NULL;
	registered = 0;
	current_registered = 0;
	result_registered = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked record cannot consult any handler property. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot get a descriptor of a revoked Proxy");
		goto cleanup;
	}

	/* Resolve the dynamic descriptor trap through ordinary GetMethod semantics. */
	method_key = vm_key_from_ascii(realm->heap, "getOwnPropertyDescriptor");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A missing or null method delegates to the original target's own operation. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, descriptor, found);
		goto cleanup;
	}

	/* Retain a fresh callable trap and turn internal integer indices into script-visible strings. */
	roots[5] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[6] = &string->cell;
	}

	/* The trap receives only the original target and normalized property key with handler as this. */
	args[0] = target;
	args[1] = trap_key;
	status = vm_call(realm, method, handler, args, 2, &produced);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(produced);
	if (is_cell)
		roots[7] = vm_value_as_cell(produced);
	is_object = vm_value_is_object(produced);
	if (!is_object && produced != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Proxy descriptor trap must return an object or undefined");
		goto cleanup;
	}

	/* Target observation precedes all getters on the returned descriptor object. */
	target_object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_get_own_property(realm, target_object, key, &current, &present);
	if (status != 0)
		goto cleanup;
	extensible = 1;
	if ((target_object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
		extensible = 0;
	if (produced == VM_VALUE_UNDEFINED) {
		if (present) {
			if ((current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U || !extensible) {
				status = vm_throw_type_error(realm, "Proxy descriptor trap cannot hide this own property");
				goto cleanup;
			}
		}

		/* Absence is valid only after the target's fixed-property constraints have passed. */
		status = 0;
		goto cleanup;
	}

	/* Descriptor conversion may delete the target property, so retain its complete snapshot payloads. */
	current_roots.realm = realm;
	current_roots.source = VM_VALUE_UNDEFINED;
	current_roots.descriptor = &current;
	current_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &current_roots);
	if (status != 0)
		goto cleanup;
	current_registered = 1;
	result_roots.realm = realm;
	result_roots.source = produced;
	result_roots.descriptor = descriptor;
	result_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &result_roots);
	if (status != 0)
		goto cleanup;
	result_registered = 1;
	status = vm_to_property_descriptor(realm, produced, descriptor);
	if (status != 0)
		goto cleanup;
	vm_complete_property_descriptor(descriptor);

	/* Compatibility uses the pre-conversion extensibility and target descriptor snapshots. */
	allowed = access_descriptor_compatible(extensible, present, &current, descriptor);
	if (!allowed) {
		status = vm_throw_type_error(realm, "Proxy descriptor trap returned an incompatible descriptor");
		goto cleanup;
	}

	/* Nonconfigurable claims must already be true of the target's observed own property. */
	if ((descriptor->attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		if (!present || (current.attributes & VM_PROPERTY_CONFIGURABLE) != 0U) {
			status = vm_throw_type_error(realm, "Proxy descriptor trap invented a nonconfigurable property");
			goto cleanup;
		}

		/* A still-writable fixed property cannot be reported as newly read-only. */
		if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U) {
			if ((current.attributes & VM_PROPERTY_WRITABLE) != 0U) {
				status = vm_throw_type_error(realm, "Proxy descriptor trap invented a fixed read-only property");
				goto cleanup;
			}
		}
	}

	/* Publish presence only after conversion, completion and every invariant have passed. */
	*found = 1;
	status = 0;

cleanup:
	/* Retire snapshot and output tracers before the stack descriptor storage leaves this frame. */
	if (result_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &result_roots);
	if (current_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &current_roots);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve errors without publishing a partially checked descriptor. */
	if (status != 0)
		return status;

	/* Succeeded: absence or the fully checked descriptor is available to the caller. */
	return 0;
}

static int
access_descriptor_allowed(
	const struct vm_object *object,
	int found,
	const struct vm_descriptor *current,
	const struct vm_descriptor *descriptor)
{
	int extensible;
	int allowed;

	/* Ordinary validation reads extensibility at the original immediate call site. */
	extensible = 1;
	if ((object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
		extensible = 0;
	allowed = access_descriptor_compatible(extensible, found, current, descriptor);

	/* Succeeded: the pure compatibility rule supplies the unchanged ordinary decision. */
	return allowed;
}

static int
access_descriptor_compatible(
	int extensible,
	int found,
	const struct vm_descriptor *current,
	const struct vm_descriptor *descriptor)
{
	int is_accessor;
	int was_accessor;
	int generic;
	int same;

	/* A new property needs an object that takes new ones. */
	if (!found) {
		if (!extensible)
			return 0;
		return 1;
	}

	/* A configurable property may become anything. */
	if ((current->attributes & VM_PROPERTY_CONFIGURABLE) != 0U)
		return 1;

	/* A property that is not configurable stays so and keeps its enumerability. */
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U && (descriptor->attributes & VM_PROPERTY_CONFIGURABLE) != 0U)
		return 0;
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U &&
	    (descriptor->attributes & VM_PROPERTY_ENUMERABLE) != (current->attributes & VM_PROPERTY_ENUMERABLE))
		return 0;

	/* It keeps its kind. */
	is_accessor = 0;
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U)
		is_accessor = 1;
	generic = 0;
	if ((descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_GET | VM_HAS_SET)) == 0U)
		generic = 1;
	was_accessor = 0;
	if ((current->has & VM_HAS_GET) != 0U)
		was_accessor = 1;
	if (!generic && is_accessor != was_accessor)
		return 0;

	/* An accessor keeps its getter and setter. */
	if (was_accessor) {
		if ((descriptor->has & VM_HAS_GET) != 0U) {
			same = vm_same_value(descriptor->getter, current->getter);
			if (!same)
				return 0;
		}

		/* The setter too. */
		if ((descriptor->has & VM_HAS_SET) != 0U) {
			same = vm_same_value(descriptor->setter, current->setter);
			if (!same)
				return 0;
		}

		/* It keeps them. */
		return 1;
	}

	/* A read-only data property stays read-only with its value. */
	if ((current->attributes & VM_PROPERTY_WRITABLE) == 0U) {
		if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) != 0U)
			return 0;
		if ((descriptor->has & VM_HAS_VALUE) != 0U) {
			same = vm_same_value(descriptor->value, current->value);
			if (!same)
				return 0;
		}
	}

	/* Allowed. */
	return 1;
}

static int
object_get_own_property_descriptor(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *object_root;
	vm_value object;
	vm_value key;
	int found;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The object, then the key. */
	status = vm_to_object(realm, js_argument(args, count, 0), &object);
	if (status != 0)
		return status;
	object_root = vm_value_as_cell(object);
	status = vm_heap_add_root(realm->heap, &object_root);
	if (status != 0)
		return status;
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	vm_heap_remove_root(realm->heap, &object_root);
	if (status != 0)
		return status;

	/* The descriptor as an object, or undefined. */
	*result = VM_VALUE_UNDEFINED;
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
	if (status != 0)
		return status;

	/* A missing descriptor follows the absence path after errors have been excluded. */
	if (!found)
		return 0;
	status = object_from_descriptor(realm, &descriptor, result);
	if (status != 0)
		return status;

	/* Succeeded: the descriptor. */
	return 0;
}

static int
proxy_gc_edges(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[5];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_descriptor own;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value answer;
	vm_value made;
	vm_value key;
	vm_value get_key;
	vm_value descriptor_key;
	vm_value payload;
	uintptr_t realm_address;
	uintptr_t descriptor_address;
	unsigned index;
	unsigned registered;
	int status;
	int same;
	int present;

	/* Setup ownership is retired deliberately before each product operation takes responsibility. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The temporary managed realm has no embedding Document or explicit lifetime. */
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	realm_address = (uintptr_t)realm;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated target while allocating the remaining protocol participants. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated handler until the private factory takes ownership. */
	roots[2] = &handler->cell;

	/* Intern keys before obtaining a transient function returned only to this native frame. */
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Intern the trap key before creating a transient method function. */
	get_key = vm_key_from_ascii(page->heap, "get");
	if (get_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Create the ordinary configurable descriptor used by the post-trap invariant read. */
	status = vm_object_define(page->heap, target, key, VM_VALUE_UNDEFINED, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = proxy_script(page->realm, "(function(){return {sole:74};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, get_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* A separate fresh descriptor result must cross the same native post-trap collector. */
	descriptor_key = vm_key_from_ascii(page->heap, "getOwnPropertyDescriptor");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* The fixture trap returns a descriptor and object payload with no persistent script owner. */
	status = proxy_script(page->realm, "(function(){return {value:{sole:75},writable:true,enumerable:true,configurable:true};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, descriptor_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Genuine allocation pressure makes the private factory retain all otherwise unrooted inputs. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Drop every setup owner before the factory must survive threshold collection. */
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &made);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(made);
	vm_heap_stats(page->heap, &after);
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* This native descriptor hook may collect but never executes script, preserving the production hook contract. */
	target->native_operations = &proxy_sole_operations;
	sole_heap = page->heap;
	sole_realm_address = realm_address;
	sole_realm_alive = 0;
	status = vm_get_receiver(realm, made, key, VM_VALUE_NULL, &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);

	/* Has fallback must independently retain the managed realm through the same native descriptor collector. */
	status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &present);
	if (status != 0)
		goto cleanup;
	if (!present) {
		status = 1;
		goto cleanup;
	}

	/* GetOwn retains its managed realm and otherwise unowned trap descriptor during target collection. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &own, &present);
	if (status != 0)
		goto cleanup;
	if (!present || own.has != (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE)) {
		status = 1;
		goto cleanup;
	}

	/* The complete descriptor owns the original fresh object until the embedding takes it. */
	roots[0] = vm_value_as_cell(own.value);
	descriptor_address = (uintptr_t)roots[0];
	descriptor_key = vm_key_from_ascii(page->heap, "sole");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read a real field from the payload that had no owner during the target policy collection. */
	status = vm_get(page->realm, own.value, descriptor_key, &payload);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(payload, vm_value_int32(75));
	if (!same) {
		status = 1;
		goto cleanup;
	}

	/* The sole result from Get must also survive the subsequent Has collection. */
	key = vm_key_from_ascii(page->heap, "sole");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read the actual sole-result payload after the native policy collection. */
	status = vm_get(page->realm, answer, key, &answer);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(answer, vm_value_int32(74));
	if (!same ||
	    sole_realm_alive != 3U ||
	    realm->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* No surviving protocol participant references the temporary realm once the native Get frame ends. */
	roots[0] = NULL;
	roots[3] = NULL;
	roots[4] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The fresh descriptor payload must also be actually reclaimed after its last embedding root ends. */
	found = vm_heap_find_cell(page->heap, descriptor_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Record the successful native ownership observations before releasing setup roots. */
	status = 0;

cleanup:
	/* Fixture observations are not collector roots and never survive the independent case. */
	sole_heap = NULL;
	sole_realm_address = 0;
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: allocation, native descriptor collection and later realm reclamation all used real ownership. */
	return 0;
}
