from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess,re
q=Path('build/ws074-20261018/q33');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q33');out.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in proof.items())
protocol=json.loads((q/'final-protocol.json').read_text());assert protocol['native_matches'] and protocol['chrome_matches'] and protocol['conditions']==135 and protocol['native_global_not_exposed_and_ownership']
runs=json.loads((v/'native-runs.json').read_text());assert all(r['returncode']==0 for r in runs if r['label']!='acid')
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
for p in q.glob('target-*.log'):assert not p.read_bytes(),p
style=json.loads((q/'style-review.json').read_text());assert style['raw_checker_flags']==45 and style['other_checker_flags']==0
paths=[p for p in q.rglob('*') if p.is_file() and p.suffix in ['.py','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'engine' not in p.parts and 'target' not in p.parts and not any(a.endswith('-data') or a=='data' for a in p.parts)];paths.append(v/'engine/proxy-read.js');mapping={str(p.relative_to(q)):p for p in paths};a=out/'focused-native-oracle-build-raw.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for name,p in sorted(mapping.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(a,'r:gz') as t:
 count=0
 for m in t:assert t.extractfile(m).read()==mapping[m.name].read_bytes();count+=1
assert count==len(mapping)
for src in [q/'approval-snapshot.md',q/'style-generated.log',q/'style-review.json',q/'target-commands-2.json',q/'final-protocol.json',q/'ordinary-compatibility-proof.json',v/'native-runs.json',v/'source-proof.json',v/'source-commit.txt',v/'shared-input-comparison.json',v/'acid/report.json']:
 shutil.copy2(src,out/('acid-report.json' if src==v/'acid/report.json' else src.name))
for src in [Path('plan/ws074/tests/proxy-read.js'),Path('plan/ws074/tests/host-proxy-read.c')]:shutil.copy2(src,out/src.name)
for f in ['vm/access.c','vm/vm.h','js/builtin_object.c']:shutil.copy2(Path('userland/desktop/libbrowser',f),out/f.replace('/','_'))
for src in q.glob('target-*.log'):shutil.copy2(src,out/src.name)
versions=json.loads(Path('plan/ws074/phase258/evidence/20261018-q31/versions.json').read_text());(out/'versions.json').write_text(json.dumps(versions,indent=2)+'\n')
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),protocol_conditions=135,native_chrome_exact=True,old93_source_prefix_identical=True,ordinary_compatibility_exact_body_mapping=True,native_pressure=['original Get and Has managed realm collection retained','GetOwn trap fresh descriptor/payload retained through post-trap no-script native descriptor GC','managed bare realm alive in all three independent operations, property depth returns to zero','fresh descriptor payload and realm actually reclaimed after releasing final roots','q32 data/getter From pressure and absent slot reclamation retained'],focused_gate_returncodes={r['label']:r['returncode'] for r in runs},acid3_score=100,acid3_pixel_diff=0,acid2_existing_pixel_diff=873,raw_allowed_cleanup=45,other_style_flags=0,host_target_warnings=0,archive={'path':a.name,'sha256':digest(a),'members':count,'readback_all_members':True},current_certified_pass=1482,denominator=3805,held=0,unattempted_harness=275,harness_reused='q31 all1508:494PASS/955FAIL/13harness_error/20no_completion/24no_output/2multiple; callbacks11540PASS/20642FAIL/14NOTRUN',static_scripted_crash_reused='q28:844/105/39',whole_pass_gain=0,limitations=['focused gates only; no q33 all1508 or all-image/strict crash measurement','frozen runtime binaries retained in build with source-proof hashes, not embedded in evidence archive','global Proxy unexposed; whole p258/WS074 remains incomplete','single-source target2 only; no full target link/runtime or whole-source p100 conformance'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('archive',count,digest(a));print('source',summary['source_commit'])
