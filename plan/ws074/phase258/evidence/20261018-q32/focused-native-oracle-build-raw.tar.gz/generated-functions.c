int vm_to_property_descriptor(struct vm_realm *realm, vm_value value, struct vm_descriptor *descriptor);
int vm_from_property_descriptor(struct vm_realm *realm, const struct vm_descriptor *descriptor, vm_value *result);
void vm_complete_property_descriptor(struct vm_descriptor *descriptor);
static int access_descriptor_field(struct vm_realm *realm, vm_value object, const char *name, uint32_t flag, struct vm_descriptor *descriptor, vm_value *value);
static int access_descriptor_put(struct vm_realm *realm, struct vm_object *object, const char *name, vm_value value);
static void access_descriptor_trace(struct vm_heap *heap, void *context);
static int object_to_descriptor(struct vm_realm *realm, vm_value value, struct vm_descriptor *descriptor);
static int object_from_descriptor(struct vm_realm *realm, const struct vm_descriptor *descriptor, vm_value *result);
int main(int argc, char **argv);
static int descriptor_roundtrip(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int descriptor_pressure(struct page *page);

int
vm_to_property_descriptor(
	struct vm_realm *realm,
	vm_value value,
	struct vm_descriptor *descriptor)
{
	struct access_descriptor_roots roots;
	vm_value field;
	int callable;
	int is_object;
	int truth;
	int status;

	/* Initialize every output payload before its conversion tracer becomes visible. */
	memset(descriptor, 0, sizeof(*descriptor));
	descriptor->value = VM_VALUE_UNDEFINED;
	descriptor->getter = VM_VALUE_UNDEFINED;
	descriptor->setter = VM_VALUE_UNDEFINED;
	roots.realm = realm;
	roots.source = value;
	roots.descriptor = descriptor;
	roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &roots);
	if (status != 0)
		return status;

	/* Descriptor sources must be objects, including native Proxy values. */
	is_object = vm_value_is_object(value);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Property description must be an object");
		goto cleanup;
	}

	/* Convert enumerable before observing any later descriptor field. */
	field = VM_VALUE_FALSE;
	status = access_descriptor_field(realm, value, "enumerable", VM_HAS_ENUMERABLE, descriptor, &field);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(field);
	if (truth)
		descriptor->attributes |= VM_PROPERTY_ENUMERABLE;

	/* Configurable follows enumerable and precedes the data value. */
	field = VM_VALUE_FALSE;
	status = access_descriptor_field(realm, value, "configurable", VM_HAS_CONFIGURABLE, descriptor, &field);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(field);
	if (truth)
		descriptor->attributes |= VM_PROPERTY_CONFIGURABLE;

	/* The descriptor tracer retains a fresh value through every later getter. */
	status = access_descriptor_field(realm, value, "value", VM_HAS_VALUE, descriptor, &descriptor->value);
	if (status != 0)
		goto cleanup;

	/* Writable is converted before any accessor fields are inspected. */
	field = VM_VALUE_FALSE;
	status = access_descriptor_field(realm, value, "writable", VM_HAS_WRITABLE, descriptor, &field);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(field);
	if (truth)
		descriptor->attributes |= VM_PROPERTY_WRITABLE;

	/* A bad getter fails immediately, before HasProperty or Get can inspect the setter. */
	status = access_descriptor_field(realm, value, "get", VM_HAS_GET, descriptor, &descriptor->getter);
	if (status != 0)
		goto cleanup;
	callable = vm_value_is_callable(descriptor->getter);
	if ((descriptor->has & VM_HAS_GET) != 0U &&
	    !callable &&
	    descriptor->getter != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Getter must be a function");
		goto cleanup;
	}

	/* Validate the setter immediately after its own read. */
	status = access_descriptor_field(realm, value, "set", VM_HAS_SET, descriptor, &descriptor->setter);
	if (status != 0)
		goto cleanup;
	callable = vm_value_is_callable(descriptor->setter);
	if ((descriptor->has & VM_HAS_SET) != 0U &&
	    !callable &&
	    descriptor->setter != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Setter must be a function");
		goto cleanup;
	}

	/* A descriptor is an accessor or a data property, not both. */
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U && (descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE)) != 0U) {
		status = vm_throw_type_error(realm, "Invalid property descriptor. Cannot both specify accessors and a value or writable attribute");
		goto cleanup;
	}

cleanup:
	/* The caller takes the completed descriptor after its getter sequence. */
	vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the descriptor. */
	return 0;
}

int
vm_from_property_descriptor(
	struct vm_realm *realm,
	const struct vm_descriptor *descriptor,
	vm_value *result)
{
	struct access_descriptor_roots roots;
	struct vm_object *made;
	int truth;
	int status;

	/* Undefined has no fields to expose or managed inputs to retain. */
	*result = VM_VALUE_UNDEFINED;
	if (descriptor == NULL)
		return 0;

	/* Only fields marked present are traced, so absent C payload slots need not be initialized. */
	roots.realm = realm;
	roots.source = VM_VALUE_UNDEFINED;
	roots.descriptor = descriptor;
	roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &roots);
	if (status != 0)
		return status;

	/* The operation's realm supplies the new object's ordinary prototype. */
	made = vm_object_create(realm->heap, realm->object_prototype);
	if (made == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The newborn must remain explicitly owned during every output-field allocation. */
	roots.made = vm_value_cell(made);

	/* A present value retains its identity rather than being cloned. */
	if ((descriptor->has & VM_HAS_VALUE) != 0U) {
		status = access_descriptor_put(realm, made, "value", descriptor->value);
		if (status != 0)
			goto cleanup;
	}

	/* Writable is omitted unless the input descriptor actually supplied that field. */
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U) {
		truth = 0;
		if ((descriptor->attributes & VM_PROPERTY_WRITABLE) != 0U)
			truth = 1;
		status = access_descriptor_put(realm, made, "writable", vm_value_boolean(truth));
		if (status != 0)
			goto cleanup;
	}

	/* Accessor slots remain ordinary data fields on the representation object. */
	if ((descriptor->has & VM_HAS_GET) != 0U) {
		status = access_descriptor_put(realm, made, "get", descriptor->getter);
		if (status != 0)
			goto cleanup;
	}

	/* Setter presence is independent of the getter field. */
	if ((descriptor->has & VM_HAS_SET) != 0U) {
		status = access_descriptor_put(realm, made, "set", descriptor->setter);
		if (status != 0)
			goto cleanup;
	}

	/* Enumerable presence is independent of its Boolean value. */
	if ((descriptor->has & VM_HAS_ENUMERABLE) != 0U) {
		truth = 0;
		if ((descriptor->attributes & VM_PROPERTY_ENUMERABLE) != 0U)
			truth = 1;
		status = access_descriptor_put(realm, made, "enumerable", vm_value_boolean(truth));
		if (status != 0)
			goto cleanup;
	}

	/* Configurable is likewise emitted only when present, in the standard final position. */
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U) {
		truth = 0;
		if ((descriptor->attributes & VM_PROPERTY_CONFIGURABLE) != 0U)
			truth = 1;
		status = access_descriptor_put(realm, made, "configurable", vm_value_boolean(truth));
		if (status != 0)
			goto cleanup;
	}

	/* Publish the complete representation after all of its ordinary fields succeed. */
	*result = roots.made;
	status = 0;

cleanup:
	/* Neither the descriptor pointer nor the newborn object may escape this tracer's C frame. */
	vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the exact partial descriptor is represented by ordinary data properties. */
	return 0;
}

void
vm_complete_property_descriptor(
	struct vm_descriptor *descriptor)
{
	int accessor;

	/* Presence of either accessor slot chooses accessor completion; generic descriptors become data descriptors. */
	accessor = 0;
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U)
		accessor = 1;
	if (accessor) {
		/* Missing accessor slots become explicit undefined payloads. */
		if ((descriptor->has & VM_HAS_GET) == 0U) {
			descriptor->getter = VM_VALUE_UNDEFINED;
			descriptor->has |= VM_HAS_GET;
		}

		/* Completion makes an omitted setter an explicit undefined slot. */
		if ((descriptor->has & VM_HAS_SET) == 0U) {
			descriptor->setter = VM_VALUE_UNDEFINED;
			descriptor->has |= VM_HAS_SET;
		}
	} else {
		/* Data completion supplies an undefined value and a false writable flag when omitted. */
		if ((descriptor->has & VM_HAS_VALUE) == 0U) {
			descriptor->value = VM_VALUE_UNDEFINED;
			descriptor->has |= VM_HAS_VALUE;
		}

		/* A missing writable field becomes present with its false default. */
		if ((descriptor->has & VM_HAS_WRITABLE) == 0U) {
			descriptor->attributes &= ~VM_PROPERTY_WRITABLE;
			descriptor->has |= VM_HAS_WRITABLE;
		}
	}

	/* Omitted enumerable and configurable fields become present false attributes. */
	if ((descriptor->has & VM_HAS_ENUMERABLE) == 0U) {
		descriptor->attributes &= ~VM_PROPERTY_ENUMERABLE;
		descriptor->has |= VM_HAS_ENUMERABLE;
	}

	/* Configurable likewise becomes explicitly false when absent. */
	if ((descriptor->has & VM_HAS_CONFIGURABLE) == 0U) {
		descriptor->attributes &= ~VM_PROPERTY_CONFIGURABLE;
		descriptor->has |= VM_HAS_CONFIGURABLE;
	}

	/* Succeeded: the descriptor has every field required by its property kind. */
	return;
}

static int
access_descriptor_field(
	struct vm_realm *realm,
	vm_value object,
	const char *name,
	uint32_t flag,
	struct vm_descriptor *descriptor,
	vm_value *value)
{
	vm_value key;
	vm_value has;
	int status;

	/* Whether it has the field. */
	key = vm_key_from_ascii(realm->heap, name);
	if (key == VM_VALUE_EMPTY)
		return ENOMEM;
	status = vm_in(realm, key, object, &has);
	if (status != 0)
		return status;
	if (has != VM_VALUE_TRUE)
		return 0;

	/* The field's value. */
	status = vm_get(realm, object, key, value);
	if (status != 0)
		return status;

	/* Succeeded: the descriptor has it. */
	descriptor->has |= flag;
	return 0;
}

static int
access_descriptor_put(
	struct vm_realm *realm,
	struct vm_object *object,
	const char *name,
	vm_value value)
{
	vm_value key;
	int status;

	/* Representation field names are ordinary interned string keys. */
	key = vm_key_from_ascii(realm->heap, name);
	if (key == VM_VALUE_EMPTY)
		return ENOMEM;
	status = vm_object_define(realm->heap, object, key, value, VM_PROPERTY_DEFAULT);
	if (status != 0)
		return status;

	/* Succeeded: the output field is writable, enumerable and configurable. */
	return 0;
}

static void
access_descriptor_trace(
	struct vm_heap *heap,
	void *context)
{
	struct access_descriptor_roots *roots;
	const struct vm_descriptor *descriptor;

	/* The managed owner, input object and unpublished result belong to this conversion frame. */
	roots = context;
	if (roots->realm->managed)
		vm_heap_mark(heap, &roots->realm->cell);
	vm_heap_mark_value(heap, roots->source);
	vm_heap_mark_value(heap, roots->made);

	/* Undefined descriptors have no payload storage to inspect. */
	descriptor = roots->descriptor;
	if (descriptor == NULL)
		return;
	if ((descriptor->has & VM_HAS_VALUE) != 0U)
		vm_heap_mark_value(heap, descriptor->value);
	if ((descriptor->has & VM_HAS_GET) != 0U)
		vm_heap_mark_value(heap, descriptor->getter);
	if ((descriptor->has & VM_HAS_SET) != 0U)
		vm_heap_mark_value(heap, descriptor->setter);

	/* Succeeded: absent descriptor slots were never read as values. */
	return;
}

static int
object_to_descriptor(
	struct vm_realm *realm,
	vm_value value,
	struct vm_descriptor *descriptor)
{
	int status;

	/* Share the VM language operation with native Proxy internal methods. */
	status = vm_to_property_descriptor(realm, value, descriptor);
	if (status != 0)
		return status;

	/* Succeeded: the common VM conversion supplied the requested descriptor representation. */
	return 0;
}

static int
object_from_descriptor(
	struct vm_realm *realm,
	const struct vm_descriptor *descriptor,
	vm_value *result)
{
	int status;

	/* Share the VM language operation with native Proxy internal methods. */
	status = vm_from_property_descriptor(realm, descriptor, result);
	if (status != 0)
		return status;

	/* Succeeded: the common VM conversion supplied the requested descriptor representation. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
descriptor_roundtrip(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	int complete;
	int status;

	UNUSED_PARAMETER(receiver);

	/* All observable field reads and validation belong to the production VM conversion. */
	status = vm_to_property_descriptor(realm, js_argument(args, count, 0), &descriptor);
	if (status != 0)
		return status;
	complete = vm_to_boolean(js_argument(args, count, 1));
	if (complete)
		vm_complete_property_descriptor(&descriptor);

	/* Completion performs no allocation before the representation operation roots every present payload. */
	status = vm_from_property_descriptor(realm, &descriptor, result);
	if (status != 0)
		return status;

	/* Succeeded: the real language operations returned the partial or completed descriptor representation. */
	return 0;
}

static int
descriptor_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *object;
	struct vm_cell *roots[5];
	struct vm_cell *unused;
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	struct vm_descriptor descriptor;
	struct vm_descriptor output_field;
	struct wb_vector keys;
	vm_value payload;
	vm_value answer;
	vm_value kept;
	vm_value key;
	const char *field_name;
	uintptr_t realm_address;
	uintptr_t payload_address;
	uintptr_t made_address;
	uintptr_t unused_address[2];
	unsigned mode;
	unsigned index;
	unsigned registered;
	int status;
	int present;
	int equal;

	/* A missing descriptor is represented directly and allocates no result object. */
	status = vm_from_property_descriptor(page->realm, NULL, &answer);
	if (status != 0)
		return status;
	if (answer != VM_VALUE_UNDEFINED)
		return 1;

	/* Setup roots retire before each conversion, so production ownership must take over. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A data payload and an accessor payload exercise the two independently traced descriptor kinds. */
	for (mode = 0; mode < 2U; mode++) {
		status = vm_realm_create_managed(page->heap, &realm);
		if (status != 0)
			goto cleanup;
		roots[0] = &realm->cell;
		realm_address = (uintptr_t)realm;
		if (mode == 0U) {
			object = vm_object_create(page->heap, NULL);
			if (object == NULL) {
				status = 2;
				goto cleanup;
			}

			/* The fresh plain payload has no owner beyond this setup frame. */
			payload = vm_value_cell(object);
			field_name = "value";
		} else {
			status = proxy_script(page->realm, "(function(){return 73;})", &payload);
			if (status != 0)
				goto cleanup;
			field_name = "get";
		}

		/* Protect the selected payload only until the production conversion takes responsibility. */
		roots[1] = vm_value_as_cell(payload);
		payload_address = (uintptr_t)roots[1];
		key = vm_key_from_ascii(page->heap, field_name);
		if (key == VM_VALUE_EMPTY) {
			status = 2;
			goto cleanup;
		}

		/* Unflagged payload slots contain real cells whose larger size prevents reuse as the output object. */
		for (index = 0; index < 2U; index++) {
			unused = vm_heap_alloc(page->heap, &proxy_pressure_type, 4096U);
			if (unused == NULL) {
				status = 2;
				goto cleanup;
			}

			/* Setup temporarily owns each otherwise meaningless payload cell. */
			roots[index + 3U] = unused;
			unused_address[index] = (uintptr_t)unused;
		}

		/* Presence flags alone decide which C payload slots and Boolean attributes are meaningful. */
		memset(&descriptor, 0, sizeof(descriptor));
		descriptor.attributes = VM_PROPERTY_DEFAULT;
		if (mode == 0U) {
			descriptor.has = VM_HAS_VALUE;
			descriptor.value = payload;
			descriptor.getter = vm_value_cell(roots[3]);
			descriptor.setter = vm_value_cell(roots[4]);
		} else {
			descriptor.has = VM_HAS_GET;
			descriptor.getter = payload;
			descriptor.value = vm_value_cell(roots[3]);
			descriptor.setter = vm_value_cell(roots[4]);
		}

		/* The next production allocation must collect with only the conversion's own descriptor and realm roots. */
		vm_heap_collect(page->heap);
		pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
		if (pressure == NULL) {
			status = 2;
			goto cleanup;
		}

		/* Transfer all meaningful ownership to the conversion before threshold collection. */
		roots[0] = NULL;
		roots[1] = NULL;
		roots[3] = NULL;
		roots[4] = NULL;
		vm_heap_stats(page->heap, &before);
		status = vm_from_property_descriptor(realm, &descriptor, &answer);
		if (status != 0)
			goto cleanup;
		roots[2] = vm_value_as_cell(answer);
		made_address = (uintptr_t)roots[2];
		vm_heap_stats(page->heap, &after);
		if (after.collections <= before.collections) {
			status = 1;
			goto cleanup;
		}

		/* The managed owner must survive the collection triggered inside conversion. */
		found = vm_heap_find_cell(page->heap, realm_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* Absent slots must not pin arbitrary cells merely because bytes remain in their C storage. */
		for (index = 0; index < 2U; index++) {
			found = vm_heap_find_cell(page->heap, unused_address[index]);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* The sole output field is an ordinary data property retaining the original flagged value. */
		status = vm_get(page->realm, answer, key, &kept);
		if (status != 0)
			goto cleanup;
		equal = vm_same_value(kept, payload);
		if (!equal) {
			status = 1;
			goto cleanup;
		}

		/* Verify ordinary data attributes independently of script observations. */
		present = vm_get_own_descriptor((struct vm_object *)roots[2], key, &output_field);
		if (present != 1 || output_field.attributes != VM_PROPERTY_DEFAULT) {
			status = 1;
			goto cleanup;
		}

		/* Inspect the real own-key set to reject materialized absent fields. */
		wb_vector_init(&keys, sizeof(vm_value));
		status = vm_object_own_keys(page->heap, (struct vm_object *)roots[2], &keys);
		if (status != 0) {
			wb_vector_release(&keys);
			goto cleanup;
		}

		/* Stale attribute bits must not create omitted Boolean fields. */
		if (keys.count != 1U) {
			wb_vector_release(&keys);
			status = 1;
			goto cleanup;
		}

		/* Discard the fixture key buffer before observing graph retirement. */
		wb_vector_release(&keys);

		/* Releasing the actual representation drops every remaining descriptor and managed-realm owner. */
		roots[2] = NULL;
		vm_heap_collect(page->heap);
		found = vm_heap_find_cell(page->heap, realm_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* The original flagged payload must retire with its last representation owner. */
		found = vm_heap_find_cell(page->heap, payload_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* The ordinary output itself must have no residual conversion root. */
		found = vm_heap_find_cell(page->heap, made_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* Both descriptor kinds met the pressure and lifetime criteria. */
	status = 0;

cleanup:
	/* Only successfully acquired native registrations belong to this independent probe. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failed observations after retiring this native frame's registrations. */
	if (status != 0)
		return status;

	/* Succeeded: both descriptor kinds preserved only meaningful values and retired every owned graph. */
	return 0;
}
