from pathlib import Path
import json
p=Path('userland/desktop/libbrowser/vm/object.c');s=p.read_text();s=s.replace('static int object_array_key_compare(', 'static int object_array_index(vm_value key, uint32_t *index);\nstatic int object_array_key_compare(',1)
a=s.index('int\nvm_array_set_length(');b=s.index('\n}\n',a)+2;s=s[:a]+s[a:b].replace('vm_value_is_array_index(key, &index)','object_array_index(key, &index)')+s[b:]
s=s.replace('''	is_index = vm_value_is_array_index(*(const vm_value *)left, &first);
	is_index = vm_value_is_array_index(*(const vm_value *)right, &second);
	UNUSED_PARAMETER(is_index);''','''	is_index = object_array_index(*(const vm_value *)left, &first);
	if (!is_index)
		return 0;
	is_index = object_array_index(*(const vm_value *)right, &second);
	if (!is_index)
		return 0;''')
s+='''
/* Recognizes actual uint32 array-index spellings without widening the ordinary storage key representation. */
static int
object_array_index(
	vm_value key,
	uint32_t *index)
{
	struct vm_string *string;
	uint64_t number;
	uint32_t position;
	uint16_t unit;
	int is_index;
	int is_string;

	/* Existing small numeric keys already carry their exact nonnegative index. */
	is_index = vm_value_is_array_index(key, index);
	if (is_index)
		return 1;
	is_string = vm_value_is_string(key);
	if (!is_string)
		return 0;

	/* Canonical decimal array indices have at most ten digits and no redundant leading zero. */
	string = (struct vm_string *)vm_value_as_cell(key);
	if (string->length == 0U || string->length > 10U)
		return 0;
	unit = vm_string_at(string, 0);
	if (unit == '0' && string->length != 1U)
		return 0;

	/* Exact integer accumulation excludes nondecimal syntax and the reserved length-minus-zero upper boundary. */
	number = 0;
	for (position = 0; position < string->length; position++) {
		unit = vm_string_at(string, position);
		if (unit < '0' || unit > '9')
			return 0;
		number = number * 10U + (uint64_t)(unit - '0');
	}

	/* The string 4294967295 is an ordinary property name rather than an array index. */
	if (number >= 4294967295ULL)
		return 0;
	*index = (uint32_t)number;

	/* Succeeded: the existing atom names one exact array index, including indices above signed int32. */
	return 1;
}
''';s=s.replace('the reserved length-minus-zero upper boundary','the reserved uint32 maximum');p.write_text(s)
q=Path('build/ws074-20261018/q46');m=json.loads((q/'function-review-scope.json').read_text());m['userland/desktop/libbrowser/vm/object.c'].append('object_array_index');(q/'function-review-scope.json').write_text(json.dumps(m,indent=2)+'\n');p=q/'format.py';s=p.read_text();a=s.index(';mapping=');b=s.index(';chunks=[]',a);s=s[:a]+';mapping='+repr(m)+s[b:];p.write_text(s)
