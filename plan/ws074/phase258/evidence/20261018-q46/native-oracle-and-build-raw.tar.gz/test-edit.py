from pathlib import Path
import re,json
p=Path('plan/ws074/tests/host-proxy-read.c');s=p.read_text();marker='static int own_collect_keys(';i=s.index(marker);s=s[:i]+'''static int assignment_refuse_define(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *handled, int *done);

/* This pure assignment policy collects and refuses without invoking user code or writing a property. */
static const struct vm_native_operations assignment_refuse_operations = {
	NULL, NULL, assignment_refuse_define, NULL, NULL
};

'''+s[i:];s=s.replace('static int ordinary_instance_pressure(struct page *page);','static int ordinary_instance_pressure(struct page *page);\nstatic int assignment_pressure(struct page *page);');x='''	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;''';assert x in s;s=s.replace(x,x+'''

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;''')
s+='''
/* Refuses a real receiver definition after collecting its native caller and leaving later error-allocation pressure. */
static int
assignment_refuse_define(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *handled,
	int *done)
{
	struct vm_cell *found;
	struct vm_cell *pressure;
	struct vm_heap_stats stats;

	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(key);
	UNUSED_PARAMETER(descriptor);

	/* This pure native policy observes weak addresses without creating an owner or running script. */
	vm_heap_collect(realm->heap);
	found = vm_heap_find_cell(realm->heap, object_consumer_case.caller_address);
	if (found == NULL)
		return EFAULT;
	found = vm_heap_find_cell(realm->heap, object_consumer_case.input_address);
	if (found == NULL)
		return EFAULT;
	pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL)
		return ENOMEM;

	/* The outer strict-refusal allocation must cause a strictly later collection after inner Set ownership retires. */
	vm_heap_stats(realm->heap, &stats);
	object_consumer_case.callback_collections = stats.collections;
	object_consumer_case.calls++;
	*handled = 1;
	*done = 0;

	/* Succeeded: actual DefineOwnProperty refusal remains Boolean until the assignment wrapper handles strictness. */
	return 0;
}

/* Verifies direct object assignment ownership on pure native errno and later strict-refusal collection paths. */
static int
assignment_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *input;
	struct vm_object *value;
	struct vm_symbol *symbol;
	struct vm_cell *roots[4];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	uintptr_t addresses[4];
	vm_value key;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int status;

	/* Setup owns construction only; the direct production API receives no outer VM-call protection. */
	memset(roots, 0, sizeof(roots));
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Native GetOwn errno and native Define refusal exercise distinct stages of the real assignment wrapper. */
	for (mode = 0; mode < 2U; mode++) {
		memset(&object_consumer_case, 0, sizeof(object_consumer_case));
		object_consumer_case.heap = page->heap;
		status = vm_realm_create_managed(page->heap, &caller);
		if (status != 0)
			goto cleanup;
		roots[0] = &caller->cell;
		input = vm_object_create(page->heap, NULL);
		if (input == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The ordinary receiver has no prototype or registry retaining any test participant. */
		roots[1] = &input->cell;
		input->native_operations = &consumer_error_descriptor_operations;
		if (mode == 1U)
			input->native_operations = &assignment_refuse_operations;
		value = vm_object_create(page->heap, NULL);
		if (value == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Both a fresh object value and a never-stored Symbol key must survive the production operation. */
		roots[2] = &value->cell;
		symbol = vm_symbol_create(page->heap, VM_VALUE_UNDEFINED);
		if (symbol == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Integer observations are weak and do not provide collector ownership. */
		roots[3] = &symbol->cell;
		key = vm_value_cell(symbol);
		object_consumer_case.caller_address = (uintptr_t)caller;
		object_consumer_case.input_address = (uintptr_t)input;
		for (index = 0; index < 4U; index++) {
			addresses[index] = (uintptr_t)roots[index];
			roots[index] = NULL;
		}

		/* The direct assignment alone now owns its caller, receiver, write value and Symbol key. */
		vm_heap_stats(page->heap, &before);
		status = vm_set(caller, vm_value_cell(input), key, vm_value_cell(value), 1);
		vm_heap_stats(page->heap, &after);
		if (mode == 0U) {
			if (status != EACCES) {
				status = EFAULT;
				goto cleanup;
			}
		} else {
			if (status != VM_THROWN || after.collections <= object_consumer_case.callback_collections) {
				status = EFAULT;
				goto cleanup;
			}
		}

		/* Both callbacks must actually run and collect, including the post-callback strict-error collection. */
		if (object_consumer_case.calls != 1U || after.collections <= before.collections) {
			status = EFAULT;
			goto cleanup;
		}

		/* All four participants survived the complete direct operation, including strict-refusal error construction. */
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, addresses[index]);
			if (found == NULL) {
				status = EFAULT;
				goto cleanup;
			}
		}

		/* Completed errno and thrown-error outcomes leave no permanent native owner for their original inputs. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, addresses[index]);
			if (found != NULL) {
				status = EFAULT;
				goto cleanup;
			}
		}
	}

	/* Both native-error and strict-refusal paths retained and then released the full original input graph. */
	status = 0;

cleanup:
	/* Retire setup registrations and weak observation context on every result path. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an observed error only after every native registration has been retired. */
	if (status != 0)
		return status;

	/* Succeeded: direct assignment owns all participants through native callbacks and later refusal errors. */
	return 0;
}
''';p.write_text(s)
q=Path('build/ws074-20261018/q46');m=json.loads((q/'function-review-scope.json').read_text());m[str(p)]=['main','assignment_refuse_define','assignment_pressure'];(q/'function-review-scope.json').write_text(json.dumps(m,indent=2)+'\n')
s=Path('build/ws074-20261018/q45/format.py').read_text();a=s.index(';mapping=');b=s.index(';chunks=[]',a);s=s[:a]+';mapping='+repr(m)+s[b:];s=s.replace('q45','q46');(q/'format.py').write_text(s)
