from pathlib import Path
import re,json
q=Path('build/ws074-20261018/q46');p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();a=s.index('\t/* Direct Proxy and TypedArray assignment');b=s.index('\n}\n',a);s=s[:a]+'''	/* Every object uses its actual receiver-aware operation, including exotic prototypes of ordinary receivers. */
	object = (struct vm_object *)vm_value_as_cell(base);
	roots.read.realm = realm;
	roots.read.base = base;
	roots.read.key = key;
	roots.read.receiver = base;
	roots.value = value;
	status = vm_heap_add_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;
	status = vm_set_receiver(realm, object, key, value, base, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		/* Keep native input ownership until any strict refusal exception has finished allocating. */
		if (object->kind == VM_KIND_PROXY)
			status = access_refuse(realm, strict, "Proxy set trap returned false");
		else
			status = access_refuse(realm, strict, "Cannot assign to read only property");
	}

cleanup:
	/* Accepted writes, sloppy refusals and abrupt operations all retire the outer assignment owner. */
	vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the actual operation accepted the write, or sloppy code ignored its refusal. */
	return 0;'''+s[b:]
a=s.index('int\nvm_set(\n');b=s.index('\n\t/* undefined and null',a);s=s[:a]+s[a:b].replace('''	struct vm_property property;
	struct vm_accessor *accessor;
	struct vm_object *object;
	vm_value ignored;
	vm_value length_key;
	struct vm_descriptor descriptor;
	int handled;''','''	struct access_write_roots roots;
	struct vm_object *object;''').replace('\n\tint found;','')+s[b:]
s,n=re.subn(r'^static int access_set_length\([^\n]*;\n','',s,flags=re.M);assert n==1;s,n=re.subn(r'/\* Sets an array\'s length by assignment:.*?\*/\nstatic int\naccess_set_length\(\n.*?\n\}\n\n','',s,flags=re.S);assert n==1;p.write_text(s)
(q/'function-review-scope.json').write_text(json.dumps({'userland/desktop/libbrowser/vm/access.c':['vm_set']},indent=2)+'\n');print('unified vm_set; obsolete length helper removed')
