from pathlib import Path
import re,json
p=Path('userland/desktop/libbrowser/vm/object.c');s=p.read_text();s=s.replace('Objects (plan/ws074/design.md §11.4): properties found through shapes,','Objects: properties found through shapes,').replace("the interpreter (ws074-p023), so a","the interpreter, so a")
s=s.replace('static int object_key_compare(const void *left, const void *right);','static int object_key_compare(const void *left, const void *right);\nstatic int object_array_key_compare(const void *left, const void *right);\nstatic void object_array_keys_trace(struct vm_heap *heap, void *context);')
body='''int
vm_array_set_length(
	struct vm_heap *heap,
	struct vm_object *array,
	uint32_t length)
{
	struct wb_vector keys;
	struct vm_cell *root;
	vm_value key;
	uint32_t index;
	size_t item;
	size_t kept;
	int is_index;
	int deleted;
	int traced;
	int error;

	/* Retain the array and every copied key across native enumeration and deletion callbacks. */
	root = &array->cell;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	error = vm_heap_add_root(heap, &root);
	if (error != 0)
		return error;
	error = vm_heap_add_tracer(heap, object_array_keys_trace, &keys);
	if (error != 0)
		goto cleanup;
	traced = 1;

	/* Growth changes no element descriptor and never scans a possibly huge sparse logical length. */
	if (length >= array->length) {
		array->length = length;
		object_sync_length(heap, array);
		goto cleanup;
	}

	/* Snapshot present own keys before publishing the shorter metadata; absent indices need no deletion. */
	error = vm_object_own_keys(heap, array, &keys);
	if (error != 0)
		goto cleanup;
	kept = 0;
	for (item = 0; item < keys.count; item++) {
		key = ((vm_value *)keys.items)[item];
		is_index = vm_value_is_array_index(key, &index);
		if (is_index && index >= length) {
			((vm_value *)keys.items)[kept] = key;
			kept++;
		}
	}

	/* Numeric ordering includes atom-backed indices above signed int32 and native-policy prefixes. */
	keys.count = kept;
	if (keys.count > 1U)
		qsort(keys.items, keys.count, sizeof(vm_value), object_array_key_compare);
	array->length = length;
	object_sync_length(heap, array);

	/* Delete higher indices first so the first refusal preserves every lower descriptor and earlier higher deletion. */
	item = keys.count;
	while (item != 0U) {
		item--;
		key = ((vm_value *)keys.items)[item];
		error = vm_object_delete(heap, array, key, &deleted);
		if (error != 0)
			goto cleanup;
		if (!deleted) {
			/* The failed index bounds the actual length after the already completed higher deletions. */
			is_index = vm_value_is_array_index(key, &index);
			array->length = index + 1U;
			object_sync_length(heap, array);
			error = EPERM;
			goto cleanup;
		}
	}

	/* Every present property at or above the requested bound was deleted. */
	error = 0;

cleanup:
	/* Snapshot ownership ends on growth, complete shrink, partial refusal and native allocation errors alike. */
	if (traced)
		vm_heap_remove_tracer(heap, object_array_keys_trace, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(heap, &root);
	if (error != 0)
		return error;

	/* Succeeded: metadata and the remaining own elements agree with the requested length. */
	return 0;
}'''
s,n=re.subn(r'int\nvm_array_set_length\(\n.*?\n\}',lambda m:body,s,flags=re.S);assert n==1
s+='''
/* Orders actual array-index keys numerically without signed-int32 truncation or coercion. */
static int
object_array_key_compare(
	const void *left,
	const void *right)
{
	uint32_t first;
	uint32_t second;
	int is_index;

	/* Enumeration filtering guarantees both keys are indices; normalization is pure and cannot run script. */
	is_index = vm_value_is_array_index(*(const vm_value *)left, &first);
	is_index = vm_value_is_array_index(*(const vm_value *)right, &second);
	UNUSED_PARAMETER(is_index);

	/* Smaller numeric indices sort first, including the atom-backed upper half of uint32. */
	if (first < second)
		return -1;
	if (first > second)
		return 1;

	/* Succeeded: equal numeric indices compare equally. */
	return 0;
}

/* Keeps the native array-length key snapshot alive while deletion callbacks may collect. */
static void
object_array_keys_trace(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *keys;
	size_t item;

	/* Vector storage is outside the managed heap and contains only initialized live entries. */
	keys = context;
	for (item = 0; item < keys->count; item++)
		vm_heap_mark_value(heap, ((vm_value *)keys->items)[item]);
}
''';p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();a=s.index('static int\naccess_define_length(');b=s.index('\n}\n',a)+2;t=s[a:b];t=t.replace('struct vm_descriptor rest;','struct vm_descriptor rest;\n\tstruct vm_descriptor latest;').replace('\n\tint allowed;','\n\tint refused;\n\tint found;\n\tint allowed;');i=t.index('\n\t/* The change must be allowed');t=t[:i]+'''
	/* Conversion may change the array or make its length read-only; inspect the actual post-conversion descriptor. */
	found = vm_get_own_descriptor(array, length_key, &latest);
	if (found < 0)
		return -found;
	if (!found)
		return EINVAL;
	current = &latest;
'''+t[i:];t=t.replace('''	/* The new length (the elements past it go). */
	if (length != array->length) {
		status = vm_array_set_length(realm->heap, array, length);
		if (status != 0)
			return status;
	}''','''	/* A partial shrink preserves higher deletions and reports Boolean refusal after applying requested writability. */
	refused = 0;
	if (length != array->length) {
		status = vm_array_set_length(realm->heap, array, length);
		if (status == EPERM)
			refused = 1;
		else if (status != 0)
			return status;
	}''');t=t.replace('''	/* Succeeded: the length is defined. */
	*done = 1;''','''	/* A fixed element prevented the complete shrink even though requested read-only metadata was applied. */
	if (refused)
		return 0;

	/* Succeeded: the length is defined. */
	*done = 1;''');s=s[:a]+t+s[b:];p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/vm.h');s=p.read_text();s=s.replace('int vm_array_set_length(struct vm_heap *heap, struct vm_object *array, uint32_t length);','/* EPERM reports a fixed-index shrink refusal after higher deletions and length restoration to the failed index plus one. */\nint vm_array_set_length(struct vm_heap *heap, struct vm_object *array, uint32_t length);');p.write_text(s)
q=Path('build/ws074-20261018/q46');m=json.loads((q/'function-review-scope.json').read_text());m['userland/desktop/libbrowser/vm/access.c'].append('access_define_length');m['userland/desktop/libbrowser/vm/object.c']=['vm_array_set_length','object_array_key_compare','object_array_keys_trace'];(q/'function-review-scope.json').write_text(json.dumps(m,indent=2)+'\n')
p=q/'format.py';s=p.read_text();a=s.index(';mapping=');b=s.index(';chunks=[]',a);s=s[:a]+';mapping='+repr(m)+s[b:];p.write_text(s)
