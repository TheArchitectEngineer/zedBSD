from pathlib import Path
import json
p=Path('plan/ws074/tests/host-proxy-read.c');s=p.read_text();i=s.index('static int own_collect_keys(');s=s[:i]+'''static int array_length_delete(struct vm_heap *heap, struct vm_object *object, vm_value key, int *handled, int *deleted);

/* Native deletion observes actual descending array shrink and delegates descriptor refusal to ordinary storage. */
static const struct vm_native_operations array_length_operations = {
	NULL, NULL, NULL, array_length_delete, NULL
};

'''+s[i:];s=s.replace('static int assignment_pressure(struct page *page);','static int assignment_pressure(struct page *page);\nstatic int array_length_pressure(struct page *page);');x='''	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;''';s=s.replace(x,x+'''

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;''')
s+='''
/* Observes real array deletion order and collection while leaving actual configurability policy unchanged. */
static int
array_length_delete(
	struct vm_heap *heap,
	struct vm_object *object,
	vm_value key,
	int *handled,
	int *deleted)
{
	struct vm_cell *found;
	int32_t index;
	int is_index;

	UNUSED_PARAMETER(deleted);

	/* The actual snapshot is traversed descending after publishing the requested shorter metadata. */
	is_index = vm_value_is_int32(key);
	if (!is_index)
		return EFAULT;
	index = vm_value_as_int32(key);
	if (index != 3 - (int32_t)object_consumer_case.calls || object->length != 1U)
		return EFAULT;
	vm_heap_collect(heap);
	found = vm_heap_find_cell(heap, object_consumer_case.input_address);
	if (found == NULL)
		return EFAULT;
	found = vm_heap_find_cell(heap, object_consumer_case.key_address);
	if (found == NULL)
		return EFAULT;
	object_consumer_case.calls++;
	*handled = 0;

	/* Succeeded: ordinary storage still decides whether each real descriptor can be deleted. */
	return 0;
}

/* Exercises the heap-level array length contract through real partial deletion, native GC and final reclamation. */
static int
array_length_pressure(
	struct page *page)
{
	struct vm_object *array;
	struct vm_object *payload;
	struct vm_cell *roots[2];
	struct vm_cell *found;
	struct vm_property property;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	unsigned registered;
	unsigned index;
	int present;
	int status;

	/* Setup roots retire before the low-level operation; the collector cannot rely on conservative stack scanning. */
	memset(roots, 0, sizeof(roots));
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A standalone array owns one fresh lower element and both the fixed and removable higher indices. */
	array = vm_array_create(page->heap, NULL);
	if (array == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The lower object payload must remain live even while temporary length metadata is smaller than its index. */
	roots[0] = &array->cell;
	payload = vm_object_create(page->heap, NULL);
	if (payload == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Actual storage descriptors decide refusal; the callback supplies no mock deletion result. */
	roots[1] = &payload->cell;
	status = vm_object_define(page->heap, array, vm_value_int32(1), vm_value_cell(payload), VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = vm_object_define(page->heap, array, vm_value_int32(2), VM_VALUE_TRUE, VM_PROPERTY_WRITABLE);
	if (status != 0)
		goto cleanup;
	status = vm_object_define(page->heap, array, vm_value_int32(3), VM_VALUE_TRUE, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	array->native_operations = &array_length_operations;
	object_consumer_case.input_address = (uintptr_t)array;
	object_consumer_case.key_address = (uintptr_t)payload;
	roots[0] = NULL;
	roots[1] = NULL;

	/* The production heap API alone owns the array while both descending deletions actually collect. */
	vm_heap_stats(page->heap, &before);
	status = vm_array_set_length(page->heap, array, 1U);
	vm_heap_stats(page->heap, &after);
	if (status != EPERM ||
	    object_consumer_case.calls != 2U ||
	    after.collections < before.collections + 2U ||
	    array->length != 3U) {
		status = EFAULT;
		goto cleanup;
	}

	/* The higher configurable element was deleted before the fixed element stopped further shrinking. */
	present = vm_object_get_own_ordinary(array, vm_value_int32(3), &property);
	if (present != 0) {
		status = EFAULT;
		goto cleanup;
	}

	/* The lower payload was never deleted or collected despite the temporarily published shorter length. */
	present = vm_object_get_own_ordinary(array, vm_value_int32(1), &property);
	if (present != 1 || *property.value != vm_value_cell(payload)) {
		status = EFAULT;
		goto cleanup;
	}

	/* No key snapshot or native registration retains either original object after the operation completes. */
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* The lower payload is independently reclaimed after its former array owner is gone. */
	found = vm_heap_find_cell(page->heap, object_consumer_case.key_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* Real deletion ordering, partial metadata restoration and complete native ownership all held. */
	status = 0;

cleanup:
	/* Weak observation addresses and partial setup registrations retire on every exit. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve any violated native-array or lifetime observation after cleanup. */
	if (status != 0)
		return status;

	/* Succeeded: descending shrink preserves its failed boundary and releases both managed participants. */
	return 0;
}
''';p.write_text(s)
q=Path('build/ws074-20261018/q46');m=json.loads((q/'function-review-scope.json').read_text());m['plan/ws074/tests/host-proxy-read.c']+=['array_length_delete','array_length_pressure'];(q/'function-review-scope.json').write_text(json.dumps(m,indent=2)+'\n');p=q/'format.py';s=p.read_text();a=s.index(';mapping=');b=s.index(';chunks=[]',a);s=s[:a]+';mapping='+repr(m)+s[b:];s=s.replace("  s=s[:m.start()]+f+s[m.end():];chunks.append(f)","  f=f.replace('if (status != EPERM || object_consumer_case.calls != 2U || after.collections < before.collections + 2U || array->length != 3U)', 'if (status != EPERM ||\\n\\t    object_consumer_case.calls != 2U ||\\n\\t    after.collections < before.collections + 2U ||\\n\\t    array->length != 3U)')\n  s=s[:m.start()]+f+s[m.end():];chunks.append(f)");p.write_text(s)
