from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
q=Path('build/ws074-20261018/q46');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q46')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in source.items())
h=json.loads((q/'harness-outcome-audit.json').read_text());assert h['completed']==1508 and not h['whole_pass_losses'] and not h['whole_pass_gains'] and not h['old_pass_callback_losses'] and not h['changes']
p=json.loads((q/'final-protocol.json').read_text());assert p['conditions']==622 and p['native_matches'] and not p['chrome_matches'] and p['chrome_qualified_comparison_complete'] and p['chrome_matching_individual_conditions']==620 and len(p['known_huge_length_differences'])==2 and p['native_global_not_exposed_and_ownership']
pre=json.loads((q/'revised-precode-native-proof.json').read_text());assert len(pre['failed'])==22 and pre['returncode']==1
public=json.loads((q/'public-precode-final-proof.json').read_text());assert public['all22_final_native_and_genuine_chrome_PASS'] and public['new37_all_native_and_genuine_chrome_match']
runs=json.loads((v/'native-runs.json').read_text());assert len(runs)==12 and all(x['returncode']==0 for x in runs)
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
n=json.loads((q/'native-proof.json').read_text());old=json.loads(Path('build/ws074-20261018/q38/native-proof.json').read_text());assert len(n['runs'])==4
for a,b in zip(n['runs'],old['runs']):assert a['callbacks']==b['callbacks'] and a['source_sha256']==b['source_sha256'] and a['returncode']==0 and a['ownership'] and a['end']
validator=json.loads((q/'webidl-validator-proof.json').read_text());a,b=validator['runs'];assert a['callbacks']==b['callbacks'] and [r['status'] for r in a['callbacks']]==[0,0,1] and a['returncode']==b['returncode']==0 and b['ownership']
assert not any(x in (q/'host-build-revised.log').read_text() for x in ['warning:','error:'])
for f in q.glob('target-*.log'):assert not f.read_bytes()
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
style=json.loads((q/'source-audit.json').read_text());assert style['raw_allowed_cleanup']==62 and style['other_checker_findings']==0
out.mkdir(parents=True,exist_ok=False);archives={}
def archive(label,paths,base):
 mapping={str(p.resolve().relative_to(base.resolve())):p for p in paths};archive=out/(label+'.tar.gz')
 with tarfile.open(archive,'w:gz') as t:
  for name,path in sorted(mapping.items()):t.add(path,arcname=name,recursive=False)
 with tarfile.open(archive,'r:gz') as t:
  count=0
  for member in t:assert t.extractfile(member).read()==mapping[member.name].read_bytes();count+=1
 assert count==len(mapping);archives[label]=dict(sha256=digest(archive),members=count,all_members_readback=True)
archive('harness-all-raw',[Path(p) for p in json.loads((q/'harness-files.json').read_text())],v/'after-harness')
paths=[f for f in q.rglob('*') if f.is_file() and f.suffix in ['.py','.sh','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'after-harness' not in f.parts and 'engine' not in f.parts and 'target' not in f.parts and not any(x.endswith('-data') or x=='data' for x in f.parts)];paths.append(v/'engine/proxy-read.js');archive('native-oracle-and-build-raw',paths,q)
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),selection='1c84bf011',scope_revision='9fbfca12c',source_hash_count=len(source),conditions=622,native_pass=622,chrome_pass=620,new_conditions=37,precode_fixed_conditions=22,new37_genuine_chrome_match=True,old585_prefix_unchanged=True,all_chrome_equality=False,oracle='q36 classifier filter inherited, q43 huge2 native primary ordered Get versus Chrome pre-index RangeError retained; new37 genuine Chrome matches; no source/oracle/expected changes',full_changed_C=style,native_gates=runs,native_new=['direct vm_set pure GetOwn errno + actual GC keeps bare managed caller/receiver/fresh value/never-stored Symbol; all4 reclaimed','direct vm_set strict native Define refusal + callback pressure triggers strictly later TypeError allocation collection after inner Set ownership retires; all4 survive then all4 reclaim','low-level array shrink real descending deletion callbacks 3 then2 each collect with length1 published; actual fixed index2 returns EPERM and restored length3, lower payload live even outside temporary metadata; array/payload actually reclaimed'],array_limit='upper uint32 atom keys recognized during shrink; ordinary creation/storage upper-index classification remains legacy and not certified',acid3_score=100,acid3_inventory=100,acid3_pixels=0,acid2_existing_pixels=873,original_webidl_q38_same_callbacks=True,additional_validator_negative_rule_callbacks=a['callbacks'],harness=h,harness_seconds=json.loads((v/'after-harness/runs.json').read_text())[-1]['seconds'],harness_comparison='q44 whole and every callback/completion',official_score=1482,denominator=3805,held=0,unattempted=275,static_scripted_crash_reused='q28',current_pair_images_crash_not_measured=True,archives=archives,remaining=['primitive Set exotic prototype/outer vm_instanceof/BoundFunction/callable Proxy','for-in/spread/JSON/other invariant realm snapshots/nested/call/construct/global constructor/revocable','array upper-index general storage/IsArray consumers/immutable prototype/typed backing/p100/full target/WS acceptance','shared Master/Queue/cache/GitHub projections pending Q1'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['approval-snapshot.md','approval-revision.md','final-protocol.json','precode-native-proof.json','revised-precode-native-proof.json','public-precode-final-proof.json','source-audit.json','old-prefix-proof.json','versions.json','native-proof.json','webidl-validator-proof.json','target-commands-2.json','harness-outcome-audit.json']:shutil.copy2(q/name,out/name)
for name in ['source-proof.json','source-commit.txt','shared-input-comparison.json','native-runs.json']:shutil.copy2(v/name,out/name)
shutil.copy2(v/'acid/report.json',out/'acid-report.json')
print('archives',archives)
