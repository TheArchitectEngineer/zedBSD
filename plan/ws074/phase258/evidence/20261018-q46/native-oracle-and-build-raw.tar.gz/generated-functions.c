int vm_set(struct vm_realm *realm, vm_value base, vm_value key, vm_value value, int strict);
static int access_define_length(struct vm_realm *realm, struct vm_object *array, const struct vm_descriptor *current, const struct vm_descriptor *descriptor, int *done);
int main(int argc, char **argv);
static int assignment_refuse_define(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *handled, int *done);
static int assignment_pressure(struct page *page);
static int array_length_delete(struct vm_heap *heap, struct vm_object *object, vm_value key, int *handled, int *deleted);
static int array_length_pressure(struct page *page);
int vm_array_set_length(struct vm_heap *heap, struct vm_object *array, uint32_t length);
static int object_array_key_compare(const void *left, const void *right);
static void object_array_keys_trace(struct vm_heap *heap, void *context);
static int object_array_index(vm_value key, uint32_t *index);

int
vm_set(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	vm_value value,
	int strict)
{
	struct access_write_roots roots;
	struct vm_object *object;
	int is_object;
	int done;
	int status;

	/* undefined and null have no properties. */
	if (base == VM_VALUE_UNDEFINED || base == VM_VALUE_NULL) {
		status = access_base_error(realm, base, key, "set", "setting");
		return status;
	}

	/* A primitive takes no property, but its prototype's setter is called with it. */
	is_object = vm_value_is_object(base);
	if (!is_object) {
		status = access_set_primitive(realm, base, key, value, strict);
		return status;
	}

	/* Every object uses its actual receiver-aware operation, including exotic prototypes of ordinary receivers. */
	object = (struct vm_object *)vm_value_as_cell(base);
	roots.read.realm = realm;
	roots.read.base = base;
	roots.read.key = key;
	roots.read.receiver = base;
	roots.value = value;
	status = vm_heap_add_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;
	status = vm_set_receiver(realm, object, key, value, base, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		/* Keep native input ownership until any strict refusal exception has finished allocating. */
		if (object->kind == VM_KIND_PROXY)
			status = access_refuse(realm, strict, "Proxy set trap returned false");
		else
			status = access_refuse(realm, strict, "Cannot assign to read only property");
	}

cleanup:
	/* Accepted writes, sloppy refusals and abrupt operations all retire the outer assignment owner. */
	vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the actual operation accepted the write, or sloppy code ignored its refusal. */
	return 0;
}

static int
access_define_length(
	struct vm_realm *realm,
	struct vm_object *array,
	const struct vm_descriptor *current,
	const struct vm_descriptor *descriptor,
	int *done)
{
	struct vm_descriptor rest;
	struct vm_descriptor latest;
	vm_value length_key;
	double number;
	uint32_t length;
	int refused;
	int found;
	int allowed;
	int status;

	/* The new length, when given: a whole number in uint32's range. */
	*done = 0;
	length_key = vm_key_from_ascii(realm->heap, "length");
	if (length_key == VM_VALUE_EMPTY)
		return ENOMEM;
	rest = *descriptor;
	length = array->length;
	if ((descriptor->has & VM_HAS_VALUE) != 0U) {
		status = vm_to_uint32(realm, descriptor->value, &length);
		if (status != 0)
			return status;
		status = vm_to_number(realm, descriptor->value, &number);
		if (status != 0)
			return status;
		if ((double)length != number) {
			status = vm_throw_range_error(realm, "Invalid array length");
			return status;
		}

		/* The value as the number it is. */
		rest.value = vm_value_number((double)length);
	}

	/* Conversion may change the array or make its length read-only; inspect the actual post-conversion descriptor. */
	found = vm_get_own_descriptor(array, length_key, &latest);
	if (found < 0)
		return -found;
	if (!found)
		return EINVAL;
	current = &latest;

	/* The change must be allowed as for any property, and a read-only length cannot change. */
	allowed = access_descriptor_allowed(array, 1, current, &rest);
	if (!allowed)
		return 0;
	if ((current->attributes & VM_PROPERTY_WRITABLE) == 0U && length != array->length)
		return 0;

	/* A partial shrink preserves higher deletions and reports Boolean refusal after applying requested writability. */
	refused = 0;
	if (length != array->length) {
		status = vm_array_set_length(realm->heap, array, length);
		if (status == EPERM)
			refused = 1;
		else if (status != 0)
			return status;
	}

	/* A length made read-only stays so. */
	if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U) {
		status = vm_object_define(realm->heap, array, length_key, vm_value_number((double)array->length), 0);
		if (status != 0)
			return status;
	}

	/* A fixed element prevented the complete shrink even though requested read-only metadata was applied. */
	if (refused)
		return 0;

	/* Succeeded: the length is defined. */
	*done = 1;
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
assignment_refuse_define(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *handled,
	int *done)
{
	struct vm_cell *found;
	struct vm_cell *pressure;
	struct vm_heap_stats stats;

	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(key);
	UNUSED_PARAMETER(descriptor);

	/* This pure native policy observes weak addresses without creating an owner or running script. */
	vm_heap_collect(realm->heap);
	found = vm_heap_find_cell(realm->heap, object_consumer_case.caller_address);
	if (found == NULL)
		return EFAULT;
	found = vm_heap_find_cell(realm->heap, object_consumer_case.input_address);
	if (found == NULL)
		return EFAULT;
	pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL)
		return ENOMEM;

	/* The outer strict-refusal allocation must cause a strictly later collection after inner Set ownership retires. */
	vm_heap_stats(realm->heap, &stats);
	object_consumer_case.callback_collections = stats.collections;
	object_consumer_case.calls++;
	*handled = 1;
	*done = 0;

	/* Succeeded: actual DefineOwnProperty refusal remains Boolean until the assignment wrapper handles strictness. */
	return 0;
}

static int
assignment_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *input;
	struct vm_object *value;
	struct vm_symbol *symbol;
	struct vm_cell *roots[4];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	uintptr_t addresses[4];
	vm_value key;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int status;

	/* Setup owns construction only; the direct production API receives no outer VM-call protection. */
	memset(roots, 0, sizeof(roots));
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Native GetOwn errno and native Define refusal exercise distinct stages of the real assignment wrapper. */
	for (mode = 0; mode < 2U; mode++) {
		memset(&object_consumer_case, 0, sizeof(object_consumer_case));
		object_consumer_case.heap = page->heap;
		status = vm_realm_create_managed(page->heap, &caller);
		if (status != 0)
			goto cleanup;
		roots[0] = &caller->cell;
		input = vm_object_create(page->heap, NULL);
		if (input == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The ordinary receiver has no prototype or registry retaining any test participant. */
		roots[1] = &input->cell;
		input->native_operations = &consumer_error_descriptor_operations;
		if (mode == 1U)
			input->native_operations = &assignment_refuse_operations;
		value = vm_object_create(page->heap, NULL);
		if (value == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Both a fresh object value and a never-stored Symbol key must survive the production operation. */
		roots[2] = &value->cell;
		symbol = vm_symbol_create(page->heap, VM_VALUE_UNDEFINED);
		if (symbol == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Integer observations are weak and do not provide collector ownership. */
		roots[3] = &symbol->cell;
		key = vm_value_cell(symbol);
		object_consumer_case.caller_address = (uintptr_t)caller;
		object_consumer_case.input_address = (uintptr_t)input;
		for (index = 0; index < 4U; index++) {
			addresses[index] = (uintptr_t)roots[index];
			roots[index] = NULL;
		}

		/* The direct assignment alone now owns its caller, receiver, write value and Symbol key. */
		vm_heap_stats(page->heap, &before);
		status = vm_set(caller, vm_value_cell(input), key, vm_value_cell(value), 1);
		vm_heap_stats(page->heap, &after);
		if (mode == 0U) {
			if (status != EACCES) {
				status = EFAULT;
				goto cleanup;
			}
		} else {
			if (status != VM_THROWN || after.collections <= object_consumer_case.callback_collections) {
				status = EFAULT;
				goto cleanup;
			}
		}

		/* Both callbacks must actually run and collect, including the post-callback strict-error collection. */
		if (object_consumer_case.calls != 1U || after.collections <= before.collections) {
			status = EFAULT;
			goto cleanup;
		}

		/* All four participants survived the complete direct operation, including strict-refusal error construction. */
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, addresses[index]);
			if (found == NULL) {
				status = EFAULT;
				goto cleanup;
			}
		}

		/* Completed errno and thrown-error outcomes leave no permanent native owner for their original inputs. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, addresses[index]);
			if (found != NULL) {
				status = EFAULT;
				goto cleanup;
			}
		}
	}

	/* Both native-error and strict-refusal paths retained and then released the full original input graph. */
	status = 0;

cleanup:
	/* Retire setup registrations and weak observation context on every result path. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an observed error only after every native registration has been retired. */
	if (status != 0)
		return status;

	/* Succeeded: direct assignment owns all participants through native callbacks and later refusal errors. */
	return 0;
}

static int
array_length_delete(
	struct vm_heap *heap,
	struct vm_object *object,
	vm_value key,
	int *handled,
	int *deleted)
{
	struct vm_cell *found;
	int32_t index;
	int is_index;

	UNUSED_PARAMETER(deleted);

	/* The actual snapshot is traversed descending after publishing the requested shorter metadata. */
	is_index = vm_value_is_int32(key);
	if (!is_index)
		return EFAULT;
	index = vm_value_as_int32(key);
	if (index != 3 - (int32_t)object_consumer_case.calls || object->length != 1U)
		return EFAULT;
	vm_heap_collect(heap);
	found = vm_heap_find_cell(heap, object_consumer_case.input_address);
	if (found == NULL)
		return EFAULT;
	found = vm_heap_find_cell(heap, object_consumer_case.key_address);
	if (found == NULL)
		return EFAULT;
	object_consumer_case.calls++;
	*handled = 0;

	/* Succeeded: ordinary storage still decides whether each real descriptor can be deleted. */
	return 0;
}

static int
array_length_pressure(
	struct page *page)
{
	struct vm_object *array;
	struct vm_object *payload;
	struct vm_cell *roots[2];
	struct vm_cell *found;
	struct vm_property property;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value expected;
	unsigned registered;
	unsigned index;
	int present;
	int status;

	/* Setup roots retire before the low-level operation; the collector cannot rely on conservative stack scanning. */
	memset(roots, 0, sizeof(roots));
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A standalone array owns one fresh lower element and both the fixed and removable higher indices. */
	array = vm_array_create(page->heap, NULL);
	if (array == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The lower object payload must remain live even while temporary length metadata is smaller than its index. */
	roots[0] = &array->cell;
	payload = vm_object_create(page->heap, NULL);
	if (payload == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Actual storage descriptors decide refusal; the callback supplies no mock deletion result. */
	roots[1] = &payload->cell;
	status = vm_object_define(page->heap, array, vm_value_int32(1), vm_value_cell(payload), VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = vm_object_define(page->heap, array, vm_value_int32(2), VM_VALUE_TRUE, VM_PROPERTY_WRITABLE);
	if (status != 0)
		goto cleanup;
	status = vm_object_define(page->heap, array, vm_value_int32(3), VM_VALUE_TRUE, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	array->native_operations = &array_length_operations;
	object_consumer_case.input_address = (uintptr_t)array;
	object_consumer_case.key_address = (uintptr_t)payload;
	roots[0] = NULL;
	roots[1] = NULL;

	/* The production heap API alone owns the array while both descending deletions actually collect. */
	vm_heap_stats(page->heap, &before);
	status = vm_array_set_length(page->heap, array, 1U);
	vm_heap_stats(page->heap, &after);
	if (status != EPERM ||
	    object_consumer_case.calls != 2U ||
	    after.collections < before.collections + 2U ||
	    array->length != 3U) {
		status = EFAULT;
		goto cleanup;
	}

	/* The higher configurable element was deleted before the fixed element stopped further shrinking. */
	present = vm_object_get_own_ordinary(array, vm_value_int32(3), &property);
	if (present != 0) {
		status = EFAULT;
		goto cleanup;
	}

	/* The lower payload was never deleted or collected despite the temporarily published shorter length. */
	expected = vm_value_cell(payload);
	present = vm_object_get_own_ordinary(array, vm_value_int32(1), &property);
	if (present != 1 || *property.value != expected) {
		status = EFAULT;
		goto cleanup;
	}

	/* No key snapshot or native registration retains either original object after the operation completes. */
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* The lower payload is independently reclaimed after its former array owner is gone. */
	found = vm_heap_find_cell(page->heap, object_consumer_case.key_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* Real deletion ordering, partial metadata restoration and complete native ownership all held. */
	status = 0;

cleanup:
	/* Weak observation addresses and partial setup registrations retire on every exit. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve any violated native-array or lifetime observation after cleanup. */
	if (status != 0)
		return status;

	/* Succeeded: descending shrink preserves its failed boundary and releases both managed participants. */
	return 0;
}

int
vm_array_set_length(
	struct vm_heap *heap,
	struct vm_object *array,
	uint32_t length)
{
	struct wb_vector keys;
	struct vm_cell *root;
	vm_value key;
	uint32_t index;
	size_t item;
	size_t kept;
	int is_index;
	int deleted;
	int traced;
	int error;

	/* Retain the array and every copied key across native enumeration and deletion callbacks. */
	root = &array->cell;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	error = vm_heap_add_root(heap, &root);
	if (error != 0)
		return error;
	error = vm_heap_add_tracer(heap, object_array_keys_trace, &keys);
	if (error != 0)
		goto cleanup;
	traced = 1;

	/* Growth changes no element descriptor and never scans a possibly huge sparse logical length. */
	if (length >= array->length) {
		array->length = length;
		object_sync_length(heap, array);
		goto cleanup;
	}

	/* Snapshot present own keys before publishing the shorter metadata; absent indices need no deletion. */
	error = vm_object_own_keys(heap, array, &keys);
	if (error != 0)
		goto cleanup;
	kept = 0;
	for (item = 0; item < keys.count; item++) {
		key = ((vm_value *)keys.items)[item];
		is_index = object_array_index(key, &index);
		if (is_index && index >= length) {
			((vm_value *)keys.items)[kept] = key;
			kept++;
		}
	}

	/* Numeric ordering includes atom-backed indices above signed int32 and native-policy prefixes. */
	keys.count = kept;
	if (keys.count > 1U)
		qsort(keys.items, keys.count, sizeof(vm_value), object_array_key_compare);
	array->length = length;
	object_sync_length(heap, array);

	/* Delete higher indices first so the first refusal preserves every lower descriptor and earlier higher deletion. */
	item = keys.count;
	while (item != 0U) {
		item--;
		key = ((vm_value *)keys.items)[item];
		error = vm_object_delete(heap, array, key, &deleted);
		if (error != 0)
			goto cleanup;
		if (!deleted) {
			/* The failed index bounds the actual length after the already completed higher deletions. */
			is_index = object_array_index(key, &index);
			array->length = index + 1U;
			object_sync_length(heap, array);
			error = EPERM;
			goto cleanup;
		}
	}

	/* Every present property at or above the requested bound was deleted. */
	error = 0;

cleanup:
	/* Snapshot ownership ends on growth, complete shrink, partial refusal and native allocation errors alike. */
	if (traced)
		vm_heap_remove_tracer(heap, object_array_keys_trace, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(heap, &root);
	if (error != 0)
		return error;

	/* Succeeded: metadata and the remaining own elements agree with the requested length. */
	return 0;
}

static int
object_array_key_compare(
	const void *left,
	const void *right)
{
	uint32_t first;
	uint32_t second;
	int is_index;

	/* Enumeration filtering guarantees both keys are indices; normalization is pure and cannot run script. */
	is_index = object_array_index(*(const vm_value *)left, &first);
	if (!is_index)
		return 0;
	is_index = object_array_index(*(const vm_value *)right, &second);
	if (!is_index)
		return 0;

	/* Smaller numeric indices sort first, including the atom-backed upper half of uint32. */
	if (first < second)
		return -1;
	if (first > second)
		return 1;

	/* Succeeded: equal numeric indices compare equally. */
	return 0;
}

static void
object_array_keys_trace(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *keys;
	size_t item;

	/* Vector storage is outside the managed heap and contains only initialized live entries. */
	keys = context;
	for (item = 0; item < keys->count; item++)
		vm_heap_mark_value(heap, ((vm_value *)keys->items)[item]);
}

static int
object_array_index(
	vm_value key,
	uint32_t *index)
{
	struct vm_string *string;
	uint64_t number;
	uint32_t position;
	uint16_t unit;
	int is_index;
	int is_string;

	/* Existing small numeric keys already carry their exact nonnegative index. */
	is_index = vm_value_is_array_index(key, index);
	if (is_index)
		return 1;
	is_string = vm_value_is_string(key);
	if (!is_string)
		return 0;

	/* Canonical decimal array indices have at most ten digits and no redundant leading zero. */
	string = (struct vm_string *)vm_value_as_cell(key);
	if (string->length == 0U || string->length > 10U)
		return 0;
	unit = vm_string_at(string, 0);
	if (unit == '0' && string->length != 1U)
		return 0;

	/* Exact integer accumulation excludes nondecimal syntax and the reserved uint32 maximum. */
	number = 0;
	for (position = 0; position < string->length; position++) {
		unit = vm_string_at(string, position);
		if (unit < '0' || unit > '9')
			return 0;
		number = number * 10U + (uint64_t)(unit - '0');
	}

	/* The string 4294967295 is an ordinary property name rather than an array index. */
	if (number >= (uint64_t)4294967295U)
		return 0;
	*index = (uint32_t)number;

	/* Succeeded: the existing atom names one exact array index, including indices above signed int32. */
	return 1;
}
