from pathlib import Path
import ast,hashlib,json,subprocess,time,re
q=Path('build/ws074-20261018/q46');base=Path('build/ws074-20261018/q29/webidl-controls/retained-3v3c9hcp/actual-webidl-negative'); engine=Path('build/ws074-20261018/q46/final/engine/host-proxy-read').resolve()
a=ast.parse(Path('build/ws074-20261018/q29/webidl-controls.py').read_text());scripts=ast.literal_eval(next(n.value for n in a.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='scripts' for t in n.targets)))
harness=(base/'resources/testharness.js').read_bytes();lib=(base/'resources/webidl2/lib/webidl2.js').read_bytes();assert hashlib.sha256(lib).hexdigest()=='954444f6daf0f8068d2fce513eac8e6a5d53189a910b9a5675e8d8e8a2808070'
proof={'engine_sha256':hashlib.sha256(engine.read_bytes()).hexdigest(),'harness_sha256':hashlib.sha256(harness).hexdigest(),'webidl_sha256':hashlib.sha256(lib).hexdigest(),'runs':[]}
for mode in ['baseline','adapter']:
 for label,tests in scripts:
  prefix=b'var probeOriginalProxy=globalThis.Proxy;\n'
  if mode=='adapter':prefix+=b'if(typeof Proxy==="undefined"){globalThis.Proxy=function Proxy(target,handler){return makeReadProxy(target,handler);};}\n'
  logger=b'\nsetup({output:false,explicit_done:true});add_result_callback(function(t){console.log("WEBIDL-PROBE "+JSON.stringify({name:t.name,status:t.status,message:t.message||""}));});\n'
  suffix=b'\nconsole.log("WEBIDL-PROBE-END");if(typeof probeOriginalProxy==="undefined"){delete globalThis.Proxy;}true;\n'
  source=prefix+harness+b'\n'+lib+logger+tests+suffix; name=mode+'-'+label; path=q/(name+'.js');path.write_bytes(source)
  run=subprocess.run([str(engine),str(path.resolve())],capture_output=True,timeout=45);(q/(name+'.out')).write_bytes(run.stdout);(q/(name+'.err')).write_bytes(run.stderr)
  callbacks=[]
  for line in (run.stdout+run.stderr).decode(errors='replace').splitlines():
   if 'WEBIDL-PROBE {' in line:
    callbacks.append(json.loads(line[line.index('WEBIDL-PROBE ')+13:]))
  row=dict(mode=mode,label=label,returncode=run.returncode,source_sha256=hashlib.sha256(source).hexdigest(),tests_sha256=hashlib.sha256(tests).hexdigest(),callbacks=callbacks,ownership=b'native proxy read ownership: passed' in run.stdout,end=b'WEBIDL-PROBE-END' in run.stdout+run.stderr)
  proof['runs'].append(row);print(json.dumps(row),flush=True)
(q/'native-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
