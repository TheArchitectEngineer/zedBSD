/* Marks only live values in a fixture vector, without retaining any completed operation owner. */
static void
proxy_key_values_trace(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *keys;
	size_t index;

	/* Stale slots beyond count must not retain rolled-back native output. */
	keys = context;
	for (index = 0; index < keys->count; index++)
		vm_heap_mark_value(heap, ((vm_value *)keys->items)[index]);
}

/* Compares actual realm own-key enumeration with genuine reflection through an ordinary result array. */
static int
proxy_own_keys(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct wb_vector keys;
	struct vm_cell *realm_root;
	struct vm_string *string;
	vm_value object;
	vm_value key;
	size_t index;
	int traced;
	int is_object;
	int is_index;
	int status;

	UNUSED_PARAMETER(receiver);

	/* The bridge owns its managed realm even while producing an invalid-target exception or result array. */
	realm_root = NULL;
	if (realm->managed)
		realm_root = &realm->cell;
	status = vm_heap_add_root(realm->heap, &realm_root);
	if (status != 0)
		return status;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, proxy_key_values_trace, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* Reflective enumeration rejects primitive input rather than boxing it. */
	object = js_argument(args, count, 0);
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Own key target must be an object");
		goto cleanup;
	}

	/* Only the production VM operation supplies keys and validates traps or invariants. */
	status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(object), &keys);
	if (status != 0)
		goto cleanup;
	for (index = 0; index < keys.count; index++) {
		key = ((vm_value *)keys.items)[index];
		is_index = vm_value_is_int32(key);
		if (!is_index)
			continue;

		/* Genuine reflection exposes numeric internal keys as primitive strings, preserving vector order. */
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		((vm_value *)keys.items)[index] = vm_value_cell(string);
	}

	/* The private result uses the same ordinary array size bound as CreateArrayFromList. */
	if (keys.count > 4294967295U) {
		status = vm_throw_range_error(realm, "Own key result exceeds the array length limit");
		goto cleanup;
	}

	/* The vector remains rooted while the real ordinary array is allocated and filled. */
	status = js_builtin_array(realm, keys.items, (unsigned)keys.count, result);

cleanup:
	/* Temporary vector storage and bridge ownership never escape into the produced array. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, proxy_key_values_trace, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(realm->heap, &realm_root);
	if (status != 0)
		return status;

	/* Succeeded: the ordinary array represents actual VM own keys. */
	return 0;
}

/* Records a fresh Symbol's address without adding any collector edge to it. */
static int
proxy_note_own_key(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value value;
	int is_cell;

	UNUSED_PARAMETER(receiver);

	/* This observation is active only during the independent synchronous own-key lifetime case. */
	value = js_argument(args, count, 0);
	is_cell = vm_value_is_cell(value);
	if (is_cell && own_case.heap == realm->heap)
		own_case.addresses[4] = (uintptr_t)vm_value_as_cell(value);
	*result = value;

	/* Succeeded: the value's only real owners remain its script or production VM frames. */
	return 0;
}
