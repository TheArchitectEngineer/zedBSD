(function(){
 var read=typeof ownReadKeys==='function'?ownReadKeys:function(t){return Reflect.ownKeys(t);};
 function proxy(t,h){return typeof makeReadProxy==='function'?makeReadProxy(t,h):new Proxy(t,h);}
 [1,Infinity,9007199254740992].forEach(function(length){var expected={},calls=0,list={length:length,get 0(){calls++;throw expected;}};try{read(proxy({},{ownKeys:function(){return list;}}));console.log('OWNKEY-LENGTH '+JSON.stringify({length:String(length),returned:true,calls:calls}));}catch(e){console.log('OWNKEY-LENGTH '+JSON.stringify({length:String(length),same_error:e===expected,calls:calls,name:e.name||'',message:e.message||''}));}});
})();true;
