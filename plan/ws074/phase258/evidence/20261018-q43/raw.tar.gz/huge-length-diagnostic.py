from pathlib import Path
import subprocess,json,time,re,hashlib
q=Path('build/ws074-20261018/q43');source=(q/'huge-length-diagnostic.js').read_bytes();rows=[]
for label in ['native','chrome']:
 if label=='native':command=[str((q/'final/engine/host-proxy-read').resolve()),str((q/'huge-length-diagnostic.js').resolve())]
 else:
  p=q/'huge-length-diagnostic.html';p.write_bytes(b'<!doctype html><html><body><script>'+source+b'</script></body></html>');command=['chromium','--headless','--no-sandbox','--disable-gpu','--user-data-dir=/tmp/ws074-q43-length-'+str(time.time_ns()),'--enable-logging=stderr','--v=0','--virtual-time-budget=5000','--dump-dom',p.resolve().as_uri()]
 run=subprocess.run(command,capture_output=True,timeout=30);(q/(label+'-huge-length.out')).write_bytes(run.stdout);(q/(label+'-huge-length.err')).write_bytes(run.stderr);observed=[]
 for line in (run.stdout+run.stderr).decode(errors='replace').splitlines():
  if 'OWNKEY-LENGTH {' in line:
   value=line[line.index('OWNKEY-LENGTH ')+14:]
   if label=='chrome':value=value.split('", source: ')[0]
   observed.append(json.loads(value))
 rows.append(dict(label=label,returncode=run.returncode,rows=observed,command=command));print(rows[-1],flush=True)
assert all(x['returncode']==0 and len(x['rows'])==3 for x in rows)
assert all(x['calls']==1 and x['same_error'] for x in rows[0]['rows'])
assert rows[1]['rows'][0]['calls']==1 and rows[1]['rows'][0]['same_error']
assert all(x['calls']==0 and x['name']=='RangeError' and not x['same_error'] for x in rows[1]['rows'][1:])
(q/'huge-length-diagnostic-proof.json').write_text(json.dumps(dict(shared_source_sha256=hashlib.sha256(source).hexdigest(),runs=rows),indent=2)+'\n')
