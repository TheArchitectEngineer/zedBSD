int vm_own_property_keys(struct vm_realm *realm, struct vm_object *object, struct wb_vector *keys);
static void access_keys_trace(struct vm_heap *heap, void *context);
static int access_property_key_list(struct vm_realm *realm, vm_value source, struct wb_vector *keys);
static int access_proxy_own_keys(struct vm_realm *realm, struct vm_proxy *proxy, struct wb_vector *keys);
int main(int argc, char **argv);
static void proxy_key_values_trace(struct vm_heap *heap, void *context);
static int proxy_own_keys(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_note_own_key(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int own_collect_keys(struct vm_heap *heap, struct vm_object *object, struct wb_vector *keys);
static int own_keys_pressure(struct page *page);

int
vm_own_property_keys(
	struct vm_realm *realm,
	struct vm_object *object,
	struct wb_vector *keys)
{
	struct access_read_roots roots;
	size_t beginning;
	int status;

	/* Caller prefixes and managed input ownership both survive every trap, native callback and error allocation. */
	beginning = keys->count;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	status = vm_heap_add_tracer(realm->heap, access_keys_trace, keys);
	if (status != 0) {
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Bound fallback recursion before any target operation while both input and prefix are rooted. */
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_keys_trace, keys);
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Ordinary objects preserve their existing native policy and key order. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY)
		status = access_proxy_own_keys(realm, (struct vm_proxy *)object, keys);
	else
		status = vm_object_own_keys(realm->heap, object, keys);

	/* Retire the native depth and discard only this operation's partial append on failure. */
	realm->property_depth--;
	if (status != 0)
		keys->count = beginning;
	vm_heap_remove_tracer(realm->heap, access_keys_trace, keys);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: only the completed operation's keys were appended to the preserved prefix. */
	return 0;
}

static void
access_keys_trace(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *keys;
	size_t index;

	/* Unused capacity holds no live values and must never become a collector edge. */
	keys = context;
	for (index = 0; index < keys->count; index++)
		vm_heap_mark_value(heap, ((vm_value *)keys->items)[index]);
}

static int
access_property_key_list(
	struct vm_realm *realm,
	vm_value source,
	struct wb_vector *keys)
{
	struct vm_cell *current_root;
	struct vm_string *string;
	vm_value length_key;
	vm_value index_key;
	vm_value value;
	vm_value key;
	double number;
	uint64_t length;
	uint64_t index;
	int is_cell;
	int is_object;
	int is_string;
	int is_symbol;
	int status;

	/* The caller retains source and the accumulated vector; this slot owns each fresh intermediate value. */
	current_root = NULL;
	status = vm_heap_add_root(realm->heap, &current_root);
	if (status != 0)
		return status;
	is_object = vm_value_is_object(source);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy ownKeys trap must return an object");
		goto cleanup;
	}

	/* LengthOfArrayLike gets length once before applying ToLength's number conversion. */
	length_key = vm_key_from_ascii(realm->heap, "length");
	if (length_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A fresh length object must survive its own valueOf callback and any collection it performs. */
	status = vm_get(realm, source, length_key, &value);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(value);
	if (is_cell)
		current_root = vm_value_as_cell(value);
	status = vm_to_number(realm, value, &number);
	if (status != 0)
		goto cleanup;
	current_root = NULL;

	/* NaN and nonpositive lengths produce an empty list, including negative zero and negative infinity. */
	length = 0;
	if (number == number && number > 0.0) {
		if (number >= 9007199254740991.0)
			length = (uint64_t)9007199254740991.0;
		else
			length = (uint64_t)floor(number);
	}

	/* Read each actual index in order; arbitrary large lengths remain lazy so the first abrupt getter still wins. */
	for (index = 0; index < length; index++) {
		if (index <= 2147483647U) {
			index_key = vm_value_int32((int32_t)index);
		} else {
			status = vm_to_string(realm, vm_value_number((double)index), &string);
			if (status != 0)
				goto cleanup;
			current_root = &string->cell;
			status = vm_key_from_string(realm->heap, string, &index_key);
			if (status != 0)
				goto cleanup;
			current_root = NULL;
		}

		/* Property-key lists permit only String or Symbol elements, with no object or numeric element coercion. */
		status = vm_get(realm, source, index_key, &value);
		if (status != 0)
			goto cleanup;
		current_root = NULL;
		is_cell = vm_value_is_cell(value);
		if (is_cell)
			current_root = vm_value_as_cell(value);
		is_string = vm_value_is_string(value);
		is_symbol = access_is_symbol(value);
		if (!is_string && !is_symbol) {
			status = vm_throw_type_error(realm, "Proxy ownKeys list elements must be strings or symbols");
			goto cleanup;
		}

		/* Only primitive strings are canonicalized into the VM's index-or-atom representation. */
		key = value;
		if (is_string) {
			status = vm_key_from_string(realm->heap, (struct vm_string *)vm_value_as_cell(value), &key);
			if (status != 0)
				goto cleanup;
		}

		/* The accumulated vector becomes the owner before the next getter may collect or delete earlier values. */
		status = wb_vector_push(keys, &key);
		if (status != 0)
			goto cleanup;
		current_root = NULL;
	}

	/* Every element was evaluated before the caller checks duplicate entries. */
	status = 0;

cleanup:
	/* Neither a length object nor an element may remain retained after this list conversion frame ends. */
	vm_heap_remove_root(realm->heap, &current_root);
	if (status != 0)
		return status;

	/* Succeeded: keys preserves the original array-like order as canonical internal property keys. */
	return 0;
}

static int
access_proxy_own_keys(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	struct wb_vector *keys)
{
	struct vm_cell *roots[4];
	struct wb_vector lists[ACCESS_OWN_LIST_COUNT];
	struct vm_descriptor descriptor;
	struct vm_object *target_object;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value produced;
	vm_value key;
	size_t item;
	unsigned index;
	unsigned registered;
	unsigned traced;
	int is_cell;
	int listed;
	int extensible;
	int found;
	int status;

	/* Original participants survive method lookup and trap revocation independently of the outer Proxy record. */
	target = proxy->target;
	handler = proxy->handler;
	memset(roots, 0, sizeof(roots));
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[0] = vm_value_as_cell(target);
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[1] = vm_value_as_cell(handler);
	registered = 0;
	traced = 0;
	for (index = 0; index < ACCESS_OWN_LIST_COUNT; index++)
		wb_vector_init(&lists[index], sizeof(vm_value));

	/* Every acquired root registration is retired even when a later registration fails. */
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Accumulated keys need native vector ownership across later element getters and target policy collections. */
	for (index = 0; index < ACCESS_OWN_LIST_COUNT; index++) {
		status = vm_heap_add_tracer(realm->heap, access_keys_trace, &lists[index]);
		if (status != 0)
			goto cleanup;
		traced++;
	}

	/* Revocation fails before the current handler method is observed. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot list the own keys of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod provides the usual dynamic getter, null fallback and noncallable checks. */
	method_key = vm_key_from_ascii(realm->heap, "ownKeys");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Missing methods delegate to the original target's actual internal key operation. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(target), keys);
		goto cleanup;
	}

	/* Retain both a fresh trap and its otherwise unowned array-like result. */
	roots[2] = vm_value_as_cell(method);
	status = vm_call(realm, method, handler, &target, 1, &produced);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(produced);
	if (is_cell)
		roots[3] = vm_value_as_cell(produced);
	status = access_property_key_list(realm, produced, &lists[ACCESS_OWN_TRAP_KEYS]);
	if (status != 0)
		goto cleanup;

	/* Duplicate rejection occurs only after the complete array-like list has been evaluated. */
	for (item = 0; item < lists[ACCESS_OWN_TRAP_KEYS].count; item++) {
		key = ((vm_value *)lists[ACCESS_OWN_TRAP_KEYS].items)[item];
		listed = access_key_listed(&lists[ACCESS_OWN_TRAP_KEYS], item, key);
		if (listed) {
			status = vm_throw_type_error(realm, "Proxy ownKeys trap returned duplicate keys");
			goto cleanup;
		}
	}

	/* Extensibility is snapshotted before the target key list, after all trap-result getters. */
	target_object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_is_extensible(realm, target_object, &extensible);
	if (status != 0)
		goto cleanup;
	status = vm_own_property_keys(realm, target_object, &lists[ACCESS_OWN_TARGET_KEYS]);
	if (status != 0)
		goto cleanup;

	/* Classify every target descriptor before checking any missing key, preserving abrupt-operation order. */
	for (item = 0; item < lists[ACCESS_OWN_TARGET_KEYS].count; item++) {
		key = ((vm_value *)lists[ACCESS_OWN_TARGET_KEYS].items)[item];
		status = vm_get_own_property(realm, target_object, key, &descriptor, &found);
		if (status != 0)
			goto cleanup;
		if (found && (descriptor.attributes & VM_PROPERTY_CONFIGURABLE) == 0U)
			status = wb_vector_push(&lists[ACCESS_OWN_FIXED_KEYS], &key);
		else
			status = wb_vector_push(&lists[ACCESS_OWN_CONFIGURABLE_KEYS], &key);
		if (status != 0)
			goto cleanup;
	}

	/* Fixed keys are mandatory regardless of target extensibility. */
	for (item = 0; item < lists[ACCESS_OWN_FIXED_KEYS].count; item++) {
		key = ((vm_value *)lists[ACCESS_OWN_FIXED_KEYS].items)[item];
		listed = access_key_listed(&lists[ACCESS_OWN_TRAP_KEYS], lists[ACCESS_OWN_TRAP_KEYS].count, key);
		if (!listed) {
			status = vm_throw_type_error(realm, "Proxy ownKeys trap omitted a fixed target key");
			goto cleanup;
		}
	}

	/* A nonextensible target also requires every configurable key and forbids every extra key. */
	if (!extensible) {
		for (item = 0; item < lists[ACCESS_OWN_CONFIGURABLE_KEYS].count; item++) {
			key = ((vm_value *)lists[ACCESS_OWN_CONFIGURABLE_KEYS].items)[item];
			listed = access_key_listed(&lists[ACCESS_OWN_TRAP_KEYS], lists[ACCESS_OWN_TRAP_KEYS].count, key);
			if (!listed) {
				status = vm_throw_type_error(realm, "Proxy ownKeys trap omitted a nonextensible target key");
				goto cleanup;
			}
		}

		/* Both lists are unique and every target key was matched, so equal size excludes all extras. */
		if (lists[ACCESS_OWN_TRAP_KEYS].count != lists[ACCESS_OWN_TARGET_KEYS].count) {
			status = vm_throw_type_error(realm, "Proxy ownKeys trap added a key to a nonextensible target");
			goto cleanup;
		}
	}

	/* Preserve trap order when appending; no ordinary numeric-key sorting is applied to a Proxy list. */
	for (item = 0; item < lists[ACCESS_OWN_TRAP_KEYS].count; item++) {
		key = ((vm_value *)lists[ACCESS_OWN_TRAP_KEYS].items)[item];
		status = wb_vector_push(keys, &key);
		if (status != 0)
			goto cleanup;
	}

	/* Complete list and invariant checks supplied the successfully appended keys. */
	status = 0;

cleanup:
	/* Stop tracing vectors before releasing their C storage; unused capacity never retains cells. */
	while (traced != 0U) {
		traced--;
		vm_heap_remove_tracer(realm->heap, access_keys_trace, &lists[traced]);
	}

	/* Every vector was initialized before any fallible registration or script operation. */
	for (index = 0; index < ACCESS_OWN_LIST_COUNT; index++)
		wb_vector_release(&lists[index]);

	/* Original participants and transient trap objects retire after all list storage. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Propagate original errors after retiring snapshots, temporary lists and trap results. */
	if (status != 0)
		return status;

	/* Succeeded: the outer frame now owns the complete appended key sequence. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static void
proxy_key_values_trace(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *keys;
	size_t index;

	/* Stale slots beyond count must not retain rolled-back native output. */
	keys = context;
	for (index = 0; index < keys->count; index++)
		vm_heap_mark_value(heap, ((vm_value *)keys->items)[index]);
}

static int
proxy_own_keys(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct wb_vector keys;
	struct vm_cell *realm_root;
	struct vm_string *string;
	vm_value object;
	vm_value key;
	size_t index;
	int traced;
	int is_object;
	int is_index;
	int status;

	UNUSED_PARAMETER(receiver);

	/* The bridge owns its managed realm even while producing an invalid-target exception or result array. */
	realm_root = NULL;
	if (realm->managed)
		realm_root = &realm->cell;
	status = vm_heap_add_root(realm->heap, &realm_root);
	if (status != 0)
		return status;
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, proxy_key_values_trace, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* Reflective enumeration rejects primitive input rather than boxing it. */
	object = js_argument(args, count, 0);
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Own key target must be an object");
		goto cleanup;
	}

	/* Only the production VM operation supplies keys and validates traps or invariants. */
	status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(object), &keys);
	if (status != 0)
		goto cleanup;

	/* Convert internal indices only after the complete validated operation has returned. */
	for (index = 0; index < keys.count; index++) {
		key = ((vm_value *)keys.items)[index];
		is_index = vm_value_is_int32(key);
		if (!is_index)
			continue;

		/* Genuine reflection exposes numeric internal keys as primitive strings, preserving vector order. */
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		((vm_value *)keys.items)[index] = vm_value_cell(string);
	}

	/* The private result uses the same ordinary array size bound as CreateArrayFromList. */
	if (keys.count > 4294967295U) {
		status = vm_throw_range_error(realm, "Own key result exceeds the array length limit");
		goto cleanup;
	}

	/* The vector remains rooted while the real ordinary array is allocated and filled. */
	status = js_builtin_array(realm, keys.items, (unsigned)keys.count, result);

cleanup:
	/* Temporary vector storage and bridge ownership never escape into the produced array. */
	if (traced)
		vm_heap_remove_tracer(realm->heap, proxy_key_values_trace, &keys);
	wb_vector_release(&keys);
	vm_heap_remove_root(realm->heap, &realm_root);
	if (status != 0)
		return status;

	/* Succeeded: the ordinary array represents actual VM own keys. */
	return 0;
}

static int
proxy_note_own_key(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value value;
	int is_cell;

	UNUSED_PARAMETER(receiver);

	/* This observation is active only during the independent synchronous own-key lifetime case. */
	value = js_argument(args, count, 0);
	is_cell = vm_value_is_cell(value);
	if (is_cell && own_case.heap == realm->heap)
		own_case.addresses[4] = (uintptr_t)vm_value_as_cell(value);
	*result = value;

	/* Succeeded: the value's only real owners remain its script or production VM frames. */
	return 0;
}

static int
own_collect_keys(
	struct vm_heap *heap,
	struct vm_object *object,
	struct wb_vector *keys)
{
	struct vm_symbol *symbol;
	struct vm_cell *found;
	vm_value key;
	unsigned index;
	int status;

	UNUSED_PARAMETER(object);

	/* This native callback runs no user script; all input and accumulated-list ownership belongs to the VM. */
	vm_heap_collect(heap);
	for (index = 0; index < 6U; index++) {
		if (own_case.addresses[index] == 0U)
			continue;
		found = vm_heap_find_cell(heap, own_case.addresses[index]);
		if (found == NULL)
			return EFAULT;
	}

	/* Count only post-trap or fallback collections that retained every expected participant. */
	own_case.calls++;
	if (own_case.mode == 3U) {
		/* A native partial append followed by errno must be rolled back without retaining its stale capacity slot. */
		symbol = vm_symbol_create(heap, VM_VALUE_UNDEFINED);
		if (symbol == NULL)
			return ENOMEM;
		key = vm_value_cell(symbol);
		status = wb_vector_push(keys, &key);
		if (status != 0)
			return status;
		own_case.addresses[4] = (uintptr_t)symbol;
		return EACCES;
	}

	/* Succeeded: ordinary storage supplies its actual keys after this collecting prefix policy. */
	return 0;
}

static int
own_keys_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_symbol *prefix;
	struct vm_cell *roots[6];
	struct vm_cell *found;
	struct wb_vector keys;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value proxy;
	vm_value getter;
	vm_value key;
	vm_value owner_key;
	vm_value prefix_value;
	vm_value expected_key;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int traced;
	int is_string;
	int matches;
	int status;

	/* Setup roots retire before the production operation; a caller tracer is acquired only after its return. */
	memset(&own_case, 0, sizeof(own_case));
	memset(roots, 0, sizeof(roots));
	wb_vector_init(&keys, sizeof(vm_value));
	registered = 0;
	traced = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Complete trap list, duplicate error, native fallback and partial native errno each need independent graphs. */
	for (mode = 0; mode < 4U; mode++) {
		status = vm_realm_create_managed(page->heap, &realm);
		if (status != 0)
			goto cleanup;
		roots[0] = &realm->cell;
		memset(&own_case, 0, sizeof(own_case));
		own_case.heap = page->heap;
		own_case.mode = mode;
		own_case.addresses[0] = (uintptr_t)realm;
		target = vm_object_create(page->heap, NULL);
		if (target == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The original target policy only collects and delegates actual ordinary key enumeration. */
		roots[1] = &target->cell;
		own_case.addresses[1] = (uintptr_t)target;
		target->native_operations = &own_collect_operations;
		handler = vm_object_create(page->heap, NULL);
		if (handler == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* A caller prefix is a fresh never-stored Symbol, so only the API can retain it during the operation. */
		roots[2] = &handler->cell;
		own_case.addresses[2] = (uintptr_t)handler;
		prefix = vm_symbol_create(page->heap, VM_VALUE_UNDEFINED);
		if (prefix == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* No registry or shape cache owns this prefix value. */
		roots[5] = &prefix->cell;
		own_case.addresses[5] = (uintptr_t)prefix;
		prefix_value = vm_value_cell(prefix);
		status = wb_vector_push(&keys, &prefix_value);
		if (status != 0)
			goto cleanup;
		if (mode >= 2U) {
			key = vm_key_from_ascii(page->heap, "native");
			if (key == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}

			/* Native fallback must enumerate a real stored ordinary name after its collecting prefix hook. */
			status = vm_object_define(page->heap, target, key, VM_VALUE_TRUE, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
		}

		/* Later getters can collect the fresh Symbol returned by an earlier getter unless the accumulated list owns it. */
		if (mode == 0U) {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return function(){return {get length(){return {valueOf:function(){collectReadProxy();return 2;}};},get 0(){return noteOwnKey(Symbol('fresh'));},get 1(){collectReadProxy();return 'v';}};};})", &getter);
		} else if (mode == 1U) {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return function(){return ['x','x'];};})", &getter);
		} else {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return null;})", &getter);
		}

		/* The handler accessor is ordinary production storage around a real script function. */
		if (status != 0)
			goto cleanup;
		roots[3] = vm_value_as_cell(getter);
		key = vm_key_from_ascii(page->heap, "ownKeys");
		owner_key = vm_key_from_ascii(page->heap, "owner");
		if (key == VM_VALUE_EMPTY || owner_key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* After lookup revokes the Proxy, only its original operation snapshots retain target and handler. */
		status = vm_define_accessor(realm, vm_value_cell(handler), key, getter, 0);
		if (status != 0)
			goto cleanup;
		roots[3] = NULL;
		status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
		if (status != 0)
			goto cleanup;
		roots[4] = vm_value_as_cell(proxy);
		own_case.addresses[3] = (uintptr_t)roots[4];
		status = vm_object_define(page->heap, handler, owner_key, proxy, VM_PROPERTY_DEFAULT);
		if (status != 0)
			goto cleanup;

		/* Neither output vectors nor inputs have an embedding tracer during the actual VM operation. */
		vm_heap_stats(page->heap, &before);
		for (index = 0; index < 6U; index++)
			roots[index] = NULL;
		status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(proxy), &keys);
		vm_heap_stats(page->heap, &after);
		if (mode == 1U) {
			if (status != VM_THROWN) {
				status = 1;
				goto cleanup;
			}

			/* A duplicate list is a language error before target native policy is ever consulted. */
			status = 0;
		} else if (mode == 3U) {
			if (status != EACCES) {
				status = 1;
				goto cleanup;
			}

			/* A partial native append preserves errno rather than becoming a completed key list. */
			status = 0;
		}

		/* Every outcome restores depth and has survived real getter or target-policy collection. */
		if (status != 0)
			goto cleanup;
		if (after.collections <= before.collections || realm->property_depth != 0U) {
			status = 1;
			goto cleanup;
		}

		/* Only now may an embedding tracer take ownership of the returned or preserved key sequence. */
		status = vm_heap_add_tracer(page->heap, proxy_key_values_trace, &keys);
		if (status != 0)
			goto cleanup;
		traced = 1;
		if (mode == 1U) {
			if (own_case.calls != 0U) {
				status = 1;
				goto cleanup;
			}
		} else if (own_case.calls != 1U) {
			status = 1;
			goto cleanup;
		}

		/* Original prefixes remain bit-identical on success and every rollback path. */
		if (keys.count == 0U || ((vm_value *)keys.items)[0] != prefix_value) {
			status = 1;
			goto cleanup;
		}

		/* Successful appends and abrupt rollback each have an exact independent vector-size expectation. */
		if (mode == 0U) {
			if (keys.count != 3U || own_case.addresses[4] == 0U) {
				status = 1;
				goto cleanup;
			}

			/* The first trap member is the actual fresh Symbol observed before its getter frame retired. */
			key = ((vm_value *)keys.items)[1];
			expected_key = vm_value_cell((void *)own_case.addresses[4]);
			if (key != expected_key) {
				status = 1;
				goto cleanup;
			}
		} else if (mode == 2U) {
			if (keys.count != 2U) {
				status = 1;
				goto cleanup;
			}

			/* This name comes from actual ordinary target storage after the collecting native prefix. */
			key = ((vm_value *)keys.items)[1];
			is_string = vm_value_is_string(key);
			if (!is_string) {
				status = 1;
				goto cleanup;
			}

			/* Verify the independently stored target name without allocating or consulting fixture policy. */
			matches = vm_string_equal_ascii((struct vm_string *)vm_value_as_cell(key), "native");
			if (!matches) {
				status = 1;
				goto cleanup;
			}
		} else if (keys.count != 1U) {
			status = 1;
			goto cleanup;
		}

		/* The output-only tracer cannot retain any original realm, target, handler or Proxy. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, own_case.addresses[index]);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* A rolled-back partial Symbol must be reclaimed despite its stale bits remaining in vector capacity. */
		if (own_case.addresses[4] != 0U) {
			found = vm_heap_find_cell(page->heap, own_case.addresses[4]);
			if (mode == 3U) {
				if (found != NULL) {
					status = 1;
					goto cleanup;
				}
			} else if (found == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* The preserved prefix remains alive until the caller explicitly releases its independent output sequence. */
		found = vm_heap_find_cell(page->heap, own_case.addresses[5]);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* Releasing only the live count and caller tracer must actually reclaim both never-stored Symbols. */
		keys.count = 0;
		vm_heap_remove_tracer(page->heap, proxy_key_values_trace, &keys);
		traced = 0;
		vm_heap_collect(page->heap);
		for (index = 4U; index < 6U; index++) {
			if (own_case.addresses[index] == 0U)
				continue;
			found = vm_heap_find_cell(page->heap, own_case.addresses[index]);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}
	}

	/* All complete and abrupt operations preserved key-list ownership and exact append semantics. */
	status = 0;

cleanup:
	/* The observer and caller tracer are synchronous and never become permanent heap owners. */
	memset(&own_case, 0, sizeof(own_case));
	if (traced)
		vm_heap_remove_tracer(page->heap, proxy_key_values_trace, &keys);
	wb_vector_release(&keys);

	/* Retire all temporary input root registrations acquired before independent cases began. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve a failure after releasing temporary setup and vector ownership. */
	if (status != 0)
		return status;

	/* Succeeded: complete lists, rollback, native errno and real participant/Symbol reclamation were all observed. */
	return 0;
}
