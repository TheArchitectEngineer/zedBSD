/*
 * Appends actual own property keys through realm-aware Proxy handling with complete native ownership.
 */
int
vm_own_property_keys(
	struct vm_realm *realm,
	struct vm_object *object,
	struct wb_vector *keys)
{
	struct access_read_roots roots;
	size_t beginning;
	int status;

	/* Caller prefixes and managed input ownership both survive every trap, native callback and error allocation. */
	beginning = keys->count;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	status = vm_heap_add_tracer(realm->heap, access_keys_trace, keys);
	if (status != 0) {
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Bound fallback recursion before any target operation while both input and prefix are rooted. */
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_keys_trace, keys);
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Ordinary objects preserve their existing native policy and key order. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY)
		status = access_proxy_own_keys(realm, (struct vm_proxy *)object, keys);
	else
		status = vm_object_own_keys(realm->heap, object, keys);
	realm->property_depth--;
	if (status != 0)
		keys->count = beginning;
	vm_heap_remove_tracer(realm->heap, access_keys_trace, keys);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: only the completed operation's keys were appended to the preserved prefix. */
	return 0;
}
