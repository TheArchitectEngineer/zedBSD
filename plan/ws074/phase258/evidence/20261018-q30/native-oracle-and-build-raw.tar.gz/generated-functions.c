int vm_value_is_object(vm_value value);
int vm_proxy_create(struct vm_realm *realm, vm_value target, vm_value handler, vm_value *result);
int vm_proxy_revoke(struct vm_realm *realm, vm_value value);
static void object_proxy_trace(struct vm_heap *heap, struct vm_cell *cell);
int vm_get(struct vm_realm *realm, vm_value base, vm_value key, vm_value *result);
int vm_get_receiver(struct vm_realm *realm, vm_value base, vm_value key, vm_value receiver, vm_value *result);
static int access_get_receiver(struct vm_realm *realm, vm_value base, vm_value key, vm_value receiver, vm_value *result);
static int access_proxy_get(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, vm_value receiver, vm_value *result);
static void access_read_trace(struct vm_heap *heap, void *context);
static int realm_create(struct vm_heap *heap, int managed, struct vm_realm **realm);
int main(void);
static int proxy_make(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_revoke(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_get_receiver(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_collect(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_script(struct vm_realm *realm, const char *source, vm_value *answer);
static int proxy_lifetime(struct page *page);
static int proxy_sole_get_own(struct vm_object *object, vm_value key, struct vm_property *property);
static int proxy_gc_edges(struct page *page);

int
vm_value_is_object(
	vm_value value)
{
	struct vm_cell *cell;
	int is_cell;

	/* Numbers and constants are primitives. */
	is_cell = vm_value_is_cell(value);
	if (!is_cell)
		return 0;

	/* The cell types that are objects. */
	cell = vm_value_as_cell(value);
	if (cell->type == &vm_object_type)
		return 1;
	if (cell->type == &vm_array_type)
		return 1;
	if (cell->type == &vm_function_type)
		return 1;
	if (cell->type == &vm_promise_type)
		return 1;
	if (cell->type == &object_proxy_type)
		return 1;

	/* Strings and symbols are primitives. */
	return 0;
}

int
vm_proxy_create(
	struct vm_realm *realm,
	vm_value target,
	vm_value handler,
	vm_value *result)
{
	struct vm_proxy *proxy;
	struct vm_object *object;
	struct vm_cell *roots[4];
	vm_value values[2];
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_object;
	int callable;
	int status;

	/* Protect incoming ownership before either validation errors or allocation can collect. */
	*result = VM_VALUE_UNDEFINED;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	values[0] = target;
	values[1] = handler;
	for (index = 0; index < 2U; index++) {
		roots[index + 1U] = NULL;
		is_cell = vm_value_is_cell(values[index]);
		if (is_cell)
			roots[index + 1U] = vm_value_as_cell(values[index]);
	}

	/* Reserve the unpublished-record root slot before acquiring registrations. */
	roots[3] = NULL;
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Both Proxy protocol participants must be objects. */
	is_object = vm_value_is_object(target);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy target must be an object");
		goto cleanup;
	}

	/* Validate the handler independently before allocating the record. */
	is_object = vm_value_is_object(handler);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy handler must be an object");
		goto cleanup;
	}

	/* This internal stage deliberately excludes operations requiring callable or nested-target semantics. */
	object = (struct vm_object *)vm_value_as_cell(target);
	callable = vm_value_is_callable(target);
	if (callable || object->kind == VM_KIND_PROXY) {
		status = vm_throw_type_error(realm, "Callable and Proxy targets require later Proxy internal methods");
		goto cleanup;
	}

	/* Retain the newborn before ordinary shape initialization can allocate. */
	proxy = vm_heap_alloc(realm->heap, &object_proxy_type, sizeof(*proxy));
	if (proxy == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Initialize every traced payload field before shape initialization can collect. */
	roots[3] = &proxy->object.cell;
	proxy->target = target;
	proxy->handler = handler;
	proxy->object.kind = VM_KIND_PROXY;
	proxy->object.internal = VM_VALUE_UNDEFINED;
	status = vm_object_init(realm->heap, &proxy->object, NULL);
	if (status != 0)
		goto cleanup;

	/* Only a complete native record becomes visible to the caller. */
	*result = vm_value_cell(proxy);

cleanup:
	/* Release only registrations actually acquired before a possible failure. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the caller owns the managed read primitive. */
	return 0;
}

int
vm_proxy_revoke(
	struct vm_realm *realm,
	vm_value value)
{
	struct vm_object *object;
	struct vm_proxy *proxy;
	int is_object;
	int status;

	/* Script values cannot forge a native Proxy record through their prototype. */
	is_object = vm_value_is_object(value);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy revocation requires a native Proxy");
		return status;
	}

	/* Inspect the native kind only after establishing object identity. */
	object = (struct vm_object *)vm_value_as_cell(value);
	if (object->kind != VM_KIND_PROXY) {
		status = vm_throw_type_error(realm, "Proxy revocation requires a native Proxy");
		return status;
	}

	/* Clearing both slots is idempotent and prevents later Get operations from entering the handler. */
	proxy = (struct vm_proxy *)object;
	proxy->target = VM_VALUE_NULL;
	proxy->handler = VM_VALUE_NULL;

	/* Succeeded: no future read can use the retired protocol participants. */
	return 0;
}

static void
object_proxy_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct vm_proxy *proxy;

	/* Revocation clears both protocol fields, allowing their former graphs to be reclaimed. */
	proxy = (struct vm_proxy *)cell;
	vm_object_trace(heap, cell);
	vm_heap_mark_value(heap, proxy->target);
	vm_heap_mark_value(heap, proxy->handler);
}

int
vm_get(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	vm_value *result)
{
	int status;

	/* Ordinary property access uses its base as the initial receiver. */
	status = vm_get_receiver(realm, base, key, base, result);
	if (status != 0)
		return status;

	/* Succeeded: the ordinary receiver convention is preserved. */
	return 0;
}

int
vm_get_receiver(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	vm_value receiver,
	vm_value *result)
{
	struct access_read_roots roots;
	int status;

	/* Count native property recursion independently of interpreter call frames. */
	*result = VM_VALUE_UNDEFINED;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		return status;
	}

	/* This native frame owns one property-operation depth until it returns. */
	realm->property_depth++;

	/* One native tracer retains the complete input graph before a getter can collect. */
	roots.realm = realm;
	roots.base = base;
	roots.key = key;
	roots.receiver = receiver;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0) {
		/* No tracer was acquired, but this attempted property operation still owns one depth count. */
		realm->property_depth--;
		return status;
	}

	/* The original receiver remains rooted through every getter and nested fallback. */
	status = access_get_receiver(realm, base, key, receiver, result);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);

	/* Retire the operation count on both normal and abrupt completion. */
	realm->property_depth--;
	if (status != 0)
		return status;

	/* Succeeded: the result belongs to the completed property access. */
	return 0;
}

static int
access_get_receiver(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	vm_value receiver,
	vm_value *result)
{
	struct vm_property property;
	struct vm_accessor *accessor;
	struct vm_object *holder;
	int is_object;
	int is_string;
	int found;
	int status;

	/* undefined and null have no properties. */
	*result = VM_VALUE_UNDEFINED;
	if (base == VM_VALUE_UNDEFINED || base == VM_VALUE_NULL) {
		status = access_base_error(realm, base, key, "read", "reading");
		return status;
	}

	/* A string's own length and characters. */
	is_string = vm_value_is_string(base);
	if (is_string) {
		status = access_string_property(realm, (struct vm_string *)vm_value_as_cell(base), key, result, &found);
		if (status != 0)
			return status;
		if (found)
			return 0;
	}

	/* An object's chain, or a primitive's prototype's (the realm has none before its built-ins). */
	is_object = vm_value_is_object(base);
	holder = NULL;
	if (is_object) {
		holder = (struct vm_object *)vm_value_as_cell(base);
	} else {
		holder = access_primitive_prototype(realm, base);
	}

	/* Nothing to look in. */
	if (holder == NULL)
		return 0;

	/* Walk ordinary descriptors until a realm-aware Proxy needs its actual Get operation. */
	found = 0;
	while (holder != NULL) {
		if (holder->kind == VM_KIND_PROXY) {
			status = access_proxy_get(realm, (struct vm_proxy *)holder, key, receiver, result);
			if (status != 0)
				return status;

			/* Succeeded: a Proxy owns the rest of the property lookup. */
			return 0;
		}

		/* Native ordinary descriptors cannot execute user script. */
		found = vm_object_get_own(holder, key, &property);
		if (found < 0)
			return -found;
		if (found)
			break;
		holder = holder->prototype;
	}

	/* A missing descriptor follows the absence path after errors have been excluded. */
	if (!found)
		return 0;

	/* A data property's value. */
	if ((property.attributes & VM_PROPERTY_ACCESSOR) == 0U) {
		*result = *property.value;
		return 0;
	}

	/* An accessor's getter, called with the original receiver as this (no getter reads undefined). */
	accessor = (struct vm_accessor *)vm_value_as_cell(*property.value);
	if (accessor->getter == VM_VALUE_UNDEFINED)
		return 0;
	status = vm_call(realm, accessor->getter, receiver, NULL, 0, result);
	if (status != 0)
		return status;

	/* Succeeded: the getter's result. */
	return 0;
}

static int
access_proxy_get(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	vm_value receiver,
	vm_value *result)
{
	struct vm_cell *roots[8];
	struct vm_descriptor descriptor;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value trap_key;
	vm_value args[3];
	vm_value produced;
	vm_value method_key;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_symbol;
	int found;
	int equal;
	int status;

	/* Snapshot target and handler before any script can revoke the Proxy. */
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(receiver);
	if (is_cell)
		roots[4] = vm_value_as_cell(receiver);
	roots[5] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[5] = vm_value_as_cell(key);
	roots[6] = NULL;
	roots[7] = NULL;
	registered = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked Proxy fails before consulting the handler. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot get a property of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod accepts null as absence and rejects other noncallable traps. */
	method_key = vm_key_from_ascii(realm->heap, "get");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Resolve the current get trap through ordinary method lookup. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_get_receiver(realm, target, key, receiver, result);
		goto cleanup;
	}

	/* A trap getter may have returned a function retained only by this native frame. */
	roots[6] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[5] = &string->cell;
	}

	/* A property trap receives the actual target, a string or symbol key, and the original receiver. */
	args[0] = target;
	args[1] = trap_key;
	args[2] = receiver;
	status = vm_call(realm, method, handler, args, 3, &produced);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(produced);
	if (is_cell)
		roots[7] = vm_value_as_cell(produced);

	/* Invariants use the original target even if the trap revoked its Proxy. */
	found = vm_get_own_descriptor((struct vm_object *)vm_value_as_cell(target), key, &descriptor);
	if (found < 0) {
		status = -found;
		goto cleanup;
	}

	/* Nonconfigurable own descriptors constrain the value a trap may report. */
	if (found && (descriptor.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		if ((descriptor.has & VM_HAS_VALUE) != 0U && (descriptor.attributes & VM_PROPERTY_WRITABLE) == 0U) {
			equal = vm_same_value(produced, descriptor.value);
			if (!equal) {
				status = vm_throw_type_error(realm, "Proxy get trap changed a fixed data property");
				goto cleanup;
			}
		}

		/* A fixed accessor without a getter can expose only undefined. */
		if ((descriptor.has & VM_HAS_GET) != 0U &&
		    descriptor.getter == VM_VALUE_UNDEFINED &&
		    produced != VM_VALUE_UNDEFINED) {
			status = vm_throw_type_error(realm, "Proxy get trap supplied a value for a fixed getterless property");
			goto cleanup;
		}
	}

	/* Publish the trap result only after every fixed-property invariant succeeds. */
	*result = produced;
	status = 0;

cleanup:
	/* Keep no registrations referring to expired C stack slots. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the original receiver's read produced the validated value. */
	return 0;
}

static void
access_read_trace(
	struct vm_heap *heap,
	void *context)
{
	struct access_read_roots *roots;

	/* Managed realms need the same explicit ownership as the input and receiver values. */
	roots = context;
	if (roots->realm->managed)
		vm_heap_mark(heap, &roots->realm->cell);
	vm_heap_mark_value(heap, roots->base);
	vm_heap_mark_value(heap, roots->key);
	vm_heap_mark_value(heap, roots->receiver);
}

static int
realm_create(
	struct vm_heap *heap,
	int managed,
	struct vm_realm **realm)
{
	struct vm_realm *made;
	int error;

	/* Managed pointers must already denote cells during intrinsic creation. */
	*realm = NULL;
	if (managed) {
		made = vm_heap_alloc(heap, &realm_type, sizeof(*made));
	} else {
		made = calloc(1, sizeof(*made));
	}

	/* No state has been published if the realm record could not be made. */
	if (made == NULL)
		return ENOMEM;

	/* Initializes state that both partial and final cleanup can release. */
	made->heap = heap;
	made->managed = managed;
	made->exception = VM_VALUE_UNDEFINED;
	made->throw_value = VM_VALUE_UNDEFINED;
	made->throw_source = VM_VALUE_UNDEFINED;
	made->callee = VM_VALUE_UNDEFINED;
	made->new_target = VM_VALUE_UNDEFINED;

	/* No realm-aware property operation is active before the realm is published. */
	made->property_depth = 0;

	/* Initialize ordinary job ownership before the realm can execute script. */
	wb_vector_init(&made->jobs, sizeof(struct vm_job));
	wb_vector_init(&made->rejections, sizeof(vm_value));

	/* Reserves the non-moving stack before any execution or tracing. */
	made->stack = calloc(REALM_STACK_SLOTS, sizeof(vm_value));
	if (made->stack == NULL) {
		if (!managed)
			free(made);
		return ENOMEM;
	}

	/* A manual realm needs a root; a managed realm is reached as a cell. */
	made->stack_capacity = REALM_STACK_SLOTS;
	if (!managed) {
		error = vm_heap_add_tracer(heap, realm_trace, made);
		if (error != 0) {
			realm_release(made);
			free(made);
			return error;
		}
	}

	/* Creates the existing globals and intrinsic skeleton in this realm. */
	error = realm_fill(made);
	if (error != 0) {
		if (managed) {
			realm_release(made);
		} else {
			vm_realm_destroy(made);
		}

		/* No partially initialized realm is published to the caller. */
		return error;
	}

	/* Saved globals and bare prototype objects retain their child's lifetime. */
	if (managed) {
		made->global->internal = vm_value_cell(made);
		made->object_prototype->internal = vm_value_cell(made);
	}

	/* Succeeded: the caller receives a fully initialized realm. */
	*realm = made;
	return 0;
}

int
main(
	void)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read("plan/ws074/tests/proxy-read.js", &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_make(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	int status;

	UNUSED_PARAMETER(receiver);

	/* Product validation handles missing or primitive arguments. */
	status = vm_proxy_create(realm, js_argument(args, count, 0), js_argument(args, count, 1), result);
	if (status != 0)
		return status;

	/* Succeeded: a genuine managed VM Proxy reaches the fixture. */
	return 0;
}

static int
proxy_revoke(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	int status;

	UNUSED_PARAMETER(receiver);

	/* No script-visible reference supplied by the fixture substitutes for native revocation. */
	status = vm_proxy_revoke(realm, js_argument(args, count, 0));
	if (status != 0)
		return status;
	*result = VM_VALUE_UNDEFINED;

	/* Succeeded: future reads observe the native revoked slots. */
	return 0;
}

static int
proxy_get_receiver(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value key;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Convert the public fixture argument with the real language property-key conversion. */
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	if (status != 0)
		return status;
	status = vm_get_receiver(realm, js_argument(args, count, 0), key, js_argument(args, count, 2), result);
	if (status != 0)
		return status;

	/* Succeeded: the supplied receiver survived the actual native property algorithm. */
	return 0;
}

static int
proxy_collect(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Conservative C stack retention is disabled by main during these operations. */
	vm_heap_collect(realm->heap);
	*result = VM_VALUE_UNDEFINED;

	/* Succeeded: real user code resumes after the actual collection. */
	return 0;
}

static int
proxy_script(
	struct vm_realm *realm,
	const char *source,
	vm_value *answer)
{
	struct wb_units units;
	struct js_syntax_error syntax;
	int status;

	/* Fixture strings become ordinary UTF-16 source without product API emulation. */
	wb_units_init(&units);
	status = wb_utf8_to_units((const unsigned char *)source, strlen(source), &units);
	if (status != 0) {
		wb_units_release(&units);
		return status;
	}

	/* Execute ordinary source before releasing its temporary UTF-16 storage. */
	status = js_run_script(realm, units.data, units.length, 0, answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		return status;

	/* Succeeded: the VM returned the actual probe completion value. */
	return 0;
}

static int
proxy_lifetime(
	struct page *page)
{
	struct vm_proxy *proxy;
	struct vm_cell *root;
	struct vm_cell *found;
	vm_value answer;
	uintptr_t target_address;
	uintptr_t handler_address;
	uintptr_t proxy_address;
	int status;
	int retained;
	int released;

	/* Only the Proxy should retain these otherwise anonymous protocol participants. */
	status = proxy_script(page->realm, "makeReadProxy({owned:1},{})", &answer);
	if (status != 0)
		return status;
	proxy = (struct vm_proxy *)vm_value_as_cell(answer);
	root = &proxy->object.cell;
	target_address = (uintptr_t)vm_value_as_cell(proxy->target);
	handler_address = (uintptr_t)vm_value_as_cell(proxy->handler);
	proxy_address = (uintptr_t)root;
	status = vm_heap_add_root(page->heap, &root);
	if (status != 0)
		return status;

	/* A retained Proxy must trace both participants without accidental C-stack support. */
	vm_heap_collect(page->heap);
	retained = 0;
	found = vm_heap_find_cell(page->heap, target_address);
	if (found != NULL) {
		found = vm_heap_find_cell(page->heap, handler_address);
		if (found != NULL)
			retained = 1;
	}

	/* Revocation releases both protocol fields while the Proxy itself remains rooted. */
	status = vm_proxy_revoke(page->realm, vm_value_cell(proxy));
	if (status != 0) {
		vm_heap_remove_root(page->heap, &root);
		return status;
	}

	/* Observe the retired participant graph while the Proxy itself remains rooted. */
	vm_heap_collect(page->heap);
	released = 0;
	found = vm_heap_find_cell(page->heap, target_address);
	if (found == NULL) {
		found = vm_heap_find_cell(page->heap, handler_address);
		if (found == NULL)
			released = 1;
	}

	/* Releasing the last Proxy root must also make its own storage collectible. */
	vm_heap_remove_root(page->heap, &root);
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, proxy_address);
	if (found != NULL)
		return 1;
	if (!retained || !released)
		return 1;
	if (page->realm->property_depth != 0U)
		return 1;

	/* Succeeded: the managed Proxy, participants and recursion ownership all retired correctly. */
	return 0;
}

static int
proxy_sole_get_own(
	struct vm_object *object,
	vm_value key,
	struct vm_property *property)
{
	struct vm_cell *found;
	int result;

	/* The managed realm and trap result must survive through real native property policy. */
	vm_heap_collect(sole_heap);
	found = vm_heap_find_cell(sole_heap, sole_realm_address);
	if (found != NULL)
		sole_realm_alive++;
	result = vm_object_get_own_ordinary(object, key, property);

	/* Preserve a native policy failure without changing its negative-errno convention. */
	if (result < 0)
		return result;

	/* Succeeded: report the ordinary descriptor's missing or found classification. */
	return result;
}

static int
proxy_gc_edges(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[5];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value answer;
	vm_value made;
	vm_value key;
	vm_value get_key;
	uintptr_t realm_address;
	unsigned index;
	unsigned registered;
	int status;
	int same;

	/* Setup ownership is retired deliberately before each product operation takes responsibility. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The temporary managed realm has no embedding Document or explicit lifetime. */
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	realm_address = (uintptr_t)realm;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated target while allocating the remaining protocol participants. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated handler until the private factory takes ownership. */
	roots[2] = &handler->cell;

	/* Intern keys before obtaining a transient function returned only to this native frame. */
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Intern the trap key before creating a transient method function. */
	get_key = vm_key_from_ascii(page->heap, "get");
	if (get_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Create the ordinary configurable descriptor used by the post-trap invariant read. */
	status = vm_object_define(page->heap, target, key, VM_VALUE_UNDEFINED, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = proxy_script(page->realm, "(function(){return {sole:74};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, get_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Genuine allocation pressure makes the private factory retain all otherwise unrooted inputs. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Drop every setup owner before the factory must survive threshold collection. */
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &made);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(made);
	vm_heap_stats(page->heap, &after);
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* This native descriptor hook may collect but never executes script, preserving the production hook contract. */
	target->native_operations = &proxy_sole_operations;
	sole_heap = page->heap;
	sole_realm_address = realm_address;
	sole_realm_alive = 0;
	status = vm_get_receiver(realm, made, key, VM_VALUE_NULL, &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	key = vm_key_from_ascii(page->heap, "sole");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read the actual sole-result payload after the native policy collection. */
	status = vm_get(page->realm, answer, key, &answer);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(answer, vm_value_int32(74));
	if (!same ||
	    sole_realm_alive != 1U ||
	    realm->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* No surviving protocol participant references the temporary realm once the native Get frame ends. */
	roots[3] = NULL;
	roots[4] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Record the successful native ownership observations before releasing setup roots. */
	status = 0;

cleanup:
	/* Fixture observations are not collector roots and never survive the independent case. */
	sole_heap = NULL;
	sole_realm_address = 0;
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: allocation, native descriptor collection and later realm reclamation all used real ownership. */
	return 0;
}
