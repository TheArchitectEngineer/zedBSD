from pathlib import Path
import subprocess,re,json,hashlib
q=Path('build/ws074-20261018/q40');base='c84e12f08';checks={}
def strip(s):return re.sub(r'\s+','',re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S))
for f,names in {'vm/access.c':['vm_is_extensible','vm_prevent_extensions','access_extensibility','access_proxy_extensibility'],'js/builtin_object.c':['object_is_extensible','object_prevent_extensions']}.items():
 p=Path('userland/desktop/libbrowser',f);old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);new=p.read_text()
 for name in names:
  pat=r'(?:static )?(?:int|void)\n'+name+r'\(\n.*?\n\}';new=re.sub(pat,'',new,flags=re.S);old=re.sub(pat,'',old,flags=re.S)
  pat=r'^static int '+name+r'\([^\n]*;\n';new=re.sub(pat,'',new,flags=re.M);old=re.sub(pat,'',old,flags=re.M)
 assert strip(old)==strip(new),f
 checks[f]='all tokens outside selected functions/declarations unchanged'
p=Path('userland/desktop/libbrowser/vm/vm.h');old=subprocess.check_output(['git','show',base+':'+str(p)],text=True);new=p.read_text();without=re.sub(r'^int vm_(?:is_extensible|prevent_extensions)\([^\n]*;\n','',new,flags=re.M);assert strip(old)==strip(without)
pattern=r'/\*\n \* Optional native property policy.*?\n\};';assert re.search(pattern,old,re.S).group()==re.search(pattern,new,re.S).group()
raw=(q/'style-raw.log').read_text().splitlines();assert len(raw)==52 and all(': goto: goto cleanup;' in l for l in raw)
oldjs=Path('build/ws074-20261018/q39/final/engine/proxy-read.js').read_bytes();prefix=oldjs.split(b" console.log('read-proxy controls:")[0];assert Path('plan/ws074/tests/proxy-read.js').read_bytes().startswith(prefix)
checks.update(header_tokens_except_two_declarations_unchanged=True,native_operations_definition_comment_bytes_unchanged=True,old336_source_prefix_unchanged=True,added_conditions=36,full_changed_functions=json.loads((q/'function-review-scope.json').read_text()),raw_allowed_cleanup=52,other_checker_flags=0,manual_review=['ANSI declaration order, meaningful paragraphs, public-before-static, table-required prototypes retained','realm/input traced before depth errors; target/handler/fresh method explicit roots; all exits retire roots/depth','Prevent false skips post-trap target observation; target extensibility uses realm-aware API after trap','ordinary pure native callback retained, no script inside callbacks; refusal and errno kept','private factory bounds/global/public ABI2/Wayland unchanged','other Proxy invariant sampling and Object integrity methods left pending','source management references removed, technical ownership comments retained'])
(q/'source-audit.json').write_text(json.dumps(checks,indent=2)+'\n');print('boundary/source-prefix/native contract/52 allowed cleanup,other0')
