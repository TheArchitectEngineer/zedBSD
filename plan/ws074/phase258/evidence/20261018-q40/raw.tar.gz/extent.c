/*
 * Reports actual extensibility through ordinary policy or native Proxy internal methods.
 */
int
vm_is_extensible(
	struct vm_realm *realm,
	struct vm_object *object,
	int *extensible)
{
	int status;

	/* The shared realm frame owns both input lifetime and the finite native operation depth. */
	status = access_extensibility(realm, object, 0, extensible);
	if (status != 0)
		return status;

	/* Succeeded: the completed operation supplied the target's actual extensibility. */
	return 0;
}

/*
 * Prevents extensions through realm-aware Proxy handling and the existing pure native policy.
 */
int
vm_prevent_extensions(
	struct vm_realm *realm,
	struct vm_object *object,
	int *done)
{
	int status;

	/* Refusal and abrupt completion remain separate from the operation's Boolean success. */
	status = access_extensibility(realm, object, 1, done);
	if (status != 0)
		return status;

	/* Succeeded: done reports whether the target accepted preventing extensions. */
	return 0;
}
