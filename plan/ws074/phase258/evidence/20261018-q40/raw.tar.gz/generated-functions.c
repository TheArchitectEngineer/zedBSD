int vm_is_extensible(struct vm_realm *realm, struct vm_object *object, int *extensible);
int vm_prevent_extensions(struct vm_realm *realm, struct vm_object *object, int *done);
static int access_extensibility(struct vm_realm *realm, struct vm_object *object, int prevent, int *result);
static int access_proxy_extensibility(struct vm_realm *realm, struct vm_proxy *proxy, int prevent, int *result);
static int object_is_extensible(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_prevent_extensions(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
int main(int argc, char **argv);
static int extent_collect_prevent(struct vm_object *object, int *allowed);
static int extent_pressure(struct page *page);

int
vm_is_extensible(
	struct vm_realm *realm,
	struct vm_object *object,
	int *extensible)
{
	int status;

	/* The shared realm frame owns both input lifetime and the finite native operation depth. */
	status = access_extensibility(realm, object, 0, extensible);
	if (status != 0)
		return status;

	/* Succeeded: the completed operation supplied the target's actual extensibility. */
	return 0;
}

int
vm_prevent_extensions(
	struct vm_realm *realm,
	struct vm_object *object,
	int *done)
{
	int status;

	/* Refusal and abrupt completion remain separate from the operation's Boolean success. */
	status = access_extensibility(realm, object, 1, done);
	if (status != 0)
		return status;

	/* Succeeded: done reports whether the target accepted preventing extensions. */
	return 0;
}

static int
access_extensibility(
	struct vm_realm *realm,
	struct vm_object *object,
	int prevent,
	int *result)
{
	struct access_read_roots roots;
	int status;

	/* Even a recursion-limit error may allocate while this frame is the only owner. */
	*result = 0;
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* Every dispatch owns exactly one depth count until its normal or abrupt completion. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_extensibility(realm, (struct vm_proxy *)object, prevent, result);
	} else if (prevent) {
		status = vm_object_prevent_extensions(object, result);
	} else {
		status = 0;
		*result = 1;
		if ((object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
			*result = 0;
	}

	/* Native callbacks never execute script; their collections still require this complete input frame. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: both operation depth and collector ownership have returned to their caller's state. */
	return 0;
}

static int
access_proxy_extensibility(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	int prevent,
	int *result)
{
	struct vm_cell *roots[3];
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value produced;
	const char *name;
	unsigned registered;
	unsigned index;
	int is_cell;
	int truth;
	int target_extensible;
	int status;

	/* Reentrant revocation cannot discard either original protocol participant. */
	target = proxy->target;
	handler = proxy->handler;
	memset(roots, 0, sizeof(roots));
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[0] = vm_value_as_cell(target);
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[1] = vm_value_as_cell(handler);
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Reject revocation before observing the current handler method. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot inspect extensibility of a revoked Proxy");
		goto cleanup;
	}

	/* Both operations use GetMethod, including null fallback and noncallable rejection. */
	name = "isExtensible";
	if (prevent)
		name = "preventExtensions";
	method_key = vm_key_from_ascii(realm->heap, name);
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* GetMethod may execute a getter that revokes the original record or collects its graph. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		if (prevent)
			status = vm_prevent_extensions(realm, (struct vm_object *)vm_value_as_cell(target), result);
		else
			status = vm_is_extensible(realm, (struct vm_object *)vm_value_as_cell(target), result);
		goto cleanup;
	}

	/* The trap can be fresh and otherwise owned only by this native call frame. */
	roots[2] = vm_value_as_cell(method);
	status = vm_call(realm, method, handler, &target, 1, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (prevent && !truth) {
		/* A refused prevention never queries or changes its target after the trap. */
		status = 0;
		goto cleanup;
	}

	/* Extensibility is observed after the trap's changes, using the target's actual internal method. */
	status = vm_is_extensible(realm, (struct vm_object *)vm_value_as_cell(target), &target_extensible);
	if (status != 0)
		goto cleanup;
	if (prevent) {
		if (target_extensible) {
			status = vm_throw_type_error(realm, "Proxy preventExtensions trap left its target extensible");
			goto cleanup;
		}
	} else if (truth != target_extensible) {
		status = vm_throw_type_error(realm, "Proxy isExtensible trap disagreed with its target");
		goto cleanup;
	}

	/* Only a completed invariant check publishes the trap's Boolean result. */
	*result = truth;
	status = 0;

cleanup:
	/* Release only acquired root registrations on every fallback, trap and error path. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original abrupt outcome after retiring snapshots and fresh method ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the result belongs to the completed extensibility operation. */
	return 0;
}

static int
object_is_extensible(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *object;
	vm_value value;
	int is_object;
	int extensible;
	int status;

	UNUSED_PARAMETER(this_value);

	/* A primitive is not. */
	value = js_argument(args, count, 0);
	*result = VM_VALUE_FALSE;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* Proxy traps and ordinary policy report actual extensibility in the current realm. */
	object = (struct vm_object *)vm_value_as_cell(value);
	status = vm_is_extensible(realm, object, &extensible);
	if (status != 0)
		return status;

	/* Succeeded: publish only the completed operation's Boolean. */
	*result = vm_value_boolean(extensible);
	return 0;
}

static int
object_prevent_extensions(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *object;
	vm_value value;
	int is_object;
	int done;
	int status;

	UNUSED_PARAMETER(this_value);

	/* A primitive is returned as it is. */
	value = js_argument(args, count, 0);
	*result = value;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* Native policy must permit the transition before any extensibility state changes. */
	object = (struct vm_object *)vm_value_as_cell(value);
	status = vm_prevent_extensions(realm, object, &done);
	if (status != 0)
		return status;

	/* Object.preventExtensions throws when a native object refuses the transition. */
	if (!done) {
		status = vm_throw_type_error(realm, "The object refuses preventing extensions.");
		return status;
	}

	/* Succeeded: the object now refuses every new own property. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
extent_collect_prevent(
	struct vm_object *object,
	int *allowed)
{
	struct vm_cell *found;
	unsigned index;

	/* This callback never executes script, even though it invokes the real collector. */
	UNUSED_PARAMETER(object);
	vm_heap_collect(extent_case.heap);
	for (index = 0; index < 4U; index++) {
		found = vm_heap_find_cell(extent_case.heap, extent_case.addresses[index]);
		if (found == NULL)
			return EFAULT;
	}

	/* Count only collections that found every otherwise unowned participant alive. */
	extent_case.collections++;
	*allowed = 0;
	if (extent_case.mode == 2U)
		return EACCES;
	if (extent_case.mode == 0U)
		*allowed = 1;

	/* Succeeded: native refusal and acceptance use the same unchanged Boolean policy contract. */
	return 0;
}

static int
extent_pressure(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[5];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value proxy;
	vm_value getter;
	vm_value key;
	unsigned mode;
	unsigned index;
	unsigned registered;
	int done;
	int status;

	/* A synchronous observation context holds only integer addresses, never collector edges. */
	memset(&extent_case, 0, sizeof(extent_case));
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Independent native acceptance, refusal, errno and script-trap modes must all retire their input graphs. */
	for (mode = 0; mode < 4U; mode++) {
		status = vm_realm_create_managed(page->heap, &realm);
		if (status != 0)
			goto cleanup;
		roots[0] = &realm->cell;
		extent_case.heap = page->heap;
		extent_case.mode = mode;
		extent_case.collections = 0;
		extent_case.addresses[0] = (uintptr_t)realm;
		target = vm_object_create(page->heap, NULL);
		if (target == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Pure native target policy observes the post-getter fallback collection. */
		roots[1] = &target->cell;
		extent_case.addresses[1] = (uintptr_t)target;
		target->native_operations = &extent_collect_operations;
		handler = vm_object_create(page->heap, NULL);
		if (handler == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The handler is retained only by the helper snapshot once its lookup revokes the record. */
		roots[2] = &handler->cell;
		extent_case.addresses[2] = (uintptr_t)handler;
		if (mode == 3U) {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return function(target){collectReadProxy();return Object.isExtensible(target);};})", &getter);
		} else {
			status = proxy_script(page->realm, "(function(){revokeReadProxy(this.owner);collectReadProxy();return undefined;})", &getter);
		}

		/* The getter must be rooted before defining the ordinary handler accessor. */
		if (status != 0)
			goto cleanup;
		roots[3] = vm_value_as_cell(getter);
		if (mode == 3U)
			key = vm_key_from_ascii(page->heap, "isExtensible");
		else
			key = vm_key_from_ascii(page->heap, "preventExtensions");
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Accessor definition uses production descriptor semantics without a scripted fixture object model. */
		status = vm_define_accessor(realm, vm_value_cell(handler), key, getter, 0);
		if (status != 0)
			goto cleanup;
		roots[3] = NULL;
		status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
		if (status != 0)
			goto cleanup;
		roots[4] = vm_value_as_cell(proxy);
		extent_case.addresses[3] = (uintptr_t)roots[4];
		key = vm_key_from_ascii(page->heap, "owner");
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The getter revokes its own Proxy, so target and handler need independent production snapshots. */
		status = vm_object_define(page->heap, handler, key, proxy, VM_PROPERTY_DEFAULT);
		if (status != 0)
			goto cleanup;
		vm_heap_stats(page->heap, &before);
		for (index = 0; index < 5U; index++)
			roots[index] = NULL;
		if (mode == 3U)
			status = vm_is_extensible(realm, (struct vm_object *)vm_value_as_cell(proxy), &done);
		else
			status = vm_prevent_extensions(realm, (struct vm_object *)vm_value_as_cell(proxy), &done);
		vm_heap_stats(page->heap, &after);
		if (mode == 2U) {
			if (status != EACCES) {
				status = 1;
				goto cleanup;
			}

			/* The original native errno is expected and must not become a language exception. */
			status = 0;
		}

		/* Every mode must collect after setup ownership ends and restore the native recursion depth. */
		if (status != 0)
			goto cleanup;
		if (after.collections <= before.collections || realm->property_depth != 0U) {
			status = 1;
			goto cleanup;
		}

		/* A refused native policy remains distinct from actual successful prevention. */
		if (mode == 0U || mode == 3U) {
			if (!done) {
				status = 1;
				goto cleanup;
			}
		} else if (done) {
			status = 1;
			goto cleanup;
		}

		/* Native policy modes require their own collection after the scripted getter has already returned. */
		if (mode != 3U && extent_case.collections != 1U) {
			status = 1;
			goto cleanup;
		}

		/* Observe every participant separately before collecting the completed frame's otherwise unreachable graph. */
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, extent_case.addresses[index]);
			if (found == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* All four participants must actually disappear once their operation snapshots have retired. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 4U; index++) {
			found = vm_heap_find_cell(page->heap, extent_case.addresses[index]);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}
	}

	/* All independent operation outcomes preserved lifetime and native policy semantics. */
	status = 0;

cleanup:
	/* Observation state is synchronous and must not outlive this one fixture call. */
	memset(&extent_case, 0, sizeof(extent_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve any failure after retiring every temporary registration. */
	if (status != 0)
		return status;

	/* Succeeded: both native and scripted extensibility operations retained and then released their full graph. */
	return 0;
}
