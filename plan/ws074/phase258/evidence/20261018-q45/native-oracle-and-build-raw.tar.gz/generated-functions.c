static int object_is_prototype_of(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int object_lookup_half(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, int setter, vm_value *result);
int vm_ordinary_has_instance(struct vm_realm *realm, vm_value constructor, vm_value value, vm_value *result);
int main(int argc, char **argv);
static int object_consumers_pressure(struct page *page);
static int ordinary_instance_pressure(struct page *page);

static int
object_is_prototype_of(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[2];
	vm_value value;
	vm_value object;
	vm_value prototype;
	unsigned registered;
	unsigned index;
	int is_object;
	int status;

	/* Primitive arguments return before even a null receiver is coerced. */
	value = js_argument(args, count, 0);
	*result = VM_VALUE_FALSE;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* The target receiver and the current chain link remain owned across every internal-method callback. */
	memset(roots, 0, sizeof(roots));
	roots[1] = vm_value_as_cell(value);
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Receiver boxing happens only after the object argument is retained. */
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		goto cleanup;
	roots[0] = vm_value_as_cell(object);

	/* Each actual prototype method decides the next link, including repeated links with changing traps. */
	while (roots[1] != NULL) {
		status = vm_get_prototype(realm, (struct vm_object *)roots[1], &prototype);
		if (status != 0)
			goto cleanup;
		if (prototype == VM_VALUE_NULL)
			break;

		/* Retain a freshly returned object before any later trap can collect it. */
		roots[1] = vm_value_as_cell(prototype);
		if (prototype == object) {
			*result = VM_VALUE_TRUE;
			break;
		}
	}

	/* A chain ending without a matching prototype is a successful false result. */
	status = 0;

cleanup:
	/* Partial root registration and abrupt prototype methods retire exactly their acquired ownership. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* A trap exception or allocation error remains the operation's status. */
	if (status != 0)
		return status;

	/* Succeeded: the actual prototype chain supplied the Boolean. */
	return 0;
}

static int
object_lookup_half(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	int setter,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *roots[3];
	vm_value object;
	vm_value key;
	vm_value prototype;
	unsigned registered;
	unsigned index;
	int is_cell;
	int found;
	int status;

	/* The converted receiver must exist before the property key is coerced. */
	*result = VM_VALUE_UNDEFINED;
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		return status;

	/* Preserve the boxed receiver, current link and any fresh key throughout descriptor and prototype traps. */
	memset(roots, 0, sizeof(roots));
	roots[0] = vm_value_as_cell(object);
	roots[1] = roots[0];
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Key conversion may run script and return a Symbol with no other remaining owner. */
	status = vm_to_key(realm, js_argument(args, count, 0), &key);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[2] = vm_value_as_cell(key);

	/* The nearest actual own descriptor decides without invoking its accessor or reading another prototype. */
	while (roots[1] != NULL) {
		status = vm_get_own_property(realm, (struct vm_object *)roots[1], key, &descriptor, &found);
		if (status != 0)
			goto cleanup;
		if (found) {
			/* Data properties shadow inherited accessors; complete accessor descriptors contain both halves. */
			if ((descriptor.has & VM_HAS_GET) != 0U) {
				*result = descriptor.getter;
				if (setter)
					*result = descriptor.setter;
			}

			/* No allocation or callback separates the selected descriptor payload from its return. */
			break;
		}

		/* Only descriptor absence follows the actual prototype method. */
		status = vm_get_prototype(realm, (struct vm_object *)roots[1], &prototype);
		if (status != 0)
			goto cleanup;
		if (prototype == VM_VALUE_NULL)
			break;
		roots[1] = vm_value_as_cell(prototype);
	}

	/* Exhaustion and a nearest data descriptor both successfully return undefined. */
	status = 0;

cleanup:
	/* Retire every acquired root even when coercion, own inspection or prototype traversal throws. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original abrupt completion or native errno. */
	if (status != 0)
		return status;

	/* Succeeded: the nearest descriptor supplied the requested half or undefined. */
	return 0;
}

int
vm_ordinary_has_instance(
	struct vm_realm *realm,
	vm_value constructor,
	vm_value value,
	vm_value *result)
{
	struct access_read_roots roots;
	struct vm_cell *prototype_root;
	vm_value key;
	vm_value prototype;
	vm_value link;
	int callable;
	int is_object;
	int status;

	/* Only callable constructors and object values require a prototype lookup. */
	*result = VM_VALUE_FALSE;
	callable = vm_value_is_callable(constructor);
	if (!callable)
		return 0;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* A managed caller, constructor and original value survive key allocation and constructor getters. */
	roots.realm = realm;
	roots.base = constructor;
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = value;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	prototype_root = NULL;
	status = vm_heap_add_root(realm->heap, &prototype_root);
	if (status != 0) {
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* The constructor's prototype is retrieved before any value-side prototype method is called. */
	key = vm_key_from_ascii(realm->heap, "prototype");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Preserve the property key through a getter that may allocate or collect. */
	roots.key = key;
	status = vm_get(realm, constructor, key, &prototype);
	if (status != 0)
		goto cleanup;
	is_object = vm_value_is_object(prototype);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Function has non-object prototype in instanceof check");
		goto cleanup;
	}

	/* The target prototype and the latest returned link remain independently owned through later traps. */
	prototype_root = vm_value_as_cell(prototype);
	while (roots.receiver != VM_VALUE_NULL) {
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(roots.receiver), &link);
		if (status != 0)
			goto cleanup;
		roots.receiver = link;
		if (link == prototype) {
			*result = VM_VALUE_TRUE;
			break;
		}
	}

	/* Reaching null without matching the prototype is a successful false result. */
	status = 0;

cleanup:
	/* Neither abrupt chain traversal nor invalid constructor output may leak native ownership. */
	vm_heap_remove_root(realm->heap, &prototype_root);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the actual internal prototype methods supplied the instance result. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
object_consumers_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *input;
	struct vm_cell *roots[2];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value owner;
	vm_value function;
	vm_value key;
	vm_value argument;
	vm_value receiver;
	vm_value answer;
	const char *name;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int done;
	int status;

	/* No static observation records a managed pointer or supplies a collector edge. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Prototype key boxing, key-list errno and descriptor errno each use actual installed native methods. */
	for (mode = 0; mode < 6U; mode++) {
		memset(&object_consumer_case, 0, sizeof(object_consumer_case));
		object_consumer_case.heap = page->heap;
		status = vm_realm_create_managed(page->heap, &caller);
		if (status != 0)
			goto cleanup;
		roots[0] = &caller->cell;
		object_consumer_case.caller_address = (uintptr_t)caller;
		input = vm_object_create(page->heap, page->realm->object_prototype);
		if (input == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The argument is rooted only until the production VM call accepts ownership. */
		roots[1] = &input->cell;
		object_consumer_case.input_address = (uintptr_t)input;
		if (mode < 2U) {
			status = js_builtin_method(page->realm, input, "toString", 0, consumer_key_primitive);
			if (status != 0)
				goto cleanup;
			owner = vm_value_cell(page->realm->object_prototype);
			name = "hasOwnProperty";
			if (mode == 1U)
				name = "propertyIsEnumerable";
			receiver = vm_value_int32(1);
			argument = vm_value_cell(input);
		} else {
			key = vm_key_from_ascii(page->heap, "x");
			if (key == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}

			/* A real stored property is present before the target becomes nonextensible. */
			status = vm_object_define(page->heap, input, key, VM_VALUE_TRUE, VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
			if (mode == 2U)
				input->native_operations = &consumer_error_keys_operations;
			else
				input->native_operations = &consumer_error_descriptor_operations;
			status = vm_prevent_extensions(page->realm, input, &done);
			if (status != 0)
				goto cleanup;
			if (!done) {
				status = 1;
				goto cleanup;
			}

			/* Integrity functions are fetched from the real installed Object constructor. */
			key = vm_key_from_ascii(page->heap, "Object");
			if (key == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}

			/* The intrinsic constructor already owns these methods; lookup adds no fixture implementation. */
			status = vm_get(page->realm, vm_value_cell(page->realm->global), key, &owner);
			if (status != 0)
				goto cleanup;
			name = "isFrozen";
			if (mode == 3U)
				name = "isSealed";
			receiver = owner;
			argument = vm_value_cell(input);
		}

		/* The legacy accessor consumers must also propagate pure native descriptor errors through real GetOwn. */
		if (mode >= 4U) {
			owner = vm_value_cell(page->realm->object_prototype);
			name = "__lookupGetter__";
			if (mode == 5U)
				name = "__lookupSetter__";
			receiver = vm_value_cell(input);
			argument = vm_key_from_ascii(page->heap, "x");
			if (argument == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}
		}

		/* Direct native invocation still uses vm_call, whose contract retains caller realm, callee and arguments. */
		key = vm_key_from_ascii(page->heap, name);
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The same production function is invoked after every temporary setup root is dropped. */
		status = vm_get(page->realm, owner, key, &function);
		if (status != 0)
			goto cleanup;
		roots[0] = NULL;
		roots[1] = NULL;
		vm_heap_stats(page->heap, &before);
		status = vm_call(caller, function, receiver, &argument, 1, &answer);
		vm_heap_stats(page->heap, &after);
		if (mode >= 2U) {
			if (status != EACCES) {
				status = 1;
				goto cleanup;
			}

			/* Native errors remain status values and never become successful integrity Booleans. */
			status = 0;
		}

		/* Every mode must reach exactly its one genuine native callback and collect during the call. */
		if (status != 0)
			goto cleanup;
		if (object_consumer_case.calls != 1U || after.collections <= before.collections) {
			status = 1;
			goto cleanup;
		}

		/* The two prototype methods report missing Symbol keys after boxing the primitive receiver. */
		if (mode < 2U) {
			if (answer != VM_VALUE_FALSE || after.collections <= object_consumer_case.callback_collections) {
				status = 1;
				goto cleanup;
			}

			/* This Symbol survived a strictly later boxing collection after the callback-local root had retired. */
			found = vm_heap_find_cell(page->heap, object_consumer_case.key_address);
			if (found == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* Managed caller and source argument remain present after their collection-bearing native call. */
		found = vm_heap_find_cell(page->heap, object_consumer_case.caller_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* No returned Boolean or errno may retain the former input object. */
		found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* Completion retires both VM-call ownership and each consumer's native temporary roots. */
		vm_heap_collect(page->heap);
		found = vm_heap_find_cell(page->heap, object_consumer_case.caller_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* The argument is actually reclaimed while only intrinsic methods remain globally owned. */
		found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* Never-stored fresh Symbol keys also become actually reclaimable after the public operation ends. */
		if (mode < 2U) {
			found = vm_heap_find_cell(page->heap, object_consumer_case.key_address);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}
	}

	/* All native and language statuses preserved their proper outcome and ownership conventions. */
	status = 0;

cleanup:
	/* Observation addresses never survive this synchronous native consumer case. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve a failure only after retiring every setup registration. */
	if (status != 0)
		return status;

	/* Succeeded: fresh-key boxing, native errors and all completed input/key reclamations were observed. */
	return 0;
}

static int
ordinary_instance_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_function *constructor;
	struct vm_object *value;
	struct vm_cell *roots[3];
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value answer;
	uintptr_t value_address;
	unsigned registered;
	unsigned index;
	int status;

	/* Setup roots own only construction; the tested API must acquire all lifetime responsibility at entry. */
	memset(roots, 0, sizeof(roots));
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A bare managed realm has no intrinsic or global registry edge that could hide missing API ownership. */
	status = vm_realm_create_managed(page->heap, &caller);
	if (status != 0)
		goto cleanup;
	roots[0] = &caller->cell;
	object_consumer_case.heap = page->heap;
	object_consumer_case.caller_address = (uintptr_t)caller;
	constructor = vm_function_create_native(page->realm, "instance-pressure", 0, proxy_collect);
	if (constructor == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The callable constructor's native descriptor policy collects and returns a genuine negative errno. */
	roots[1] = &constructor->object.cell;
	object_consumer_case.input_address = (uintptr_t)constructor;
	constructor->object.native_operations = &consumer_error_descriptor_operations;
	value = vm_object_create(page->heap, NULL);
	if (value == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* No fixture-owned managed edge remains when the direct native operation begins. */
	roots[2] = &value->cell;
	value_address = (uintptr_t)value;
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_ordinary_has_instance(caller, vm_value_cell(constructor), vm_value_cell(value), &answer);
	vm_heap_stats(page->heap, &after);
	if (status != EACCES) {
		status = EFAULT;
		goto cleanup;
	}

	/* Collection must actually run inside the one constructor-side descriptor observation. */
	if (object_consumer_case.calls != 1U || after.collections <= before.collections) {
		status = EFAULT;
		goto cleanup;
	}

	/* The value was not an argument of any enclosing VM call, yet survived constructor-side collection. */
	found = vm_heap_find_cell(page->heap, value_address);
	if (found == NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* Completion releases every direct-API owner, allowing all three original participants to be reclaimed. */
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, value_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* The managed caller has no hidden intrinsic or test registry ownership. */
	found = vm_heap_find_cell(page->heap, object_consumer_case.caller_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* The discarded callable constructor is independently reclaimed after native error propagation. */
	found = vm_heap_find_cell(page->heap, object_consumer_case.input_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* All direct-call ownership and errno observations held under actual collection. */
	status = 0;

cleanup:
	/* Retire partial setup registrations and weak observations on every result path. */
	memset(&object_consumer_case, 0, sizeof(object_consumer_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve a failed lifetime or native-error observation. */
	if (status != 0)
		return status;

	/* Succeeded: the direct API retained and then released its managed participants. */
	return 0;
}
