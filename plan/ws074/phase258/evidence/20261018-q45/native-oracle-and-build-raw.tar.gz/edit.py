from pathlib import Path
import re,json
q=Path('build/ws074-20261018/q45')
p=Path('userland/desktop/libbrowser/js/builtin_object.c');s=p.read_text()
def replace(name,body):
 global s
 pat=r'static int\n'+name+r'\(\n.*?\n\}'
 s,n=re.subn(pat,body,s,flags=re.S);assert n==1
replace('object_is_prototype_of','''static int
object_is_prototype_of(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *roots[2];
	vm_value value;
	vm_value object;
	vm_value prototype;
	unsigned registered;
	unsigned index;
	int is_object;
	int status;

	/* Primitive arguments return before even a null receiver is coerced. */
	value = js_argument(args, count, 0);
	*result = VM_VALUE_FALSE;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* The target receiver and the current chain link remain owned across every internal-method callback. */
	memset(roots, 0, sizeof(roots));
	roots[1] = vm_value_as_cell(value);
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Receiver boxing happens only after the object argument is retained. */
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		goto cleanup;
	roots[0] = vm_value_as_cell(object);

	/* Each actual prototype method decides the next link, including repeated links with changing traps. */
	while (roots[1] != NULL) {
		status = vm_get_prototype(realm, (struct vm_object *)roots[1], &prototype);
		if (status != 0)
			goto cleanup;
		if (prototype == VM_VALUE_NULL)
			break;

		/* Retain a freshly returned object before any later trap can collect it. */
		roots[1] = vm_value_as_cell(prototype);
		if (prototype == object) {
			*result = VM_VALUE_TRUE;
			break;
		}
	}

	/* A chain ending without a matching prototype is a successful false result. */
	status = 0;

cleanup:
	/* Partial root registration and abrupt prototype methods retire exactly their acquired ownership. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* A trap exception or allocation error remains the operation's status. */
	if (status != 0)
		return status;

	/* Succeeded: the actual prototype chain supplied the Boolean. */
	return 0;
}''')
replace('object_lookup_half','''static int
object_lookup_half(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	int setter,
	vm_value *result)
{
	struct vm_descriptor descriptor;
	struct vm_cell *roots[3];
	vm_value object;
	vm_value key;
	vm_value prototype;
	unsigned registered;
	unsigned index;
	int is_cell;
	int found;
	int status;

	/* The converted receiver must exist before the property key is coerced. */
	*result = VM_VALUE_UNDEFINED;
	status = vm_to_object(realm, this_value, &object);
	if (status != 0)
		return status;

	/* Preserve the boxed receiver, current link and any fresh key throughout descriptor and prototype traps. */
	memset(roots, 0, sizeof(roots));
	roots[0] = vm_value_as_cell(object);
	roots[1] = roots[0];
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Key conversion may run script and return a Symbol with no other remaining owner. */
	status = vm_to_key(realm, js_argument(args, count, 0), &key);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[2] = vm_value_as_cell(key);

	/* The nearest actual own descriptor decides without invoking its accessor or reading another prototype. */
	while (roots[1] != NULL) {
		status = vm_get_own_property(realm, (struct vm_object *)roots[1], key, &descriptor, &found);
		if (status != 0)
			goto cleanup;
		if (found) {
			/* Data properties shadow inherited accessors; complete accessor descriptors contain both halves. */
			if ((descriptor.has & VM_HAS_GET) != 0U) {
				*result = descriptor.getter;
				if (setter)
					*result = descriptor.setter;
			}

			/* No allocation or callback separates the selected descriptor payload from its return. */
			break;
		}

		/* Only descriptor absence follows the actual prototype method. */
		status = vm_get_prototype(realm, (struct vm_object *)roots[1], &prototype);
		if (status != 0)
			goto cleanup;
		if (prototype == VM_VALUE_NULL)
			break;
		roots[1] = vm_value_as_cell(prototype);
	}

	/* Exhaustion and a nearest data descriptor both successfully return undefined. */
	status = 0;

cleanup:
	/* Retire every acquired root even when coercion, own inspection or prototype traversal throws. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve the original abrupt completion or native errno. */
	if (status != 0)
		return status;

	/* Succeeded: the nearest descriptor supplied the requested half or undefined. */
	return 0;
}''')
# Normal helper declaration belongs after every constant table.
pat=r'^static int object_lookup_half\([^\n]*;\n';m=re.search(pat,s,re.M);decl=m.group();s=s[:m.start()]+s[m.end():];pos=s.index('static int object_own_keys(');s=s[:pos]+decl+s[pos:];p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();body='''int
vm_ordinary_has_instance(
	struct vm_realm *realm,
	vm_value constructor,
	vm_value value,
	vm_value *result)
{
	struct access_read_roots roots;
	struct vm_cell *prototype_root;
	vm_value key;
	vm_value prototype;
	vm_value link;
	int callable;
	int is_object;
	int status;

	/* Only callable constructors and object values require a prototype lookup. */
	*result = VM_VALUE_FALSE;
	callable = vm_value_is_callable(constructor);
	if (!callable)
		return 0;
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

	/* A managed caller, constructor and original value survive key allocation and constructor getters. */
	roots.realm = realm;
	roots.base = constructor;
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = value;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	prototype_root = NULL;
	status = vm_heap_add_root(realm->heap, &prototype_root);
	if (status != 0) {
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* The constructor's prototype is retrieved before any value-side prototype method is called. */
	key = vm_key_from_ascii(realm->heap, "prototype");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Preserve the property key through a getter that may allocate or collect. */
	roots.key = key;
	status = vm_get(realm, constructor, key, &prototype);
	if (status != 0)
		goto cleanup;
	is_object = vm_value_is_object(prototype);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Function has non-object prototype in instanceof check");
		goto cleanup;
	}

	/* The target prototype and the latest returned link remain independently owned through later traps. */
	prototype_root = vm_value_as_cell(prototype);
	while (roots.receiver != VM_VALUE_NULL) {
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(roots.receiver), &link);
		if (status != 0)
			goto cleanup;
		roots.receiver = link;
		if (link == prototype) {
			*result = VM_VALUE_TRUE;
			break;
		}
	}

	/* Reaching null without matching the prototype is a successful false result. */
	status = 0;

cleanup:
	/* Neither abrupt chain traversal nor invalid constructor output may leak native ownership. */
	vm_heap_remove_root(realm->heap, &prototype_root);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the actual internal prototype methods supplied the instance result. */
	return 0;
}'''
s,n=re.subn(r'int\nvm_ordinary_has_instance\(\n.*?\n\}',lambda m:body,s,flags=re.S);assert n==1;p.write_text(s)
(q/'function-review-scope.json').write_text(json.dumps({'userland/desktop/libbrowser/js/builtin_object.c':['object_is_prototype_of','object_lookup_half'],'userland/desktop/libbrowser/vm/access.c':['vm_ordinary_has_instance']},indent=2)+'\n')
# The pre-code helper writes console diagnostics on stderr.
p=q/'precode-native-proof.json';d=json.loads(p.read_text());d['failed']=[x for x in (q/'precode-native.err').read_text().splitlines() if ': FAIL' in x];assert len(d['failed'])==21;p.write_text(json.dumps(d,indent=2)+'\n');print('3 product functions; precode21 new failures')
