from pathlib import Path
p=Path('userland/desktop/libbrowser/vm/function.c');s=p.read_text();a=s.index('/* Allocates this using new.target');b=s.index('\n\t\t/* Makes the ordinary',a);old=s[a:b];new='''/* Ordinary construction resolves new.target before entering the callee's execution context. */
		status = vm_construct_prototype(
		    realm,
		    new_target,
		    realm->object_prototype,
		    &prototype);
		if (status != 0)
			goto cleanup;
''';s=s[:a]+new+s[b:];p.write_text(s)
p=Path('plan/ws074/tests/host-proxy-read.c');s=p.read_text();a=s.index('static int\nproxy_foreign_constructor(');b=s.index('\n/* Revoke during GetMethod',a);f=s[a:b];f=f.replace('\tvm_value error;','\tvm_value error;\n\tvm_value ordinary;\n\tint ordinary_requested;');f=f.replace('\tUNUSED_PARAMETER(args);\n\tUNUSED_PARAMETER(count);\n','',1);a1=f.index('\tfunction = vm_function_create_native(foreign');b1=f.index('\n\t/* The function owns',a1);f=f[:a1]+'''	/* An optional control returns a true foreign bytecode function rather than a native constructor. */
 ordinary_requested = 0;
 if (count > 0U)
  ordinary_requested = vm_to_boolean(args[0]);
 if (ordinary_requested) {
  status = proxy_script(foreign, "(function Foreign(){})", &ordinary);
  if (status != 0)
   goto cleanup;
  function = (struct vm_function *)vm_value_as_cell(ordinary);
 } else {
  function = vm_function_create_native(foreign, "Foreign", 0, proxy_foreign_construct);
  if (function == NULL) {
   status = ENOMEM;
   goto cleanup;
  }

  /* Only the native helper uses the explicit native construction callback. */
  function->construct = proxy_foreign_construct;
 }
'''+f[b1:];f=f.replace('\tfunction->construct = proxy_foreign_construct;\n','',1) if f.count('\tfunction->construct = proxy_foreign_construct;')>1 else f
# The old unconditionally assigned construct slot must not alter the bytecode control.
f=f.replace('roots[1] = &function->object.cell;\n\tfunction->construct = proxy_foreign_construct;', 'roots[1] = &function->object.cell;');s=s[:a]+f+s[b:];p.write_text(s)
p=Path('plan/ws074/tests/proxy-read.js');s=p.read_text();i=s.index(" console.log('read-proxy controls:");s=s[:i]+''' check('invoke-foreign-ordinary-revoked-realm-is-caller',function(){var f=makeForeignReadConstructor(true),p=makeReadProxy(f,{get:function(t,k){if(k==='prototype'){revokeReadProxy(p);return 1;}return t[k];}});try{new p();}catch(x){return x instanceof TypeError&&!(x instanceof f.TypeError);}return false;});
 check('invoke-foreign-ordinary-primitive-prototype-fallback',function(){var f=makeForeignReadConstructor(true),p=makeReadProxy(f,{get:function(t,k){if(k==='prototype')return 1;return t[k];}});return Object.getPrototypeOf(new p())===f.prototype;});
'''+s[i:];p.write_text(s)
p=Path('build/ws074-20261018/q53/protocol.py');s=p.read_text();s=s.replace('function makeForeignReadConstructor(){','function makeForeignReadConstructor(ordinary){').replace('var f=w.Function("");f.prototype=w.Object.prototype;', 'var f=ordinary?w.Function(""):w.Function.prototype.bind.call(w.Object,null);Object.defineProperty(f,"prototype",{value:w.Object.prototype,writable:true});');p.write_text(s)
