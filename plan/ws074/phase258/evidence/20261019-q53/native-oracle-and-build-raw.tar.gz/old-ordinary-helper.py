from pathlib import Path
import subprocess,shlex,glob,re,json,hashlib
q=Path('build/ws074-20261018/q53');out=Path('build/ws074-20261018/plain');script=Path('plan/ws074/tests/host-build.sh').read_text();loops=re.findall(r'for file in (.*?); do',script,re.S);assert len(loops)==4;objects=[]
for group,chunk in enumerate(loops[:3]):
 for token in shlex.split(chunk.replace('\\\n',' ')):
  files=sorted(glob.glob(token));assert files,token
  for file in files:
   p=Path(file)
   if group==0:name='truetype-'+p.stem
   elif group==1:name=p.parent.name+'-'+p.stem
   else:name='media-'+p.parent.name+'-'+p.stem
   objects.append(out/'obj'/(name+'.o'))
sources=subprocess.check_output(['sh','plan/ws074/tests/list-sources.sh'],text=True).splitlines()
for file in sources:
 if '/shell/' in file or file.endswith('/main.c'):continue
 name=file.removeprefix('userland/desktop/').removesuffix('.c').replace('/','_');objects.append(out/'obj'/(name+'.o'))
actual=set((out/'obj').glob('*.o'))-{out/'obj/browser_main.o',out/'obj/host-shell.o'};assert set(objects)==actual,{'extra':[str(p) for p in actual-set(objects)],'missing':[str(p) for p in set(objects)-actual]};assert len(objects)==len(set(objects))
flags=shlex.split((out/'flags').read_text());command=flags+['-o',str(out/'host-proxy-read'),'plan/ws074/tests/host-proxy-read.c']+[str(p) for p in objects]+[str(out/'obj/host-shell.o'),'-lvulkan','-lm','-ldl','-lpthread'];(q/'pre-realm-helper-build-command.json').write_text(json.dumps(dict(command=command,object_count=len(objects),object_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in objects},reason='fixture-only counterfactual uses frozen engine objects from c602718f7 before ordinary foreign realm correction; same exact engine list/flags/libraries as host-build.sh'),indent=2)+'\n')
with (q/'host-helper-pre-realm.log').open('w') as f:r=subprocess.run(command,stdout=f,stderr=f,timeout=300)
assert r.returncode==0 and not (q/'host-helper-pre-realm.log').read_bytes();print('selected helper warning0',len(objects),'engine objects unchanged')
