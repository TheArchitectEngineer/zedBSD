from pathlib import Path
q=Path('build/ws074-20261018/q53');old=Path('build/ws074-20261018/q52')
for name in ['target.py','freeze.py','protocol.py','verify-native.py','webidl-probe.py','webidl-validator.py','census.py','audit.py']:
 s=(old/name).read_text().replace('20261018/q52','20261018/q53').replace('ws074-q52-','ws074-q53-')
 if name=='freeze.py':s=s.replace('20261018/q51/final/source-proof','20261018/q52/final/source-proof')
 if name=='audit.py':s=s.replace('20261018/q49','20261018/q52')
 if name=='protocol.py':
  bridge='''function constructReadProxy(t,n){if(arguments.length<2)n=t;return Reflect.construct(t,Array.prototype.slice.call(arguments,2),n);}function makeForeignReadConstructor(){var frame=document.createElement("iframe");document.body.appendChild(frame);var w=frame.contentWindow;var f=w.Function("");f.prototype=w.Object.prototype;f.TypeError=w.TypeError;return f;}'''
  s=s.replace('helper=b\'\'\'','helper=b\'\'\''+bridge,1)
 (q/name).write_text(s)
(q/'native-step-controls.js').write_bytes((old/'native-step-controls.js').read_bytes())
