from pathlib import Path
import re
p=Path('userland/desktop/libbrowser/js/builtin_function.c');s=p.read_text();s=re.sub(r' \(ws074-p\d+\)','',s)
m=re.search(r'static int\nfunction_bind\(\n.*?\n\}',s,re.S);f=m.group();f=f.replace('\tstruct vm_function *target;','\tstruct vm_object *prototype;').replace('\tstruct vm_cell *roots[3];','\tstruct vm_cell *roots[5];').replace('\tvm_value data_array;','\tvm_value data_array;\n\tvm_value prototype_value;');f=f.replace('''	/* The target. */
	target = (struct vm_function *)vm_value_as_cell(this_value);

''','');f=f.replace('\troots[2] = NULL;','\troots[2] = NULL;\n\troots[3] = NULL;\n\troots[4] = NULL;',1).replace('index < 3U','index < 5U',1);pos=f.index('\t/* The bound function:');f=f[:pos]+'''	/* BoundFunctionCreate observes the actual target prototype before length or name properties. */
 status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(this_value), &prototype_value);
 if (status != 0)
  goto cleanup;
 prototype = NULL;
 if (prototype_value != VM_VALUE_NULL) {
  prototype = (struct vm_object *)vm_value_as_cell(prototype_value);
  roots[3] = &prototype->cell;
 }

'''+f[pos:];f=f.replace('\tbound->object.prototype = target->object.prototype;','\tbound->bound_target = this_value;\n\tbound->object.prototype = prototype;');f=f.replace('\tstatus = js_builtin_value(realm, &bound->object, "name", name, VM_PROPERTY_CONFIGURABLE);','\troots[4] = vm_value_as_cell(name);\n\tstatus = js_builtin_value(realm, &bound->object, "name", name, VM_PROPERTY_CONFIGURABLE);',1);s=s[:m.start()]+f+s[m.end():]
m=re.search(r'static int\nfunction_bound_length\(\n.*?\n\}',s,re.S);f=m.group();a=f.index('\tfound = vm_get_own_descriptor');b=f.index('\n\t/* A missing descriptor',a);f=f[:a]+'''	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, &descriptor, &found);
 if (status != 0)
  return status;
'''+f[b:];s=s[:m.start()]+f+s[m.end():]
m=re.search(r'static int\nfunction_to_string\(\n.*?\n\}',s,re.S);f=m.group().replace('\tstruct wb_buffer text;','\tstruct vm_object *object;\n\tstruct wb_buffer text;',1);pos=f.index('\t/* function NAME()');f=f[:pos]+'''	/* A callable Proxy exposes native function syntax without consulting any user-visible property. */
 object = (struct vm_object *)vm_value_as_cell(this_value);
 if (object->kind == VM_KIND_PROXY) {
  status = js_builtin_string(realm, "function () { [native code] }", result);
  if (status != 0)
   return status;

  /* Succeeded: revoked callable Proxies have the same non-observing native form. */
  return 0;
 }

'''+f[pos:];s=s[:m.start()]+f+s[m.end():]
# Only normal helpers move; table initializer method declarations retain their required early position.
decl='static int function_bound_length(struct vm_realm *realm, vm_value target, unsigned bound_count, vm_value *length);\n';assert s.count(decl)==1;s=s.replace(decl,'');pos=s.index('/*\n * Installs Function');s=s[:pos]+decl+'\n'+s[pos:];p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();pos=s.index('static void access_keys_trace(');s=s[:pos]+'static int access_instanceof(struct vm_realm *realm, vm_value value, vm_value constructor, vm_value *result);\n'+s[pos:]
m=re.search(r'int\nvm_instanceof\(\n.*?\n\}',s,re.S);old=m.group();inner=old.replace('int\nvm_instanceof(', 'static int\naccess_instanceof(',1);wrapper='''int
vm_instanceof(
 struct vm_realm *realm,
 vm_value value,
 vm_value constructor,
 vm_value *result)
{
 struct access_read_roots roots;
 int status;

 /* Direct native calls retain both operands and the managed realm before any custom method lookup. */
 *result = VM_VALUE_FALSE;
 roots.realm = realm;
 roots.base = constructor;
 roots.key = VM_VALUE_UNDEFINED;
 roots.receiver = value;
 status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
 if (status != 0)
  return status;

 /* Every constructor getter and custom hasInstance callback remains within this native ownership boundary. */
 status = access_instanceof(realm, value, constructor, result);
 vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
 if (status != 0)
  return status;

 /* Succeeded: the caller receives the complete instance classification. */
 return 0;
}''';s=s[:m.start()]+wrapper+s[m.end():];pos=s.index('/* Tells whether a key is among');s=s[:pos]+'/* Evaluate instanceof while the public wrapper owns both operands across all property methods. */\n'+inner+'\n\n'+s[pos:]
m=re.search(r'int\nvm_ordinary_has_instance\(\n.*?\n\}',s,re.S);f=m.group().replace('\tstruct access_read_roots roots;','\tstruct access_read_roots roots;\n\tstruct vm_cell *constructor_cell;\n\tstruct vm_function *function;',1);f=f.replace('''	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;

''','',1);pos=f.index('\t/* The constructor\'s prototype is retrieved');f=f[:pos]+'''	/* BoundTargetFunction delegation precedes the primitive-value refusal and may use a custom hasInstance. */
 constructor_cell = vm_value_as_cell(constructor);
 if (constructor_cell->type == &vm_function_type) {
  function = (struct vm_function *)constructor_cell;
  if (function->bound_target != VM_VALUE_UNDEFINED) {
   status = vm_instanceof(realm, value, function->bound_target, result);
   goto cleanup;
  }
 }

 /* Only a non-bound callable with an object operand needs a prototype-chain walk. */
 is_object = vm_value_is_object(value);
 if (!is_object) {
  status = 0;
  goto cleanup;
 }

'''+f[pos:];s=s[:m.start()]+f+s[m.end():];p.write_text(s)
