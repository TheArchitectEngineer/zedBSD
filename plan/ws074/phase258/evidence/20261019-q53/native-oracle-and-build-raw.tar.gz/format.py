from pathlib import Path
import subprocess,re,json
q=Path('build/ws074-20261018/q53')
mapping={'userland/desktop/libbrowser/vm/object.c':['vm_proxy_create'],'userland/desktop/libbrowser/vm/function.c':['vm_function_create_native','vm_function_create','vm_value_is_callable','vm_value_is_constructor','vm_call','vm_construct','vm_construct_prototype','function_default_prototype','function_trace','function_proxy_trace','function_proxy_invoke','function_run_native'],'userland/desktop/libbrowser/vm/interpreter.c':['interpreter_call','interpreter_construct'],'userland/desktop/libbrowser/js/builtin_function.c':['function_bind','function_bound_length','function_to_string'],'userland/desktop/libbrowser/vm/access.c':['vm_instanceof','access_instanceof','vm_ordinary_has_instance'],'plan/ws074/tests/host-proxy-read.c':['main','proxy_construct','proxy_foreign_constructor','proxy_foreign_construct','invoke_get_method','invoke_trap','invoke_pressure']}
chunks=[];protos=[]
for file,names in mapping.items():
 p=Path(file);s=p.read_text()
 for name in names:
  m=re.search(r'(?:static )?(?:int|void|double|struct vm_function \*)\n'+name+r'\(\n.*?\n\}',s,re.S);assert m,name
  f=subprocess.check_output(['clang-format-19','--assume-filename='+file,'--style={BasedOnStyle: InheritParentConfig, ColumnLimit: 0}'],input=m.group().encode()).decode().rstrip();i=f.index('{');h=re.match(r'([^\n]+)\n(\w+)\((.*)\)',f[:i].strip(),re.S);assert h,name;f=h[1]+'\n'+h[2]+'(\n'+',\n'.join('\t'+a.strip() for a in h[3].split(','))+')\n'+f[i:]
  for before,after in [
   ('if (function->code != NULL && (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U)', 'if (function->code != NULL &&\n\t    (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U)'),
   ('if (function->code != NULL && (function->code->flags & VM_CODE_CLASS) != 0U)', 'if (function->code != NULL &&\n\t    (function->code->flags & VM_CODE_CLASS) != 0U)'),
   ('if (method != VM_VALUE_UNDEFINED && !ordinary)', 'if (method != VM_VALUE_UNDEFINED &&\n\t\t    !ordinary)'),
   ('if (status != 0 || !done)', 'if (status != 0 ||\n\t    !done)'),
   ('if (invoke_case.gets != 1U || invoke_case.traps != 1U || after.collections < before.collections + 3U)', 'if (invoke_case.gets != 1U ||\n\t\t    invoke_case.traps != 1U ||\n\t\t    after.collections < before.collections + 3U)')]:f=f.replace(before,after)
  for match in list(re.finditer(r'status = interpreter_push\((.*?)\);',f,re.S))[::-1]:
   args=match[1].split(',');call='status = interpreter_push(\n'+',\n'.join('\t\t    '+a.strip() for a in args)+');';f=f[:match.start()]+call+f[match.end():]
  f=re.sub(r'(\n[ \t]*\}\n)(?=[ \t]*(?!else\b|\}|cleanup:)[^\s])',r'\1\n',f)
  s=s[:m.start()]+f+s[m.end():];chunks.append(f);protos.append(re.sub(r'\s+',' ',f[:f.index('{')].strip()).replace('( ','(')+';')
 p.write_text(s)
(q/'generated-functions.c').write_text('\n'.join(protos)+'\n\n'+'\n\n'.join(chunks)+'\n');(q/'function-review-scope.json').write_text(json.dumps(mapping,indent=2)+'\n')
