from pathlib import Path
import re
q=Path('build/ws074-20261018/q53')
# Private immutable Proxy metadata and VM-owned BoundTargetFunction slot.
p=Path('userland/desktop/libbrowser/vm/internal.h');s=p.read_text();s=s.replace('\tvm_value handler;\n};','\tvm_value handler;\n\t/* Creation captures internal call/construct slots even after revocation clears object edges. */\n\tint callable;\n\tint constructor;\n};',1);p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/vm.h');s=p.read_text();needle='\tvm_value source;\n};\n\n/*\n * A realm:';assert needle in s;s=s.replace(needle,'\tvm_value source;\n\t/* VM-owned BoundTargetFunction is undefined for ordinary functions and traced for bound functions. */\n\tvm_value bound_target;\n};\n\n/*\n * A realm:',1);p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/object.c');s=p.read_text();m=re.search(r'int\nvm_proxy_create\(\n.*?\n\}',s,re.S);f=m.group().replace('\tint callable;','\tint callable;\n\tint constructor;',1);a=f.index('\t/* Callable targets require separate');b=f.index('\n\t/* Retain the newborn',a);f=f[:a]+'''\t/* Capture immutable internal call and construct slots before allocation can collect. */
 callable = vm_value_is_callable(target);
 constructor = vm_value_is_constructor(target);
'''+f[b:];f=f.replace('\tproxy->handler = handler;','\tproxy->handler = handler;\n\tproxy->callable = callable;\n\tproxy->constructor = constructor;',1);s=s[:m.start()]+f+s[m.end():];s=s.replace('Creates private managed noncallable Proxy records without publishing a JS constructor.\n * Callable targets require callable internal dispatch and are rejected.','Creates private managed Proxy records with immutable internal call/construct slots.\n * Public constructor installation is independent of this native factory.');p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/function.c');s=p.read_text();(q/'original-function.c').write_text(s);s=s.replace('Functions (plan/ws074/design.md §11.6):','Functions:')
pos=s.index('/* Trace declarations are required');s=s[:pos]+'''/* One Proxy invocation snapshots revocable edges and owns fresh trap methods and argument lists. */
struct function_proxy_roots {
 struct vm_realm *realm;
 vm_value target;
 vm_value handler;
 vm_value method;
 vm_value list;
};

'''+s[pos:];s=s.replace('static struct vm_object *function_default_prototype(struct vm_realm *realm, vm_value target, struct vm_object *fallback);','static int function_default_prototype(struct vm_realm *realm, vm_value target, struct vm_object *fallback, struct vm_object **prototype);\nstatic void function_proxy_trace(struct vm_heap *heap, void *context);\nstatic int function_proxy_invoke(struct vm_realm *realm, vm_value callee, vm_value receiver, const vm_value *args, unsigned count, vm_value new_target, int construct, vm_value *result);')
# Initialize the new traced slot before any object-shape initialization may collect.
s=s.replace('\troots[1] = &function->object.cell;\n\terror = vm_object_init','\troots[1] = &function->object.cell;\n\tfunction->bound_target = VM_VALUE_UNDEFINED;\n\terror = vm_object_init',1)
s=s.replace('\troots[2] = &function->object.cell;\n\terror = vm_object_init','\troots[2] = &function->object.cell;\n\tfunction->bound_target = VM_VALUE_UNDEFINED;\n\terror = vm_object_init',1)
def repl(n,f):
 global s
 m=re.search(r'(?:static )?(?:int|void|struct vm_object \*)\n'+n+r'\(\n.*?\n\}',s,re.S);assert m,n;s=s[:m.start()]+f+s[m.end():]
repl('vm_value_is_callable','''int
vm_value_is_callable(
 vm_value value)
{
 struct vm_cell *cell;
 struct vm_object *object;
 struct vm_proxy *proxy;
 int is_cell;
 int is_object;

 /* Primitive values have no internal Call method. */
 is_cell = vm_value_is_cell(value);
 if (!is_cell)
  return 0;
 cell = vm_value_as_cell(value);
 if (cell->type == &vm_function_type)
  return 1;

 /* A Proxy retains its creation-time Call slot after target and handler revocation. */
 is_object = vm_value_is_object(value);
 if (!is_object)
  return 0;
 object = (struct vm_object *)cell;
 if (object->kind != VM_KIND_PROXY)
  return 0;
 proxy = (struct vm_proxy *)object;

 /* Succeeded: only the immutable native slot determines Proxy callability. */
 return proxy->callable;
}''')
m=re.search(r'int\nvm_value_is_constructor\(\n.*?\n\}',s,re.S);f=m.group().replace('\tstruct vm_function *function;','\tstruct vm_function *function;\n\tstruct vm_object *object;',1);needle='\t/* A code unit that can, or a native constructor. */';pos=f.index(needle);f=f[:pos]+'''\t/* Proxy Construct classification is immutable and never reads a vm_function layout. */
 object = (struct vm_object *)vm_value_as_cell(value);
 if (object->kind == VM_KIND_PROXY)
  return ((struct vm_proxy *)object)->constructor;

'''+f[pos:];s=s[:m.start()]+f+s[m.end():]
m=re.search(r'int\nvm_call\(\n.*?\n\}',s,re.S);f=m.group().replace('\tstruct vm_function *function;','\tstruct vm_function *function;\n\tstruct vm_object *object;',1);pos=f.index('\t/* Rejects a class constructor');f=f[:pos]+'''\t/* An exotic callable uses its own dispatch before any ordinary function fields are inspected. */
 object = (struct vm_object *)vm_value_as_cell(callee);
 if (object->kind == VM_KIND_PROXY) {
  status = function_proxy_invoke(realm, callee, this_value, args, count, VM_VALUE_UNDEFINED, 0, result);
  goto cleanup;
 }

'''+f[pos:];s=s[:m.start()]+f+s[m.end():]
m=re.search(r'int\nvm_construct\(\n.*?\n\}',s,re.S);f=m.group().replace('\tstruct vm_function *function;','\tstruct vm_function *function;\n\tstruct vm_object *object;',1);pos=f.index('\t/* A native constructor creates');f=f[:pos]+'''\t/* An exotic constructor forwards the original new.target through its own Construct method. */
 object = (struct vm_object *)vm_value_as_cell(constructor);
 if (object->kind == VM_KIND_PROXY) {
  status = function_proxy_invoke(realm, constructor, VM_VALUE_UNDEFINED, args, count, new_target, 1, result);
  goto cleanup;
 }

'''+f[pos:];s=s[:m.start()]+f+s[m.end():]
s=s.replace('\t\t*prototype = function_default_prototype(realm, new_target, fallback);','\t\tstatus = function_default_prototype(realm, new_target, fallback, prototype);\n\t\tif (status != 0)\n\t\t\tgoto cleanup;',1)
repl('function_default_prototype','''static int
function_default_prototype(
 struct vm_realm *realm,
 vm_value target,
 struct vm_object *fallback,
 struct vm_object **prototype)
{
 struct vm_cell *cell;
 struct vm_object *object;
 struct vm_proxy *proxy;
 struct vm_function *function;
 struct vm_realm *target_realm;
 unsigned index;
 int callable;
 int status;

 /* Host-provided nonfunctions retain the explicit default chosen by their caller. */
 *prototype = fallback;
 callable = vm_value_is_callable(target);
 if (!callable)
  return 0;

 /* GetFunctionRealm follows immutable Proxy and bound targets without interpreting JS private data. */
 for (;;) {
  cell = vm_value_as_cell(target);
  object = (struct vm_object *)cell;
  if (object->kind == VM_KIND_PROXY) {
   proxy = (struct vm_proxy *)object;
   if (proxy->handler == VM_VALUE_NULL) {
    status = vm_throw_type_error(realm, "Cannot obtain realm of a revoked Proxy");
    if (status != 0)
     return status;

    /* Succeeded: the VM accepted the revocation exception report. */
    return 0;
   }

   /* The target chain cannot change through user-visible assignments. */
   target = proxy->target;
   continue;
  }

  /* Every remaining callable belongs to the actual ordinary function cell layout. */
  function = (struct vm_function *)cell;
  if (function->bound_target != VM_VALUE_UNDEFINED) {
   target = function->bound_target;
   continue;
  }
  break;
 }

 /* The common same-realm case requires no intrinsic translation. */
 target_realm = function->realm;
 if (target_realm == realm)
  return 0;

 /* Translate foundational prototypes stored outside the intrinsic registry. */
 if (fallback == realm->object_prototype) {
  *prototype = target_realm->object_prototype;
  return 0;
 }
 if (fallback == realm->function_prototype) {
  *prototype = target_realm->function_prototype;
  return 0;
 }
 if (fallback == realm->array_prototype) {
  *prototype = target_realm->array_prototype;
  return 0;
 }

 /* Each registered default intrinsic retains its logical identity in the target realm. */
 for (index = 0; index < VM_INTRINSICS; index++) {
  if (realm->intrinsics[index] == NULL)
   continue;
  if (fallback == realm->intrinsics[index]) {
   *prototype = target_realm->intrinsics[index];
   return 0;
  }
 }

 /* Succeeded: a host-specific fallback remains the explicitly supplied object. */
 return 0;
}''')
s=s.replace('\tvm_heap_mark_value(heap, function->data);','\tvm_heap_mark_value(heap, function->data);\n\n\t/* BoundTargetFunction is a VM-owned immutable slot used independently of native call data. */\n\tvm_heap_mark_value(heap, function->bound_target);',1)
pos=s.index('/* Resolves a default intrinsic')
s=s[:pos]+'''/* Retain snapshotted protocol participants and unpublished callback inputs across reentrant code. */
static void
function_proxy_trace(
 struct vm_heap *heap,
 void *context)
{
 struct function_proxy_roots *roots;

 /* Only initialized tagged fields and a collectible caller realm enter this native ownership frame. */
 roots = context;
 if (roots->realm->managed)
  vm_heap_mark(heap, &roots->realm->cell);
 vm_heap_mark_value(heap, roots->target);
 vm_heap_mark_value(heap, roots->handler);
 vm_heap_mark_value(heap, roots->method);
 vm_heap_mark_value(heap, roots->list);
}

/* Invoke Proxy Call or Construct using actual traps and the original argument and new.target values. */
static int
function_proxy_invoke(
 struct vm_realm *realm,
 vm_value callee,
 vm_value receiver,
 const vm_value *args,
 unsigned count,
 vm_value new_target,
 int construct,
 vm_value *result)
{
 struct function_proxy_roots roots;
 struct vm_proxy *proxy;
 struct vm_object *object;
 struct vm_object *list;
 vm_value key;
 vm_value index_key;
 vm_value trap_args[3];
 unsigned index;
 int is_object;
 int status;

 /* The outer dispatcher owns direct arguments while this frame owns revocable snapshots and fresh VM results. */
 roots.realm = realm;
 roots.target = callee;
 roots.handler = VM_VALUE_UNDEFINED;
 roots.method = VM_VALUE_UNDEFINED;
 roots.list = VM_VALUE_UNDEFINED;
 status = vm_heap_add_tracer(realm->heap, function_proxy_trace, &roots);
 if (status != 0)
  return status;

 /* A missing trap can follow nested immutable Proxy targets without consuming another C recursion frame. */
 for (;;) {
  proxy = (struct vm_proxy *)vm_value_as_cell(roots.target);
  if (proxy->handler == VM_VALUE_NULL) {
   status = vm_throw_type_error(realm, "Cannot invoke a revoked Proxy");
   goto cleanup;
  }

  /* Snapshot both original edges before GetMethod can revoke the record or collect its previous target. */
  roots.handler = proxy->handler;
  roots.target = proxy->target;
  key = vm_key_from_ascii(realm->heap, construct ? "construct" : "apply");
  if (key == VM_VALUE_EMPTY) {
   status = ENOMEM;
   goto cleanup;
  }

  /* A nullish method falls back; every other value must be callable before any argument Array is allocated. */
  status = vm_get_method(realm, roots.handler, key, &roots.method);
  if (status != 0)
   goto cleanup;
  if (roots.method == VM_VALUE_UNDEFINED) {
   object = (struct vm_object *)vm_value_as_cell(roots.target);
   if (object->kind == VM_KIND_PROXY)
    continue;

   /* Forward exactly the original receiver or new.target to the final target operation. */
   if (construct) {
    status = vm_construct(realm, roots.target, args, count, new_target, result);
   } else {
    status = vm_call(realm, roots.target, receiver, args, count, result);
   }
   goto cleanup;
  }

  /* A real trap receives a newly allocated dense Array owned before the first element definition. */
  list = vm_array_create(realm->heap, realm->array_prototype);
  if (list == NULL) {
   status = ENOMEM;
   goto cleanup;
  }
  roots.list = vm_value_cell(list);

  /* Own default data properties cannot invoke inherited Array prototype setters. */
  for (index = 0; index < count; index++) {
   index_key = vm_value_int32((int32_t)index);
   status = vm_object_define(realm->heap, list, index_key, args[index], VM_PROPERTY_DEFAULT);
   if (status != 0)
    goto cleanup;
  }

  /* Apply and Construct share handler this but have distinct specified argument positions. */
  trap_args[0] = roots.target;
  if (construct) {
   trap_args[1] = roots.list;
   trap_args[2] = new_target;
  } else {
   trap_args[1] = receiver;
   trap_args[2] = roots.list;
  }
  status = vm_call(realm, roots.method, roots.handler, trap_args, 3, result);
  if (status != 0)
   goto cleanup;
  if (construct) {
   is_object = vm_value_is_object(*result);
   if (!is_object) {
    /* An unused primitive result need not survive the TypeError allocation. */
    *result = VM_VALUE_UNDEFINED;
    status = vm_throw_type_error(realm, "Proxy construct trap must return an object");
    goto cleanup;
   }
  }

  /* A successful trap result needs no later allocation before returning to the original caller. */
  goto cleanup;
 }

 /* Retire snapshots only after target or trap execution and all refusal reporting have finished. */
cleanup:
 vm_heap_remove_tracer(realm->heap, function_proxy_trace, &roots);
 if (status != 0)
  return status;

 /* Succeeded: the original caller receives the complete Call or Construct result. */
 return 0;
}

'''+s[pos:];p.write_text(s)
# Bytecode dispatch must branch before ordinary-function field reads.
p=Path('userland/desktop/libbrowser/vm/interpreter.c');s=p.read_text();s=s.replace('The interpreter (plan/ws074/design.md §11.5, §11.6):','The interpreter:');s=re.sub(r' \(ws074-p\d+\)','',s)
for name,invoke in [('interpreter_call','vm_call'),('interpreter_construct','vm_construct')]:
 m=re.search(r'static int\n'+name+r'\(\n.*?\n\}',s,re.S);f=m.group().replace('\tstruct vm_function *function;','\tstruct vm_function *function;\n\tstruct vm_cell *cell;',1);pos=f.index('\t/* A class\'s constructor' if name=='interpreter_call' else '\t/* Constructs in a foreign realm')
 callargs='registers[words[3]], &registers[words[4]], words[5]' if name=='interpreter_call' else '&registers[words[4]], words[5], registers[words[3]]'
 f=f[:pos]+'''\t/* An exotic callable must reach generic dispatch before any optimized vm_function access. */
 cell = vm_value_as_cell(callee);
 if (cell->type != &vm_function_type) {
  status = '''+invoke+'(run->realm, callee, '+callargs+''', &value);
  if (status != 0)
   return status;
  registers[words[1]] = value;
  run->pc = next;

  /* Succeeded: the exotic result is published before the caller resumes. */
  return 0;
 }

'''+f[pos:];s=s[:m.start()]+f+s[m.end():]
p.write_text(s)
