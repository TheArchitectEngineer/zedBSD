from pathlib import Path
p=Path('plan/ws074/tests/host-proxy-read.c');s=p.read_text();pos=s.index('/* One for-in probe');s=s[:pos]+'''/* One invocation observation stores only weak addresses and actual callback counters. */
struct invoke_observation {
 struct vm_heap *heap;
 uintptr_t addresses[9];
 unsigned mode;
 unsigned gets;
 unsigned traps;
};

'''+s[pos:];pos=s.index('/* Only for_in_pressure');s=s[:pos]+'''/* Only invoke_pressure activates this synchronous observer; it contributes no collector edges. */
static struct invoke_observation invoke_case;

'''+s[pos:];pos=s.index('static int proxy_make(');s=s[:pos]+'''static int proxy_construct(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_foreign_constructor(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_foreign_construct(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int invoke_get_method(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int invoke_trap(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int invoke_pressure(struct page *page);
'''+s[pos:];pos=s.index('\t/* The parser probe');s=s[:pos]+'''	/* Private construction and foreign-realm bridges leave the product globals unpublished. */
 status = js_builtin_method(page->realm, page->realm->global, "constructReadProxy", 2, proxy_construct);
 if (status != 0)
  goto cleanup;
 status = js_builtin_method(page->realm, page->realm->global, "makeForeignReadConstructor", 0, proxy_foreign_constructor);
 if (status != 0)
  goto cleanup;

'''+s[pos:];s=s.replace('(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()',"(function(){var p=makeReadProxy(function(){return 7;},{});return typeof p==='function'&&p()===7;})()",1);pos=s.index('\t/* Exercise managed realm');s=s[:pos]+'''	/* Direct native invocation must own revoked snapshots, fresh methods and argument Arrays during actual GC. */
 status = invoke_pressure(page);
 if (status != 0)
  goto cleanup;
 puts("native proxy invocation snapshots and reclamation: passed");

'''+s[pos:];s+='''
/* Forward construction to the production VM after validating both constructor operands. */
static int
proxy_construct(
 struct vm_realm *realm,
 vm_value receiver,
 const vm_value *args,
 unsigned count,
 vm_value *result)
{
 vm_value target;
 vm_value new_target;
 const vm_value *list;
 unsigned length;
 int constructor;
 int status;

 UNUSED_PARAMETER(receiver);

 /* Validate new.target before a Proxy construct getter can execute. */
 target = js_argument(args, count, 0);
 new_target = target;
 if (count >= 2U)
  new_target = args[1];
 constructor = vm_value_is_constructor(target);
 if (!constructor) {
  status = vm_throw_type_error(realm, "Target is not a constructor");
  return status;
 }

 /* The second constructor operand has its own independent language check. */
 constructor = vm_value_is_constructor(new_target);
 if (!constructor) {
  status = vm_throw_type_error(realm, "new.target is not a constructor");
  return status;
 }

 /* Argument storage remains owned by the normal native call frame. */
 list = NULL;
 length = 0;
 if (count > 2U) {
  list = args + 2;
  length = count - 2U;
 }

 /* Invoke genuine VM construction without a fixture implementation of its algorithms. */
 status = vm_construct(realm, target, list, length, new_target, result);
 if (status != 0)
  return status;

 /* Succeeded: return the actual constructed object. */
 return 0;
}

/* Allocate the receiver using the actual active new.target and intrinsic fallback operation. */
static int
proxy_foreign_construct(
 struct vm_realm *realm,
 vm_value receiver,
 const vm_value *args,
 unsigned count,
 vm_value *result)
{
 int status;

 UNUSED_PARAMETER(receiver);
 UNUSED_PARAMETER(args);
 UNUSED_PARAMETER(count);

 /* Native construction uses the function realm selected by vm_construct. */
 status = vm_construct_this(realm, realm->new_target, result);
 if (status != 0)
  return status;

 /* Succeeded: return an object allocated by the production constructor operation. */
 return 0;
}

/* Create a real managed realm with its own intrinsic objects and error constructors. */
static int
proxy_foreign_constructor(
 struct vm_realm *realm,
 vm_value receiver,
 const vm_value *args,
 unsigned count,
 vm_value *result)
{
 struct vm_realm *foreign;
 struct vm_function *function;
 struct vm_cell *roots[2];
 vm_value key;
 vm_value error;
 unsigned registered;
 unsigned index;
 int status;

 UNUSED_PARAMETER(receiver);
 UNUSED_PARAMETER(args);
 UNUSED_PARAMETER(count);

 /* Register empty placeholders before any collectible realm or function allocation. */
 memset(roots, 0, sizeof(roots));
 registered = 0;
 for (index = 0; index < 2U; index++) {
  status = vm_heap_add_root(realm->heap, &roots[index]);
  if (status != 0)
   goto cleanup;
  registered++;
 }

 /* Builtins are installed in the independent real realm, including its TypeError constructor. */
 status = vm_realm_create_managed(realm->heap, &foreign);
 if (status != 0)
  goto cleanup;
 roots[0] = &foreign->cell;
 status = js_install_builtins(foreign);
 if (status != 0)
  goto cleanup;
 function = vm_function_create_native(foreign, "Foreign", 0, proxy_foreign_construct);
 if (function == NULL) {
  status = ENOMEM;
  goto cleanup;
 }

 /* The function owns its managed realm after the temporary setup root retires. */
 roots[1] = &function->object.cell;
 function->construct = proxy_foreign_construct;
 key = vm_key_from_ascii(realm->heap, "prototype");
 if (key == VM_VALUE_EMPTY) {
  status = ENOMEM;
  goto cleanup;
 }

 /* A writable prototype allows a genuine Proxy to expose a primitive without violating fixed-property invariants. */
 status = vm_object_define(realm->heap, &function->object, key, vm_value_cell(foreign->object_prototype), VM_PROPERTY_WRITABLE);
 if (status != 0)
  goto cleanup;
 key = vm_key_from_ascii(realm->heap, "TypeError");
 if (key == VM_VALUE_EMPTY) {
  status = ENOMEM;
  goto cleanup;
 }

 /* The actual realm error constructor is exposed solely for cross-realm identity checks. */
 status = vm_get(foreign, vm_value_cell(foreign->global), key, &error);
 if (status != 0)
  goto cleanup;
 status = vm_object_define(realm->heap, &function->object, key, error, VM_PROPERTY_DEFAULT);
 if (status != 0)
  goto cleanup;
 *result = vm_value_cell(function);

cleanup:
 /* Release only successfully acquired temporary roots. */
 while (registered != 0U) {
  registered--;
  vm_heap_remove_root(realm->heap, &roots[registered]);
 }

 /* Preserve an installation or allocation failure. */
 if (status != 0)
  return status;

 /* Succeeded: the constructor retains its real foreign intrinsics. */
 return 0;
}

/* Revoke during GetMethod and return a fresh trap before argument-Array allocation collects. */
static int
invoke_get_method(
 struct vm_realm *realm,
 vm_value receiver,
 const vm_value *args,
 unsigned count,
 vm_value *result)
{
 struct vm_cell *cell;
 struct vm_function *method;
 struct vm_cell *pressure;
 unsigned index;
 int status;

 UNUSED_PARAMETER(receiver);
 UNUSED_PARAMETER(args);
 UNUSED_PARAMETER(count);

 /* Revocation removes the only record edges to the original target and handler. */
 cell = vm_heap_find_cell(invoke_case.heap, invoke_case.addresses[1]);
 if (cell == NULL)
  return EFAULT;
 status = vm_proxy_revoke(realm, vm_value_cell(cell));
 if (status != 0)
  return status;
 vm_heap_collect(invoke_case.heap);

 /* No allocation can reuse a dead participant address before checking the snapshots. */
 for (index = 0; index < 6U; index++) {
  cell = vm_heap_find_cell(invoke_case.heap, invoke_case.addresses[index]);
  if (cell == NULL)
   return EFAULT;
 }

 /* A fresh method has no handler or script reference after this getter frame returns. */
 invoke_case.gets++;
 method = vm_function_create_native(realm, "fresh-invoke-trap", 3, invoke_trap);
 if (method == NULL)
  return ENOMEM;
 *result = vm_value_cell(method);
 invoke_case.addresses[6] = (uintptr_t)method;
 pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
 if (pressure == NULL)
  return ENOMEM;

 /* Succeeded: the following production argument-Array allocation must retain the returned method. */
 return 0;
}

/* Observe original participants and actual argument Array through a collecting native trap. */
static int
invoke_trap(
 struct vm_realm *realm,
 vm_value receiver,
 const vm_value *args,
 unsigned count,
 vm_value *result)
{
 struct vm_cell *cell;
 struct vm_object *output;
 vm_value list;
 vm_value value;
 unsigned index;
 int status;

 /* Check the specified trap argument positions against weak participant identities. */
 if (count != 3U)
  return EINVAL;
 cell = vm_value_as_cell(receiver);
 if ((uintptr_t)cell != invoke_case.addresses[3])
  return EFAULT;
 cell = vm_value_as_cell(args[0]);
 if ((uintptr_t)cell != invoke_case.addresses[2])
  return EFAULT;
 if (invoke_case.mode == 0U) {
  list = args[2];
  value = args[1];
 } else {
  list = args[1];
  value = args[2];
 }

 /* Call receiver and Construct new.target both use the independent identity function. */
 cell = vm_value_as_cell(value);
 if ((uintptr_t)cell != invoke_case.addresses[5])
  return EFAULT;
 invoke_case.addresses[7] = (uintptr_t)vm_value_as_cell(list);
 vm_heap_collect(invoke_case.heap);
 for (index = 0; index < 8U; index++) {
  cell = vm_heap_find_cell(invoke_case.heap, invoke_case.addresses[index]);
  if (cell == NULL)
   return EFAULT;
 }

 /* Read the production Array element after collection rather than retaining the original payload in the observer. */
 status = vm_get(realm, list, vm_value_int32(0), &value);
 if (status != 0)
  return status;
 cell = vm_value_as_cell(value);
 if ((uintptr_t)cell != invoke_case.addresses[4])
  return EFAULT;
 invoke_case.traps++;
 output = vm_object_create(realm->heap, NULL);
 if (output == NULL)
  return ENOMEM;
 invoke_case.addresses[8] = (uintptr_t)output;
 *result = vm_value_cell(output);

 /* Succeeded: the output has no prototype edge to the otherwise unowned direct caller. */
 return 0;
}

/* Verify direct Call and Construct ownership across revocation, threshold collection and trap collection. */
static int
invoke_pressure(
 struct page *page)
{
 struct vm_realm *caller;
 struct vm_function *target;
 struct vm_function *identity;
 struct vm_function *getter;
 struct vm_object *handler;
 struct vm_object *payload;
 struct vm_cell *roots[8];
 struct vm_cell *cell;
 struct vm_heap_stats before;
 struct vm_heap_stats after;
 vm_value proxy;
 vm_value key;
 vm_value input;
 vm_value output;
 unsigned registered;
 unsigned index;
 unsigned mode;
 int status;

 /* Only setup placeholders and the final result slot are registered by the embedding fixture. */
 memset(roots, 0, sizeof(roots));
 registered = 0;
 for (index = 0; index < 8U; index++) {
  status = vm_heap_add_root(page->heap, &roots[index]);
  if (status != 0)
   goto cleanup;
  registered++;
 }

 /* Each invocation gets independent cells so the second mode cannot inherit ownership from the first. */
 for (mode = 0; mode < 2U; mode++) {
  memset(&invoke_case, 0, sizeof(invoke_case));
  invoke_case.heap = page->heap;
  invoke_case.mode = mode;
  status = vm_realm_create_managed(page->heap, &caller);
  if (status != 0)
   goto cleanup;
  roots[0] = &caller->cell;
  target = vm_function_create_native(page->realm, "unreached-target", 0, proxy_collect);
  if (target == NULL) {
   status = ENOMEM;
   goto cleanup;
  }

  /* The target is constructable but belongs to the permanently retained Page realm. */
  roots[1] = &target->object.cell;
  target->construct = proxy_collect;
  handler = vm_object_create(page->heap, NULL);
  if (handler == NULL) {
   status = ENOMEM;
   goto cleanup;
  }

  /* Handler and payload have no caller-realm prototype backedges. */
  roots[2] = &handler->cell;
  payload = vm_object_create(page->heap, NULL);
  if (payload == NULL) {
   status = ENOMEM;
   goto cleanup;
  }

  /* A distinct identity function serves as Call thisArg or Construct new.target. */
  roots[3] = &payload->cell;
  identity = vm_function_create_native(page->realm, "identity", 0, proxy_collect);
  if (identity == NULL) {
   status = ENOMEM;
   goto cleanup;
  }

  /* Neither identity nor getter owns the managed caller. */
  roots[4] = &identity->object.cell;
  identity->construct = proxy_collect;
  getter = vm_function_create_native(page->realm, "invoke-method-getter", 0, invoke_get_method);
  if (getter == NULL) {
   status = ENOMEM;
   goto cleanup;
  }

  /* Install an ordinary accessor so GetMethod exercises normal script-capable VM calls. */
  roots[5] = &getter->object.cell;
  key = vm_key_from_ascii(page->heap, mode == 0U ? "apply" : "construct");
  if (key == VM_VALUE_EMPTY) {
   status = ENOMEM;
   goto cleanup;
  }
  status = vm_define_accessor(page->realm, vm_value_cell(handler), key, vm_value_cell(getter), 0);
  if (status != 0)
   goto cleanup;
  status = vm_proxy_create(page->realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
  if (status != 0)
   goto cleanup;

  /* The original record itself has no caller-realm prototype backedge. */
  roots[6] = vm_value_as_cell(proxy);
  ((struct vm_object *)roots[6])->prototype = NULL;
  invoke_case.addresses[0] = (uintptr_t)caller;
  invoke_case.addresses[1] = (uintptr_t)roots[6];
  invoke_case.addresses[2] = (uintptr_t)target;
  invoke_case.addresses[3] = (uintptr_t)handler;
  invoke_case.addresses[4] = (uintptr_t)payload;
  invoke_case.addresses[5] = (uintptr_t)identity;
  input = vm_value_cell(payload);
  vm_heap_stats(page->heap, &before);
  memset(roots, 0, sizeof(roots));
  if (mode == 0U) {
   status = vm_call(caller, proxy, vm_value_cell(identity), &input, 1, &output);
  } else {
   status = vm_construct(caller, proxy, &input, 1, vm_value_cell(identity), &output);
  }
  if (status != 0)
   goto cleanup;

  /* The method getter and actual trap must each have collected, with an intervening allocation-threshold collection. */
  roots[7] = vm_value_as_cell(output);
  vm_heap_stats(page->heap, &after);
  if (invoke_case.gets != 1U || invoke_case.traps != 1U || after.collections < before.collections + 3U) {
   status = 1;
   goto cleanup;
  }

  /* Keeping only the fresh output must not retain any input or managed caller graph. */
  vm_heap_collect(page->heap);
  for (index = 0; index < 8U; index++) {
   cell = vm_heap_find_cell(page->heap, invoke_case.addresses[index]);
   if (cell != NULL) {
    status = 1;
    goto cleanup;
   }
  }

  /* The sole rooted result must remain alive until its own final embedding edge retires. */
  cell = vm_heap_find_cell(page->heap, invoke_case.addresses[8]);
  if (cell == NULL) {
   status = 1;
   goto cleanup;
  }
  roots[7] = NULL;
  vm_heap_collect(page->heap);
  cell = vm_heap_find_cell(page->heap, invoke_case.addresses[8]);
  if (cell != NULL) {
   status = 1;
   goto cleanup;
  }
 }

 /* Both operation modes satisfied all independent ownership and reclamation gates. */
 status = 0;

cleanup:
 /* The weak observer and successful root registrations retire on every outcome. */
 memset(&invoke_case, 0, sizeof(invoke_case));
 while (registered != 0U) {
  registered--;
  vm_heap_remove_root(page->heap, &roots[registered]);
 }

 /* Preserve protocol errors and failed lifetime observations. */
 if (status != 0)
  return status;

 /* Succeeded: Call and Construct retain their graph only for the duration of the direct operation. */
 return 0;
}
''';p.write_text(s)
