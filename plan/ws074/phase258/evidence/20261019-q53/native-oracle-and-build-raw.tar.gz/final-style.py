from pathlib import Path
import re
p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text();s=s.replace('if (!callable)\n\t\treturn 0;\n\t/* A managed caller','if (!callable)\n\t\treturn 0;\n\n\t/* A managed caller',1);s=s.replace('/* Only callable constructors and object values require a prototype lookup. */','/* A non-callable has no instances; bound callables can delegate even for primitive values. */',1);p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/function.c');s=p.read_text();s=s.replace('\tvm_heap_mark_value(heap, roots->list);\n}', '\tvm_heap_mark_value(heap, roots->list);\n\n\t/* Succeeded: every initialized invocation snapshot contributes its collector edge. */\n\treturn;\n}',1);p.write_text(s)
p=Path('build/ws074-20261018/q53/format.py');s=p.read_text();mark="  f=re.sub(r'(\\n[ \\t]*\\}\\n)";i=s.index(mark);s=s[:i]+'''  for before,after in [
   ('if (function->code != NULL && (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U)', 'if (function->code != NULL &&\\n\\t    (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U)'),
   ('if (function->code != NULL && (function->code->flags & VM_CODE_CLASS) != 0U)', 'if (function->code != NULL &&\\n\\t    (function->code->flags & VM_CODE_CLASS) != 0U)'),
   ('if (method != VM_VALUE_UNDEFINED && !ordinary)', 'if (method != VM_VALUE_UNDEFINED &&\\n\\t\\t    !ordinary)'),
   ('if (status != 0 || !done)', 'if (status != 0 ||\\n\\t    !done)'),
   ('if (invoke_case.gets != 1U || invoke_case.traps != 1U || after.collections < before.collections + 3U)', 'if (invoke_case.gets != 1U ||\\n\\t\\t    invoke_case.traps != 1U ||\\n\\t\\t    after.collections < before.collections + 3U)')]:f=f.replace(before,after)
  for match in list(re.finditer(r'status = interpreter_push\\((.*?)\\);',f,re.S))[::-1]:
   args=match[1].split(',');call='status = interpreter_push(\\n'+',\\n'.join('\\t\\t    '+a.strip() for a in args)+');';f=f[:match.start()]+call+f[match.end():]
'''+s[i:];p.write_text(s)
