int vm_proxy_create(struct vm_realm *realm, vm_value target, vm_value handler, vm_value *result);
struct vm_function * vm_function_create_native(struct vm_realm *realm, const char *name, unsigned length, vm_native native);
struct vm_function * vm_function_create(struct vm_realm *realm, struct vm_code *code);
int vm_value_is_callable(vm_value value);
int vm_value_is_constructor(vm_value value);
int vm_call(struct vm_realm *realm, vm_value callee, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
int vm_construct(struct vm_realm *realm, vm_value constructor, const vm_value *args, unsigned count, vm_value new_target, vm_value *result);
int vm_construct_prototype(struct vm_realm *realm, vm_value new_target, struct vm_object *fallback, struct vm_object **prototype);
static int function_default_prototype(struct vm_realm *realm, vm_value target, struct vm_object *fallback, struct vm_object **prototype);
static void function_trace(struct vm_heap *heap, struct vm_cell *cell);
static void function_proxy_trace(struct vm_heap *heap, void *context);
static int function_proxy_invoke(struct vm_realm *realm, vm_value callee, vm_value receiver, const vm_value *args, unsigned count, vm_value new_target, int construct, vm_value *result);
static int function_run_native(struct vm_realm *realm, struct vm_function *function, vm_native native, vm_value this_value, const vm_value *args, unsigned count, vm_value new_target, vm_value *result);
static int interpreter_call(struct interpreter *run, const uint32_t *words, vm_value *registers, uint32_t next);
static int interpreter_construct(struct interpreter *run, const uint32_t *words, vm_value *registers, uint32_t next);
static int function_bind(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int function_bound_length(struct vm_realm *realm, vm_value target, unsigned bound_count, vm_value *length);
static int function_to_string(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
int vm_instanceof(struct vm_realm *realm, vm_value value, vm_value constructor, vm_value *result);
static int access_instanceof(struct vm_realm *realm, vm_value value, vm_value constructor, vm_value *result);
int vm_ordinary_has_instance(struct vm_realm *realm, vm_value constructor, vm_value value, vm_value *result);
int main(int argc, char **argv);
static int proxy_construct(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_foreign_constructor(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_foreign_construct(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int invoke_get_method(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int invoke_trap(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int invoke_pressure(struct page *page);

int
vm_proxy_create(
	struct vm_realm *realm,
	vm_value target,
	vm_value handler,
	vm_value *result)
{
	struct vm_proxy *proxy;
	struct vm_cell *roots[4];
	vm_value values[2];
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_object;
	int callable;
	int constructor;
	int status;

	/* Protect incoming ownership before either validation errors or allocation can collect. */
	*result = VM_VALUE_UNDEFINED;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	values[0] = target;
	values[1] = handler;
	for (index = 0; index < 2U; index++) {
		roots[index + 1U] = NULL;
		is_cell = vm_value_is_cell(values[index]);
		if (is_cell)
			roots[index + 1U] = vm_value_as_cell(values[index]);
	}

	/* Reserve the unpublished-record root slot before acquiring registrations. */
	roots[3] = NULL;
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Both Proxy protocol participants must be objects. */
	is_object = vm_value_is_object(target);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy target must be an object");
		goto cleanup;
	}

	/* Validate the handler independently before allocating the record. */
	is_object = vm_value_is_object(handler);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy handler must be an object");
		goto cleanup;
	}

	/* Capture immutable internal call and construct slots before allocation can collect. */
	callable = vm_value_is_callable(target);
	constructor = vm_value_is_constructor(target);

	/* Retain the newborn before ordinary shape initialization can allocate. */
	proxy = vm_heap_alloc(realm->heap, &object_proxy_type, sizeof(*proxy));
	if (proxy == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Initialize every traced payload field before shape initialization can collect. */
	roots[3] = &proxy->object.cell;
	proxy->target = target;
	proxy->handler = handler;
	proxy->callable = callable;
	proxy->constructor = constructor;
	proxy->object.kind = VM_KIND_PROXY;
	proxy->object.internal = VM_VALUE_UNDEFINED;
	status = vm_object_init(realm->heap, &proxy->object, NULL);
	if (status != 0)
		goto cleanup;

	/* Only a complete native record becomes visible to the caller. */
	*result = vm_value_cell(proxy);

cleanup:
	/* Release only registrations actually acquired before a possible failure. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the caller owns the managed read primitive. */
	return 0;
}

struct vm_function *
vm_function_create_native(
	struct vm_realm *realm,
	const char *name,
	unsigned length,
	vm_native native)
{
	struct vm_heap *heap;
	struct vm_function *function;
	struct vm_string *text;
	struct vm_cell *roots[3];
	vm_value key;
	unsigned index;
	unsigned registered;
	int error;

	/* Retains a collectible realm before the first allocation and both unpublished cells. */
	heap = realm->heap;
	function = NULL;
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;

	/* Collectible realms need an explicit input edge before the function can own them. */
	if (realm->managed)
		roots[0] = &realm->cell;

	/* The acquisition count owns only slots successfully inserted into the heap registry. */
	registered = 0;
	for (index = 0; index < 3U; index++) {
		error = vm_heap_add_root(heap, &roots[index]);
		if (error != 0)
			goto cleanup;

		/* Cleanup owns this slot only after the heap registry has acquired it. */
		registered++;
	}

	/* Allocates the function before publishing its shape or native state. */
	function = vm_heap_alloc(heap, &vm_function_type, sizeof(*function));
	if (function == NULL) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Protects the newborn while initialization may allocate a cold root shape. */
	roots[1] = &function->object.cell;
	function->bound_target = VM_VALUE_UNDEFINED;
	error = vm_object_init(heap, &function->object, realm->function_prototype);
	if (error != 0)
		goto cleanup;

	/* Retains only collectible realms without consulting retired manual owners. */
	function->realm = realm;

	/* The completed function supplies the durable edge only for collectible realms. */
	if (realm->managed)
		function->realm_owner = &realm->cell;

	/* Initializes the native entry point and its ordinary function state. */
	function->native = native;
	function->object.kind = VM_KIND_FUNCTION;
	function->data = VM_VALUE_UNDEFINED;
	function->source = VM_VALUE_UNDEFINED;

	/* Acquires the heap-owned length key before defining its configurable property. */
	key = vm_key_from_ascii(heap, "length");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Records the native argument count without writable or enumerable attributes. */
	error = vm_object_define(heap, &function->object, key, vm_value_int32((int32_t)length), VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

	/* Allocates the name before protecting it across subsequent key and shape allocations. */
	text = vm_string_from_utf8(heap, name, strlen(name));
	if (text == NULL) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Keeps the private name alive until its completed property owns it. */
	roots[2] = &text->cell;
	key = vm_key_from_ascii(heap, "name");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Publishes the name only after its key is available. */
	error = vm_object_define(heap, &function->object, key, vm_value_cell(text), VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

cleanup:
	/* Releases only registrations acquired by this invocation on every outcome. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(heap, &roots[registered]);
	}

	/* Failed construction publishes no partially initialized result. */
	if (error != 0)
		return NULL;

	/* Succeeded: the complete native function owns its realm and name. */
	return function;
}

struct vm_function *
vm_function_create(
	struct vm_realm *realm,
	struct vm_code *code)
{
	struct vm_heap *heap;
	struct vm_function *function;
	struct vm_cell *roots[3];
	vm_value key;
	vm_value name;
	uint32_t length;
	unsigned index;
	unsigned registered;
	int error;

	/* Retains the input code, collectible realm and unpublished function for the whole factory. */
	heap = realm->heap;
	function = NULL;
	roots[0] = &code->cell;
	roots[1] = NULL;
	roots[2] = NULL;

	/* A collectible input realm cannot rely on an unpublished function's future edge. */
	if (realm->managed)
		roots[1] = &realm->cell;

	/* Only completed registry insertions belong to the factory's cleanup path. */
	registered = 0;
	for (index = 0; index < 3U; index++) {
		error = vm_heap_add_root(heap, &roots[index]);
		if (error != 0)
			goto cleanup;

		/* Cleanup owns this slot only after the heap registry has acquired it. */
		registered++;
	}

	/* Allocates a function without borrowing conservative caller retention. */
	function = vm_heap_alloc(heap, &vm_function_type, sizeof(*function));
	if (function == NULL) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Protects the partially initialized cell before any shape allocation. */
	roots[2] = &function->object.cell;
	function->bound_target = VM_VALUE_UNDEFINED;
	error = vm_object_init(heap, &function->object, realm->function_prototype);
	if (error != 0)
		goto cleanup;

	/* Retains only collectible realms without consulting retired manual owners. */
	function->realm = realm;

	/* The completed function supplies the durable edge only for collectible realms. */
	if (realm->managed)
		function->realm_owner = &realm->cell;

	/* Initializes the bytecode entry point and its ordinary function state. */
	function->code = code;
	function->object.kind = VM_KIND_FUNCTION;
	function->data = VM_VALUE_UNDEFINED;
	function->source = VM_VALUE_UNDEFINED;

	/* Uses the parameter count before a default or rest parameter when the code records it. */
	length = code->parameter_count;

	/* Explicit length metadata excludes parameters after the first default or rest. */
	if ((code->flags & VM_CODE_LENGTH) != 0U)
		length = code->length;
	key = vm_key_from_ascii(heap, "length");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Defines the ordinary configurable length after acquiring its heap-owned key. */
	error = vm_object_define(heap, &function->object, key, vm_value_int32((int32_t)length), VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

	/* Uses the code-owned name, creating an empty string only when necessary. */
	name = VM_VALUE_EMPTY;
	if (code->name != NULL)
		name = vm_value_cell(code->name);
	if (name == VM_VALUE_EMPTY) {
		code->name = vm_string_from_utf8(heap, "", 0);
		if (code->name == NULL) {
			error = ENOMEM;
			goto cleanup;
		}

		/* The already rooted code now owns the generated name. */
		name = vm_value_cell(code->name);
	}

	/* Acquires the property key before publishing the protected name. */
	key = vm_key_from_ascii(heap, "name");
	if (key == VM_VALUE_EMPTY) {
		error = ENOMEM;
		goto cleanup;
	}

	/* Completes the bytecode function's name property. */
	error = vm_object_define(heap, &function->object, key, name, VM_PROPERTY_CONFIGURABLE);
	if (error != 0)
		goto cleanup;

cleanup:
	/* No input or partially initialized function remains pinned after return. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(heap, &roots[registered]);
	}

	/* Failed construction publishes no partially initialized result. */
	if (error != 0)
		return NULL;

	/* Succeeded: the function owns its checked code unit and name. */
	return function;
}

int
vm_value_is_callable(
	vm_value value)
{
	struct vm_cell *cell;
	struct vm_object *object;
	struct vm_proxy *proxy;
	int is_cell;
	int is_object;

	/* Primitive values have no internal Call method. */
	is_cell = vm_value_is_cell(value);
	if (!is_cell)
		return 0;
	cell = vm_value_as_cell(value);
	if (cell->type == &vm_function_type)
		return 1;

	/* A Proxy retains its creation-time Call slot after target and handler revocation. */
	is_object = vm_value_is_object(value);
	if (!is_object)
		return 0;
	object = (struct vm_object *)cell;
	if (object->kind != VM_KIND_PROXY)
		return 0;
	proxy = (struct vm_proxy *)object;

	/* Succeeded: only the immutable native slot determines Proxy callability. */
	return proxy->callable;
}

int
vm_value_is_constructor(
	vm_value value)
{
	struct vm_function *function;
	struct vm_object *object;
	int callable;

	/* Only functions construct. */
	callable = vm_value_is_callable(value);
	if (!callable)
		return 0;

	/* Proxy Construct classification is immutable and never reads a vm_function layout. */
	object = (struct vm_object *)vm_value_as_cell(value);
	if (object->kind == VM_KIND_PROXY)
		return ((struct vm_proxy *)object)->constructor;

	/* A code unit that can, or a native constructor. */
	function = (struct vm_function *)vm_value_as_cell(value);
	if (function->code != NULL &&
	    (function->code->flags & VM_CODE_CONSTRUCTOR) != 0U) {
		/* Succeeded: the bytecode explicitly permits construction. */
		return 1;
	}

	/* A native without construction behavior cannot be used with new. */
	if (function->construct == NULL)
		return 0;

	/* Succeeded: the native supplies its construction behavior. */
	return 1;
}

int
vm_call(
	struct vm_realm *realm,
	vm_value callee,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_function *function;
	struct vm_realm *native_realm;
	struct vm_object *object;
	struct function_roots roots;
	vm_value inputs[2];
	int callable;
	int status;

	/* Rejects a non-callable value in the caller's realm. */
	*result = VM_VALUE_UNDEFINED;
	callable = vm_value_is_callable(callee);
	if (!callable) {
		status = vm_throw(realm, VM_VALUE_UNDEFINED);
		if (status != 0)
			return status;

		/* Succeeded: the refusal follows its existing native throw contract. */
		return 0;
	}

	/* Retains the direct callee, receiver, arguments and caller realm across reentrant execution. */
	inputs[0] = callee;
	inputs[1] = this_value;
	status = function_retain(realm, inputs, 2, args, count, &roots);
	if (status != 0)
		return status;

	/* An exotic callable uses its own dispatch before any ordinary function fields are inspected. */
	object = (struct vm_object *)vm_value_as_cell(callee);
	if (object->kind == VM_KIND_PROXY) {
		status = function_proxy_invoke(realm, callee, this_value, args, count, VM_VALUE_UNDEFINED, 0, result);
		goto cleanup;
	}

	/* Rejects a class constructor invoked without new. */
	function = (struct vm_function *)vm_value_as_cell(callee);
	if (function->code != NULL &&
	    (function->code->flags & VM_CODE_CLASS) != 0U) {
		status = vm_throw_class_call(realm, function);
		if (status != 0)
			goto cleanup;

		/* Successful refusal still completes through the same ownership cleanup. */
		goto cleanup;
	}

	/* Runs script code in the callee's realm, including suspended functions. */
	if (function->code != NULL) {
		status = vm_interpret(
		    function->realm,
		    function,
		    this_value,
		    args,
		    count,
		    result);
		if (status != 0) {
			function_transfer_exception(realm, function->realm, status);
			goto cleanup;
		}
	} else {
		/* A native-less function cannot be executed. */
		if (function->native == NULL) {
			status = ENOSYS;
			goto cleanup;
		}

		/* Preserves the native caller's callee and construction state. */
		/* Bound forwarding has no execution context of its own; ordinary natives enter their creation realm. */
		native_realm = function->realm;
		if (function->bound_target != VM_VALUE_UNDEFINED)
			native_realm = realm;
		status = function_run_native(
		    native_realm,
		    function,
		    function->native,
		    this_value,
		    args,
		    count,
		    VM_VALUE_UNDEFINED,
		    result);
		if (status != 0) {
			function_transfer_exception(realm, native_realm, status);
			goto cleanup;
		}
	}

cleanup:
	/* Unwinds direct input ownership after any foreign exception has reached its caller. */
	function_release(&roots);
	if (status != 0)
		return status;

	/* Succeeded: the callee's result is available in the caller. */
	return 0;
}

int
vm_construct(
	struct vm_realm *realm,
	vm_value constructor,
	const vm_value *args,
	unsigned count,
	vm_value new_target,
	vm_value *result)
{
	struct vm_function *function;
	struct vm_realm *native_realm;
	struct vm_object *object;
	struct function_roots roots;
	vm_value inputs[2];
	struct vm_object *prototype;
	struct vm_object *made;
	int is_constructor;
	int status;

	/* Rejects a non-constructor in the caller's realm. */
	*result = VM_VALUE_UNDEFINED;
	is_constructor = vm_value_is_constructor(constructor);
	if (!is_constructor) {
		/* Error construction may collect an otherwise unowned managed caller realm. */
		status = function_retain(realm, NULL, 0, NULL, 0, &roots);
		if (status != 0)
			return status;

		/* Preserve the existing TypeError refusal before validating direct arguments. */
		status = vm_throw_type_error(realm, "value is not a constructor");
		if (status != 0)
			goto cleanup;

		/* Successful refusal uses the same temporary realm ownership cleanup. */
		goto cleanup;
	}

	/* Constructor input ownership begins before any prototype getter or receiver allocation. */
	inputs[0] = constructor;
	inputs[1] = new_target;
	status = function_retain(realm, inputs, 2, args, count, &roots);
	if (status != 0)
		return status;

	/* An exotic constructor forwards the original new.target through its own Construct method. */
	object = (struct vm_object *)vm_value_as_cell(constructor);
	if (object->kind == VM_KIND_PROXY) {
		status = function_proxy_invoke(realm, constructor, VM_VALUE_UNDEFINED, args, count, new_target, 1, result);
		goto cleanup;
	}

	/* A native constructor creates its object in its own realm. */
	function = (struct vm_function *)vm_value_as_cell(constructor);
	if (function->code == NULL) {
		/* Bound forwarding has no execution context of its own; ordinary natives enter their creation realm. */
		native_realm = function->realm;
		if (function->bound_target != VM_VALUE_UNDEFINED)
			native_realm = realm;
		status = function_run_native(
		    native_realm,
		    function,
		    function->construct,
		    VM_VALUE_UNDEFINED,
		    args,
		    count,
		    new_target,
		    result);
		if (status != 0) {
			function_transfer_exception(realm, native_realm, status);
			goto cleanup;
		}
	} else if ((function->code->flags & VM_CODE_DERIVED) != 0U) {
		/* A derived constructor's super call supplies this. */
		status = vm_interpret_construct(
		    function->realm,
		    function,
		    VM_VALUE_EMPTY,
		    args,
		    count,
		    new_target,
		    result);
		if (status != 0) {
			function_transfer_exception(realm, function->realm, status);
			goto cleanup;
		}
	} else {
		/* Ordinary construction resolves new.target before entering the callee's execution context. */
		status = vm_construct_prototype(
		    realm,
		    new_target,
		    realm->object_prototype,
		    &prototype);
		if (status != 0)
			goto cleanup;

		/* Makes the ordinary constructor's receiver in the shared heap. */
		made = vm_object_create(function->realm->heap, prototype);
		if (made == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Runs the constructor without losing its realm or new.target. */
		status = vm_interpret_construct(
		    function->realm,
		    function,
		    vm_value_cell(made),
		    args,
		    count,
		    new_target,
		    result);
		if (status != 0) {
			function_transfer_exception(realm, function->realm, status);
			goto cleanup;
		}
	}

cleanup:
	/* Releases direct constructor inputs only after execution and exception transfer finish. */
	function_release(&roots);
	if (status != 0)
		return status;

	/* Succeeded: the constructor's object is available to the caller. */
	return 0;
}

int
vm_construct_prototype(
	struct vm_realm *realm,
	vm_value new_target,
	struct vm_object *fallback,
	struct vm_object **prototype)
{
	struct function_roots roots;
	vm_value inputs[2];
	vm_value key;
	vm_value value;
	int is_object;
	int status;

	/* Direct GetPrototypeFromConstructor callers may have no VM execution frame. */
	inputs[0] = new_target;
	inputs[1] = VM_VALUE_UNDEFINED;
	if (fallback != NULL)
		inputs[1] = vm_value_cell(fallback);
	status = function_retain(realm, inputs, 2, NULL, 0, &roots);
	if (status != 0)
		return status;

	/* Acquires the heap-owned key while preserving the target and fallback. */
	*prototype = fallback;
	key = vm_key_from_ascii(realm->heap, "prototype");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The getter may invoke script, reenter native code or collect the heap. */
	status = vm_get(realm, new_target, key, &value);
	if (status != 0)
		goto cleanup;

	/* Uses an explicit object prototype or the target realm's default intrinsic. */
	is_object = vm_value_is_object(value);
	if (is_object) {
		*prototype = (struct vm_object *)vm_value_as_cell(value);
	} else {
		status = function_default_prototype(realm, new_target, fallback, prototype);
		if (status != 0)
			goto cleanup;
	}

cleanup:
	/* No temporary target, fallback or realm root remains after the lookup. */
	function_release(&roots);
	if (status != 0)
		return status;

	/* Succeeded: the prototype is available before the caller's next allocation. */
	return 0;
}

static int
function_default_prototype(
	struct vm_realm *realm,
	vm_value target,
	struct vm_object *fallback,
	struct vm_object **prototype)
{
	struct vm_cell *cell;
	struct vm_object *object;
	struct vm_proxy *proxy;
	struct vm_function *function;
	struct vm_realm *target_realm;
	unsigned index;
	int callable;
	int status;

	/* Host-provided nonfunctions retain the explicit default chosen by their caller. */
	*prototype = fallback;
	callable = vm_value_is_callable(target);
	if (!callable)
		return 0;

	/* GetFunctionRealm follows immutable Proxy and bound targets without interpreting JS private data. */
	for (;;) {
		cell = vm_value_as_cell(target);
		object = (struct vm_object *)cell;
		if (object->kind == VM_KIND_PROXY) {
			proxy = (struct vm_proxy *)object;
			if (proxy->handler == VM_VALUE_NULL) {
				status = vm_throw_type_error(realm, "Cannot obtain realm of a revoked Proxy");
				if (status != 0)
					return status;

				/* Succeeded: the VM accepted the revocation exception report. */
				return 0;
			}

			/* The target chain cannot change through user-visible assignments. */
			target = proxy->target;
			continue;
		}

		/* Every remaining callable belongs to the actual ordinary function cell layout. */
		function = (struct vm_function *)cell;
		if (function->bound_target != VM_VALUE_UNDEFINED) {
			target = function->bound_target;
			continue;
		}

		break;
	}

	/* The common same-realm case requires no intrinsic translation. */
	target_realm = function->realm;
	if (target_realm == realm)
		return 0;

	/* Translate foundational prototypes stored outside the intrinsic registry. */
	if (fallback == realm->object_prototype) {
		*prototype = target_realm->object_prototype;
		return 0;
	}

	/* A function default retains the target realm's Function.prototype identity. */
	if (fallback == realm->function_prototype) {
		*prototype = target_realm->function_prototype;
		return 0;
	}

	/* An array default retains the target realm's Array.prototype identity. */
	if (fallback == realm->array_prototype) {
		*prototype = target_realm->array_prototype;
		return 0;
	}

	/* Each registered default intrinsic retains its logical identity in the target realm. */
	for (index = 0; index < VM_INTRINSICS; index++) {
		if (realm->intrinsics[index] == NULL)
			continue;
		if (fallback == realm->intrinsics[index]) {
			*prototype = target_realm->intrinsics[index];
			return 0;
		}
	}

	/* Succeeded: a host-specific fallback remains the explicitly supplied object. */
	return 0;
}

static void
function_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct vm_function *function;

	/* The object's shape, prototype, slots and elements. */
	vm_object_trace(heap, cell);

	/* The code unit it runs, the environment it runs in, and its data. */
	function = (struct vm_function *)cell;
	vm_heap_mark(heap, function->realm_owner);
	if (function->code != NULL)
		vm_heap_mark(heap, (struct vm_cell *)function->code);
	if (function->env != NULL)
		vm_heap_mark(heap, &function->env->cell);
	vm_heap_mark_value(heap, function->data);

	/* BoundTargetFunction is a VM-owned immutable slot used independently of native call data. */
	vm_heap_mark_value(heap, function->bound_target);

	/* The embedding owns source interpretation; functions only retain its managed value. */
	vm_heap_mark_value(heap, function->source);

	/* Succeeded: the function's owned graph was marked. */
	return;
}

static void
function_proxy_trace(
	struct vm_heap *heap,
	void *context)
{
	struct function_proxy_roots *roots;

	/* Only initialized tagged fields and a collectible caller realm enter this native ownership frame. */
	roots = context;
	if (roots->realm->managed)
		vm_heap_mark(heap, &roots->realm->cell);
	vm_heap_mark_value(heap, roots->target);
	vm_heap_mark_value(heap, roots->handler);
	vm_heap_mark_value(heap, roots->method);
	vm_heap_mark_value(heap, roots->list);

	/* Succeeded: every initialized invocation snapshot contributes its collector edge. */
	return;
}

static int
function_proxy_invoke(
	struct vm_realm *realm,
	vm_value callee,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value new_target,
	int construct,
	vm_value *result)
{
	struct function_proxy_roots roots;
	struct vm_proxy *proxy;
	struct vm_object *object;
	struct vm_object *list;
	vm_value key;
	vm_value index_key;
	const char *method_name;
	vm_value trap_args[3];
	unsigned index;
	int is_object;
	int status;

	/* The outer dispatcher owns direct arguments while this frame owns revocable snapshots and fresh VM results. */
	roots.realm = realm;
	roots.target = callee;
	roots.handler = VM_VALUE_UNDEFINED;
	roots.method = VM_VALUE_UNDEFINED;
	roots.list = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, function_proxy_trace, &roots);
	if (status != 0)
		return status;

	/* A missing trap can follow nested immutable Proxy targets without consuming another C recursion frame. */
	for (;;) {
		proxy = (struct vm_proxy *)vm_value_as_cell(roots.target);
		if (proxy->handler == VM_VALUE_NULL) {
			status = vm_throw_type_error(realm, "Cannot invoke a revoked Proxy");
			goto cleanup;
		}

		/* Snapshot both original edges before GetMethod can revoke the record or collect its previous target. */
		roots.handler = proxy->handler;
		roots.target = proxy->target;
		method_name = "apply";
		if (construct)
			method_name = "construct";
		key = vm_key_from_ascii(realm->heap, method_name);
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* A nullish method falls back; every other value must be callable before any argument Array is allocated. */
		status = vm_get_method(realm, roots.handler, key, &roots.method);
		if (status != 0)
			goto cleanup;
		if (roots.method == VM_VALUE_UNDEFINED) {
			object = (struct vm_object *)vm_value_as_cell(roots.target);
			if (object->kind == VM_KIND_PROXY)
				continue;

			/* Forward exactly the original receiver or new.target to the final target operation. */
			if (construct) {
				status = vm_construct(realm, roots.target, args, count, new_target, result);
			} else {
				status = vm_call(realm, roots.target, receiver, args, count, result);
			}

			/* Retire the fallback snapshot through the common cleanup path. */
			goto cleanup;
		}

		/* A real trap receives a newly allocated dense Array owned before the first element definition. */
		list = vm_array_create(realm->heap, realm->array_prototype);
		if (list == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Publish ownership of the fresh Array before defining its elements. */
		roots.list = vm_value_cell(list);

		/* Own default data properties cannot invoke inherited Array prototype setters. */
		for (index = 0; index < count; index++) {
			index_key = vm_value_int32((int32_t)index);
			status = vm_object_define(realm->heap, list, index_key, args[index], VM_PROPERTY_DEFAULT);
			if (status != 0)
				goto cleanup;
		}

		/* Apply and Construct share handler this but have distinct specified argument positions. */
		trap_args[0] = roots.target;
		if (construct) {
			trap_args[1] = roots.list;
			trap_args[2] = new_target;
		} else {
			trap_args[1] = receiver;
			trap_args[2] = roots.list;
		}

		/* Invoke the selected trap with its specified handler receiver and three arguments. */
		status = vm_call(realm, roots.method, roots.handler, trap_args, 3, result);
		if (status != 0)
			goto cleanup;
		if (construct) {
			is_object = vm_value_is_object(*result);
			if (!is_object) {
				/* An unused primitive result need not survive the TypeError allocation. */
				*result = VM_VALUE_UNDEFINED;
				status = vm_throw_type_error(realm, "Proxy construct trap must return an object");
				goto cleanup;
			}
		}

		/* A successful trap result needs no later allocation before returning to the original caller. */
		goto cleanup;
	}

	/* Retire snapshots only after target or trap execution and all refusal reporting have finished. */
cleanup:
	vm_heap_remove_tracer(realm->heap, function_proxy_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the original caller receives the complete Call or Construct result. */
	return 0;
}

static int
function_run_native(
	struct vm_realm *realm,
	struct vm_function *function,
	vm_native native,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value new_target,
	vm_value *result)
{
	struct function_roots roots;
	vm_value saved[2];
	int status;

	/* Retains suspended callee and new.target edges before temporarily replacing them. */
	saved[0] = realm->callee;
	saved[1] = realm->new_target;
	status = function_retain(realm, saved, 2, NULL, 0, &roots);
	if (status != 0)
		return status;

	/* The public dispatcher already owns direct function, receiver and argument inputs. */
	realm->callee = vm_value_cell(function);
	realm->new_target = new_target;
	status = native(realm, this_value, args, count, result);
	if (status != 0) {
		realm->callee = saved[0];
		realm->new_target = saved[1];
		goto cleanup;
	}

	/* Lets the suspended outer native observe its original invocation again. */
	realm->callee = saved[0];
	realm->new_target = saved[1];

cleanup:
	/* Suspended state returns to the realm before temporary roots are released. */
	function_release(&roots);
	if (status != 0)
		return status;

	/* Succeeded: the native produced its result with the outer state intact. */
	return 0;
}

static int
interpreter_call(
	struct interpreter *run,
	const uint32_t *words,
	vm_value *registers,
	uint32_t next)
{
	struct vm_function *function;
	struct vm_cell *cell;
	vm_value callee;
	vm_value value;
	uint32_t base;
	int callable;
	int suspendable;
	int status;

	/* Only functions can be called. */
	callee = registers[words[2]];
	callable = vm_value_is_callable(callee);
	if (!callable) {
		status = vm_throw_type_error(run->realm, "value is not a function");
		return status;
	}

	/* An exotic callable must reach generic dispatch before any optimized vm_function access. */
	cell = vm_value_as_cell(callee);
	if (cell->type != &vm_function_type) {
		status = vm_call(run->realm, callee, registers[words[3]], &registers[words[4]], words[5], &value);
		if (status != 0)
			return status;
		registers[words[1]] = value;
		run->pc = next;

		/* Succeeded: the exotic result is published before the caller resumes. */
		return 0;
	}

	/* A class's constructor runs only with new. */
	function = (struct vm_function *)vm_value_as_cell(callee);
	if (function->code != NULL &&
	    (function->code->flags & VM_CODE_CLASS) != 0U) {
		status = vm_throw_class_call(run->realm, function);
		return status;
	}

	/* A foreign function enters its own realm and transports any thrown value. */
	if (function->realm != run->realm) {
		status = vm_call(
		    run->realm,
		    callee,
		    registers[words[3]],
		    &registers[words[4]],
		    words[5],
		    &value);
		if (status != 0)
			return status;

		/* Continues the caller after the foreign stack has unwound. */
		registers[words[1]] = value;
		run->pc = next;
		return 0;
	}

	/* A generator or an async function runs from C, which keeps its frame apart when it suspends. */
	suspendable = vm_code_is_suspendable(function);
	if (suspendable) {
		status = vm_generator_call(function->realm, function, registers[words[3]], &registers[words[4]], words[5], &value);
		if (status != 0)
			return status;

		/* The generator or the promise is in the register and the caller goes on. */
		registers[words[1]] = value;
		run->pc = next;
		return 0;
	}

	/* A bytecode function: its frame, whose caller goes on after the call. */
	if (function->code != NULL) {
		status = interpreter_push(
		    run->realm,
		    function,
		    registers[words[3]],
		    &registers[words[4]],
		    words[5],
		    run->base + 1U,
		    next,
		    words[1],
		    &base);
		if (status != 0)
			return status;
		run->base = base;
		run->code = function->code;
		run->pc = 0;
		return 0;
	}

	/* Uses the shared native call boundary to preserve reentrant callee state. */
	status = vm_call(
	    run->realm,
	    callee,
	    registers[words[3]],
	    &registers[words[4]],
	    words[5],
	    &value);
	if (status != 0)
		return status;

	/* Succeeded: the result is in the register and the caller goes on. */
	registers[words[1]] = value;
	run->pc = next;
	return 0;
}

static int
interpreter_construct(
	struct interpreter *run,
	const uint32_t *words,
	vm_value *registers,
	uint32_t next)
{
	struct vm_function *function;
	struct vm_cell *cell;
	vm_value callee;
	vm_value this_value;
	vm_value value;
	uint32_t base;
	int constructor;
	int status;

	/* Only constructors can be used with new. */
	callee = registers[words[2]];
	constructor = vm_value_is_constructor(callee);
	if (!constructor) {
		status = vm_throw_type_error(run->realm, "value is not a constructor");
		return status;
	}

	/* An exotic callable must reach generic dispatch before any optimized vm_function access. */
	cell = vm_value_as_cell(callee);
	if (cell->type != &vm_function_type) {
		status = vm_construct(run->realm, callee, &registers[words[4]], words[5], registers[words[3]], &value);
		if (status != 0)
			return status;
		registers[words[1]] = value;
		run->pc = next;

		/* Succeeded: the exotic result is published before the caller resumes. */
		return 0;
	}

	/* Constructs in a foreign realm without putting its code on our stack. */
	function = (struct vm_function *)vm_value_as_cell(callee);
	if (function->realm != run->realm) {
		status = vm_construct(
		    run->realm,
		    callee,
		    &registers[words[4]],
		    words[5],
		    registers[words[3]],
		    &value);
		if (status != 0)
			return status;

		/* Continues the caller with the foreign constructor's object. */
		registers[words[1]] = value;
		run->pc = next;
		return 0;
	}

	/* A bytecode constructor: the new object (none for a derived class's), then its frame, marked as a construction. */
	if (function->code != NULL) {
		this_value = VM_VALUE_EMPTY;
		if ((function->code->flags & VM_CODE_DERIVED) == 0U) {
			status = vm_construct_this(run->realm, registers[words[3]], &this_value);
			if (status != 0)
				return status;
		}

		/* The frame, with new.target. */
		status = interpreter_push(
		    run->realm,
		    function,
		    this_value,
		    &registers[words[4]],
		    words[5],
		    run->base + 1U,
		    next,
		    words[1] | FRAME_CONSTRUCT,
		    &base);
		if (status != 0)
			return status;
		run->realm->stack[base + FRAME_NEW_TARGET] = registers[words[3]];
		run->base = base;
		run->code = function->code;
		run->pc = 0;
		return 0;
	}

	/* Uses the shared native constructor boundary with scoped new.target. */
	status = vm_construct(
	    run->realm,
	    callee,
	    &registers[words[4]],
	    words[5],
	    registers[words[3]],
	    &value);
	if (status != 0)
		return status;

	/* Succeeded: the object is in the register and the caller goes on. */
	registers[words[1]] = value;
	run->pc = next;
	return 0;
}

static int
function_bind(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *prototype;
	struct vm_function *bound;
	struct vm_cell *roots[5];
	vm_native construct;
	vm_value *data;
	size_t allocation_count;
	vm_value data_array;
	vm_value prototype_value;
	vm_value length;
	vm_value name;
	unsigned bound_count;
	unsigned index;
	unsigned registered;
	int callable;
	int constructor;
	int status;

	/* Only a function can be bound. */
	callable = vm_value_is_callable(this_value);
	if (!callable) {
		status = vm_throw_type_error(realm, "Bind must be called on a function");
		return status;
	}

	/* The data: the target, the bound this and the bound arguments. */
	bound_count = 0;
	if (count > 1U)
		bound_count = count - 1U;
	allocation_count = (size_t)bound_count;
	if (allocation_count > SIZE_MAX / sizeof(vm_value) - FUNCTION_BOUND_ARGS)
		return EOVERFLOW;
	allocation_count += FUNCTION_BOUND_ARGS;
	data = calloc(allocation_count, sizeof(vm_value));
	if (data == NULL)
		return ENOMEM;
	data[FUNCTION_BOUND_TARGET] = this_value;
	data[FUNCTION_BOUND_THIS] = js_argument(args, count, 0);
	for (index = 0; index < bound_count; index++)
		data[FUNCTION_BOUND_ARGS + index] = args[index + 1U];

	/* Retain the collectible realm, private data array and unpublished bound function. */
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = NULL;
	roots[2] = NULL;
	roots[3] = NULL;
	roots[4] = NULL;
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup releases only acquired registrations. */
		registered++;
	}

	/* The data array owns every copied bound argument before native storage ends. */
	status = js_builtin_array(realm, data, FUNCTION_BOUND_ARGS + bound_count, &data_array);
	if (status != 0)
		goto cleanup;
	roots[1] = vm_value_as_cell(data_array);
	free(data);
	data = NULL;

	/* BoundFunctionCreate observes the actual target prototype before length or name properties. */
	status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(this_value), &prototype_value);
	if (status != 0)
		goto cleanup;
	prototype = NULL;
	if (prototype_value != VM_VALUE_NULL) {
		prototype = (struct vm_object *)vm_value_as_cell(prototype_value);
		roots[3] = &prototype->cell;
	}

	/* The bound function: a constructor when its target is one, with the target's prototype. */
	constructor = vm_value_is_constructor(this_value);
	construct = NULL;
	if (constructor)
		construct = function_bound_construct;
	status = js_builtin_function(realm, "", 0, function_bound_call, construct, &bound);
	if (status != 0)
		goto cleanup;
	roots[2] = &bound->object.cell;
	bound->data = data_array;
	bound->bound_target = this_value;
	bound->object.prototype = prototype;

	/* Its length and name from the target's. */
	name = VM_VALUE_UNDEFINED;
	status = function_bound_length(realm, this_value, bound_count, &length);
	if (status != 0)
		goto cleanup;
	status = js_builtin_value(realm, &bound->object, "length", length, VM_PROPERTY_CONFIGURABLE);
	if (status != 0)
		goto cleanup;

	/* The name getter can run user code while the bound result is unpublished. */
	status = function_bound_name(realm, this_value, &name);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(name);
	status = js_builtin_value(realm, &bound->object, "name", name, VM_PROPERTY_CONFIGURABLE);
	if (status != 0)
		goto cleanup;

	/* Succeeded: the bound function. */
	*result = vm_value_cell(bound);
	status = 0;

cleanup:
	/* A failed factory may still own its native temporary argument array. */
	free(data);

	/* No root points into this native frame after return. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* A failed bind never publishes the incomplete native function. */
	if (status != 0)
		return status;

	/* Succeeded: the caller owns the fully bound function. */
	return 0;
}

static int
function_bound_length(
	struct vm_realm *realm,
	vm_value target,
	unsigned bound_count,
	vm_value *length)
{
	struct vm_descriptor descriptor;
	vm_value key;
	vm_value value;
	double number;
	int found;
	int is_number;
	int status;

	/* 0 unless the target has its own length. */
	*length = vm_value_int32(0);
	key = vm_key_from_ascii(realm->heap, "length");
	if (key == VM_VALUE_EMPTY)
		return ENOMEM;
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, &descriptor, &found);
	if (status != 0)
		return status;

	/* A missing descriptor follows the absence path after errors have been excluded. */
	if (!found)
		return 0;

	/* The target's length, when a number. */
	status = vm_get(realm, target, key, &value);
	if (status != 0)
		return status;
	is_number = vm_value_is_number(value);
	if (!is_number)
		return 0;

	/* Infinity stays; -Infinity is 0; otherwise the integer less the bound arguments. */
	number = vm_value_as_number(value);
	if (number == INFINITY) {
		*length = value;
		return 0;
	}

	/* The integer less the bound arguments. */
	status = js_builtin_integer(realm, value, &number);
	if (status != 0)
		return status;
	number -= (double)bound_count;
	if (number < 0.0)
		number = 0.0;

	/* Succeeded: the length. */
	*length = vm_value_number(number);
	return 0;
}

static int
function_to_string(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *object;
	struct wb_buffer text;
	struct vm_string *name;
	vm_value key;
	vm_value value;
	int callable;
	int is_string;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Only a function has a source text. */
	callable = vm_value_is_callable(this_value);
	if (!callable) {
		status = vm_throw_type_error(realm, "Function.prototype.toString requires that 'this' be a Function");
		return status;
	}

	/* A callable Proxy exposes native function syntax without consulting any user-visible property. */
	object = (struct vm_object *)vm_value_as_cell(this_value);
	if (object->kind == VM_KIND_PROXY) {
		status = js_builtin_string(realm, "function () { [native code] }", result);
		if (status != 0)
			return status;

		/* Succeeded: revoked callable Proxies have the same non-observing native form. */
		return 0;
	}

	/* function NAME() { [native code] }, the name when it is a string. */
	wb_buffer_init(&text);
	status = wb_buffer_append_string(&text, "function ");
	if (status != 0)
		goto cleanup;
	key = vm_key_from_ascii(realm->heap, "name");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A user-defined name getter may fail before text conversion. */
	status = vm_get(realm, this_value, key, &value);
	if (status != 0)
		goto cleanup;
	is_string = vm_value_is_string(value);
	if (is_string) {
		name = (struct vm_string *)vm_value_as_cell(value);
		status = vm_string_to_utf8(name, &text);
		if (status != 0)
			goto cleanup;
	}

	/* The rest of the text, as a string. */
	status = wb_buffer_append_string(&text, "() { [native code] }");
	if (status != 0)
		goto cleanup;
	status = js_builtin_string(realm, wb_buffer_string(&text), result);

cleanup:
	/* No native text buffer survives either successful output or failure. */
	wb_buffer_release(&text);

	/* A name getter or native-text conversion error is returned immediately. */
	if (status != 0)
		return status;

	/* Succeeded: the text. */
	return 0;
}

int
vm_instanceof(
	struct vm_realm *realm,
	vm_value value,
	vm_value constructor,
	vm_value *result)
{
	struct access_read_roots roots;
	int status;

	/* Direct native calls retain both operands and the managed realm before any custom method lookup. */
	*result = VM_VALUE_FALSE;
	roots.realm = realm;
	roots.base = constructor;
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = value;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Every constructor getter and custom hasInstance callback remains within this native ownership boundary. */
	status = access_instanceof(realm, value, constructor, result);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the caller receives the complete instance classification. */
	return 0;
}

static int
access_instanceof(
	struct vm_realm *realm,
	vm_value value,
	vm_value constructor,
	vm_value *result)
{
	vm_value method;
	vm_value answer;
	vm_value builtin;
	int ordinary;
	int truth;
	int callable;
	int is_object;
	int status;

	/* An object's Symbol.hasInstance answers for it, unless it is Function.prototype's own. */
	*result = VM_VALUE_FALSE;
	is_object = vm_value_is_object(constructor);
	if (is_object) {
		status = vm_get_method(realm, constructor, vm_symbol_key(realm, VM_SYMBOL_HAS_INSTANCE), &method);
		if (status != 0)
			return status;
		ordinary = 0;
		if (realm->intrinsics[VM_INTRINSIC_HAS_INSTANCE] != NULL) {
			builtin = vm_value_cell(realm->intrinsics[VM_INTRINSIC_HAS_INSTANCE]);
			if (method == builtin)
				ordinary = 1;
		}

		/* A method of its own is called, its answer made a boolean. */
		if (method != VM_VALUE_UNDEFINED &&
		    !ordinary) {
			status = vm_call(realm, method, constructor, &value, 1, &answer);
			if (status != 0)
				return status;
			truth = vm_to_boolean(answer);
			*result = vm_value_boolean(truth);
			return 0;
		}
	}

	/* Otherwise only a callable right side answers instanceof. */
	callable = vm_value_is_callable(constructor);
	if (!callable) {
		status = vm_throw_type_error(realm, "Right-hand side of 'instanceof' is not callable");
		return status;
	}

	/* The prototype chain answers. */
	status = vm_ordinary_has_instance(realm, constructor, value, result);
	if (status != 0)
		return status;

	/* Succeeded: the answer is stored. */
	return 0;
}

int
vm_ordinary_has_instance(
	struct vm_realm *realm,
	vm_value constructor,
	vm_value value,
	vm_value *result)
{
	struct access_read_roots roots;
	struct vm_cell *constructor_cell;
	struct vm_function *function;
	struct vm_cell *prototype_root;
	vm_value key;
	vm_value prototype;
	vm_value link;
	int callable;
	int is_object;
	int status;

	/* A non-callable has no instances; bound callables can delegate even for primitive values. */
	*result = VM_VALUE_FALSE;
	callable = vm_value_is_callable(constructor);
	if (!callable)
		return 0;

	/* A managed caller, constructor and original value survive key allocation and constructor getters. */
	roots.realm = realm;
	roots.base = constructor;
	roots.key = VM_VALUE_UNDEFINED;
	roots.receiver = value;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;
	prototype_root = NULL;
	status = vm_heap_add_root(realm->heap, &prototype_root);
	if (status != 0) {
		vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
		return status;
	}

	/* BoundTargetFunction delegation precedes the primitive-value refusal and may use a custom hasInstance. */
	constructor_cell = vm_value_as_cell(constructor);
	if (constructor_cell->type == &vm_function_type) {
		function = (struct vm_function *)constructor_cell;
		if (function->bound_target != VM_VALUE_UNDEFINED) {
			status = vm_instanceof(realm, value, function->bound_target, result);
			goto cleanup;
		}
	}

	/* Only a non-bound callable with an object operand needs a prototype-chain walk. */
	is_object = vm_value_is_object(value);
	if (!is_object) {
		status = 0;
		goto cleanup;
	}

	/* The constructor's prototype is retrieved before any value-side prototype method is called. */
	key = vm_key_from_ascii(realm->heap, "prototype");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Preserve the property key through a getter that may allocate or collect. */
	roots.key = key;
	status = vm_get(realm, constructor, key, &prototype);
	if (status != 0)
		goto cleanup;
	is_object = vm_value_is_object(prototype);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Function has non-object prototype in instanceof check");
		goto cleanup;
	}

	/* The target prototype and the latest returned link remain independently owned through later traps. */
	prototype_root = vm_value_as_cell(prototype);
	while (roots.receiver != VM_VALUE_NULL) {
		status = vm_get_prototype(realm, (struct vm_object *)vm_value_as_cell(roots.receiver), &link);
		if (status != 0)
			goto cleanup;
		roots.receiver = link;
		if (link == prototype) {
			*result = VM_VALUE_TRUE;
			break;
		}
	}

	/* Reaching null without matching the prototype is a successful false result. */
	status = 0;

cleanup:
	/* Neither abrupt chain traversal nor invalid constructor output may leak native ownership. */
	vm_heap_remove_root(realm->heap, &prototype_root);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the actual internal prototype methods supplied the instance result. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* Private construction and foreign-realm bridges leave the product globals unpublished. */
	status = js_builtin_method(page->realm, page->realm->global, "constructReadProxy", 2, proxy_construct);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeForeignReadConstructor", 0, proxy_foreign_constructor);
	if (status != 0)
		goto cleanup;

	/* The parser probe reaches the unchanged production allocation threshold without editing heap policy. */
	status = js_builtin_method(page->realm, page->realm->global, "pressureReadProxy", 0, proxy_parse_pressure);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){var p=makeReadProxy(function(){return 7;},{});return typeof p==='function'&&p()===7;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fresh coercion text must survive a later parser allocation after the toString call frame has retired. */
	status = proxy_script(page->realm,
			      "(function(){var before,r=JSON.parse({toString:function(){var text=['{','\"a\":[1,{\"b\":2}]}'].join('');before=pressureReadProxy();return text;}});return r.a[1].b===2&&pressureReadProxy(true)>before;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Publish only the actual threshold-counter and parsed-value gate after both have passed. */
	puts("native JSON parser threshold collection: passed");

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 ||
	    !done) {
		status = 1;
		goto cleanup;
	}

	/* A direct CopyDataProperties call must own its bare native inputs and a fresh getter result through target policy. */
	status = spread_copy_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native object copy collection and reclamation: passed");

	/* Direct start and next calls must own their managed caller, private state and source without embedding roots. */
	status = for_in_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native for-in collection and reclamation: passed");

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Direct native invocation must own revoked snapshots, fresh methods and argument Arrays during actual GC. */
	status = invoke_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native proxy invocation snapshots and reclamation: passed");

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A primitive receiver's temporary source box must survive later depth conversion and then become reclaimable. */
	status = flat_source_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_construct(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value target;
	vm_value new_target;
	const vm_value *list;
	unsigned length;
	int constructor;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Validate new.target before a Proxy construct getter can execute. */
	target = js_argument(args, count, 0);
	new_target = target;
	if (count >= 2U)
		new_target = args[1];
	constructor = vm_value_is_constructor(target);
	if (!constructor) {
		status = vm_throw_type_error(realm, "Target is not a constructor");
		return status;
	}

	/* The second constructor operand has its own independent language check. */
	constructor = vm_value_is_constructor(new_target);
	if (!constructor) {
		status = vm_throw_type_error(realm, "new.target is not a constructor");
		return status;
	}

	/* Argument storage remains owned by the normal native call frame. */
	list = NULL;
	length = 0;
	if (count > 2U) {
		list = args + 2;
		length = count - 2U;
	}

	/* Invoke genuine VM construction without a fixture implementation of its algorithms. */
	status = vm_construct(realm, target, list, length, new_target, result);
	if (status != 0)
		return status;

	/* Succeeded: return the actual constructed object. */
	return 0;
}

static int
proxy_foreign_constructor(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_realm *foreign;
	struct vm_function *function;
	struct vm_cell *roots[2];
	vm_value key;
	vm_value error;
	vm_value ordinary;
	int ordinary_requested;
	unsigned registered;
	unsigned index;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Register empty placeholders before any collectible realm or function allocation. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 2U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Builtins are installed in the independent real realm, including its TypeError constructor. */
	status = vm_realm_create_managed(realm->heap, &foreign);
	if (status != 0)
		goto cleanup;
	roots[0] = &foreign->cell;
	status = js_install_builtins(foreign);
	if (status != 0)
		goto cleanup;

	/* An optional control returns a true foreign bytecode function rather than a native constructor. */
	ordinary_requested = 0;
	if (count > 0U)
		ordinary_requested = vm_to_boolean(args[0]);
	if (ordinary_requested) {
		status = proxy_script(foreign, "(function Foreign(){})", &ordinary);
		if (status != 0)
			goto cleanup;
		function = (struct vm_function *)vm_value_as_cell(ordinary);
	} else {
		function = vm_function_create_native(foreign, "Foreign", 0, proxy_foreign_construct);
		if (function == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Only the native helper uses the explicit native construction callback. */
		function->construct = proxy_foreign_construct;
	}

	/* The function owns its managed realm after the temporary setup root retires. */
	roots[1] = &function->object.cell;
	key = vm_key_from_ascii(realm->heap, "prototype");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A writable prototype allows a genuine Proxy to expose a primitive without violating fixed-property invariants. */
	status = vm_object_define(realm->heap, &function->object, key, vm_value_cell(foreign->object_prototype), VM_PROPERTY_WRITABLE);
	if (status != 0)
		goto cleanup;
	key = vm_key_from_ascii(realm->heap, "TypeError");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The actual realm error constructor is exposed solely for cross-realm identity checks. */
	status = vm_get(foreign, vm_value_cell(foreign->global), key, &error);
	if (status != 0)
		goto cleanup;
	status = vm_object_define(realm->heap, &function->object, key, error, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	*result = vm_value_cell(function);

cleanup:
	/* Release only successfully acquired temporary roots. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve an installation or allocation failure. */
	if (status != 0)
		return status;

	/* Succeeded: the constructor retains its real foreign intrinsics. */
	return 0;
}

static int
proxy_foreign_construct(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	int status;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Native construction uses the function realm selected by vm_construct. */
	status = vm_construct_this(realm, realm->new_target, result);
	if (status != 0)
		return status;

	/* Succeeded: return an object allocated by the production constructor operation. */
	return 0;
}

static int
invoke_get_method(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *cell;
	struct vm_function *method;
	struct vm_cell *pressure;
	unsigned index;
	int status;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Revocation removes the only record edges to the original target and handler. */
	cell = vm_heap_find_cell(invoke_case.heap, invoke_case.addresses[1]);
	if (cell == NULL)
		return EFAULT;
	status = vm_proxy_revoke(realm, vm_value_cell(cell));
	if (status != 0)
		return status;
	vm_heap_collect(invoke_case.heap);

	/* No allocation can reuse a dead participant address before checking the snapshots. */
	for (index = 0; index < 6U; index++) {
		cell = vm_heap_find_cell(invoke_case.heap, invoke_case.addresses[index]);
		if (cell == NULL)
			return EFAULT;
	}

	/* A fresh method has no handler or script reference after this getter frame returns. */
	invoke_case.gets++;
	method = vm_function_create_native(realm, "fresh-invoke-trap", 3, invoke_trap);
	if (method == NULL)
		return ENOMEM;
	*result = vm_value_cell(method);
	invoke_case.addresses[6] = (uintptr_t)method;
	pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL)
		return ENOMEM;

	/* Succeeded: the following production argument-Array allocation must retain the returned method. */
	return 0;
}

static int
invoke_trap(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *cell;
	struct vm_object *output;
	vm_value list;
	vm_value value;
	unsigned index;
	int status;

	/* Check the specified trap argument positions against weak participant identities. */
	if (count != 3U)
		return EINVAL;
	cell = vm_value_as_cell(receiver);
	if ((uintptr_t)cell != invoke_case.addresses[3])
		return EFAULT;
	cell = vm_value_as_cell(args[0]);
	if ((uintptr_t)cell != invoke_case.addresses[2])
		return EFAULT;
	if (invoke_case.mode == 0U) {
		list = args[2];
		value = args[1];
	} else {
		list = args[1];
		value = args[2];
	}

	/* Call receiver and Construct new.target both use the independent identity function. */
	cell = vm_value_as_cell(value);
	if ((uintptr_t)cell != invoke_case.addresses[5])
		return EFAULT;
	invoke_case.addresses[7] = (uintptr_t)vm_value_as_cell(list);
	vm_heap_collect(invoke_case.heap);
	for (index = 0; index < 8U; index++) {
		cell = vm_heap_find_cell(invoke_case.heap, invoke_case.addresses[index]);
		if (cell == NULL)
			return EFAULT;
	}

	/* Read the production Array element after collection rather than retaining the original payload in the observer. */
	status = vm_get(realm, list, vm_value_int32(0), &value);
	if (status != 0)
		return status;
	cell = vm_value_as_cell(value);
	if ((uintptr_t)cell != invoke_case.addresses[4])
		return EFAULT;
	invoke_case.traps++;
	output = vm_object_create(realm->heap, NULL);
	if (output == NULL)
		return ENOMEM;
	invoke_case.addresses[8] = (uintptr_t)output;
	*result = vm_value_cell(output);

	/* Succeeded: the output has no prototype edge to the otherwise unowned direct caller. */
	return 0;
}

static int
invoke_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_function *target;
	struct vm_function *identity;
	struct vm_function *getter;
	struct vm_object *handler;
	struct vm_object *payload;
	struct vm_cell *roots[8];
	struct vm_cell *cell;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	const char *method_name;
	vm_value proxy;
	vm_value key;
	vm_value input;
	vm_value output;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int status;

	/* Only setup placeholders and the final result slot are registered by the embedding fixture. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Each invocation gets independent cells so the second mode cannot inherit ownership from the first. */
	for (mode = 0; mode < 2U; mode++) {
		memset(&invoke_case, 0, sizeof(invoke_case));
		invoke_case.heap = page->heap;
		invoke_case.mode = mode;
		status = vm_realm_create_managed(page->heap, &caller);
		if (status != 0)
			goto cleanup;
		roots[0] = &caller->cell;
		target = vm_function_create_native(page->realm, "unreached-target", 0, proxy_collect);
		if (target == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The target is constructable but belongs to the permanently retained Page realm. */
		roots[1] = &target->object.cell;
		target->construct = proxy_collect;
		handler = vm_object_create(page->heap, NULL);
		if (handler == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Handler and payload have no caller-realm prototype backedges. */
		roots[2] = &handler->cell;
		payload = vm_object_create(page->heap, NULL);
		if (payload == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* A distinct identity function serves as Call thisArg or Construct new.target. */
		roots[3] = &payload->cell;
		identity = vm_function_create_native(page->realm, "identity", 0, proxy_collect);
		if (identity == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Neither identity nor getter owns the managed caller. */
		roots[4] = &identity->object.cell;
		identity->construct = proxy_collect;
		getter = vm_function_create_native(page->realm, "invoke-method-getter", 0, invoke_get_method);
		if (getter == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Install an ordinary accessor so GetMethod exercises normal script-capable VM calls. */
		roots[5] = &getter->object.cell;
		method_name = "apply";
		if (mode != 0U)
			method_name = "construct";
		key = vm_key_from_ascii(page->heap, method_name);
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* The handler owns its getter before any setup root can retire. */
		status = vm_define_accessor(page->realm, vm_value_cell(handler), key, vm_value_cell(getter), 0);
		if (status != 0)
			goto cleanup;
		status = vm_proxy_create(page->realm, vm_value_cell(target), vm_value_cell(handler), &proxy);
		if (status != 0)
			goto cleanup;

		/* The original record itself has no caller-realm prototype backedge. */
		roots[6] = vm_value_as_cell(proxy);
		((struct vm_object *)roots[6])->prototype = NULL;
		invoke_case.addresses[0] = (uintptr_t)caller;
		invoke_case.addresses[1] = (uintptr_t)roots[6];
		invoke_case.addresses[2] = (uintptr_t)target;
		invoke_case.addresses[3] = (uintptr_t)handler;
		invoke_case.addresses[4] = (uintptr_t)payload;
		invoke_case.addresses[5] = (uintptr_t)identity;
		input = vm_value_cell(payload);
		vm_heap_stats(page->heap, &before);
		memset(roots, 0, sizeof(roots));
		if (mode == 0U) {
			status = vm_call(caller, proxy, vm_value_cell(identity), &input, 1, &output);
		} else {
			status = vm_construct(caller, proxy, &input, 1, vm_value_cell(identity), &output);
		}

		/* Abrupt invocation cannot satisfy the lifetime gate. */
		if (status != 0)
			goto cleanup;

		/* The method getter and actual trap must each have collected, with an intervening allocation-threshold collection. */
		roots[7] = vm_value_as_cell(output);
		vm_heap_stats(page->heap, &after);
		if (invoke_case.gets != 1U ||
		    invoke_case.traps != 1U ||
		    after.collections < before.collections + 3U) {
			status = 1;
			goto cleanup;
		}

		/* Keeping only the fresh output must not retain any input or managed caller graph. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 8U; index++) {
			cell = vm_heap_find_cell(page->heap, invoke_case.addresses[index]);
			if (cell != NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* The sole rooted result must remain alive until its own final embedding edge retires. */
		cell = vm_heap_find_cell(page->heap, invoke_case.addresses[8]);
		if (cell == NULL) {
			status = 1;
			goto cleanup;
		}

		/* Retire the final output owner before checking actual result reclamation. */
		roots[7] = NULL;
		vm_heap_collect(page->heap);
		cell = vm_heap_find_cell(page->heap, invoke_case.addresses[8]);
		if (cell != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* Both operation modes satisfied all independent ownership and reclamation gates. */
	status = 0;

cleanup:
	/* The weak observer and successful root registrations retire on every outcome. */
	memset(&invoke_case, 0, sizeof(invoke_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve protocol errors and failed lifetime observations. */
	if (status != 0)
		return status;

	/* Succeeded: Call and Construct retain their graph only for the duration of the direct operation. */
	return 0;
}
