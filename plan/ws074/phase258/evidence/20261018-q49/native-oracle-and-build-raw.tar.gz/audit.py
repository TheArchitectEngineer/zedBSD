from pathlib import Path
import json,gzip,collections,hashlib,tarfile,subprocess,shutil,re
q=Path('build/ws074-20261018/q49');root=q/'final/after-harness';oldroot=Path('build/ws074-20261018/q48/final/after-harness');old={};new={};entries=[];files=[]
for r in json.loads((oldroot/'results.json').read_text()):old[r['id']]=json.loads(gzip.decompress((oldroot/r['report']).read_bytes()))
for p in sorted(root.glob('shard-*/report.json')):
 d=json.loads(p.read_text());assert d['eligible']==1508 and d['eligible_sha256']=='82147e6edaec1b3b8d537e46eb71b64f2f03132cc12803e284c6ca72377779e7';assert [r for r in [json.loads(l) for l in (p.parent/'progress.jsonl').read_text().splitlines()] if r['kind']=='result']==d['results'];files += [p,p.parent/'progress.jsonl']
 for r in d['results']:
  data=gzip.decompress((p.parent/r['report']).read_bytes());assert (p.parent/r['report']).with_suffix('').read_bytes()==data;v=json.loads(data);assert v['test_id']==r['test_id'] and v['outcome']==r['outcome'];assert v['test_id'] not in new;new[v['test_id']]=v;files.append(p.parent/r['report']);entries.append(dict(id=v['test_id'],outcome=v['outcome'],report=str((p.parent/r['report']).relative_to(root))))
  if 'generated' in v:
   raw=Path(v['generated']['raw_directory']);files.extend(p for p in raw.rglob('*') if p.is_file());assert json.loads((raw/'provider.json').read_text())==v['generated'];assert (raw/'stdout.bin').read_bytes().decode('utf8',errors='replace')==v['stdout']
assert len(new)==1508 and set(old)==set(new)
(root/'results.json').write_text(json.dumps(entries,indent=2)+'\n');files += [root/'results.json',root/'runs.json']
changes=[];passloss=[]
for k,a in old.items():
 b=new[k];ap=collections.Counter(c['name'] for c in a['result_callbacks'] if c['status']==0);bp=collections.Counter(c['name'] for c in b['result_callbacks'] if c['status']==0)
 if ap-bp:passloss.append(dict(id=k,lost=dict(ap-bp)))
 if (a['outcome'],a['result_callbacks'],a['completion'])!=(b['outcome'],b['result_callbacks'],b['completion']):changes.append(dict(id=k,old_outcome=a['outcome'],new_outcome=b['outcome'],old_callback_counts=dict(collections.Counter(str(c['status']) for c in a['result_callbacks'])),new_callback_counts=dict(collections.Counter(str(c['status']) for c in b['result_callbacks'])),old_completion=a['completion'],new_completion=b['completion'],stdout_tail=b['stdout'][-4500:]))
proof=dict(completed=len(new),counts=dict(collections.Counter(r['outcome'] for r in new.values())),callbacks=dict(collections.Counter(str(c['status']) for r in new.values() for c in r['result_callbacks'])),whole_pass_losses=[k for k in new if old[k]['outcome']=='pass' and new[k]['outcome']!='pass'],whole_pass_gains=[k for k in new if old[k]['outcome']!='pass' and new[k]['outcome']=='pass'],old_pass_callback_losses=passloss,changes=changes)
(q/'harness-outcome-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print({k:v for k,v in proof.items() if k!='changes'},flush=True);print('changes',[(r['id'],r['old_outcome'],r['new_outcome']) for r in changes],flush=True)
assert not proof['whole_pass_losses'] and not passloss
# Gain certification is a separate human-readable prerequisite review before reconciliation.
(q/'harness-files.json').write_text(json.dumps([str(p) for p in files],indent=2)+'\n')
