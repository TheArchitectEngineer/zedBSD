from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
q=Path('build/ws074-20261018/q49');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q49')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in source.items())
h=json.loads((q/'harness-outcome-audit.json').read_text());assert h['completed']==1508 and not h['whole_pass_losses'] and not h['whole_pass_gains'] and not h['old_pass_callback_losses'] and not h['changes']
p=json.loads((q/'final-protocol.json').read_text());assert p['conditions']==726 and p['native_matches'] and not p['chrome_matches'] and p['chrome_qualified_comparison_complete'] and p['chrome_matching_individual_conditions']==724 and len(p['known_huge_length_differences'])==2 and p['native_global_not_exposed_and_ownership']
pre=json.loads((q/'precode-native-proof.json').read_text());assert len(pre['failed'])==22 and pre['returncode']==1 and [r['returncode'] for r in pre['gc_isolated']]==[-11,-11,1,1,1,1]
public=json.loads((q/'public-precode-final-proof.json').read_text());assert public['new36_genuine_all_match'] and public['precode22_all_final_native_and_chrome_PASS'] and public['all6_gc_final_native_and_chrome_PASS']
runs=json.loads((v/'native-runs.json').read_text());assert len(runs)==12 and all(x['returncode']==0 for x in runs)
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
n=json.loads((q/'native-proof.json').read_text());old=json.loads(Path('build/ws074-20261018/q38/native-proof.json').read_text());assert len(n['runs'])==4
for a,b in zip(n['runs'],old['runs']):assert a['callbacks']==b['callbacks'] and a['source_sha256']==b['source_sha256'] and a['returncode']==0 and a['ownership'] and a['end']
validator=json.loads((q/'webidl-validator-proof.json').read_text());a,b=validator['runs'];assert a['callbacks']==b['callbacks'] and [r['status'] for r in a['callbacks']]==[0,0,1] and a['returncode']==b['returncode']==0 and b['ownership']
assert not any(x in (q/'host-build-final.log').read_text() for x in ['warning:','error:'])
for f in q.glob('target-*.log'):assert not f.read_bytes()
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
style=json.loads((q/'source-audit.json').read_text());assert style['raw_allowed_cleanup']==26 and style['other_checker_findings']==0
out.mkdir(parents=True,exist_ok=False);archives={}
def archive(label,paths,base):
 mapping={str(p.resolve().relative_to(base.resolve())):p for p in paths};artifact=out/(label+'.tar.gz')
 with tarfile.open(artifact,'w:gz') as t:
  for name,path in sorted(mapping.items()):t.add(path,arcname=name,recursive=False)
 with tarfile.open(artifact,'r:gz') as t:
  count=0
  for member in t:assert t.extractfile(member).read()==mapping[member.name].read_bytes();count+=1
 assert count==len(mapping);archives[label]=dict(sha256=digest(artifact),members=count,all_members_readback=True)
archive('harness-all-raw',[Path(p) for p in json.loads((q/'harness-files.json').read_text())],v/'after-harness')
paths=[f for f in q.rglob('*') if f.is_file() and f.suffix in ['.py','.sh','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'after-harness' not in f.parts and 'engine' not in f.parts and 'target' not in f.parts and not any(x.endswith('-data') or x=='data' for x in f.parts)];paths.append(v/'engine/proxy-read.js');archive('native-oracle-and-build-raw',paths,q)
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),selection='1a215fd22',source_hash_count=len(source),conditions=726,native_pass=726,chrome_pass=724,new_conditions=36,precode_functional_conditions_failed=22,precode_gc_isolated_returncodes=[-11,-11,1,1,1,1],final_all36_genuine_chrome_match=True,old690_prefix_unchanged=True,all_chrome_equality=False,oracle='q36 classifier filter inherited; q43 huge2 native primary versus Chrome pre-index RangeError retained; all new36 genuine rows match',full_changed_C=style,native_gates=runs,GC='actual bridge collect with conservative stack disabled; precode two detached ancestors SIGSEGV and four functional failures; final six input results pass. No new weak-address reclamation fixture measured.',acid3_score=100,acid3_inventory=100,acid3_pixels=0,acid2_existing_pixels=873,original_webidl_q38_same_callbacks=True,additional_validator_negative_rule_callbacks=a['callbacks'],harness=h,harness_seconds=json.loads((v/'after-harness/runs.json').read_text())[-1]['seconds'],harness_comparison='q48 whole and every callback/completion',timing_investigation=json.loads((q/'timing-investigation/comparison.json').read_text()),first128_seconds={'q48':44.0,'q49':140.1},performance_equivalence_not_claimed=True,official_score=1482,denominator=3805,held=0,unattempted=275,static_scripted_crash_reused='q28',current_pair_images_crash_not_measured=True,archives=archives,main_integration=json.loads((q/'main-integration.json').read_text()),remaining=['JSON parse/reviver ownership and Proxy routing','uint32/int32 length/storage width, JSON_DEPTH_MAX resource policy, RawJSON','Species/newtarget/callable Proxy/for-in/spread/primitive Set/outer instanceof/BoundFunction/call/construct/global Proxy/revocable/Reflect','immutable prototype/typed backing/p100/full target/WS acceptance','master.md not edited; shared projections pending Q1'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['approval-snapshot.md','final-protocol.json','precode-native-proof.json','precode-gc-proof.json','public-precode-final-proof.json','source-audit.json','old-prefix-proof.json','versions.json','native-proof.json','webidl-validator-proof.json','target-commands-1.json','harness-outcome-audit.json','main-integration.json']:shutil.copy2(q/name,out/name)
for name in ['source-proof.json','source-commit.txt','shared-input-comparison.json','native-runs.json']:shutil.copy2(v/name,out/name)
shutil.copy2(v/'acid/report.json',out/'acid-report.json');print('archives',archives)
