from pathlib import Path
import subprocess,time,json,os
q=Path('build/ws074-20261018/q49');out=q/'timing-investigation';out.mkdir(exist_ok=False);rows=[]
for cycle in ['q48','q49']:
 program=Path('build/ws074-20261018')/cycle/'final/engine/browser';cmd=['python3','plan/ws074/tests/run-interop2025-harness.py','--manifest','plan/ws074/phase173/evidence/20261013-q1012/manifest.json','--program',str(program.resolve()),'--test-id','/css/css-flexbox/parsing/flex-flow-valid.html','--out',str(out/(cycle+'.json')),'--settle-ms','5000','--process-timeout','20','--font-dir','userland/desktop/fonts'];start=time.monotonic()
 with (out/(cycle+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=log,timeout=30,env=dict(os.environ,XDG_DATA_HOME=str((out/(cycle+'-data')).resolve())))
 d=json.loads((out/(cycle+'.json')).read_text());row=dict(cycle=cycle,command=cmd,seconds=round(time.monotonic()-start,3),returncode=r.returncode,outcome=d['outcome'],callbacks=d['result_callbacks'],completion=d['completion']);rows.append(row);print(cycle,row['seconds'],d['outcome'],flush=True)
(out/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n');assert (rows[0]['outcome'],rows[0]['callbacks'],rows[0]['completion'])==(rows[1]['outcome'],rows[1]['callbacks'],rows[1]['completion'])
