static int json_stringify(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int json_property(struct json_writer *writer, vm_value holder, vm_value key, int *written);
static int json_property_inner(struct json_property_roots *roots, int *written);
static int json_property_list(struct json_writer *writer, vm_value replacer);
static int json_property_list_inner(struct json_property_roots *roots);
static int json_serialize_object(struct json_writer *writer, vm_value object);
static void json_trace_values(struct vm_heap *heap, void *context);
static void json_trace_writer(struct vm_heap *heap, void *context);
static void json_trace_property(struct vm_heap *heap, void *context);

static int
json_stringify(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct json_writer writer;
	struct vm_object *wrapper;
	struct vm_string *text;
	vm_value key;
	vm_value argument;
	vm_value replacer;
	int traced;
	int written;
	int callable;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The writer, the replacer or property list, and the gap. */
	memset(&writer, 0, sizeof(writer));
	writer.realm = realm;
	writer.replacer = VM_VALUE_UNDEFINED;
	writer.keys = VM_VALUE_UNDEFINED;
	writer.holder = VM_VALUE_UNDEFINED;
	writer.root_key = VM_VALUE_UNDEFINED;
	wb_units_init(&writer.gap);
	wb_units_init(&writer.indent);
	wb_units_init(&writer.out);
	wb_vector_init(&writer.stack, sizeof(vm_value));
	/* Register fully initialized writer storage before any replacer or spacing callback. */
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, json_trace_writer, &writer);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* Choose callable replacement before considering a property-list array. */
	replacer = js_argument(args, count, 1);
	callable = vm_value_is_callable(replacer);
	status = 0;
	if (callable) {
		writer.replacer = replacer;
	} else {
		status = json_property_list(&writer, replacer);
		if (status != 0)
			goto cleanup;
	}

	/* The optional gap is prepared after the replacer list has settled. */
	argument = js_argument(args, count, 2);
	status = json_space(&writer, argument);
	if (status != 0)
		goto cleanup;

	/* The value, as the "" property of a wrapper object. */
	wrapper = vm_object_create(realm->heap, realm->object_prototype);
	if (wrapper == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Retain the unpublished holder before allocating its empty key. */
	writer.holder = vm_value_cell(wrapper);

	/* The key "". */
	status = js_builtin_string(realm, "", &key);
	if (status != 0)
		goto cleanup;

	/* The key remains owned if interning or holder definition collects. */
	writer.root_key = key;

	/* Interns the key before publishing the original value in its holder. */
	status = vm_key_from_string(realm->heap, (struct vm_string *)vm_value_as_cell(key), &key);
	if (status != 0)
		goto cleanup;

	/* The key remains owned if interning or holder definition collects. */
	writer.root_key = key;

	/* The original argument remains unchanged until serialization starts. */
	argument = js_argument(args, count, 0);
	status = vm_object_define(realm->heap, wrapper, key, argument, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;

	/* Serializes the holder property with its root key. */
	written = 0;
	status = json_property(&writer, vm_value_cell(wrapper), key, &written);
	if (status != 0)
		goto cleanup;

	/* The text, or undefined when the value has none. */
	*result = VM_VALUE_UNDEFINED;
	if (written) {
		text = vm_string_from_units(realm->heap, writer.out.data, writer.out.length);
		if (text == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Publishes the complete allocated serialization. */
		*result = vm_value_cell(text);
	}

	/* The writer's buffers are no longer needed. */
cleanup:
	if (traced)
		vm_heap_remove_tracer(realm->heap, json_trace_writer, &writer);
	wb_units_release(&writer.gap);
	wb_units_release(&writer.indent);
	wb_units_release(&writer.out);
	wb_vector_release(&writer.stack);
	if (status != 0) {
		*result = VM_VALUE_UNDEFINED;
		return status;
	}

	/* Succeeded: complete text or the original undefined outcome is available. */
	return 0;
}

static int
json_property(
	struct json_writer *writer,
	vm_value holder,
	vm_value key,
	int *written)
{
	struct json_property_roots roots;
	int status;

	/* Initialize every traced slot before publishing native storage to the collector. */
	roots.writer = writer;
	roots.holder = holder;
	roots.key = key;
	roots.value = VM_VALUE_UNDEFINED;
	roots.method = VM_VALUE_UNDEFINED;
	roots.key_value = VM_VALUE_UNDEFINED;
	roots.method_key = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(writer->realm->heap, json_trace_property, &roots);
	if (status != 0)
		return status;

	/* All early exits from the property algorithm pass through this ownership boundary. */
	status = json_property_inner(&roots, written);
	vm_heap_remove_tracer(writer->realm->heap, json_trace_property, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the completed property no longer owns callback temporaries. */
	return 0;
}

static int
json_property_inner(
	struct json_property_roots *roots,
	int *written)
{
	struct json_writer *writer;
	struct vm_realm *realm;
	struct vm_bigint *bigint;
	struct vm_object *object;
	struct vm_string *string;
	vm_value call_args[2];
	double number;
	int is_array;
	int has_tojson;
	int is_object;
	int is_string;
	int is_number;
	int infinite;
	int callable;
	int status;

	/* Load the actual holder property into the traced value slot. */
	writer = roots->writer;
	realm = writer->realm;
	*written = 0;
	status = vm_get(realm, roots->holder, roots->key, &roots->value);
	if (status != 0)
		return status;

	/* Objects and primitive BigInts consult toJSON before the replacer. */
	is_object = vm_value_is_object(roots->value);
	bigint = vm_value_as_bigint(roots->value);
	has_tojson = is_object;
	if (bigint != NULL)
		has_tojson = 1;
	if (has_tojson) {
		roots->method_key = vm_key_from_ascii(realm->heap, "toJSON");
		if (roots->method_key == VM_VALUE_EMPTY)
			return ENOMEM;

		/* Reads the callback only after its key allocation is checked. */
		status = vm_get(realm, roots->value, roots->method_key, &roots->method);
		if (status != 0)
			return status;
		callable = vm_value_is_callable(roots->method);
		if (callable) {
			status = json_key_value(realm, roots->key, &roots->key_value);
			if (status != 0)
				return status;

			/* Invokes the actual callback after its arguments are ready. */
			status = vm_call(realm, roots->method, roots->value, &roots->key_value, 1, &roots->value);
			if (status != 0)
				return status;
		}
	}

	/* The replacer receives the original holder and a string key. */
	if (writer->replacer != VM_VALUE_UNDEFINED) {
		status = json_key_value(realm, roots->key, &roots->key_value);
		if (status != 0)
			return status;

		/* Calls the replacer after its string key is ready. */
		call_args[0] = roots->key_value;
		call_args[1] = roots->value;

		/* Invokes the actual callback after its arguments are ready. */
		status = vm_call(realm, writer->replacer, roots->holder, call_args, 2, &roots->value);
		if (status != 0)
			return status;
	}

	/* A wrapper stands for its primitive. */
	is_object = vm_value_is_object(roots->value);
	if (is_object) {
		object = (struct vm_object *)vm_value_as_cell(roots->value);
		if (object->kind == VM_KIND_NUMBER) {
			status = vm_to_number(realm, roots->value, &number);
			if (status != 0)
				return status;
			roots->value = vm_value_number(number);
		} else if (object->kind == VM_KIND_STRING) {
			status = vm_to_string(realm, roots->value, &string);
			if (status != 0)
				return status;
			roots->value = vm_value_cell(string);
		} else if (object->kind == VM_KIND_BOOLEAN) {
			roots->value = object->internal;
		}
	}

	/* Boxed BigInts expose their stored primitive only after toJSON and replacement. */
	is_object = vm_value_is_object(roots->value);
	if (is_object) {
		object = (struct vm_object *)vm_value_as_cell(roots->value);
		if (object->kind == VM_KIND_BIGINT)
			roots->value = object->internal;
	}

	/* A remaining primitive BigInt has no JSON form. */
	bigint = vm_value_as_bigint(roots->value);
	if (bigint != NULL) {
		status = vm_throw_type_error(realm, "Do not know how to serialize a BigInt");
		if (status != 0)
			return status;

		/* Succeeded: the VM accepted the exception report. */
		return 0;
	}

	/* The kinds of value. */
	*written = 1;
	if (roots->value == VM_VALUE_NULL) {
		status = json_text(writer, "null");
		if (status != 0)
			return status;

		/* Succeeded: the value has its complete JSON text. */
		return 0;
	}

	/* true and false. */
	if (roots->value == VM_VALUE_TRUE) {
		status = json_text(writer, "true");
		if (status != 0)
			return status;

		/* Succeeded: the value has its complete JSON text. */
		return 0;
	}

	/* false. */
	if (roots->value == VM_VALUE_FALSE) {
		status = json_text(writer, "false");
		if (status != 0)
			return status;

		/* Succeeded: the value has its complete JSON text. */
		return 0;
	}

	/* A string. */
	is_string = vm_value_is_string(roots->value);
	if (is_string) {
		status = json_quote(writer, (struct vm_string *)vm_value_as_cell(roots->value));
		if (status != 0)
			return status;

		/* Succeeded: the value has its complete JSON text. */
		return 0;
	}

	/* A number. */
	is_number = vm_value_is_number(roots->value);
	if (is_number) {
		number = vm_value_as_number(roots->value);
		infinite = isinf(number);
		if (number != number || infinite) {
			status = json_text(writer, "null");
			if (status != 0)
				return status;

			/* Succeeded: the value has its complete JSON text. */
			return 0;
		}

		/* Its numeral. */
		status = vm_to_string(realm, roots->value, &string);
		if (status != 0)
			return status;

		/* Appends the completed number representation to the output. */
		status = vm_string_append_units(string, &writer->out);
		if (status != 0)
			return status;

		/* Succeeded: the value has its complete JSON text. */
		return 0;
	}

	/* An object that is not a function. */
	is_object = vm_value_is_object(roots->value);
	callable = vm_value_is_callable(roots->value);
	if (is_object && !callable) {
		/* Classify actual Proxy target chains and propagate revoked-array failures. */
		status = vm_is_array(realm, roots->value, &is_array);
		if (status != 0)
			return status;
		if (is_array)
			status = json_serialize_array(writer, roots->value);
		else
			status = json_serialize_object(writer, roots->value);
		if (status != 0)
			return status;

		/* Succeeded: the value has its complete JSON text. */
		return 0;
	}

	/* undefined, a function, a symbol: no text. */
	*written = 0;
	return 0;
}

static int
json_property_list(
	struct json_writer *writer,
	vm_value replacer)
{
	struct json_property_roots roots;
	int status;

	/* The writer owns the normalized list; this frame owns the current unboxed element. */
	roots.writer = writer;
	roots.holder = replacer;
	roots.key = VM_VALUE_UNDEFINED;
	roots.value = VM_VALUE_UNDEFINED;
	roots.method = VM_VALUE_UNDEFINED;
	roots.key_value = VM_VALUE_UNDEFINED;
	roots.method_key = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(writer->realm->heap, json_trace_property, &roots);
	if (status != 0)
		return status;

	/* Release the element frame after success or any abrupt coercion. */
	status = json_property_list_inner(&roots);
	vm_heap_remove_tracer(writer->realm->heap, json_trace_property, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the writer retains the completed deduplicated list. */
	return 0;
}

static int
json_property_list_inner(
	struct json_property_roots *roots)
{
	struct json_writer *writer;
	struct vm_object *object;
	struct vm_object *list;
	struct vm_string *string;
	vm_value key;
	vm_value listed;
	uint32_t length;
	uint32_t index;
	uint32_t other;
	int is_array;
	int is_object;
	int is_string;
	int is_number;
	int duplicate;
	int same;
	int status;

	/* Actual array classification follows nested targets and rejects revoked replacers. */
	writer = roots->writer;
	status = vm_is_array(writer->realm, roots->holder, &is_array);
	if (status != 0)
		return status;
	if (!is_array)
		return 0;

	/* Each usable element as a string, once. */
	list = vm_array_create(writer->realm->heap, writer->realm->array_prototype);
	if (list == NULL)
		return ENOMEM;

	/* Retains the native property list in the active writer. */
	writer->keys = vm_value_cell(list);
	status = js_builtin_length(writer->realm, roots->holder, &length);
	if (status != 0)
		return status;

	/* Coerces and deduplicates the snapshot of requested indices. */
	for (index = 0; index < length; index++) {
		status = vm_get(writer->realm, roots->holder, vm_value_int32((int32_t)index), &roots->value);
		if (status != 0)
			return status;
		is_object = vm_value_is_object(roots->value);
		if (is_object) {
			object = (struct vm_object *)vm_value_as_cell(roots->value);
			if (object->kind != VM_KIND_STRING && object->kind != VM_KIND_NUMBER)
				continue;
		} else {
			is_string = vm_value_is_string(roots->value);
			is_number = vm_value_is_number(roots->value);
			if (!is_string && !is_number)
				continue;
		}

		/* As a string. */
		status = vm_to_string(writer->realm, roots->value, &string);
		if (status != 0)
			return status;
		roots->key_value = vm_value_cell(string);

		/* Compare only normalized names while retaining the converted string through definition. */
		duplicate = 0;
		for (other = 0; other < list->length; other++) {
			listed = list->elements[other];
			same = vm_string_equal((struct vm_string *)vm_value_as_cell(listed), string);
			if (same)
				duplicate = 1;
		}

		/* A name listed already is skipped. */
		if (duplicate)
			continue;
		key = vm_value_cell(string);
		status = vm_object_define(writer->realm->heap, list, vm_value_int32((int32_t)list->length), key, VM_PROPERTY_DEFAULT);
		if (status != 0)
			return status;
	}

	/* Reports whether the list was made. */
	if (status != 0)
		return status;

	/* Succeeded: the deduplicated property list is retained in the writer. */
	return 0;
}

static int
json_serialize_object(
	struct json_writer *writer,
	vm_value object)
{
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	size_t mark;
	size_t selected;
	size_t item;
	size_t indent_length;
	uint32_t length;
	uint32_t index;
	vm_value key;
	vm_value name;
	const char *colon;
	int traced;
	int first;
	int found;
	int written;
	int is_index;
	int is_string;
	int status;

	/* A cycle is an error. */
	status = json_enter(writer, object);
	if (status != 0)
		return status;

	/* The keys. */
	wb_vector_init(&keys, sizeof(vm_value));
	indent_length = writer->indent.length;
	traced = 0;
	status = vm_heap_add_tracer(writer->realm->heap, json_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;
	if (writer->keys != VM_VALUE_UNDEFINED) {
		status = js_builtin_length(writer->realm, writer->keys, &length);
		if (status != 0)
			goto cleanup;

		/* Snapshots each requested replacer property before output starts. */
		for (index = 0; index < length; index++) {
			status = vm_get(writer->realm, writer->keys, vm_value_int32((int32_t)index), &name);
			if (status != 0)
				goto cleanup;

			/* Resolves the replacer name as a native property key. */
			status = vm_to_key(writer->realm, name, &key);
			if (status != 0)
				goto cleanup;

			/* Adds the resolved key to the owned snapshot. */
			status = wb_vector_push(&keys, &key);
			if (status != 0)
				goto cleanup;
		}
	} else {
		status = vm_own_property_keys(writer->realm, (struct vm_object *)vm_value_as_cell(object), &keys);
		if (status != 0)
			goto cleanup;

		/* Snapshot every enumerable string key before the first value getter can change another descriptor. */
		selected = 0;
		for (item = 0; item < keys.count; item++) {
			key = *(vm_value *)wb_vector_at(&keys, item);
			is_index = vm_value_is_int32(key);
			is_string = vm_value_is_string(key);
			if (!is_index && !is_string)
				continue;

			/* Symbols never invoke GetOwnProperty during string-key enumeration. */
			status = vm_get_own_property(writer->realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
			if (status != 0)
				goto cleanup;
			if (!found)
				continue;
			if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
				continue;

			/* Retain unvisited keys until classification ends, then expose only selected names. */
			*(vm_value *)wb_vector_at(&keys, selected) = key;
			selected++;
		}

		/* Publish the complete enumerable-string snapshot before reading any value. */
		keys.count = selected;
	}

	/* Each property with a text: "key": value (a space after the colon when indenting). */
	colon = ":";
	if (writer->gap.length > 0)
		colon = ": ";

	/* Extends indentation by the configured gap. */
	status = wb_units_append(&writer->indent, writer->gap.data, writer->gap.length);
	if (status != 0)
		goto cleanup;

	/* Writes the opening object delimiter. */
	status = json_text(writer, "{");
	if (status != 0)
		goto cleanup;

	/* The first written member omits its leading separator. */
	first = 1;
	for (item = 0; item < keys.count; item++) {
		key = *(vm_value *)wb_vector_at(&keys, item);
		is_index = vm_value_is_int32(key);
		is_string = vm_value_is_string(key);
		if (!is_index && !is_string)
			continue;

		/* Where the member starts, to take it back when it has no text. */
		mark = writer->out.length;
		if (!first)
			status = json_text(writer, ",");
		if (status != 0)
			goto cleanup;

		/* Starts the member at the current indentation. */
		status = json_newline(writer);
		if (status != 0)
			goto cleanup;

		/* Converts the property key to its JSON name. */
		status = json_key_value(writer->realm, key, &name);
		if (status != 0)
			goto cleanup;

		/* Quotes the completed property name. */
		status = json_quote(writer, (struct vm_string *)vm_value_as_cell(name));
		if (status != 0)
			goto cleanup;

		/* Separates the property name from its serialized value. */
		status = json_text(writer, colon);
		if (status != 0)
			goto cleanup;

		/* Serializes the actual holder property. */
		status = json_property(writer, object, key, &written);
		if (status != 0)
			goto cleanup;

		/* Removes speculative key text only when the value has no JSON text. */
		if (!written) {
			writer->out.length = mark;
			continue;
		}

		/* The next member follows a comma. */
		first = 0;
	}

	/* The indentation back, and the end. */
	writer->indent.length = indent_length;
	if (!first) {
		status = json_newline(writer);
		if (status != 0)
			goto cleanup;
	}

	/* Writes the closing object delimiter. */
	status = json_text(writer, "}");
	if (status != 0)
		goto cleanup;

	/* Restores indentation and releases the one key snapshot on either outcome. */
cleanup:
	writer->indent.length = indent_length;
	if (traced)
		vm_heap_remove_tracer(writer->realm->heap, json_trace_values, &keys);
	wb_vector_release(&keys);
	if (status == 0)
		writer->stack.count--;
	if (status != 0)
		return status;

	/* Succeeded: the object output is closed and its key snapshot released. */
	return 0;
}

static void
json_trace_values(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *values;
	size_t index;
	vm_value value;

	/* Only published vector entries contain valid VM values. */
	values = context;
	for (index = 0; index < values->count; index++) {
		value = *(vm_value *)wb_vector_at(values, index);
		vm_heap_mark_value(heap, value);
	}
}

static void
json_trace_writer(
	struct vm_heap *heap,
	void *context)
{
	struct json_writer *writer;

	/* Managed realm ownership and serialized ancestors outlive every nested VM call. */
	writer = context;
	if (writer->realm->managed)
		vm_heap_mark(heap, &writer->realm->cell);
	vm_heap_mark_value(heap, writer->replacer);
	vm_heap_mark_value(heap, writer->keys);
	vm_heap_mark_value(heap, writer->holder);
	vm_heap_mark_value(heap, writer->root_key);
	json_trace_values(heap, &writer->stack);
}

static void
json_trace_property(
	struct vm_heap *heap,
	void *context)
{
	struct json_property_roots *roots;

	/* Every slot is initialized before registration, including primitive and absent values. */
	roots = context;
	vm_heap_mark_value(heap, roots->holder);
	vm_heap_mark_value(heap, roots->key);
	vm_heap_mark_value(heap, roots->value);
	vm_heap_mark_value(heap, roots->method);
	vm_heap_mark_value(heap, roots->key_value);
	vm_heap_mark_value(heap, roots->method_key);
}
