(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-gc-fresh-array-from-getter',function(){return JSON.stringify({get a(){return [1,{get toJSON(){collectReadProxy();return function(){return 2;};}},3];}})==='{"a":[1,2,3]}';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
