(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-gc-fresh-replacer-result-recursive',function(){return JSON.stringify({a:1},function(k,v){if(k==='a')return {x:{get toJSON(){collectReadProxy();return function(){return 3;};}},y:4};return v;})==='{"a":{"x":3,"y":4}}';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
