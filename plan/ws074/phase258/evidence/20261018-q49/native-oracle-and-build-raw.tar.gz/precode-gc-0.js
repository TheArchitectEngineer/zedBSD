(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-gc-detached-ancestor-and-fresh-tojson',function(){var source={get a(){return {x:{get toJSON(){collectReadProxy();return function(){return 1;};}},y:2};}};return JSON.stringify(source)==='{"a":{"x":1,"y":2}}';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
