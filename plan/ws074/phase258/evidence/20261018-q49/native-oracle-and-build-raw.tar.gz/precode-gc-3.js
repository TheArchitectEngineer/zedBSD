(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-gc-fresh-list-element-coercion',function(){var p=makeReadProxy(['unused'],{get:function(t,k){if(k==='0'){var n=new String('a');n.toString=function(){collectReadProxy();return 'a';};return n;}return t[k];}});return JSON.stringify({a:1,b:2},p)==='{"a":1}';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
