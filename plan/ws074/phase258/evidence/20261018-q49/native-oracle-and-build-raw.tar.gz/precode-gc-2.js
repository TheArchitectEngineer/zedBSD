(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-gc-propertylist-normalized-through-space',function(){var space=new Number(1);space.valueOf=function(){collectReadProxy();return 0;};return JSON.stringify({a:1,b:2},['b','a'],space)==='{"b":2,"a":1}';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
