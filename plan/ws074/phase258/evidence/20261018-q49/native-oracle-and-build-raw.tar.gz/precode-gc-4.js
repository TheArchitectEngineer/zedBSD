(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-gc-ownkeys-descriptor-and-values',function(){var p=makeReadProxy({a:1,b:2},{ownKeys:function(){return ['b','a'];},getOwnPropertyDescriptor:function(t,k){collectReadProxy();return Object.getOwnPropertyDescriptor(t,k);},get:function(t,k){collectReadProxy();return t[k];}});return JSON.stringify(p)==='{"b":2,"a":1}';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
