from pathlib import Path
import re
p=Path('userland/desktop/libbrowser/js/builtin_json.c');s=p.read_text();original=s
s=s.replace('VM values follow ordinary realm and conservative native caller ownership.','a registered tracer retains all managed state across reentrant callbacks.')
s=s.replace('\tvm_value keys;\n','\tvm_value keys;\n\tvm_value holder;\n\tvm_value root_key;\n',1)
pos=s.index('static int json_parse(')
s=s[:pos]+'''/* One property operation retains its receiver, key and callback temporaries until every early return has retired. */
struct json_property_roots {
 struct json_writer *writer;
 vm_value holder;
 vm_value key;
 vm_value value;
 vm_value method;
 vm_value key_value;
 vm_value method_key;
};

'''+s[pos:]
pos=s.index('/*\n * Installs JSON.')
s=s[:pos]+'''static void json_trace_values(struct vm_heap *heap, void *context);
static void json_trace_writer(struct vm_heap *heap, void *context);
static void json_trace_property(struct vm_heap *heap, void *context);
static int json_property_inner(struct json_property_roots *roots, int *written);
static int json_property_list_inner(struct json_property_roots *roots);

'''+s[pos:]
def get(name):
 m=re.search(r'static int\n'+name+r'\(\n.*?\n\}',s,re.S);assert m;return m
m=get('json_stringify');f=m.group();f=f.replace('\tint written;','\tint traced;\n\tint written;',1);f=f.replace('\twriter.keys = VM_VALUE_UNDEFINED;','\twriter.keys = VM_VALUE_UNDEFINED;\n\twriter.holder = VM_VALUE_UNDEFINED;\n\twriter.root_key = VM_VALUE_UNDEFINED;');f=f.replace('\treplacer = js_argument(args, count, 1);','''	/* Register fully initialized writer storage before any replacer or spacing callback. */
 traced = 0;
 status = vm_heap_add_tracer(realm->heap, json_trace_writer, &writer);
 if (status != 0)
  goto cleanup;
 traced = 1;

 /* Choose callable replacement before considering a property-list array. */
 replacer = js_argument(args, count, 1);''');f=f.replace('\t/* The key "". */','\t/* Retain the unpublished holder before allocating its empty key. */\n\twriter.holder = vm_value_cell(wrapper);\n\n\t/* The key "". */');f=f.replace('\t/* Interns the key before publishing','\twriter.root_key = key;\n\n\t/* Interns the key before publishing');f=f.replace('\t/* The original argument remains','\twriter.root_key = key;\n\n\t/* The original argument remains');f=f.replace('cleanup:\n','cleanup:\n\tif (traced)\n\t\tvm_heap_remove_tracer(realm->heap, json_trace_writer, &writer);\n',1);s=s[:m.start()]+f+s[m.end():]
m=get('json_property');f=m.group();f=f.replace('json_property(\n\tstruct json_writer *writer,\n\tvm_value holder,\n\tvm_value key,\n\tint *written)','json_property_inner(\n\tstruct json_property_roots *roots,\n\tint *written)');f=f.replace('\tstruct vm_realm *realm;','\tstruct json_writer *writer;\n\tstruct vm_realm *realm;\n\tstruct vm_bigint *bigint;');
for line in ['\tvm_value value;\n','\tvm_value method;\n','\tvm_value method_key;\n','\tvm_value key_value;\n']:f=f.replace(line,'')
f=f.replace('\tint is_object;','\tint is_array;\n\tint has_tojson;\n\tint is_object;',1)
f=f.replace('\trealm = writer->realm;','\twriter = roots->writer;\n\trealm = writer->realm;',1)
# Replace variable references only, without changing field names in descriptors or literal strings.
for name in ['holder','key','value','method','method_key','key_value']:
 f=re.sub(r'(?<![\w.>])'+name+r'\b', 'roots->'+name, f)
# Keep comments intelligible after token substitutions.
f=re.sub(r'/\*.*?\*/',lambda m:m.group().replace('roots->',''),f,flags=re.S)
f=f.replace('is_object = vm_value_is_object(roots->value);\n\tif (is_object) {','''is_object = vm_value_is_object(roots->value);
 bigint = vm_value_as_bigint(roots->value);
 has_tojson = is_object;
 if (bigint != NULL)
  has_tojson = 1;
 if (has_tojson) {''',1)
f=f.replace('status = json_key_value(realm, roots->key, &call_args[0]);','status = json_key_value(realm, roots->key, &roots->key_value);');f=f.replace('\t\tcall_args[1] = roots->value;','\t\tcall_args[0] = roots->key_value;\n\t\tcall_args[1] = roots->value;');start=f.index('\t/* A BigInt has no JSON form. */');end=f.index('\t/* The kinds of value. */',start)
f=f[:start]+'''	/* Boxed BigInts expose their stored primitive only after toJSON and replacement. */
 is_object = vm_value_is_object(roots->value);
 if (is_object) {
  object = (struct vm_object *)vm_value_as_cell(roots->value);
  if (object->kind == VM_KIND_BIGINT)
   roots->value = object->internal;
 }

 /* A remaining primitive BigInt has no JSON form. */
 bigint = vm_value_as_bigint(roots->value);
 if (bigint != NULL) {
  status = vm_throw_type_error(realm, "Do not know how to serialize a BigInt");
  if (status != 0)
   return status;

  /* Succeeded: the VM accepted the exception report. */
  return 0;
 }

'''+f[end:]
f=f.replace('''		object = (struct vm_object *)vm_value_as_cell(roots->value);
		if ((object->flags & VM_OBJECT_ARRAY) != 0U)''','''		/* Classify actual Proxy target chains and propagate revoked-array failures. */
  status = vm_is_array(realm, roots->value, &is_array);
  if (status != 0)
   return status;
  if (is_array)''');s=s[:m.start()]+f+s[m.end():]
# A single traced wrapper owns all early returns from SerializeJSONProperty.
pos=s.index('/* Writes one property of a holder')
s=s[:pos]+'''/* Retain one holder operation until its callback and recursive serialization finish. */
static int
json_property(
 struct json_writer *writer,
 vm_value holder,
 vm_value key,
 int *written)
{
 struct json_property_roots roots;
 int status;

 /* Initialize every traced slot before publishing native storage to the collector. */
 roots.writer = writer;
 roots.holder = holder;
 roots.key = key;
 roots.value = VM_VALUE_UNDEFINED;
 roots.method = VM_VALUE_UNDEFINED;
 roots.key_value = VM_VALUE_UNDEFINED;
 roots.method_key = VM_VALUE_UNDEFINED;
 status = vm_heap_add_tracer(writer->realm->heap, json_trace_property, &roots);
 if (status != 0)
  return status;

 /* All early exits from the property algorithm pass through this ownership boundary. */
 status = json_property_inner(&roots, written);
 vm_heap_remove_tracer(writer->realm->heap, json_trace_property, &roots);
 if (status != 0)
  return status;

 /* Succeeded: the completed property no longer owns callback temporaries. */
 return 0;
}

'''+s[pos:]
m=get('json_serialize_object');f=m.group().replace('\tstruct vm_object *source;\n','').replace('\tsize_t item;','\tsize_t selected;\n\tsize_t item;').replace('\tint first;','\tint traced;\n\tint first;');f=f.replace('\tsource = (struct vm_object *)vm_value_as_cell(object);','''	traced = 0;
 status = vm_heap_add_tracer(writer->realm->heap, json_trace_values, &keys);
 if (status != 0)
  goto cleanup;
 traced = 1;''');f=f.replace('vm_object_own_keys(writer->realm->heap, source, &keys)','vm_own_property_keys(writer->realm, (struct vm_object *)vm_value_as_cell(object), &keys)');start=f.index('\t\tstatus = vm_own_property_keys');end=f.index('\n\t}\n',start)
f=f[:end]+'''

  /* Snapshot every enumerable string key before the first value getter can change another descriptor. */
  selected = 0;
  for (item = 0; item < keys.count; item++) {
   key = *(vm_value *)wb_vector_at(&keys, item);
   is_index = vm_value_is_int32(key);
   is_string = vm_value_is_string(key);
   if (!is_index && !is_string)
    continue;

   /* Symbols never invoke GetOwnProperty during string-key enumeration. */
   status = vm_get_own_property(writer->realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
   if (status != 0)
    goto cleanup;
   if (!found)
    continue;
   if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
    continue;

   /* Retain unvisited keys until classification ends, then expose only selected names. */
   *(vm_value *)wb_vector_at(&keys, selected) = key;
   selected++;
  }
  keys.count = selected;'''+f[end:]
start=f.index('\t\tif (writer->keys == VM_VALUE_UNDEFINED) {',f.index('first = 1;'));end=f.index('\n\t\t/* Where the member',start);f=f[:start]+f[end:];f=f.replace('\twb_vector_release(&keys);','\tif (traced)\n\t\tvm_heap_remove_tracer(writer->realm->heap, json_trace_values, &keys);\n\twb_vector_release(&keys);');s=s[:m.start()]+f+s[m.end():]
m=get('json_property_list');f=m.group();f=f.replace('json_property_list(\n\tstruct json_writer *writer,\n\tvm_value replacer)','json_property_list_inner(\n\tstruct json_property_roots *roots)');f=f.replace('\tstruct vm_object *object;','\tstruct json_writer *writer;\n\tstruct vm_object *object;',1).replace('\tvm_value element;\n','').replace('\tint is_object;','\tint is_array;\n\tint is_object;',1)
f=f.replace('''	/* Only an array. */
	is_object = vm_value_is_object(replacer);
	if (!is_object)
		return 0;
	object = (struct vm_object *)vm_value_as_cell(replacer);
	if ((object->flags & VM_OBJECT_ARRAY) == 0U)
		return 0;''','''	/* Actual array classification follows nested targets and rejects revoked replacers. */
 writer = roots->writer;
 status = vm_is_array(writer->realm, roots->holder, &is_array);
 if (status != 0)
  return status;
 if (!is_array)
  return 0;''');f=re.sub(r'\breplacer\b','roots->holder',f);f=re.sub(r'\belement\b','roots->value',f);f=f.replace('\t\tduplicate = 0;','\t\troots->key_value = vm_value_cell(string);\n\n\t\t/* Compare only normalized names while retaining the converted string through definition. */\n\t\tduplicate = 0;');f=re.sub(r'/\*.*?\*/',lambda m:m.group().replace('roots->holder','replacer').replace('roots->value','element'),f,flags=re.S);s=s[:m.start()]+f+s[m.end():]
pos=s.index('/* Makes the property list')
s=s[:pos]+'''/* Retain freshly returned list elements while their String or Number conversion runs script. */
static int
json_property_list(
 struct json_writer *writer,
 vm_value replacer)
{
 struct json_property_roots roots;
 int status;

 /* The writer owns the normalized list; this frame owns the current unboxed element. */
 roots.writer = writer;
 roots.holder = replacer;
 roots.key = VM_VALUE_UNDEFINED;
 roots.value = VM_VALUE_UNDEFINED;
 roots.method = VM_VALUE_UNDEFINED;
 roots.key_value = VM_VALUE_UNDEFINED;
 roots.method_key = VM_VALUE_UNDEFINED;
 status = vm_heap_add_tracer(writer->realm->heap, json_trace_property, &roots);
 if (status != 0)
  return status;

 /* Release the element frame after success or any abrupt coercion. */
 status = json_property_list_inner(&roots);
 vm_heap_remove_tracer(writer->realm->heap, json_trace_property, &roots);
 if (status != 0)
  return status;

 /* Succeeded: the writer retains the completed deduplicated list. */
 return 0;
}

'''+s[pos:]
pos=s.index('/* JSON.parse(text, reviver). */')
s=s[:pos]+'''/* Trace all initialized values copied into native vectors while callbacks run. */
static void
json_trace_values(
 struct vm_heap *heap,
 void *context)
{
 struct wb_vector *values;
 size_t index;
 vm_value value;

 /* Only published vector entries contain valid VM values. */
 values = context;
 for (index = 0; index < values->count; index++) {
  value = *(vm_value *)wb_vector_at(values, index);
  vm_heap_mark_value(heap, value);
 }
}

/* Retain the full active serialization, including objects detached from their original parents. */
static void
json_trace_writer(
 struct vm_heap *heap,
 void *context)
{
 struct json_writer *writer;

 /* Managed realm ownership and serialized ancestors outlive every nested VM call. */
 writer = context;
 if (writer->realm->managed)
  vm_heap_mark(heap, &writer->realm->cell);
 vm_heap_mark_value(heap, writer->replacer);
 vm_heap_mark_value(heap, writer->keys);
 vm_heap_mark_value(heap, writer->holder);
 vm_heap_mark_value(heap, writer->root_key);
 json_trace_values(heap, &writer->stack);
}

/* Retain callback results independently of the VM call frames which produced them. */
static void
json_trace_property(
 struct vm_heap *heap,
 void *context)
{
 struct json_property_roots *roots;

 /* Every slot is initialized before registration, including primitive and absent values. */
 roots = context;
 vm_heap_mark_value(heap, roots->holder);
 vm_heap_mark_value(heap, roots->key);
 vm_heap_mark_value(heap, roots->value);
 vm_heap_mark_value(heap, roots->method);
 vm_heap_mark_value(heap, roots->key_value);
 vm_heap_mark_value(heap, roots->method_key);
}

'''+s[pos:]
p.write_text(s);Path('build/ws074-20261018/q49/original-json.c').write_text(original)
