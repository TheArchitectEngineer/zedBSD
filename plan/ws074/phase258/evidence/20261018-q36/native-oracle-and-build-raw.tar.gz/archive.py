from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess,re
q=Path('build/ws074-20261018/q36');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q36');out.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in proof.items())
h=json.loads((q/'harness-outcome-audit.json').read_text());assert h['completed']==1508 and not h['whole_pass_losses'] and not h['old_pass_callback_losses']
protocol=json.loads((q/'final-protocol.json').read_text());assert protocol['native_matches'] and protocol['chrome_matches'] and protocol['conditions']==272 and protocol['native_global_not_exposed_and_ownership']
original=json.loads((q/'oracle-before-negative-zero/final-protocol.json').read_text());assert original['native_matches'] and not original['chrome_matches'] and original['chrome_lines'][-1]=='read-proxy controls: 271/272'
runs=json.loads((v/'native-runs.json').read_text());assert all(r['returncode']==0 for r in runs)
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
for p in q.glob('target-*.log'):assert not p.read_bytes(),p
style=json.loads((q/'style-review.json').read_text());assert style['raw_checker_flags']==51 and style['other_checker_flags']==0
archives={}
def archive(label,paths,base):
 mapping={str(p.resolve().relative_to(base.resolve())):p for p in paths};a=out/(label+'.tar.gz')
 with tarfile.open(a,'w:gz') as t:
  for name,p in sorted(mapping.items()):t.add(p,arcname=name,recursive=False)
 with tarfile.open(a,'r:gz') as t:
  count=0
  for m in t:assert t.extractfile(m).read()==mapping[m.name].read_bytes();count+=1
 assert count==len(mapping);archives[label]=dict(sha256=digest(a),members=count,readback_all_members=True)
archive('harness-all-raw',[Path(p) for p in json.loads((q/'harness-files.json').read_text())],v/'after-harness')
paths=[p for p in q.rglob('*') if p.is_file() and p.suffix in ['.py','.sh','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'after-harness' not in p.parts and 'engine' not in p.parts and 'target' not in p.parts and not any(a.endswith('-data') or a=='data' for a in p.parts)];paths.append(v/'engine/proxy-read.js');archive('native-oracle-and-build-raw',paths,q)
for src in [q/'approval-snapshot.md',q/'style-generated.log',q/'style-review.json',q/'target-commands-2.json',q/'final-protocol.json',q/'precode-proof.json',q/'final-public-proof.json',q/'precode.html',q/'final-public.out',q/'oracle-negative-zero-reconciliation.json',q/'canonical-diagnostic.json',q/'fixture-rebuild-proof.json',q/'existing-operation-proof.json',q/'harness-outcome-audit.json',v/'native-runs.json',v/'source-proof.json',v/'source-commit.txt',v/'shared-input-comparison.json',v/'acid/report.json']:
 shutil.copy2(src,out/('acid-report.json' if src==v/'acid/report.json' else src.name))
for src in [Path('plan/ws074/tests/proxy-read.js'),Path('plan/ws074/tests/host-proxy-read.c')]:shutil.copy2(src,out/src.name)
for f in ['vm/operation.c','vm/vm.h','js/builtin_bigint.c']:shutil.copy2(Path('userland/desktop/libbrowser',f),out/f.replace('/','_'))
for src in q.glob('target-*.log'):shutil.copy2(src,out/src.name)
versions=json.loads(Path('plan/ws074/phase258/evidence/20261018-q35/versions.json').read_text());(out/'versions.json').write_text(json.dumps(versions,indent=2)+'\n')
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),protocol_conditions=272,final_mixed_oracle_exact=True,original_genuine_chrome='271/272; one ordinary-name group differs because Chromium153 TypedArray rejects -0.0; raw preserved',oracle_reconciliation='same272 source and expectations; genuine TypedArray classification with documented primitive Number/Object.is negative-zero spelling filter; ToBigInt genuine asIntN4096 with bounded selected magnitudes',old235_source_prefix_identical=True,public_bigint_precode=json.loads((q/'final-public-proof.json').read_text()),native_pressure=['managed realm retained during Boolean result allocation','native valueOf returns sole fresh numeric string; actual strictly later parser collection after callback root removed','real input/source/string cell type live until conversion completes','completed output alone does not retain former realm/source/primitive; all actually reclaimed; final BigInt root controls output reclamation','q30-q35 managed Get/Has/GetOwn/Define/Set5 hook collections, independent value/receiver and From pressure/absence reclamation retained'],focused_gate_returncodes={r['label']:r['returncode'] for r in runs},acid3_score=100,acid3_pixel_diff=0,acid2_existing_pixel_diff=873,raw_allowed_cleanup=51,other_style_flags=0,host_target_warnings=0,fixture_only_recompile_product_bytes_unchanged=True,archives=archives,harness=h['counts'],callbacks=h['callbacks'],whole_pass_gains=h['whole_pass_gains'],whole_pass_losses=h['whole_pass_losses'],old_pass_callback_losses=h['old_pass_callback_losses'],changes=len(h['changes']),current_raw_lower_bound=h['counts'].get('pass',0)+844+105+39,denominator=3805,held=0,unattempted_harness=275,static_scripted_crash_reused='q28:844/105/39',limitations=['new whole gains require separate prerequisite/negative-control audit before certification','original Chrome TypedArray -0.0 mismatch is retained; no claim all272 match the unadjusted exotic oracle','genuine ToBigInt Chrome4096-bit oracle only covers selected inputs within signed4096-bit range','frozen binaries retained in build with hashes, not embedded in archives','actual TypedArray Set remains ENOTSUP, ordinary vm_set prototype/primitive routing/global Proxy/p258/full target/p100/WS100% unfinished','static/scripted/strict q28 evidence reused; no q36 all-image/strict equality claim'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('counts',h['counts'],'callbacks',h['callbacks'],'changes',len(h['changes']));print('archives',archives);print('source',summary['source_commit'])
