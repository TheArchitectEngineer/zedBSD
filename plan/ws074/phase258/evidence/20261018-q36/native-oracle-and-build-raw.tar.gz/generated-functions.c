double vm_string_to_number(const struct vm_string *string);
int vm_canonical_numeric_index(vm_value key, double *number, int *canonical);
int vm_to_bigint(struct vm_realm *realm, vm_value value, vm_value *result);
static void operation_bigint_trace(struct vm_heap *heap, void *context);
static int bigint_call(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int bigint_as_n(struct vm_realm *realm, const vm_value *args, unsigned count, int is_signed, vm_value *result);
int main(int argc, char **argv);
static int proxy_canonical_index(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_to_bigint(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int conversion_primitive(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int numeric_conversion_pressure(struct page *page);

double
vm_string_to_number(
	const struct vm_string *string)
{
	double number;

	/* Reuse the established language parser without a synthetic realm or object conversion. */
	number = operation_parse_number(string);

	/* Succeeded: the parsed number, including NaN for invalid numeric text. */
	return number;
}

int
vm_canonical_numeric_index(
	vm_value key,
	double *number,
	int *canonical)
{
	struct wb_buffer text;
	const struct vm_string *string;
	uint32_t index;
	uint16_t unit;
	int is_int32;
	int is_string;
	int special;
	int status;

	/* Internal integer keys already denote their canonical numeric index. */
	*canonical = 0;
	*number = 0.0;
	is_int32 = vm_value_is_int32(key);
	if (is_int32) {
		*number = (double)vm_value_as_int32(key);
		*canonical = 1;
		return 0;
	}

	/* Symbols have no numeric index, and callers supply already converted property keys. */
	is_string = vm_value_is_string(key);
	if (!is_string)
		return 0;
	string = (const struct vm_string *)vm_value_as_cell(key);
	special = vm_string_equal_ascii(string, "-0");
	if (special) {
		*number = -0.0;
		*canonical = 1;
		return 0;
	}

	/* Canonical spelling must equal the exact language formatter's round-trip output. */
	*number = vm_string_to_number(string);
	wb_buffer_init(&text);
	status = vm_number_to_text(*number, 10, &text);
	if (status != 0)
		goto cleanup;
	if (text.length != string->length)
		goto cleanup;
	for (index = 0; index < string->length; index++) {
		unit = vm_string_at(string, index);
		if (unit != (uint16_t)text.data[index])
			goto cleanup;
	}

	/* Only identical source spelling denotes a canonical numeric index. */
	*canonical = 1;

cleanup:
	/* The formatter's C storage never retains or allocates a VM cell. */
	wb_buffer_release(&text);
	if (status != 0)
		return status;

	/* Succeeded: canonical distinguishes an actual numeric index from an ordinary property name. */
	return 0;
}

int
vm_to_bigint(
	struct vm_realm *realm,
	vm_value value,
	vm_value *result)
{
	struct operation_bigint_roots roots;
	struct wb_buffer text;
	struct vm_bigint *big;
	struct vm_string *string;
	uint32_t start;
	uint32_t end;
	uint32_t index;
	uint16_t unit;
	int is_string;
	int blank;
	int boolean;
	int status;

	/* Publish no partial conversion while its source or transient primitive may still run script. */
	*result = VM_VALUE_UNDEFINED;
	roots.realm = realm;
	roots.source = value;
	roots.primitive = VM_VALUE_UNDEFINED;
	wb_buffer_init(&text);
	status = vm_heap_add_tracer(realm->heap, operation_bigint_trace, &roots);
	if (status != 0)
		return status;
	status = vm_to_primitive(realm, value, VM_HINT_NUMBER, &roots.primitive);
	if (status != 0)
		goto cleanup;
	big = vm_value_as_bigint(roots.primitive);
	if (big != NULL) {
		*result = roots.primitive;
		status = 0;
		goto cleanup;
	}

	/* Booleans become exactly zero or one without accepting Number primitives. */
	if (roots.primitive == VM_VALUE_TRUE || roots.primitive == VM_VALUE_FALSE) {
		boolean = 0;
		if (roots.primitive == VM_VALUE_TRUE)
			boolean = 1;
		status = vm_bigint_from_int64(realm->heap, boolean, result);
		goto cleanup;
	}

	/* Every remaining accepted primitive is a string; Number, Symbol, null and undefined throw. */
	is_string = vm_value_is_string(roots.primitive);
	if (!is_string) {
		status = vm_throw_type_error(realm, "Cannot convert the value to a BigInt");
		goto cleanup;
	}

	/* Trim the language's complete Unicode whitespace and line-terminator set before parsing ASCII numeric grammar. */
	string = (struct vm_string *)vm_value_as_cell(roots.primitive);
	start = 0;
	end = string->length;
	while (start < end) {
		unit = vm_string_at(string, start);
		blank = vm_is_space(unit);
		if (!blank)
			break;
		start++;
	}

	/* Trailing language whitespace is excluded independently of leading whitespace. */
	while (end > start) {
		unit = vm_string_at(string, end - 1U);
		blank = vm_is_space(unit);
		if (!blank)
			break;
		end--;
	}

	/* StringToBigInt's accepted digits, signs and prefixes are ASCII; other remaining code units are invalid. */
	for (index = start; index < end; index++) {
		unit = vm_string_at(string, index);
		if (unit > 0x7FU) {
			status = vm_throw_error(realm, VM_ERROR_SYNTAX, "Cannot convert the string to a BigInt");
			goto cleanup;
		}

		/* Copy one grammar byte into noncollectible parsing storage. */
		status = wb_buffer_append_byte(&text, (unsigned char)unit);
		if (status != 0)
			goto cleanup;
	}

	/* The established BigInt parser handles empty text, radix prefixes, signed decimal and exact magnitude. */
	status = vm_bigint_from_text(realm->heap, wb_buffer_string(&text), text.length, result);
	if (status == EINVAL)
		status = vm_throw_error(realm, VM_ERROR_SYNTAX, "Cannot convert the string to a BigInt");

cleanup:
	/* Neither the transient primitive nor its native parsing buffer escapes this frame's conversion lifetime. */
	wb_buffer_release(&text);
	vm_heap_remove_tracer(realm->heap, operation_bigint_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the result is the converted BigInt with its original or exact parsed value. */
	return 0;
}

static void
operation_bigint_trace(
	struct vm_heap *heap,
	void *context)
{
	struct operation_bigint_roots *roots;

	/* A conversion can be the only native owner of its realm or freshly returned primitive. */
	roots = context;
	if (roots->realm->managed)
		vm_heap_mark(heap, &roots->realm->cell);
	vm_heap_mark_value(heap, roots->source);
	vm_heap_mark_value(heap, roots->primitive);

	/* Succeeded: later script getters and parsing allocation can collect safely. */
	return;
}

static int
bigint_call(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value primitive;
	double number;
	double whole;
	int is_number;
	int infinite;
	int status;

	UNUSED_PARAMETER(this_value);

	/* The value as a primitive. */
	status = vm_to_primitive(realm, js_argument(args, count, 0), VM_HINT_NUMBER, &primitive);
	if (status != 0)
		return status;

	/* A number must be an integer. */
	is_number = vm_value_is_number(primitive);
	if (is_number) {
		number = vm_value_as_number(primitive);
		if (number != number) {
			status = vm_throw_range_error(realm, "The number cannot be converted to a BigInt because it is not an integer");
			return status;
		}

		/* Infinity has no integer BigInt representation. */
		infinite = isinf(number);
		if (infinite) {
			status = vm_throw_range_error(realm, "The number cannot be converted to a BigInt because it is not an integer");
			return status;
		}

		/* A finite Number must have no fractional part. */
		whole = floor(number);
		if (number != whole) {
			status = vm_throw_range_error(realm, "The number cannot be converted to a BigInt because it is not an integer");
			return status;
		}

		/* The constructor alone accepts an exact integer Number. */
		status = vm_bigint_from_double(realm->heap, number, result);
		if (status != 0)
			return status;

		/* Succeeded: the constructor accepts an exact integer Number. */
		return 0;
	}

	/* Non-Number constructor inputs share ToBigInt, including complete Unicode whitespace handling. */
	status = vm_to_bigint(realm, primitive, result);
	if (status != 0)
		return status;

	/* Succeeded: constructor Number handling and language ToBigInt remain distinct. */
	return 0;
}

static int
bigint_as_n(
	struct vm_realm *realm,
	const vm_value *args,
	unsigned count,
	int is_signed,
	vm_value *result)
{
	struct vm_bigint *big;
	vm_value argument;
	double bits;
	int status;

	/* The bit count as an integer index. */
	status = vm_to_number(realm, js_argument(args, count, 0), &bits);
	if (status != 0)
		return status;
	if (bits != bits)
		bits = 0.0;
	bits = trunc(bits);
	if (bits < 0.0 || bits > 9007199254740991.0) {
		status = vm_throw_range_error(realm, "Invalid value: not (convertible to) a safe integer");
		return status;
	}

	/* ToBigInt rejects Number inputs even when the bit count is zero. */
	argument = js_argument(args, count, 1);
	status = vm_to_bigint(realm, argument, &argument);
	if (status != 0)
		return status;
	big = vm_value_as_bigint(argument);
	status = vm_bigint_as_n(realm, (uint64_t)bits, is_signed, big, result);
	if (status != 0)
		return status;

	/* Succeeded: the properly converted BigInt is truncated to the requested width. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* TypedArray's separate Set contract remains explicitly unsupported in this private receiver-aware stage. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != ENOTSUP || done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_canonical_index(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value key;
	double number;
	int canonical;
	int status;

	UNUSED_PARAMETER(receiver);

	/* The VM classifier receives an already converted property key and cannot run script itself. */
	status = vm_to_key(realm, js_argument(args, count, 0), &key);
	if (status != 0)
		return status;
	status = vm_canonical_numeric_index(key, &number, &canonical);
	if (status != 0)
		return status;
	*result = VM_VALUE_UNDEFINED;
	if (canonical)
		*result = vm_value_number(number);

	/* Succeeded: undefined distinguishes an ordinary name from every numeric result including NaN. */
	return 0;
}

static int
proxy_to_bigint(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	int status;

	UNUSED_PARAMETER(receiver);

	/* The production abstract operation owns all primitive conversion and lifetime behavior. */
	status = vm_to_bigint(realm, js_argument(args, count, 0), result);
	if (status != 0)
		return status;

	/* Succeeded: the original or converted BigInt is returned without fixture arithmetic. */
	return 0;
}

static int
conversion_primitive(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_string *string;
	struct vm_cell *root;
	struct vm_cell *pressure;
	struct vm_heap_stats stats;
	int status;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Protect a noninterned numeric primitive only until its caller takes responsibility. */
	root = NULL;
	status = vm_heap_add_root(realm->heap, &root);
	if (status != 0)
		return status;
	string = vm_string_from_utf8(realm->heap, "9007199254740993", 16U);
	if (string == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The saved address is an observation and never a collector root. */
	root = &string->cell;
	conversion_primitive_address = (uintptr_t)string;
	pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A later collection must happen after this callback releases its own primitive root. */
	vm_heap_stats(realm->heap, &stats);
	conversion_primitive_collections = stats.collections;

	/* The primitive must next be owned by ToPrimitive and the production ToBigInt tracer. */
	*result = vm_value_cell(string);
	status = 0;

cleanup:
	/* No callback root may remain when the production parser triggers its own collection. */
	vm_heap_remove_root(realm->heap, &root);
	if (status != 0)
		return status;

	/* Succeeded: a sole fresh primitive and pending real allocation pressure reach the conversion. */
	return 0;
}

static int
numeric_conversion_pressure(
	struct page *page)
{
	struct vm_cell *roots[3];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_realm *realm;
	struct vm_object *source;
	struct vm_bigint *big;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	struct wb_buffer text;
	vm_value input;
	vm_value converted;
	uintptr_t realm_address;
	uintptr_t source_address;
	uintptr_t output_address;
	unsigned registered;
	unsigned index;
	unsigned mode;
	int differs;
	int status;

	/* Caller setup ownership ends before each actual product conversion begins. */
	memset(roots, 0, sizeof(roots));
	wb_buffer_init(&text);
	registered = 0;
	for (index = 0; index < 3U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Boolean allocation and a fresh object-produced primitive exercise distinct source and result paths. */
	for (mode = 0; mode < 2U; mode++) {
		conversion_primitive_address = 0;
		conversion_primitive_collections = 0;
		status = vm_realm_create_managed(page->heap, &realm);
		if (status != 0)
			goto cleanup;
		roots[0] = &realm->cell;
		realm_address = (uintptr_t)realm;
		source_address = 0;
		input = VM_VALUE_TRUE;
		if (mode != 0U) {
			source = vm_object_create(page->heap, NULL);
			if (source == NULL) {
				status = ENOMEM;
				goto cleanup;
			}

			/* Native valueOf returns a fresh string before arranging the actual parser collection. */
			roots[1] = &source->cell;
			source_address = (uintptr_t)source;
			status = js_builtin_method(page->realm, source, "valueOf", 0, conversion_primitive);
			if (status != 0)
				goto cleanup;
			input = vm_value_cell(source);
		}

		/* Start from the unchanged heap threshold with no pressure left from the previous lifetime case. */
		vm_heap_collect(page->heap);
		if (mode == 0U) {
			pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
			if (pressure == NULL) {
				status = ENOMEM;
				goto cleanup;
			}
		}

		/* The conversion must now retain its managed realm and original input without embedding roots. */
		roots[0] = NULL;
		roots[1] = NULL;
		vm_heap_stats(page->heap, &before);
		status = vm_to_bigint(realm, input, &converted);
		if (status != 0)
			goto cleanup;
		roots[2] = vm_value_as_cell(converted);
		output_address = (uintptr_t)roots[2];
		vm_heap_stats(page->heap, &after);
		if (after.collections <= before.collections) {
			status = 1;
			goto cleanup;
		}

		/* Exclude a test that collected only while the native valueOf callback still owned its fresh primitive. */
		if (mode != 0U && after.collections <= conversion_primitive_collections) {
			status = 1;
			goto cleanup;
		}

		/* A real managed owner survived the allocation performed inside conversion. */
		found = vm_heap_find_cell(page->heap, realm_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* The object-produced primitive remains a string rather than a reused address of a newly allocated result. */
		if (mode != 0U) {
			found = vm_heap_find_cell(page->heap, source_address);
			if (found == NULL) {
				status = 1;
				goto cleanup;
			}

			/* The exact fresh primitive, with its actual cell type, survived the post-return parser collection. */
			found = vm_heap_find_cell(page->heap, conversion_primitive_address);
			if (found == NULL || found->type != &vm_string_type) {
				status = 1;
				goto cleanup;
			}
		}

		/* Verify exact result magnitude with noncollectible text storage. */
		big = vm_value_as_bigint(converted);
		if (big == NULL) {
			status = 1;
			goto cleanup;
		}

		/* The Boolean and fresh string have distinct independently known exact values. */
		status = vm_bigint_to_text(big, 10, &text);
		if (status != 0)
			goto cleanup;
		differs = strcmp(wb_buffer_string(&text), "1");
		if (mode != 0U)
			differs = strcmp(wb_buffer_string(&text), "9007199254740993");
		wb_buffer_release(&text);
		wb_buffer_init(&text);
		if (differs != 0) {
			status = 1;
			goto cleanup;
		}

		/* Keeping only the BigInt output must not keep its former realm or source alive. */
		vm_heap_collect(page->heap);
		found = vm_heap_find_cell(page->heap, realm_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}

		/* Conversion source and fresh primitive must also be actually reclaimed once their frame ends. */
		if (mode != 0U) {
			found = vm_heap_find_cell(page->heap, source_address);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}

			/* No output graph edge may retain the temporary numeric string. */
			found = vm_heap_find_cell(page->heap, conversion_primitive_address);
			if (found != NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* The embedding still owns the completed output until its own root is released. */
		found = vm_heap_find_cell(page->heap, output_address);
		if (found == NULL) {
			status = 1;
			goto cleanup;
		}

		/* The last output root must be sufficient to control actual BigInt reclamation. */
		roots[2] = NULL;
		vm_heap_collect(page->heap);
		found = vm_heap_find_cell(page->heap, output_address);
		if (found != NULL) {
			status = 1;
			goto cleanup;
		}
	}

	/* Both conversion kinds met the independent pressure and lifetime observations. */
	status = 0;

cleanup:
	/* Saved addresses are observations only and never survive the bounded conversion cases. */
	conversion_primitive_address = 0;
	conversion_primitive_collections = 0;
	wb_buffer_release(&text);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve failed lifetime observations after retiring every embedding registration. */
	if (status != 0)
		return status;

	/* Succeeded: both conversion frames and their complete temporary graphs were actually retired. */
	return 0;
}
