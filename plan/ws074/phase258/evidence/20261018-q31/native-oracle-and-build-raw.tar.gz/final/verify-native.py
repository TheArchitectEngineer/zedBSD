from pathlib import Path
import subprocess,os,json,time
q=Path('build/ws074-20261018/q31/final');engine=(q/'engine').resolve();start=time.monotonic();runs=[]
commands=[('proxy-read',[str(engine/'host-proxy-read'),str(engine/'proxy-read.js')]),('delegation',[str(engine/'host-generator-delegation')]),('interpreter',[str(engine/'host-interp')]),('vm-factory',[str(engine/'host-vm-factory')]),('dom',['python3','plan/ws074/tests/run-dom-tests.py','--program',str(engine/'browser')]),('cssom',[str(engine/'host-cssom')]),('cssom-mutation',[str(engine/'host-cssom-mutation')]),('marks',[str(engine/'host-performance-marks')]),('observer',[str(engine/'host-performance-observer')]),('error-events',[str(engine/'host-error-events')]),('error-reporting',[str(engine/'host-error-reporting')]),('acid',['python3','plan/ws074/tests/run-acid-tests.py','--program',str(engine/'browser'),'--out',str(q/'acid')])]
for label,command in commands:
 with (q/(label+'.log')).open('w') as log:run=subprocess.run(command,stdout=log,stderr=log,env=dict(os.environ,XDG_DATA_HOME=str((q/(label+'-data')).resolve())),timeout=300)
 runs.append(dict(label=label,command=command,returncode=run.returncode,seconds=round(time.monotonic()-start,1)));(q/'native-runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(runs[-1],flush=True)
 # Strict crash/Acid criteria are audited by exact report comparison, not their broad pass/fail exit.
 if label not in ['crash','acid']:assert run.returncode==0,label
