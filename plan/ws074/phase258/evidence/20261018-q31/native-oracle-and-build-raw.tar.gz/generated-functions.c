int vm_in(struct vm_realm *realm, vm_value key, vm_value object, vm_value *result);
int vm_has_property(struct vm_realm *realm, struct vm_object *object, vm_value key, int *found);
static int access_has_property(struct vm_realm *realm, struct vm_object *object, vm_value key, int *found);
static int access_proxy_has(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, int *found);
static int object_to_descriptor(struct vm_realm *realm, vm_value value, struct vm_descriptor *descriptor);
int main(int argc, char **argv);
static int proxy_gc_edges(struct page *page);

int
vm_in(
	struct vm_realm *realm,
	vm_value key,
	vm_value object,
	vm_value *result)
{
	struct access_read_roots roots;
	vm_value property_key;
	int is_object;
	int found;
	int status;

	/* Keep both language operands and their owner alive before property-key conversion can run script. */
	*result = VM_VALUE_FALSE;
	roots.realm = realm;
	roots.base = object;
	roots.key = key;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* The right operand must be an object before the left operand is converted. */
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Cannot use 'in' operator to search for a key in a primitive");
		goto cleanup;
	}

	/* A fresh symbol returned by conversion also belongs to the active native frame. */
	status = vm_to_key(realm, key, &property_key);
	if (status != 0)
		goto cleanup;
	roots.receiver = property_key;
	status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(object), property_key, &found);
	if (status != 0)
		goto cleanup;
	*result = vm_value_boolean(found);

cleanup:
	/* No tracer may outlive the operand slots it observes. */
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the actual object's HasProperty result supplies the language Boolean. */
	return 0;
}

int
vm_has_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	int *found)
{
	struct access_read_roots roots;
	int status;

	/* Bound native fallback recursion independently from interpreter call frames. */
	*found = 0;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		return status;
	}

	/* This HasProperty frame owns one recursion count until its normal or abrupt return. */
	realm->property_depth++;

	/* Property presence may invoke a Proxy trap that collects its own input graph. */
	roots.realm = realm;
	roots.base = vm_value_cell(object);
	roots.key = key;
	roots.receiver = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_read_trace, &roots);
	if (status != 0) {
		/* This attempted operation still owns its depth even when tracer registration failed. */
		realm->property_depth--;
		return status;
	}

	/* Run the actual ordinary or Proxy presence operation while its complete input graph is rooted. */
	status = access_has_property(realm, object, key, found);
	vm_heap_remove_tracer(realm->heap, access_read_trace, &roots);

	/* Retire property-operation depth on both normal and abrupt completion. */
	realm->property_depth--;
	if (status != 0)
		return status;

	/* Succeeded: found reports actual property presence. */
	return 0;
}

static int
access_has_property(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	int *found)
{
	struct vm_property property;
	int present;
	int status;

	/* Presence never invokes an ordinary accessor's getter. */
	*found = 0;
	while (object != NULL) {
		if (object->kind == VM_KIND_PROXY) {
			status = access_proxy_has(realm, (struct vm_proxy *)object, key, found);
			if (status != 0)
				return status;

			/* Succeeded: the Proxy supplies the remaining chain's answer. */
			return 0;
		}

		/* Ordinary native hooks report descriptor presence without running script. */
		present = vm_object_get_own(object, key, &property);
		if (present < 0)
			return -present;
		if (present) {
			*found = 1;
			return 0;
		}

		/* A missing own descriptor continues on the ordinary prototype chain. */
		object = object->prototype;
	}

	/* Succeeded: no object on the chain supplies this property. */
	return 0;
}

static int
access_proxy_has(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	int *found)
{
	struct vm_cell *roots[6];
	struct vm_descriptor descriptor;
	struct vm_object *object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value args[2];
	vm_value produced;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_symbol;
	int present;
	int truth;
	int status;

	/* Revocation during method lookup cannot retire the operation's original protocol participants. */
	*found = 0;
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[4] = vm_value_as_cell(key);
	roots[5] = NULL;
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked Proxy must fail before any handler access. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot search a revoked Proxy");
		goto cleanup;
	}

	/* Fetch the current has trap using the ordinary GetMethod rules. */
	method_key = vm_key_from_ascii(realm->heap, "has");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Read the current has method before choosing trap or target fallback. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(target), key, found);
		goto cleanup;
	}

	/* The trap may be a fresh function returned only to this native frame. */
	roots[5] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[4] = &string->cell;
	}

	/* Has receives exactly the actual target and a string-or-symbol property key. */
	args[0] = target;
	args[1] = trap_key;
	status = vm_call(realm, method, handler, args, 2, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (truth) {
		*found = 1;
		status = 0;
		goto cleanup;
	}

	/* A false result inspects the original target after the trap's changes. */
	object = (struct vm_object *)vm_value_as_cell(target);
	present = vm_get_own_descriptor(object, key, &descriptor);
	if (present < 0) {
		status = -present;
		goto cleanup;
	}

	/* Only an existing own property constrains a false has result. */
	if (present) {
		if ((descriptor.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
			status = vm_throw_type_error(realm, "Proxy has trap hid a fixed own property");
			goto cleanup;
		}

		/* A nonextensible target also keeps its configurable own properties visible. */
		if ((object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U) {
			status = vm_throw_type_error(realm, "Proxy has trap hid a nonextensible target's own property");
			goto cleanup;
		}
	}

	/* The missing or legally hidden property produces an ordinary false result. */
	status = 0;

cleanup:
	/* Unregister only slots acquired before an allocation or trap failure. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Propagate the original failure after releasing this native frame's roots. */
	if (status != 0)
		return status;

	/* Succeeded: the reported presence respects the target's actual invariants. */
	return 0;
}

static int
object_to_descriptor(
	struct vm_realm *realm,
	vm_value value,
	struct vm_descriptor *descriptor)
{
	struct vm_object *object;
	struct vm_cell *value_root;
	vm_value field;
	int callable;
	int is_cell;
	int truth;
	int status;

	/* A descriptor is an object. */
	memset(descriptor, 0, sizeof(*descriptor));
	descriptor->value = VM_VALUE_UNDEFINED;
	descriptor->getter = VM_VALUE_UNDEFINED;
	descriptor->setter = VM_VALUE_UNDEFINED;
	value_root = NULL;
	is_cell = vm_value_is_cell(value);
	if (is_cell)
		value_root = vm_value_as_cell(value);
	status = vm_heap_add_root(realm->heap, &value_root);
	if (status != 0)
		return status;
	status = vm_heap_add_tracer(realm->heap, object_trace_descriptor, descriptor);
	if (status != 0) {
		vm_heap_remove_root(realm->heap, &value_root);
		return status;
	}

	/* The descriptor source must remain valid across its getter sequence. */
	status = object_require(realm, value, "Property description must be an object", &object);
	if (status != 0)
		goto cleanup;

	/* Convert enumerable before observing any later descriptor field. */
	field = VM_VALUE_FALSE;
	status = object_descriptor_field(realm, value, "enumerable", VM_HAS_ENUMERABLE, descriptor, &field);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(field);
	if (truth)
		descriptor->attributes |= VM_PROPERTY_ENUMERABLE;

	/* Configurable follows enumerable and precedes the data value. */
	field = VM_VALUE_FALSE;
	status = object_descriptor_field(realm, value, "configurable", VM_HAS_CONFIGURABLE, descriptor, &field);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(field);
	if (truth)
		descriptor->attributes |= VM_PROPERTY_CONFIGURABLE;

	/* The descriptor tracer retains a fresh value through every later getter. */
	status = object_descriptor_field(realm, value, "value", VM_HAS_VALUE, descriptor, &descriptor->value);
	if (status != 0)
		goto cleanup;

	/* Writable is converted before any accessor fields are inspected. */
	field = VM_VALUE_FALSE;
	status = object_descriptor_field(realm, value, "writable", VM_HAS_WRITABLE, descriptor, &field);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(field);
	if (truth)
		descriptor->attributes |= VM_PROPERTY_WRITABLE;

	/* A bad getter fails immediately, before HasProperty or Get can inspect the setter. */
	status = object_descriptor_field(realm, value, "get", VM_HAS_GET, descriptor, &descriptor->getter);
	if (status != 0)
		goto cleanup;
	callable = vm_value_is_callable(descriptor->getter);
	if ((descriptor->has & VM_HAS_GET) != 0U &&
	    !callable &&
	    descriptor->getter != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Getter must be a function");
		goto cleanup;
	}

	/* Validate the setter immediately after its own read. */
	status = object_descriptor_field(realm, value, "set", VM_HAS_SET, descriptor, &descriptor->setter);
	if (status != 0)
		goto cleanup;
	callable = vm_value_is_callable(descriptor->setter);
	if ((descriptor->has & VM_HAS_SET) != 0U &&
	    !callable &&
	    descriptor->setter != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Setter must be a function");
		goto cleanup;
	}

	/* A descriptor is an accessor or a data property, not both. */
	if ((descriptor->has & (VM_HAS_GET | VM_HAS_SET)) != 0U && (descriptor->has & (VM_HAS_VALUE | VM_HAS_WRITABLE)) != 0U) {
		status = vm_throw_type_error(realm, "Invalid property descriptor. Cannot both specify accessors and a value or writable attribute");
		goto cleanup;
	}

cleanup:
	/* The caller takes the completed descriptor after its getter sequence. */
	vm_heap_remove_tracer(realm->heap, object_trace_descriptor, descriptor);
	vm_heap_remove_root(realm->heap, &value_root);
	if (status != 0)
		return status;

	/* Succeeded: the descriptor. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_gc_edges(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[5];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value answer;
	vm_value made;
	vm_value key;
	vm_value get_key;
	uintptr_t realm_address;
	unsigned index;
	unsigned registered;
	int status;
	int same;
	int present;

	/* Setup ownership is retired deliberately before each product operation takes responsibility. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The temporary managed realm has no embedding Document or explicit lifetime. */
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	realm_address = (uintptr_t)realm;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated target while allocating the remaining protocol participants. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated handler until the private factory takes ownership. */
	roots[2] = &handler->cell;

	/* Intern keys before obtaining a transient function returned only to this native frame. */
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Intern the trap key before creating a transient method function. */
	get_key = vm_key_from_ascii(page->heap, "get");
	if (get_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Create the ordinary configurable descriptor used by the post-trap invariant read. */
	status = vm_object_define(page->heap, target, key, VM_VALUE_UNDEFINED, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = proxy_script(page->realm, "(function(){return {sole:74};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, get_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Genuine allocation pressure makes the private factory retain all otherwise unrooted inputs. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Drop every setup owner before the factory must survive threshold collection. */
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &made);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(made);
	vm_heap_stats(page->heap, &after);
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* This native descriptor hook may collect but never executes script, preserving the production hook contract. */
	target->native_operations = &proxy_sole_operations;
	sole_heap = page->heap;
	sole_realm_address = realm_address;
	sole_realm_alive = 0;
	status = vm_get_receiver(realm, made, key, VM_VALUE_NULL, &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);

	/* Has fallback must independently retain the managed realm through the same native descriptor collector. */
	status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &present);
	if (status != 0)
		goto cleanup;
	if (!present) {
		status = 1;
		goto cleanup;
	}

	/* The sole result from Get must also survive the subsequent Has collection. */
	key = vm_key_from_ascii(page->heap, "sole");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read the actual sole-result payload after the native policy collection. */
	status = vm_get(page->realm, answer, key, &answer);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(answer, vm_value_int32(74));
	if (!same ||
	    sole_realm_alive != 2U ||
	    realm->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* No surviving protocol participant references the temporary realm once the native Get frame ends. */
	roots[3] = NULL;
	roots[4] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Record the successful native ownership observations before releasing setup roots. */
	status = 0;

cleanup:
	/* Fixture observations are not collector roots and never survive the independent case. */
	sole_heap = NULL;
	sole_realm_address = 0;
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: allocation, native descriptor collection and later realm reclamation all used real ownership. */
	return 0;
}
