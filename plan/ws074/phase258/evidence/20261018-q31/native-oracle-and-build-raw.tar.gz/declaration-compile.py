from pathlib import Path
import shlex,subprocess,json,hashlib
q=Path('build/ws074-20261018/q31');hostargs=shlex.split(Path('build/ws074-20261018/plain/flags').read_text())+['-c','userland/desktop/libbrowser/js/builtin_object.c','-o',str(q/'host-object-after-declaration.o')]
with (q/'declaration-host-compile.log').open('w') as log:r=subprocess.run(hostargs,stdout=log,stderr=log)
assert r.returncode==0 and not (q/'declaration-host-compile.log').read_text();targetargs=json.loads((q/'target-commands-2.json').read_text())[1];assert targetargs[targetargs.index('-c')+1]=='userland/desktop/libbrowser/js/builtin_object.c';targetargs[targetargs.index('-o')+1]=str(q/'target-object-after-declaration.o')
with (q/'declaration-target-compile.log').open('w') as log:r=subprocess.run(targetargs,stdout=log,stderr=log)
assert r.returncode==0 and not (q/'declaration-target-compile.log').read_text();proof=json.loads((q/'declaration-source-proof.json').read_text());proof['commands']=[hostargs,targetargs];proof['objects']={}
for mode in ['host','target']:
 paths=[]
 for stage in ['before','after']:
  a=q/(mode+'-object-'+stage+'-declaration.o');b=q/(mode+'-object-'+stage+'-declaration-stripped.o');subprocess.run(['objcopy','--strip-debug',str(a),str(b)],check=True);paths.append(b)
 assert paths[0].read_bytes()==paths[1].read_bytes(),mode;proof['objects'][mode]=dict(stripped_all_bytes_equal=True,sha256=hashlib.sha256(paths[0].read_bytes()).hexdigest(),before_bytes=paths[0].stat().st_size,after_bytes=paths[1].stat().st_size)
(q/'declaration-equivalence.json').write_text(json.dumps(proof,indent=2)+'\n');print('host/target warning0; each stripped object all bytes identical')
