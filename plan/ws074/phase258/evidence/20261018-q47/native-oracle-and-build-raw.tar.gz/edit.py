from pathlib import Path
import re,json
q=Path('build/ws074-20261018/q47');p=Path('userland/desktop/libbrowser/vm/access.c');s=p.read_text()
def edit(name,fn):
 global s
 pat=r'static int\n'+name+r'\(\n.*?\n\}';m=re.search(pat,s,re.S);assert m,name;s=s[:m.start()]+fn(m.group())+s[m.end():]
def get(t):
 x='''	found = vm_get_own_descriptor((struct vm_object *)vm_value_as_cell(target), key, &descriptor);
	if (found < 0) {
		status = -found;
		goto cleanup;
	}''';assert x in t;return t.replace(x,'''	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, &descriptor, &found);
	if (status != 0)
		goto cleanup;''')
edit('access_proxy_get',get)
def has(t):
 t=t.replace('\n\tint truth;','\n\tint extensible;\n\tint truth;');x='''	present = vm_get_own_descriptor(object, key, &descriptor);
	if (present < 0) {
		status = -present;
		goto cleanup;
	}''';assert x in t;t=t.replace(x,'''	status = vm_get_own_property(realm, object, key, &descriptor, &present);
	if (status != 0)
		goto cleanup;''');x='''		if ((object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U) {''';assert x in t;t=t.replace(x,'''		status = vm_is_extensible(realm, object, &extensible);
		if (status != 0)
			goto cleanup;
		if (!extensible) {''');return t
edit('access_proxy_has',has)
def getown(t):
 x='''	/* Preserve the original target and handler even if a getter or trap revokes the record. */''';assert x in t;t=t.replace(x,'''	/* Absent target descriptors have no payload slots for the snapshot tracer to inspect. */
	memset(&current, 0, sizeof(current));

'''+x)
 a=t.index('\t/* Descriptor conversion may delete the target property');b=t.index('\tresult_roots.realm = realm;',a);block=t[a:b];t=t[:a]+t[b:]
 a=t.index('\textensible = 1;');b=t.index('\n\tresult_roots.realm = realm;',a)
 t=t[:a]+block.replace('Descriptor conversion may delete the target property, so retain its complete snapshot payloads.','Target extent callbacks may revoke or mutate its graph, so retain all flagged snapshot payloads first.')+'''	/* Undefined output skips extent observation when the target property is absent or already fixed. */
	if (produced == VM_VALUE_UNDEFINED) {
		if (!present) {
			status = 0;
			goto cleanup;
		}

		/* A fixed own property cannot be hidden, regardless of the target's extensibility. */
		if ((current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
			status = vm_throw_type_error(realm, "Proxy descriptor trap cannot hide this own property");
			goto cleanup;
		}

		/* Only a configurable present property requires actual target extensibility on the absence path. */
		status = vm_is_extensible(realm, target_object, &extensible);
		if (status != 0)
			goto cleanup;
		if (!extensible) {
			status = vm_throw_type_error(realm, "Proxy descriptor trap cannot hide this own property");
			goto cleanup;
		}

		/* The observed configurable property may be hidden on an extensible target. */
		status = 0;
		goto cleanup;
	}

	/* Nonundefined output observes target extensibility before any returned descriptor getter executes. */
	status = vm_is_extensible(realm, target_object, &extensible);
	if (status != 0)
		goto cleanup;

	/* The original trap output and every converted field survive descriptor getters independently. */'''+t[b:];return t
edit('access_proxy_get_own',getown)
def define(t):
 t=t.replace('struct access_descriptor_roots input_roots;','struct access_descriptor_roots input_roots;\n\tstruct access_descriptor_roots current_roots;').replace('int input_registered;','int input_registered;\n\tint current_registered;');t=t.replace('''	/* Snapshot protocol participants and clear the Boolean output before any observable method read. */''','''	/* No absent target descriptor exposes uninitialized payloads to its eventual snapshot tracer. */
	memset(&current, 0, sizeof(current));

	/* Snapshot protocol participants and clear the Boolean output before any observable method read. */''');t=t.replace('\tinput_registered = 0;','\tinput_registered = 0;\n\tcurrent_registered = 0;')
 x='''	extensible = 1;
	if ((target_object->flags & VM_OBJECT_NOT_EXTENSIBLE) != 0U)
		extensible = 0;''';assert x in t;t=t.replace(x,'''
	/* Extent traps may sever the target's last payload owner while compatibility still needs the original descriptor. */
	current_roots.realm = realm;
	current_roots.source = VM_VALUE_UNDEFINED;
	current_roots.descriptor = &current;
	current_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &current_roots);
	if (status != 0)
		goto cleanup;
	current_registered = 1;
	status = vm_is_extensible(realm, target_object, &extensible);
	if (status != 0)
		goto cleanup;''');t=t.replace('''	if (input_registered)
		vm_heap_remove_tracer''','''	if (current_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &current_roots);
	if (input_registered)
		vm_heap_remove_tracer''');return t
edit('access_proxy_define',define);p.write_text(s)
p=Path('userland/desktop/libbrowser/vm/object.c');s=p.read_text();s=s.replace('Creates the private noncallable Proxy read primitive without publishing a JS constructor.\n * Callable and Proxy targets remain excluded until their internal methods are implemented.','Creates private managed noncallable Proxy records without publishing a JS constructor.\n * Callable targets require callable internal dispatch and are rejected.')
a=s.index('int\nvm_proxy_create(');b=s.index('\n}\n',a)+2;t=s[a:b].replace('\n\tstruct vm_object *object;','').replace('''	/* This internal stage deliberately excludes operations requiring callable or nested-target semantics. */
	object = (struct vm_object *)vm_value_as_cell(target);''','''	/* Callable targets require separate call and construct dispatch; object targets may themselves be Proxies. */''').replace('if (callable || object->kind == VM_KIND_PROXY)', 'if (callable)').replace('Callable and Proxy targets require later Proxy internal methods','Callable Proxy targets require callable internal dispatch');s=s[:a]+t+s[b:];p.write_text(s)
(q/'function-review-scope.json').write_text(json.dumps({'userland/desktop/libbrowser/vm/access.c':['access_proxy_get','access_proxy_has','access_proxy_get_own','access_proxy_define'],'userland/desktop/libbrowser/vm/object.c':['vm_proxy_create']},indent=2)+'\n');print('4 invariant observers + noncallable nested factory')
