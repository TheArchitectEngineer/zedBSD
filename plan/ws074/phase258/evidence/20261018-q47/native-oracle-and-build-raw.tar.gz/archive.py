from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
q=Path('build/ws074-20261018/q47');v=q/'final';out=Path('plan/ws074/phase258/evidence/20261018-q47')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in source.items())
p=json.loads((q/'final-protocol.json').read_text());assert p['conditions']==658 and p['native_matches'] and not p['chrome_matches'] and p['chrome_qualified_comparison_complete'] and p['chrome_matching_individual_conditions']==656 and len(p['known_huge_length_differences'])==2 and p['native_global_not_exposed_and_ownership']
pre=json.loads((q/'precode-native-proof.json').read_text());assert len(pre['failed'])==36 and pre['returncode']==1
public=json.loads((q/'public-precode-final-proof.json').read_text());assert public['all36_final_native_and_genuine_chrome_PASS']
runs=json.loads((v/'native-runs.json').read_text());assert len(runs)==12 and all(x['returncode']==0 for x in runs)
acid=json.loads((v/'acid/report.json').read_text());assert acid['acid3']['score']=='100' and acid['acid3']['different_pixels']==0 and acid['acid3_inventory']['pass_count']==100 and acid['acid2']['different_pixels']==873
n=json.loads((q/'native-proof.json').read_text());old=json.loads(Path('build/ws074-20261018/q38/native-proof.json').read_text());assert len(n['runs'])==4
for a,b in zip(n['runs'],old['runs']):assert a['callbacks']==b['callbacks'] and a['source_sha256']==b['source_sha256'] and a['returncode']==0 and a['ownership'] and a['end']
validator=json.loads((q/'webidl-validator-proof.json').read_text());a,b=validator['runs'];assert a['callbacks']==b['callbacks'] and [r['status'] for r in a['callbacks']]==[0,0,1] and a['returncode']==b['returncode']==0 and b['ownership']
assert not any(x in (q/'host-build.log').read_text() for x in ['warning:','error:'])
for f in q.glob('target-*.log'):assert not f.read_bytes()
assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
style=json.loads((q/'source-audit.json').read_text());assert style['raw_allowed_cleanup']==125 and style['other_checker_findings']==0
oldh=Path('plan/ws074/phase258/evidence/20261018-q46/harness-all-raw.tar.gz');assert digest(oldh)=='4247433ec00c0cb9f7d6fcae320b1c9dd8f346ce90517456351ec87d79b60589'
out.mkdir(parents=True,exist_ok=False)
paths=[f for f in q.rglob('*') if f.is_file() and f.suffix in ['.py','.sh','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'engine' not in f.parts and 'target' not in f.parts and not any(x.endswith('-data') or x=='data' for x in f.parts)];paths.append(v/'engine/proxy-read.js');mapping={str(p.resolve().relative_to(q.resolve())):p for p in paths};archive=out/'native-oracle-and-build-raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,path in sorted(mapping.items()):t.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 count=0
 for member in t:assert t.extractfile(member).read()==mapping[member.name].read_bytes();count+=1
assert count==len(mapping)
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),selection='4e0c49fdb',source_hash_count=len(source),conditions=658,native_pass=658,chrome_pass=656,new_conditions=36,precode_failed_conditions=36,precode_cause='nested target bound; not 36 independent bugs',new36_genuine_chrome_match=True,old622_prefix_unchanged=True,all_chrome_equality=False,oracle='q36 classifier filter inherited, q43 huge2 native primary ordered Get versus Chrome pre-index RangeError retained; new36 genuine Chrome matches; no source/oracle/expected changes',full_changed_C=style,native_gates=runs,native_snapshot_GC=['actual fixed data target owns fresh object payload, inner actual IsExtensible trap revokes inner Proxy','outer descriptor value getter actual GC after target operation frames retire: weak observer proves actualtarget reclaimed and sole snapshot payload alive','getter returns that same live payload and actual fixed-property SameValue validation succeeds','output-only root then target/inner/outer/handlers/representation graph all reclaimed, final output-root removal then payload actual reclaim'],old_native_GC_differential_not_measured=True,nested_fresh_GetPrototypeOf_output_post_target_extent_actual_GC=True,callable_target_bound_retained=True,nested_target_bound_removed=True,global_Proxy_Reflect_unexposed=True,acid3_score=100,acid3_inventory=100,acid3_pixels=0,acid2_existing_pixels=873,original_webidl_q38_same_callbacks=True,additional_validator_negative_rule_callbacks=a['callbacks'],harness_latest_measured='q46 1508 all callback/completion exactly q44, 256.7 seconds',current_pair_full_harness_not_measured=True,official_score=1482,denominator=3805,held=0,unattempted=275,static_scripted_crash_reused='q28',current_pair_images_crash_not_measured=True,archive=dict(sha256=digest(archive),members=count,all_members_readback=True),remaining=['for-in/spread/JSON/ObjectToString/array IsArray consumers','primitive Set/outer vm_instanceof/BoundFunction/callable Proxy/call/construct/newtarget/global constructor/revocable/Reflect','array upper-index general storage/immutable prototype/typed backing/p100/full target/WS acceptance','shared Master/Queue/cache/GitHub projections pending Q1'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['approval-snapshot.md','final-protocol.json','precode-native-proof.json','public-precode-final-proof.json','source-audit.json','old-prefix-proof.json','versions.json','native-proof.json','webidl-validator-proof.json','target-commands-2.json']:shutil.copy2(q/name,out/name)
for name in ['source-proof.json','source-commit.txt','shared-input-comparison.json','native-runs.json']:shutil.copy2(v/name,out/name)
shutil.copy2(v/'acid/report.json',out/'acid-report.json')
print('archive',count,digest(archive))
