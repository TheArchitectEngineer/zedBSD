static int access_proxy_get(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, vm_value receiver, vm_value *result);
static int access_proxy_has(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, int *found);
static int access_proxy_get_own(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, struct vm_descriptor *descriptor, int *found);
static int access_proxy_define(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, const struct vm_descriptor *descriptor, int *done);
int vm_proxy_create(struct vm_realm *realm, vm_value target, vm_value handler, vm_value *result);
int main(int argc, char **argv);
static int nested_snapshot_extent(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int nested_snapshot_descriptor(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int nested_snapshot_value(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int nested_snapshot_pressure(struct page *page);

static int
access_proxy_get(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	vm_value receiver,
	vm_value *result)
{
	struct vm_cell *roots[8];
	struct vm_descriptor descriptor;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value trap_key;
	vm_value args[3];
	vm_value produced;
	vm_value method_key;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_symbol;
	int found;
	int equal;
	int status;

	/* Snapshot target and handler before any script can revoke the Proxy. */
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(receiver);
	if (is_cell)
		roots[4] = vm_value_as_cell(receiver);
	roots[5] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[5] = vm_value_as_cell(key);
	roots[6] = NULL;
	roots[7] = NULL;
	registered = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked Proxy fails before consulting the handler. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot get a property of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod accepts null as absence and rejects other noncallable traps. */
	method_key = vm_key_from_ascii(realm->heap, "get");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Resolve the current get trap through ordinary method lookup. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_get_receiver(realm, target, key, receiver, result);
		goto cleanup;
	}

	/* A trap getter may have returned a function retained only by this native frame. */
	roots[6] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[5] = &string->cell;
	}

	/* A property trap receives the actual target, a string or symbol key, and the original receiver. */
	args[0] = target;
	args[1] = trap_key;
	args[2] = receiver;
	status = vm_call(realm, method, handler, args, 3, &produced);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(produced);
	if (is_cell)
		roots[7] = vm_value_as_cell(produced);

	/* Invariants use the original target even if the trap revoked its Proxy. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, &descriptor, &found);
	if (status != 0)
		goto cleanup;

	/* Nonconfigurable own descriptors constrain the value a trap may report. */
	if (found && (descriptor.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		if ((descriptor.has & VM_HAS_VALUE) != 0U && (descriptor.attributes & VM_PROPERTY_WRITABLE) == 0U) {
			equal = vm_same_value(produced, descriptor.value);
			if (!equal) {
				status = vm_throw_type_error(realm, "Proxy get trap changed a fixed data property");
				goto cleanup;
			}
		}

		/* A fixed accessor without a getter can expose only undefined. */
		if ((descriptor.has & VM_HAS_GET) != 0U &&
		    descriptor.getter == VM_VALUE_UNDEFINED &&
		    produced != VM_VALUE_UNDEFINED) {
			status = vm_throw_type_error(realm, "Proxy get trap supplied a value for a fixed getterless property");
			goto cleanup;
		}
	}

	/* Publish the trap result only after every fixed-property invariant succeeds. */
	*result = produced;
	status = 0;

cleanup:
	/* Keep no registrations referring to expired C stack slots. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the original receiver's read produced the validated value. */
	return 0;
}

static int
access_proxy_has(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	int *found)
{
	struct vm_cell *roots[6];
	struct vm_descriptor descriptor;
	struct vm_object *object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value args[2];
	vm_value produced;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_symbol;
	int present;
	int extensible;
	int truth;
	int status;

	/* Revocation during method lookup cannot retire the operation's original protocol participants. */
	*found = 0;
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[4] = vm_value_as_cell(key);
	roots[5] = NULL;
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked Proxy must fail before any handler access. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot search a revoked Proxy");
		goto cleanup;
	}

	/* Fetch the current has trap using the ordinary GetMethod rules. */
	method_key = vm_key_from_ascii(realm->heap, "has");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Read the current has method before choosing trap or target fallback. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(target), key, found);
		goto cleanup;
	}

	/* The trap may be a fresh function returned only to this native frame. */
	roots[5] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[4] = &string->cell;
	}

	/* Has receives exactly the actual target and a string-or-symbol property key. */
	args[0] = target;
	args[1] = trap_key;
	status = vm_call(realm, method, handler, args, 2, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (truth) {
		*found = 1;
		status = 0;
		goto cleanup;
	}

	/* A false result inspects the original target after the trap's changes. */
	object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_get_own_property(realm, object, key, &descriptor, &present);
	if (status != 0)
		goto cleanup;

	/* Only an existing own property constrains a false has result. */
	if (present) {
		if ((descriptor.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
			status = vm_throw_type_error(realm, "Proxy has trap hid a fixed own property");
			goto cleanup;
		}

		/* A nonextensible target also keeps its configurable own properties visible. */
		status = vm_is_extensible(realm, object, &extensible);
		if (status != 0)
			goto cleanup;
		if (!extensible) {
			status = vm_throw_type_error(realm, "Proxy has trap hid a nonextensible target's own property");
			goto cleanup;
		}
	}

	/* The missing or legally hidden property produces an ordinary false result. */
	status = 0;

cleanup:
	/* Unregister only slots acquired before an allocation or trap failure. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Propagate the original failure after releasing this native frame's roots. */
	if (status != 0)
		return status;

	/* Succeeded: the reported presence respects the target's actual invariants. */
	return 0;
}

static int
access_proxy_get_own(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	struct vm_descriptor *descriptor,
	int *found)
{
	struct vm_cell *roots[8];
	struct access_descriptor_roots current_roots;
	struct access_descriptor_roots result_roots;
	struct vm_descriptor current;
	struct vm_object *target_object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value produced;
	vm_value args[2];
	unsigned index;
	unsigned registered;
	int current_registered;
	int result_registered;
	int is_cell;
	int is_object;
	int is_symbol;
	int present;
	int extensible;
	int allowed;
	int status;

	/* Absent target descriptors have no payload slots for the snapshot tracer to inspect. */
	memset(&current, 0, sizeof(current));

	/* Preserve the original target and handler even if a getter or trap revokes the record. */
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[4] = vm_value_as_cell(key);
	roots[5] = NULL;
	roots[6] = NULL;
	roots[7] = NULL;
	registered = 0;
	current_registered = 0;
	result_registered = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* A revoked record cannot consult any handler property. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot get a descriptor of a revoked Proxy");
		goto cleanup;
	}

	/* Resolve the dynamic descriptor trap through ordinary GetMethod semantics. */
	method_key = vm_key_from_ascii(realm->heap, "getOwnPropertyDescriptor");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A missing or null method delegates to the original target's own operation. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, descriptor, found);
		goto cleanup;
	}

	/* Retain a fresh callable trap and turn internal integer indices into script-visible strings. */
	roots[5] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[6] = &string->cell;
	}

	/* The trap receives only the original target and normalized property key with handler as this. */
	args[0] = target;
	args[1] = trap_key;
	status = vm_call(realm, method, handler, args, 2, &produced);
	if (status != 0)
		goto cleanup;
	is_cell = vm_value_is_cell(produced);
	if (is_cell)
		roots[7] = vm_value_as_cell(produced);
	is_object = vm_value_is_object(produced);
	if (!is_object && produced != VM_VALUE_UNDEFINED) {
		status = vm_throw_type_error(realm, "Proxy descriptor trap must return an object or undefined");
		goto cleanup;
	}

	/* Target observation precedes all getters on the returned descriptor object. */
	target_object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_get_own_property(realm, target_object, key, &current, &present);
	if (status != 0)
		goto cleanup;
	/* Target extent callbacks may revoke or mutate its graph, so retain all flagged snapshot payloads first. */
	current_roots.realm = realm;
	current_roots.source = VM_VALUE_UNDEFINED;
	current_roots.descriptor = &current;
	current_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &current_roots);
	if (status != 0)
		goto cleanup;
	current_registered = 1;
	/* Undefined output skips extent observation when the target property is absent or already fixed. */
	if (produced == VM_VALUE_UNDEFINED) {
		if (!present) {
			status = 0;
			goto cleanup;
		}

		/* A fixed own property cannot be hidden, regardless of the target's extensibility. */
		if ((current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
			status = vm_throw_type_error(realm, "Proxy descriptor trap cannot hide this own property");
			goto cleanup;
		}

		/* Only a configurable present property requires actual target extensibility on the absence path. */
		status = vm_is_extensible(realm, target_object, &extensible);
		if (status != 0)
			goto cleanup;
		if (!extensible) {
			status = vm_throw_type_error(realm, "Proxy descriptor trap cannot hide this own property");
			goto cleanup;
		}

		/* The observed configurable property may be hidden on an extensible target. */
		status = 0;
		goto cleanup;
	}

	/* Nonundefined output observes target extensibility before any returned descriptor getter executes. */
	status = vm_is_extensible(realm, target_object, &extensible);
	if (status != 0)
		goto cleanup;

	/* The original trap output and every converted field survive descriptor getters independently. */
	result_roots.realm = realm;
	result_roots.source = produced;
	result_roots.descriptor = descriptor;
	result_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &result_roots);
	if (status != 0)
		goto cleanup;
	result_registered = 1;
	status = vm_to_property_descriptor(realm, produced, descriptor);
	if (status != 0)
		goto cleanup;
	vm_complete_property_descriptor(descriptor);

	/* Compatibility uses the pre-conversion extensibility and target descriptor snapshots. */
	allowed = access_descriptor_compatible(extensible, present, &current, descriptor);
	if (!allowed) {
		status = vm_throw_type_error(realm, "Proxy descriptor trap returned an incompatible descriptor");
		goto cleanup;
	}

	/* Nonconfigurable claims must already be true of the target's observed own property. */
	if ((descriptor->attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		if (!present || (current.attributes & VM_PROPERTY_CONFIGURABLE) != 0U) {
			status = vm_throw_type_error(realm, "Proxy descriptor trap invented a nonconfigurable property");
			goto cleanup;
		}

		/* A still-writable fixed property cannot be reported as newly read-only. */
		if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U) {
			if ((current.attributes & VM_PROPERTY_WRITABLE) != 0U) {
				status = vm_throw_type_error(realm, "Proxy descriptor trap invented a fixed read-only property");
				goto cleanup;
			}
		}
	}

	/* Publish presence only after conversion, completion and every invariant have passed. */
	*found = 1;
	status = 0;

cleanup:
	/* Retire snapshot and output tracers before the stack descriptor storage leaves this frame. */
	if (result_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &result_roots);
	if (current_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &current_roots);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve errors without publishing a partially checked descriptor. */
	if (status != 0)
		return status;

	/* Succeeded: absence or the fully checked descriptor is available to the caller. */
	return 0;
}

static int
access_proxy_define(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *done)
{
	struct vm_cell *roots[8];
	struct access_descriptor_roots input_roots;
	struct access_descriptor_roots current_roots;
	struct vm_descriptor current;
	struct vm_object *target_object;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value representation;
	vm_value produced;
	vm_value args[3];
	unsigned index;
	unsigned registered;
	int input_registered;
	int current_registered;
	int depth_owned;
	int is_cell;
	int is_symbol;
	int truth;
	int present;
	int extensible;
	int setting_fixed;
	int allowed;
	int status;

	/* No absent target descriptor exposes uninitialized payloads to its eventual snapshot tracer. */
	memset(&current, 0, sizeof(current));

	/* Snapshot protocol participants and clear the Boolean output before any observable method read. */
	*done = 0;
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	is_cell = vm_value_is_cell(key);
	if (is_cell)
		roots[4] = vm_value_as_cell(key);
	roots[5] = NULL;
	roots[6] = NULL;
	roots[7] = NULL;
	registered = 0;
	input_registered = 0;
	current_registered = 0;
	depth_owned = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Retain flagged original input values independently of the separately mutable trap argument object. */
	input_roots.realm = realm;
	input_roots.source = VM_VALUE_UNDEFINED;
	input_roots.descriptor = descriptor;
	input_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &input_roots);
	if (status != 0)
		goto cleanup;
	input_registered = 1;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		goto cleanup;
	}

	/* This frame owns one property depth until its normal or abrupt completion. */
	realm->property_depth++;
	depth_owned = 1;
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot define a property of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod observes the current define trap and treats null as absence. */
	method_key = vm_key_from_ascii(realm->heap, "defineProperty");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Missing traps delegate the unchanged partial descriptor to the original target. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, descriptor, done);
		goto cleanup;
	}

	/* Retain a fresh method and normalize internal indices without altering symbol identity. */
	roots[5] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[6] = &string->cell;
	}

	/* A trap sees exactly the present descriptor fields as ordinary writable data properties. */
	status = vm_from_property_descriptor(realm, descriptor, &representation);
	if (status != 0)
		goto cleanup;
	roots[7] = vm_value_as_cell(representation);
	args[0] = target;
	args[1] = trap_key;
	args[2] = representation;
	status = vm_call(realm, method, handler, args, 3, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (!truth) {
		status = 0;
		goto cleanup;
	}

	/* Successful traps are constrained by the original target's state after the trap has run. */
	target_object = (struct vm_object *)vm_value_as_cell(target);
	status = vm_get_own_property(realm, target_object, key, &current, &present);
	if (status != 0)
		goto cleanup;

	/* Extent traps may sever the target's last payload owner while compatibility still needs the original descriptor. */
	current_roots.realm = realm;
	current_roots.source = VM_VALUE_UNDEFINED;
	current_roots.descriptor = &current;
	current_roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &current_roots);
	if (status != 0)
		goto cleanup;
	current_registered = 1;
	status = vm_is_extensible(realm, target_object, &extensible);
	if (status != 0)
		goto cleanup;
	setting_fixed = 0;
	if ((descriptor->has & VM_HAS_CONFIGURABLE) != 0U && (descriptor->attributes & VM_PROPERTY_CONFIGURABLE) == 0U)
		setting_fixed = 1;
	if (!present) {
		if (!extensible || setting_fixed) {
			status = vm_throw_type_error(realm, "Proxy define trap cannot invent this property");
			goto cleanup;
		}
	} else {
		/* Existing properties use the original input fields rather than the trap's mutable object. */
		allowed = access_descriptor_compatible(extensible, present, &current, descriptor);
		if (!allowed) {
			status = vm_throw_type_error(realm, "Proxy define trap accepted an incompatible descriptor");
			goto cleanup;
		}

		/* An explicit fixed claim must already hold on the target after the trap. */
		if (setting_fixed && (current.attributes & VM_PROPERTY_CONFIGURABLE) != 0U) {
			status = vm_throw_type_error(realm, "Proxy define trap invented a nonconfigurable property");
			goto cleanup;
		}

		/* A nonconfigurable data property must already be read-only before a false writable claim succeeds. */
		if ((current.has & VM_HAS_VALUE) != 0U &&
		    (current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U &&
		    (current.attributes & VM_PROPERTY_WRITABLE) != 0U) {
			if ((descriptor->has & VM_HAS_WRITABLE) != 0U && (descriptor->attributes & VM_PROPERTY_WRITABLE) == 0U) {
				status = vm_throw_type_error(realm, "Proxy define trap invented a fixed read-only property");
				goto cleanup;
			}
		}
	}

	/* Report success only after every post-trap invariant agrees with the unchanged input descriptor. */
	*done = 1;
	status = 0;

cleanup:
	/* The original descriptor pointer and depth ownership end with this native frame. */
	if (depth_owned)
		realm->property_depth--;
	if (current_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &current_roots);
	if (input_registered)
		vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &input_roots);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve errors without changing refusal into successful definition. */
	if (status != 0)
		return status;

	/* Succeeded: done distinguishes a valid truthy trap result from ordinary refusal. */
	return 0;
}

int
vm_proxy_create(
	struct vm_realm *realm,
	vm_value target,
	vm_value handler,
	vm_value *result)
{
	struct vm_proxy *proxy;
	struct vm_cell *roots[4];
	vm_value values[2];
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_object;
	int callable;
	int status;

	/* Protect incoming ownership before either validation errors or allocation can collect. */
	*result = VM_VALUE_UNDEFINED;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	values[0] = target;
	values[1] = handler;
	for (index = 0; index < 2U; index++) {
		roots[index + 1U] = NULL;
		is_cell = vm_value_is_cell(values[index]);
		if (is_cell)
			roots[index + 1U] = vm_value_as_cell(values[index]);
	}

	/* Reserve the unpublished-record root slot before acquiring registrations. */
	roots[3] = NULL;
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Both Proxy protocol participants must be objects. */
	is_object = vm_value_is_object(target);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy target must be an object");
		goto cleanup;
	}

	/* Validate the handler independently before allocating the record. */
	is_object = vm_value_is_object(handler);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Proxy handler must be an object");
		goto cleanup;
	}

	/* Callable targets require separate call and construct dispatch; object targets may themselves be Proxies. */
	callable = vm_value_is_callable(target);
	if (callable) {
		status = vm_throw_type_error(realm, "Callable Proxy targets require callable internal dispatch");
		goto cleanup;
	}

	/* Retain the newborn before ordinary shape initialization can allocate. */
	proxy = vm_heap_alloc(realm->heap, &object_proxy_type, sizeof(*proxy));
	if (proxy == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Initialize every traced payload field before shape initialization can collect. */
	roots[3] = &proxy->object.cell;
	proxy->target = target;
	proxy->handler = handler;
	proxy->object.kind = VM_KIND_PROXY;
	proxy->object.internal = VM_VALUE_UNDEFINED;
	status = vm_object_init(realm->heap, &proxy->object, NULL);
	if (status != 0)
		goto cleanup;

	/* Only a complete native record becomes visible to the caller. */
	*result = vm_value_cell(proxy);

cleanup:
	/* Release only registrations actually acquired before a possible failure. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the caller owns the managed read primitive. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
nested_snapshot_extent(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *inner;
	vm_value target;
	int extensible;
	int status;

	UNUSED_PARAMETER(receiver);

	/* The integer observer supplies no root; the outer operation must still own the inner target Proxy. */
	inner = vm_heap_find_cell(realm->heap, nested_snapshot_case.inner_address);
	if (inner == NULL)
		return EFAULT;
	status = vm_proxy_revoke(realm, vm_value_cell(inner));
	if (status != 0)
		return status;
	target = js_argument(args, count, 0);
	status = vm_is_extensible(realm, (struct vm_object *)vm_value_as_cell(target), &extensible);
	if (status != 0)
		return status;
	*result = vm_value_boolean(extensible);

	/* Succeeded: this trap returns while retiring the inner Proxy's original target and handler edges. */
	return 0;
}

static int
nested_snapshot_descriptor(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value key;
	int status;

	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* The descriptor representation belongs only to the original outer handler graph. */
	key = vm_key_from_ascii(realm->heap, "resultDescriptor");
	if (key == VM_VALUE_EMPTY)
		return ENOMEM;
	status = vm_get(realm, receiver, key, result);
	if (status != 0)
		return status;

	/* Succeeded: descriptor conversion must wait until the actual nested target checks finish. */
	return 0;
}

static int
nested_snapshot_value(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_cell *found;
	struct vm_heap_stats before;
	struct vm_heap_stats after;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* No conservative stack or original target edge may hide missing native descriptor ownership. */
	vm_heap_stats(realm->heap, &before);
	vm_heap_collect(realm->heap);
	vm_heap_stats(realm->heap, &after);
	if (after.collections <= before.collections)
		return EFAULT;
	found = vm_heap_find_cell(realm->heap, nested_snapshot_case.target_address);
	if (found != NULL)
		return EFAULT;
	found = vm_heap_find_cell(realm->heap, nested_snapshot_case.payload_address);
	if (found == NULL)
		return EFAULT;
	nested_snapshot_case.getter_collections++;
	*result = vm_value_cell(found);

	/* Succeeded: only the native current-descriptor snapshot retained the fixed data payload across collection. */
	return 0;
}

static int
nested_snapshot_pressure(
	struct page *page)
{
	struct vm_object *target;
	struct vm_object *payload;
	struct vm_object *inner_handler;
	struct vm_object *outer_handler;
	struct vm_object *representation;
	struct vm_cell *roots[8];
	struct vm_cell *found;
	struct vm_descriptor descriptor;
	uintptr_t addresses[7];
	vm_value key;
	vm_value inner;
	vm_value outer;
	unsigned registered;
	unsigned index;
	int present;
	int status;

	/* Temporary setup roots retire before the real operation, leaving only its production ownership. */
	memset(roots, 0, sizeof(roots));
	memset(&nested_snapshot_case, 0, sizeof(nested_snapshot_case));
	registered = 0;
	for (index = 0; index < 8U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The fixed target property initially supplies the only graph edge to a fresh ordinary payload. */
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* A fresh payload has no global, atom, shape transition or native registry owner. */
	roots[0] = &target->cell;
	payload = vm_object_create(page->heap, NULL);
	if (payload == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Nonconfigurable nonwritable data forces later SameValue comparison against the retained snapshot. */
	roots[1] = &payload->cell;
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Actual ordinary storage, rather than a synthetic native descriptor, owns the original fixed value. */
	status = vm_object_define(page->heap, target, key, vm_value_cell(payload), 0U);
	if (status != 0)
		goto cleanup;
	inner_handler = vm_object_create(page->heap, NULL);
	if (inner_handler == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Its native IsExtensible trap runs through vm_call and revokes the inner record without capturing the target. */
	roots[2] = &inner_handler->cell;
	status = js_builtin_method(page->realm, inner_handler, "isExtensible", 1, nested_snapshot_extent);
	if (status != 0)
		goto cleanup;
	status = vm_proxy_create(page->realm, vm_value_cell(target), vm_value_cell(inner_handler), &inner);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(inner);
	representation = vm_object_create(page->heap, NULL);
	if (representation == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* This representation owns no payload until its later value accessor retrieves the live native snapshot. */
	roots[4] = &representation->cell;
	status = js_builtin_accessor(page->realm, representation, "value", nested_snapshot_value, NULL);
	if (status != 0)
		goto cleanup;
	status = js_builtin_value(page->realm, representation, "configurable", VM_VALUE_FALSE, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = js_builtin_value(page->realm, representation, "writable", VM_VALUE_FALSE, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	outer_handler = vm_object_create(page->heap, NULL);
	if (outer_handler == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The outer trap returns its real representation while the target remains the actual inner Proxy. */
	roots[5] = &outer_handler->cell;
	status = js_builtin_value(page->realm, outer_handler, "resultDescriptor", vm_value_cell(representation), VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, outer_handler, "getOwnPropertyDescriptor", 2, nested_snapshot_descriptor);
	if (status != 0)
		goto cleanup;
	status = vm_proxy_create(page->realm, inner, vm_value_cell(outer_handler), &outer);
	if (status != 0)
		goto cleanup;
	roots[6] = vm_value_as_cell(outer);

	/* Weak integer observations never keep the old target, payload or either Proxy alive. */
	nested_snapshot_case.target_address = (uintptr_t)target;
	nested_snapshot_case.payload_address = (uintptr_t)payload;
	nested_snapshot_case.inner_address = (uintptr_t)vm_value_as_cell(inner);
	for (index = 0; index < 7U; index++) {
		addresses[index] = (uintptr_t)roots[index];
		roots[index] = NULL;
	}

	/* Actual target GetOwn precedes inner revoke, then descriptor value conversion collects the discarded target. */
	status = vm_get_own_property(page->realm, (struct vm_object *)vm_value_as_cell(outer), key, &descriptor, &present);
	if (status != 0)
		goto cleanup;
	if (!present || nested_snapshot_case.getter_collections != 1U) {
		status = EFAULT;
		goto cleanup;
	}

	/* The resulting descriptor contains exactly the live fixed payload after the original target was reclaimed. */
	roots[7] = vm_value_as_cell(descriptor.value);
	if ((uintptr_t)roots[7] != nested_snapshot_case.payload_address) {
		status = EFAULT;
		goto cleanup;
	}

	/* Output-only ownership now allows the complete original target, handlers, representation and Proxy graph to go. */
	vm_heap_collect(page->heap);
	for (index = 0; index < 7U; index++) {
		if (index == 1U)
			continue;
		found = vm_heap_find_cell(page->heap, addresses[index]);
		if (found != NULL) {
			status = EFAULT;
			goto cleanup;
		}
	}

	/* The payload remains independently rooted after every participant that produced its descriptor has gone. */
	found = vm_heap_find_cell(page->heap, nested_snapshot_case.payload_address);
	if (found == NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* Dropping the final output root makes the actual fresh payload reclaimable as well. */
	roots[7] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, nested_snapshot_case.payload_address);
	if (found != NULL) {
		status = EFAULT;
		goto cleanup;
	}

	/* Native snapshot ownership survived later collection and left no permanently retained graph. */
	status = 0;

cleanup:
	/* Partial construction and every abrupt native operation retire all setup roots and weak observations. */
	memset(&nested_snapshot_case, 0, sizeof(nested_snapshot_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve any lifetime, order or reclamation failure after releasing native registrations. */
	if (status != 0)
		return status;

	/* Succeeded: the sole fixed snapshot payload outlived its original target and was finally reclaimed. */
	return 0;
}
