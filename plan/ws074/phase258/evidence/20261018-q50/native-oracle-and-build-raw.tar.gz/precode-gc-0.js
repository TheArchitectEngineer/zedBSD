(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-reviver-gc-nested-root-and-holder',function(){var r=JSON.parse('{"a":[1,{"b":2}],"c":3}',function(k,v){collectReadProxy();return v;});return r.a[1].b===2&&r.c===3;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
