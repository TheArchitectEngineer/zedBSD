(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-reviver-gc-primitive-root-holder',function(){var holder,r=JSON.parse('1',function(k,v){holder=this;collectReadProxy();return v+1;});return r===2&&holder['']===1;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
