static int json_parse(struct vm_realm *realm, vm_value this_value, const vm_value *args, unsigned count, vm_value *result);
static int json_parse_inner(struct json_parser *parser, const vm_value *args, unsigned count, vm_value *result);
static int json_object(struct json_parser *parser, vm_value *value);
static int json_array(struct json_parser *parser, vm_value *value);
static int json_parse_container(struct json_parser *parser, vm_value *value, int is_array);
static int json_object_inner(struct json_parse_roots *roots, vm_value *value);
static int json_array_inner(struct json_parse_roots *roots, vm_value *value);
static int json_internalize(struct vm_realm *realm, vm_value reviver, vm_value holder, vm_value key, vm_value *result, unsigned depth);
static int json_internalize_inner(struct json_reviver_roots *roots, vm_value *result, unsigned depth);
static int json_enumerable_keys(struct vm_realm *realm, vm_value object, struct wb_vector *keys);
static void json_trace_parser(struct vm_heap *heap, void *context);
static void json_trace_parse_frame(struct vm_heap *heap, void *context);
static void json_trace_reviver(struct vm_heap *heap, void *context);
int main(int argc, char **argv);
static int proxy_parse_pressure(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);

static int
json_parse(
	struct vm_realm *realm,
	vm_value this_value,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct json_parser parser;
	int status;

	UNUSED_PARAMETER(this_value);

	/* Only initialized native slots are visible to the collector during coercion and recursion. */
	memset(&parser, 0, sizeof(parser));
	parser.realm = realm;
	parser.root_value = VM_VALUE_UNDEFINED;
	parser.holder = VM_VALUE_UNDEFINED;
	parser.root_key = VM_VALUE_UNDEFINED;
	parser.reviver = js_argument(args, count, 1);
	status = vm_heap_add_tracer(realm->heap, json_trace_parser, &parser);
	if (status != 0)
		return status;

	/* Syntax errors and callback exceptions retire exactly the same top-level ownership. */
	status = json_parse_inner(&parser, args, count, result);
	vm_heap_remove_tracer(realm->heap, json_trace_parser, &parser);
	if (status != 0)
		return status;

	/* Succeeded: the caller owns the final parsed or revived value. */
	return 0;
}

static int
json_parse_inner(
	struct json_parser *parser,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_realm *realm;
	struct vm_string *text;
	struct vm_object *root;
	vm_value argument;
	int callable;
	int status;

	/* The top-level traced frame is already registered before input coercion. */
	realm = parser->realm;

	/* The text, then one value and nothing after it but blanks. */
	argument = js_argument(args, count, 0);
	status = vm_to_string(realm, argument, &text);
	if (status != 0)
		return status;

	/* Retain the coerced text before the first container or string allocation. */
	parser->text = text;
	json_skip_space(parser);
	status = json_value(parser, &parser->root_value);
	if (status != 0)
		return status;

	/* Checks for text following the complete parsed value. */
	json_skip_space(parser);
	if (parser->position < text->length) {
		status = json_fail(parser, "Unexpected text after JSON");
		if (status != 0)
			return status;

		/* Succeeded: the VM accepted the JSON exception report. */
		return 0;
	}

	/* Publish the parsed root before checking the optional callback. */
	*result = parser->root_value;

	/* A reviver walks the result from a holder { "": result }. */
	callable = vm_value_is_callable(parser->reviver);
	if (!callable)
		return 0;
	root = vm_object_create(realm->heap, realm->object_prototype);
	if (root == NULL)
		return ENOMEM;

	/* Retain the unpublished holder before allocating its root property key. */
	parser->holder = vm_value_cell(root);

	/* Allocates the empty root key before interning it. */
	status = js_builtin_string(realm, "", &parser->root_key);
	if (status != 0)
		return status;

	/* Interns the root holder key before defining the parsed result. */
	status = vm_key_from_string(realm->heap, (struct vm_string *)vm_value_as_cell(parser->root_key), &parser->root_key);
	if (status != 0)
		return status;

	/* The temporary holder supplies the reviver's root receiver. */
	status = vm_object_define(realm->heap, root, parser->root_key, *result, VM_PROPERTY_DEFAULT);
	if (status != 0)
		return status;

	/* Revives the already parsed root through the actual callback. */
	status = json_internalize(realm, parser->reviver, parser->holder, parser->root_key, result, 0);
	if (status != 0)
		return status;

	/* Succeeded: the final revived root is available. */
	return 0;
}

static int
json_object(
	struct json_parser *parser,
	vm_value *value)
{
	int status;

	/* Keep the container and unfinished property values alive until this recursive parse returns. */
	status = json_parse_container(parser, value, 0);
	if (status != 0)
		return status;

	/* Succeeded: the enclosing frame now owns the completed container. */
	return 0;
}

static int
json_array(
	struct json_parser *parser,
	vm_value *value)
{
	int status;

	/* Keep the container and unfinished property values alive until this recursive parse returns. */
	status = json_parse_container(parser, value, 1);
	if (status != 0)
		return status;

	/* Succeeded: the enclosing frame now owns the completed container. */
	return 0;
}

static int
json_parse_container(
	struct json_parser *parser,
	vm_value *value,
	int is_array)
{
	struct json_parse_roots roots;
	int status;

	/* Register initialized slots even when the first container allocation fails. */
	roots.parser = parser;
	roots.container = VM_VALUE_UNDEFINED;
	roots.name = VM_VALUE_UNDEFINED;
	roots.key = VM_VALUE_UNDEFINED;
	roots.member = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(parser->realm->heap, json_trace_parse_frame, &roots);
	if (status != 0)
		return status;

	/* Every syntax failure and depth-limit exit passes through the same wrapper. */
	if (is_array) {
		status = json_array_inner(&roots, value);
	} else {
		status = json_object_inner(&roots, value);
	}

	/* The enclosing frame now owns successful output; abrupt output has no remaining native owner. */
	vm_heap_remove_tracer(parser->realm->heap, json_trace_parse_frame, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the completed container has transferred to its caller's traced slot. */
	return 0;
}

static int
json_object_inner(
	struct json_parse_roots *roots,
	vm_value *value)
{
	struct json_parser *parser;
	struct vm_object *object;
	uint16_t unit;
	int status;

	/* The active container frame owns every recursive temporary. */
	parser = roots->parser;

	/* Too deep. */
	if (parser->depth >= JSON_DEPTH_MAX) {
		status = vm_throw_range_error(parser->realm, "JSON nested too deeply");
		if (status != 0)
			return status;

		/* Succeeded: the VM accepted the JSON exception report. */
		return 0;
	}

	/* The object. */
	object = vm_object_create(parser->realm->heap, parser->realm->object_prototype);
	if (object == NULL)
		return ENOMEM;

	/* Publishes the container before reading its recursive children. */
	roots->container = vm_value_cell(object);
	*value = roots->container;
	parser->position++;
	parser->depth++;
	json_skip_space(parser);
	unit = json_peek(parser);
	if (unit == '}') {
		parser->position++;
		parser->depth--;
		return 0;
	}

	/* Each "name": value, separated by commas. */
	for (;;) {
		json_skip_space(parser);
		unit = json_peek(parser);
		if (unit != '"') {
			status = json_fail(parser, "Expected a property roots->name in JSON");
			if (status != 0)
				return status;

			/* Succeeded: the invalid input was reported through the VM. */
			return 0;
		}

		/* Reads the checked quoted property name. */
		status = json_string(parser, &roots->name);
		if (status != 0)
			return status;
		json_skip_space(parser);
		unit = json_peek(parser);
		if (unit != ':') {
			status = json_fail(parser, "Expected ':' in JSON");
			if (status != 0)
				return status;

			/* Succeeded: the invalid input was reported through the VM. */
			return 0;
		}

		/* Advances beyond the checked syntax token. */
		parser->position++;
		json_skip_space(parser);
		status = json_value(parser, &roots->member);
		if (status != 0)
			return status;

		/* Interns the parsed name as an object property key. */
		status = vm_key_from_string(parser->realm->heap, (struct vm_string *)vm_value_as_cell(roots->name), &roots->key);
		if (status != 0)
			return status;

		/* Defines the completed value using its resolved key. */
		status = vm_object_define(parser->realm->heap, object, roots->key, roots->member, VM_PROPERTY_DEFAULT);
		if (status != 0)
			return status;
		json_skip_space(parser);
		unit = json_peek(parser);
		if (unit == ',') {
			parser->position++;
			continue;
		}

		/* The end of the object. */
		unit = json_peek(parser);
		if (unit == '}') {
			parser->position++;
			parser->depth--;
			return 0;
		}

		/* Anything else is not JSON. */
		status = json_fail(parser, "Expected ',' or '}' in JSON");
		if (status != 0)
			return status;

		/* Succeeded: the invalid input was reported through the VM. */
		return 0;
	}
}

static int
json_array_inner(
	struct json_parse_roots *roots,
	vm_value *value)
{
	struct json_parser *parser;
	struct vm_object *array;
	uint16_t unit;
	int status;

	/* The active container frame owns every recursive temporary. */
	parser = roots->parser;

	/* Too deep. */
	if (parser->depth >= JSON_DEPTH_MAX) {
		status = vm_throw_range_error(parser->realm, "JSON nested too deeply");
		if (status != 0)
			return status;

		/* Succeeded: the VM accepted the JSON exception report. */
		return 0;
	}

	/* The array. */
	array = vm_array_create(parser->realm->heap, parser->realm->array_prototype);
	if (array == NULL)
		return ENOMEM;

	/* Publishes the container before reading its recursive children. */
	roots->container = vm_value_cell(array);
	*value = roots->container;
	parser->position++;
	parser->depth++;
	json_skip_space(parser);
	unit = json_peek(parser);
	if (unit == ']') {
		parser->position++;
		parser->depth--;
		return 0;
	}

	/* Each value, separated by commas. */
	for (;;) {
		json_skip_space(parser);
		status = json_value(parser, &roots->member);
		if (status != 0)
			return status;

		/* Defines the completed value using its resolved key. */
		status = vm_object_define(parser->realm->heap, array, vm_value_int32((int32_t)array->length), roots->member, VM_PROPERTY_DEFAULT);
		if (status != 0)
			return status;
		json_skip_space(parser);
		unit = json_peek(parser);
		if (unit == ',') {
			parser->position++;
			continue;
		}

		/* The end of the array. */
		unit = json_peek(parser);
		if (unit == ']') {
			parser->position++;
			parser->depth--;
			return 0;
		}

		/* Anything else is not JSON. */
		status = json_fail(parser, "Expected ',' or ']' in JSON");
		if (status != 0)
			return status;

		/* Succeeded: the invalid input was reported through the VM. */
		return 0;
	}
}

static int
json_internalize(
	struct vm_realm *realm,
	vm_value reviver,
	vm_value holder,
	vm_value key,
	vm_value *result,
	unsigned depth)
{
	struct json_reviver_roots roots;
	int status;

	/* Every callback temporary has a valid tagged value before registration. */
	roots.realm = realm;
	roots.reviver = reviver;
	roots.holder = holder;
	roots.key = key;
	roots.value = VM_VALUE_UNDEFINED;
	roots.name = VM_VALUE_UNDEFINED;
	roots.key_value = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, json_trace_reviver, &roots);
	if (status != 0)
		return status;

	/* All recursive, property-policy and callback failures retire their native frame here. */
	status = json_internalize_inner(&roots, result, depth);
	vm_heap_remove_tracer(realm->heap, json_trace_reviver, &roots);
	if (status != 0)
		return status;

	/* Succeeded: the parent owns the returned reviver value. */
	return 0;
}

static int
json_internalize_inner(
	struct json_reviver_roots *roots,
	vm_value *result,
	unsigned depth)
{
	struct vm_realm *realm;
	struct wb_vector keys;
	struct vm_descriptor descriptor;
	struct vm_object *object;
	vm_value element;
	vm_value call_args[2];
	vm_value ignored;
	uint32_t length;
	uint32_t index;
	size_t item;
	int traced;
	int is_array;
	int is_object;
	int done;
	int status;

	/* The active reviver frame retains saved values before any callback or depth error. */
	realm = roots->realm;

	/* The value at the key. */
	if (depth > JSON_DEPTH_MAX) {
		status = vm_throw_range_error(realm, "JSON nested too deeply");
		if (status != 0)
			return status;

		/* Succeeded: the VM accepted the JSON exception report. */
		return 0;
	}

	/* The value at the key. */
	status = vm_get(realm, roots->holder, roots->key, &roots->value);
	if (status != 0)
		return status;

	/* Prepares the one owned key list before any recursive member work. */
	wb_vector_init(&keys, sizeof(vm_value));
	traced = 0;
	status = vm_heap_add_tracer(realm->heap, json_trace_values, &keys);
	if (status != 0)
		goto cleanup;
	traced = 1;

	/* An object's (or an array's) members first, each revived, removed when the reviver answers undefined. */
	is_object = vm_value_is_object(roots->value);
	if (is_object) {
		object = (struct vm_object *)vm_value_as_cell(roots->value);
		status = 0;

		/* Classification observes actual Proxy targets without consulting an ordinary brand field. */
		status = vm_is_array(realm, roots->value, &is_array);
		if (status != 0)
			goto cleanup;
		if (is_array) {
			status = js_builtin_length(realm, roots->value, &length);
			if (status != 0)
				goto cleanup;

			/* Snapshots each array index before callbacks start. */
			for (index = 0; index < length; index++) {
				element = vm_value_int32((int32_t)index);
				status = wb_vector_push(&keys, &element);
				if (status != 0)
					goto cleanup;
			}
		} else {
			status = json_enumerable_keys(realm, roots->value, &keys);
			if (status != 0)
				goto cleanup;
		}

		/* Each member revived. */
		for (item = 0; item < keys.count; item++) {
			element = *(vm_value *)wb_vector_at(&keys, item);

			/* The member revived. */
			status = json_internalize(realm, roots->reviver, roots->value, element, &roots->name, depth + 1U);
			if (status != 0)
				goto cleanup;
			if (roots->name == VM_VALUE_UNDEFINED) {
				status = vm_delete(realm, roots->value, element, 0, &ignored);
				if (status != 0)
					goto cleanup;
			} else {
				memset(&descriptor, 0, sizeof(descriptor));
				descriptor.has = VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE;
				descriptor.attributes = VM_PROPERTY_DEFAULT;
				descriptor.value = roots->name;
				status = vm_define_own_property(realm, object, element, &descriptor, &done);
				if (status != 0)
					goto cleanup;
			}
		}
	}

	/* The snapshot is released before the enclosing value callback. */
cleanup:
	if (traced)
		vm_heap_remove_tracer(realm->heap, json_trace_values, &keys);
	wb_vector_release(&keys);
	if (status != 0)
		return status;

	/* The reviver on the value, with the key as a string. */
	status = json_key_value(realm, roots->key, &roots->key_value);
	if (status != 0)
		return status;
	/* Keep the callback key independently rooted until vm_call has acquired its arguments. */
	call_args[0] = roots->key_value;
	call_args[1] = roots->value;
	status = vm_call(realm, roots->reviver, roots->holder, call_args, 2, result);
	if (status != 0)
		return status;

	/* Succeeded: the reviver returned the enclosing value. */
	return 0;
}

static int
json_enumerable_keys(
	struct vm_realm *realm,
	vm_value object,
	struct wb_vector *keys)
{
	struct vm_descriptor descriptor;
	vm_value key;
	size_t item;
	size_t selected;
	int is_index;
	int is_string;
	int found;
	int status;

	/* The caller's vector tracer retains original and selected names through all descriptor callbacks. */
	status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(object), keys);
	if (status != 0)
		return status;

	/* Symbols are omitted before GetOwnProperty, including Symbols invented by a Proxy trap. */
	selected = 0;
	for (item = 0; item < keys->count; item++) {
		key = *(vm_value *)wb_vector_at(keys, item);
		is_index = vm_value_is_int32(key);
		is_string = vm_value_is_string(key);
		if (!is_index && !is_string)
			continue;

		/* A missing or nonenumerable own property contributes no name to this snapshot. */
		status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
		if (status != 0)
			return status;
		if (!found)
			continue;
		if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
			continue;

		/* Compaction replaces only entries whose descriptor has already been inspected. */
		*(vm_value *)wb_vector_at(keys, selected) = key;
		selected++;
	}

	/* Publish the immutable name sequence before any child value is read. */
	keys->count = selected;
	return 0;
}

static void
json_trace_parser(
	struct vm_heap *heap,
	void *context)
{
	struct json_parser *parser;

	/* Managed realm ownership starts before coercion; text becomes live only after conversion returns. */
	parser = context;
	if (parser->realm->managed)
		vm_heap_mark(heap, &parser->realm->cell);
	if (parser->text != NULL)
		vm_heap_mark(heap, (struct vm_cell *)parser->text);
	vm_heap_mark_value(heap, parser->root_value);
	vm_heap_mark_value(heap, parser->holder);
	vm_heap_mark_value(heap, parser->root_key);
	vm_heap_mark_value(heap, parser->reviver);
}

static void
json_trace_parse_frame(
	struct vm_heap *heap,
	void *context)
{
	struct json_parse_roots *roots;

	/* The surrounding parser frame retains the text and managed realm. */
	roots = context;
	vm_heap_mark_value(heap, roots->container);
	vm_heap_mark_value(heap, roots->name);
	vm_heap_mark_value(heap, roots->key);
	vm_heap_mark_value(heap, roots->member);
}

static void
json_trace_reviver(
	struct vm_heap *heap,
	void *context)
{
	struct json_reviver_roots *roots;

	/* Native key-vector callbacks and direct recursion need independent ownership of every saved value. */
	roots = context;
	if (roots->realm->managed)
		vm_heap_mark(heap, &roots->realm->cell);
	vm_heap_mark_value(heap, roots->reviver);
	vm_heap_mark_value(heap, roots->holder);
	vm_heap_mark_value(heap, roots->key);
	vm_heap_mark_value(heap, roots->value);
	vm_heap_mark_value(heap, roots->name);
	vm_heap_mark_value(heap, roots->key_value);
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* The parser probe reaches the unchanged production allocation threshold without editing heap policy. */
	status = js_builtin_method(page->realm, page->realm->global, "pressureReadProxy", 0, proxy_parse_pressure);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fresh coercion text must survive a later parser allocation after the toString call frame has retired. */
	status = proxy_script(page->realm,
			      "(function(){var before,r=JSON.parse({toString:function(){var text=['{','\"a\":[1,{\"b\":2}]}'].join('');before=pressureReadProxy();return text;}});return r.a[1].b===2&&pressureReadProxy(true)>before;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Publish only the actual threshold-counter and parsed-value gate after both have passed. */
	puts("native JSON parser threshold collection: passed");

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A primitive receiver's temporary source box must survive later depth conversion and then become reclaimable. */
	status = flat_source_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_parse_pressure(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_heap_stats stats;
	struct vm_cell *pressure;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);

	/* Queries allocate nothing and report actual collections rather than a simulated callback count. */
	if (count > 0U) {
		vm_heap_stats(realm->heap, &stats);
		*result = vm_value_number((double)stats.collections);
		return 0;
	}

	/* Drop old pressure before filling the unchanged minimum threshold with one inert, unrooted cell. */
	vm_heap_collect(realm->heap);
	pressure = vm_heap_alloc(realm->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL)
		return ENOMEM;

	/* The next production allocation performs collection after this native call returns. */
	vm_heap_stats(realm->heap, &stats);
	*result = vm_value_number((double)stats.collections);
	return 0;
}
