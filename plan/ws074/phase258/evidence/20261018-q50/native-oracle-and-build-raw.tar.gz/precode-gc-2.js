(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-reviver-gc-detached-saved-object',function(){var parent,seen,r=JSON.parse('{"a":0,"b":{"x":1,"y":2}}',function(k,v){if(k==='a')parent=this;if(k==='x'){delete parent.b;collectReadProxy();}if(k==='b'){collectReadProxy();seen=v.y;}return v;});return seen===2&&r.b.y===2;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
