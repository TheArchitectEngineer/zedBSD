(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-reviver-gc-proxy-keys-and-descriptors',function(){var r=JSON.parse('{"a":0,"b":0}',function(k,v){if(k==='a')this.b=makeReadProxy({x:1,y:2},{ownKeys:function(){collectReadProxy();return ['y','x'];},getOwnPropertyDescriptor:function(t,k){collectReadProxy();return Object.getOwnPropertyDescriptor(t,k);}});return v;});return r.b.x===1&&r.b.y===2;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
