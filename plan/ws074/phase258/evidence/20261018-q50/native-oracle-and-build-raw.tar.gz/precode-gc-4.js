(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-reviver-gc-fresh-child-replacement',function(){var r=JSON.parse('{"a":1,"b":2}',function(k,v){collectReadProxy();if(k==='a')return {fresh:7};return v;});return r.a.fresh===7&&r.b===2;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
