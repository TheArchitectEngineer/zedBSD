(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('json-reviver-gc-callback-error-cleanup',function(){var e={};try{JSON.parse('{"a":1}',function(){collectReadProxy();throw e;});}catch(x){return x===e&&JSON.parse('{"a":2}').a===2;}return false;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
