from pathlib import Path
import re
p=Path('userland/desktop/libbrowser/js/builtin_json.c');s=p.read_text();Path('build/ws074-20261018/q50/original-json.c').write_text(s)
s=s.replace('\tunsigned depth;\n};','\tunsigned depth;\n\tvm_value root_value;\n\tvm_value holder;\n\tvm_value root_key;\n\tvm_value reviver;\n};',1)
pos=s.index('/*\n * The state of one JSON.stringify')
s=s[:pos]+'''/* One recursive parser container retains names and children before they are installed in its object. */
struct json_parse_roots {
 struct json_parser *parser;
 vm_value container;
 vm_value name;
 vm_value key;
 vm_value member;
};

/* One reviver operation retains its saved value independently of callback mutations to the holder. */
struct json_reviver_roots {
 struct vm_realm *realm;
 vm_value reviver;
 vm_value holder;
 vm_value key;
 vm_value value;
 vm_value name;
 vm_value key_value;
};

'''+s[pos:]
pos=s.index('/*\n * Installs JSON.')
s=s[:pos]+'''static void json_trace_parser(struct vm_heap *heap, void *context);
static void json_trace_parse_frame(struct vm_heap *heap, void *context);
static void json_trace_reviver(struct vm_heap *heap, void *context);
static int json_parse_inner(struct json_parser *parser, const vm_value *args, unsigned count, vm_value *result);
static int json_parse_container(struct json_parser *parser, vm_value *value, int is_array);
static int json_object_inner(struct json_parse_roots *roots, vm_value *value);
static int json_array_inner(struct json_parse_roots *roots, vm_value *value);
static int json_internalize_inner(struct json_reviver_roots *roots, vm_value *result, unsigned depth);
static int json_enumerable_keys(struct vm_realm *realm, vm_value object, struct wb_vector *keys);

'''+s[pos:]
def get(n):
 m=re.search(r'static int\n'+n+r'\(\n.*?\n\}',s,re.S);assert m,n;return m
m=get('json_parse');f=m.group();f=f.replace('json_parse(\n\tstruct vm_realm *realm,\n\tvm_value this_value,','json_parse_inner(\n\tstruct json_parser *parser,').replace('\tstruct json_parser parser;','\tstruct vm_realm *realm;');f=f.replace('\tvm_value reviver;\n','').replace('\tvm_value key;\n','').replace('\tUNUSED_PARAMETER(this_value);','\t/* The top-level traced frame is already registered before input coercion. */\n\trealm = parser->realm;');f=f.replace('''	/* Initializes the parser after text coercion succeeds. */
	memset(&parser, 0, sizeof(parser));
	parser.realm = realm;
	parser.text = text;
	json_skip_space(&parser);
	status = json_value(&parser, result);''','''	/* Retain the coerced text before the first container or string allocation. */
 parser->text = text;
 json_skip_space(parser);
 status = json_value(parser, &parser->root_value);''');f=f.replace('json_skip_space(&parser)','json_skip_space(parser)').replace('parser.position','parser->position').replace('json_fail(&parser','json_fail(parser');f=f.replace('\t/* A reviver walks the result from a holder { "": result }. */','\t/* Publish the parsed root before checking the optional callback. */\n\t*result = parser->root_value;\n\n\t/* A reviver walks the result from a holder { "": result }. */');f=f.replace('\treviver = js_argument(args, count, 1);\n\tcallable = vm_value_is_callable(reviver);','\tcallable = vm_value_is_callable(parser->reviver);');f=f.replace('\t/* Allocates the empty root key','\tparser->holder = vm_value_cell(root);\n\n\t/* Allocates the empty root key');f=re.sub(r'(?<![\w.>])key\b','parser->root_key',f);f=re.sub(r'/\*.*?\*/',lambda m:m.group().replace('parser->root_key','key'),f,flags=re.S);f=f.replace('json_internalize(realm, reviver, vm_value_cell(root),','json_internalize(realm, parser->reviver, parser->holder,');s=s[:m.start()]+f+s[m.end():]
pos=s.index('/* JSON.parse(text, reviver). */')
s=s[:pos]+'''/* Retain the input conversion, parsed root and temporary reviver holder through every parser exit. */
static int
json_parse(
 struct vm_realm *realm,
 vm_value this_value,
 const vm_value *args,
 unsigned count,
 vm_value *result)
{
 struct json_parser parser;
 int status;

 UNUSED_PARAMETER(this_value);

 /* Only initialized native slots are visible to the collector during coercion and recursion. */
 memset(&parser, 0, sizeof(parser));
 parser.realm = realm;
 parser.root_value = VM_VALUE_UNDEFINED;
 parser.holder = VM_VALUE_UNDEFINED;
 parser.root_key = VM_VALUE_UNDEFINED;
 parser.reviver = js_argument(args, count, 1);
 status = vm_heap_add_tracer(realm->heap, json_trace_parser, &parser);
 if (status != 0)
  return status;

 /* Syntax errors and callback exceptions retire exactly the same top-level ownership. */
 status = json_parse_inner(&parser, args, count, result);
 vm_heap_remove_tracer(realm->heap, json_trace_parser, &parser);
 if (status != 0)
  return status;

 /* Succeeded: the caller owns the final parsed or revived value. */
 return 0;
}

'''+s[pos:]
for name,kind in [('json_object',0),('json_array',1)]:
 m=get(name);f=m.group();f=f.replace(name+'(\n\tstruct json_parser *parser,',name+'_inner(\n\tstruct json_parse_roots *roots,');f=f.replace('{\n\tstruct vm_object','{\n\tstruct json_parser *parser;\n\tstruct vm_object',1)
 for v in ['name','key','member']:f=f.replace('\tvm_value '+v+';\n','');f=re.sub(r'(?<![\w.>])'+v+r'\b','roots->'+v,f)
 f=re.sub(r'/\*.*?\*/',lambda m:m.group().replace('roots->',''),f,flags=re.S);f=f.replace('\t/* Too deep. */','\t/* The active container frame owns every recursive temporary. */\n\tparser = roots->parser;\n\n\t/* Too deep. */',1);var='array' if kind else 'object';f=f.replace('\t*value = vm_value_cell('+var+');','\troots->container = vm_value_cell('+var+');\n\t*value = roots->container;',1)
 wrapper='''static int
'''+name+'''(
 struct json_parser *parser,
 vm_value *value)
{
 int status;

 /* Keep the container and unfinished property values alive until this recursive parse returns. */
 status = json_parse_container(parser, value, '''+str(kind)+''');
 if (status != 0)
  return status;

 /* Succeeded: the enclosing frame now owns the completed container. */
 return 0;
}

/* Parse the container while its wrapper retains unpublished children and property names. */
'''
 s=s[:m.start()]+wrapper+f+s[m.end():]
pos=s.index('/* Reads an object. */')
s=s[:pos]+'''/* Own recursive parser temporaries before allocating an unpublished object or array. */
static int
json_parse_container(
 struct json_parser *parser,
 vm_value *value,
 int is_array)
{
 struct json_parse_roots roots;
 int status;

 /* Register initialized slots even when the first container allocation fails. */
 roots.parser = parser;
 roots.container = VM_VALUE_UNDEFINED;
 roots.name = VM_VALUE_UNDEFINED;
 roots.key = VM_VALUE_UNDEFINED;
 roots.member = VM_VALUE_UNDEFINED;
 status = vm_heap_add_tracer(parser->realm->heap, json_trace_parse_frame, &roots);
 if (status != 0)
  return status;

 /* Every syntax failure and depth-limit exit passes through the same wrapper. */
 if (is_array) {
  status = json_array_inner(&roots, value);
 } else {
  status = json_object_inner(&roots, value);
 }
 vm_heap_remove_tracer(parser->realm->heap, json_trace_parse_frame, &roots);
 if (status != 0)
  return status;

 /* Succeeded: the completed container has transferred to its caller's traced slot. */
 return 0;
}

'''+s[pos:]
m=get('json_internalize');f=m.group();f=f.replace('json_internalize(\n\tstruct vm_realm *realm,\n\tvm_value reviver,\n\tvm_value holder,\n\tvm_value key,','json_internalize_inner(\n\tstruct json_reviver_roots *roots,');f=f.replace('{\n\tstruct wb_vector','{\n\tstruct vm_realm *realm;\n\tstruct wb_vector',1)
for n in ['value','name']:f=f.replace('\tvm_value '+n+';\n','')
f=f.replace('\tint is_object;','\tint traced;\n\tint is_array;\n\tint is_object;').replace('\tint is_index;\n','').replace('\tint is_string;\n','').replace('\tint found;\n','')
for n in ['reviver','holder','key','value','name']:f=re.sub(r'(?<![\w.>])'+n+r'\b','roots->'+n,f)
f=re.sub(r'/\*.*?\*/',lambda m:m.group().replace('roots->',''),f,flags=re.S);f=f.replace('\t/* The value at the key. */','\t/* The active reviver frame retains saved values before any callback or depth error. */\n\trealm = roots->realm;\n\n\t/* The value at the key. */',1)
f=f.replace('\twb_vector_init(&keys, sizeof(vm_value));','''	wb_vector_init(&keys, sizeof(vm_value));
 traced = 0;
 status = vm_heap_add_tracer(realm->heap, json_trace_values, &keys);
 if (status != 0)
  goto cleanup;
 traced = 1;''',1)
f=f.replace('\t\tif ((object->flags & VM_OBJECT_ARRAY) != 0U) {','''		/* Classification observes actual Proxy targets without consulting an ordinary brand field. */
  status = vm_is_array(realm, roots->value, &is_array);
  if (status != 0)
   goto cleanup;
  if (is_array) {''',1)
f=f.replace('vm_object_own_keys(realm->heap, object, &keys)','json_enumerable_keys(realm, roots->value, &keys)')
start=f.index('\t\t\tis_index =');end=f.index('\n\t\t\t/* The member revived. */',start);f=f[:start]+f[end:]
f=f.replace('descriptor.roots->value','descriptor.value');f=f.replace('cleanup:\n\twb_vector_release(&keys);','cleanup:\n\tif (traced)\n\t\tvm_heap_remove_tracer(realm->heap, json_trace_values, &keys);\n\twb_vector_release(&keys);');f=f.replace('json_key_value(realm, roots->key, &call_args[0])','json_key_value(realm, roots->key, &roots->key_value)');f=f.replace('\tcall_args[1] = roots->value;','\tcall_args[0] = roots->key_value;\n\tcall_args[1] = roots->value;');s=s[:m.start()]+f+s[m.end():]
pos=s.index('/* Walks a parsed value with a reviver')
s=s[:pos]+'''/* Snapshot enumerable string names completely before the first child reviver can alter later descriptors. */
static int
json_enumerable_keys(
 struct vm_realm *realm,
 vm_value object,
 struct wb_vector *keys)
{
 struct vm_descriptor descriptor;
 vm_value key;
 size_t item;
 size_t selected;
 int is_index;
 int is_string;
 int found;
 int status;

 /* The caller's vector tracer retains original and selected names through all descriptor callbacks. */
 status = vm_own_property_keys(realm, (struct vm_object *)vm_value_as_cell(object), keys);
 if (status != 0)
  return status;

 /* Symbols are omitted before GetOwnProperty, including Symbols invented by a Proxy trap. */
 selected = 0;
 for (item = 0; item < keys->count; item++) {
  key = *(vm_value *)wb_vector_at(keys, item);
  is_index = vm_value_is_int32(key);
  is_string = vm_value_is_string(key);
  if (!is_index && !is_string)
   continue;

  /* A missing or nonenumerable own property contributes no name to this snapshot. */
  status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(object), key, &descriptor, &found);
  if (status != 0)
   return status;
  if (!found)
   continue;
  if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
   continue;

  /* Compaction replaces only entries whose descriptor has already been inspected. */
  *(vm_value *)wb_vector_at(keys, selected) = key;
  selected++;
 }

 /* Publish the immutable name sequence before any child value is read. */
 keys->count = selected;
 return 0;
}

/* Keep one saved holder value alive even if a child callback deletes or replaces the original property. */
static int
json_internalize(
 struct vm_realm *realm,
 vm_value reviver,
 vm_value holder,
 vm_value key,
 vm_value *result,
 unsigned depth)
{
 struct json_reviver_roots roots;
 int status;

 /* Every callback temporary has a valid tagged value before registration. */
 roots.realm = realm;
 roots.reviver = reviver;
 roots.holder = holder;
 roots.key = key;
 roots.value = VM_VALUE_UNDEFINED;
 roots.name = VM_VALUE_UNDEFINED;
 roots.key_value = VM_VALUE_UNDEFINED;
 status = vm_heap_add_tracer(realm->heap, json_trace_reviver, &roots);
 if (status != 0)
  return status;

 /* All recursive, property-policy and callback failures retire their native frame here. */
 status = json_internalize_inner(&roots, result, depth);
 vm_heap_remove_tracer(realm->heap, json_trace_reviver, &roots);
 if (status != 0)
  return status;

 /* Succeeded: the parent owns the returned reviver value. */
 return 0;
}

'''+s[pos:]
pos=s.index('/* Retain the input conversion')
s=s[:pos]+'''/* Retain the coerced parse text and top-level outputs through allocation and reviver callbacks. */
static void
json_trace_parser(
 struct vm_heap *heap,
 void *context)
{
 struct json_parser *parser;

 /* Managed realm ownership starts before coercion; text becomes live only after conversion returns. */
 parser = context;
 if (parser->realm->managed)
  vm_heap_mark(heap, &parser->realm->cell);
 if (parser->text != NULL)
  vm_heap_mark(heap, (struct vm_cell *)parser->text);
 vm_heap_mark_value(heap, parser->root_value);
 vm_heap_mark_value(heap, parser->holder);
 vm_heap_mark_value(heap, parser->root_key);
 vm_heap_mark_value(heap, parser->reviver);
}

/* Retain unpublished parser containers, property names and completed children while later allocations collect. */
static void
json_trace_parse_frame(
 struct vm_heap *heap,
 void *context)
{
 struct json_parse_roots *roots;

 /* The surrounding parser frame retains the text and managed realm. */
 roots = context;
 vm_heap_mark_value(heap, roots->container);
 vm_heap_mark_value(heap, roots->name);
 vm_heap_mark_value(heap, roots->key);
 vm_heap_mark_value(heap, roots->member);
}

/* Retain the original saved value and fresh callback outputs during recursive reviver operations. */
static void
json_trace_reviver(
 struct vm_heap *heap,
 void *context)
{
 struct json_reviver_roots *roots;

 /* Native key-vector callbacks and direct recursion need independent ownership of every saved value. */
 roots = context;
 if (roots->realm->managed)
  vm_heap_mark(heap, &roots->realm->cell);
 vm_heap_mark_value(heap, roots->reviver);
 vm_heap_mark_value(heap, roots->holder);
 vm_heap_mark_value(heap, roots->key);
 vm_heap_mark_value(heap, roots->value);
 vm_heap_mark_value(heap, roots->name);
 vm_heap_mark_value(heap, roots->key_value);
}

'''+s[pos:]
p.write_text(s)
