(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('copy-gc-ordinary-fresh-getters-preserved',function(){var r={...{get a(){collectReadProxy();return {fresh:1};},get b(){collectReadProxy();return 2;}}};return r.a.fresh===1&&r.b===2;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
