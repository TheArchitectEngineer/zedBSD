int vm_object_rest(struct vm_realm *realm, vm_value source, vm_value excluded, vm_value *result);
static int spread_copy(struct vm_realm *realm, struct vm_object *target, vm_value source, vm_value excluded);
static void spread_trace_keys(struct vm_heap *heap, void *context);
int main(int argc, char **argv);
static int spread_copy_value(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int spread_copy_define(struct vm_realm *realm, struct vm_object *object, vm_value key, const struct vm_descriptor *descriptor, int *handled, int *done);
static int spread_copy_pressure(struct page *page);

int
vm_object_rest(
	struct vm_realm *realm,
	vm_value source,
	vm_value excluded,
	vm_value *result)
{
	struct vm_object *rest;
	struct vm_cell *roots[4];
	unsigned index;
	unsigned registered;
	int is_cell;
	int status;

	/* A direct native caller need not retain the realm or input cells before the first allocation. */
	memset(roots, 0, sizeof(roots));
	if (realm->managed)
		roots[0] = &realm->cell;
	is_cell = vm_value_is_cell(source);
	if (is_cell)
		roots[1] = vm_value_as_cell(source);
	is_cell = vm_value_is_cell(excluded);
	if (is_cell)
		roots[2] = vm_value_as_cell(excluded);
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup owns this registry slot only after acquisition succeeds. */
		registered++;
	}

	/* The unpublished result acquires its registered slot before any source trap can run. */
	rest = vm_object_create(realm->heap, realm->object_prototype);
	if (rest == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Keep the unpublished result alive while exclusions and source accessors run. */
	roots[3] = &rest->cell;

	/* Exclusions and source properties follow the shared CopyDataProperties order. */
	status = spread_copy(realm, rest, source, excluded);
	if (status != 0)
		goto cleanup;
	*result = vm_value_cell(rest);

	/* Both partial registration and abrupt source operations retire exactly their acquired roots. */
cleanup:
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve abrupt property or root-registration errors after releasing native ownership. */
	if (status != 0)
		return status;

	/* Succeeded: the caller owns the completed object rest value. */
	return 0;
}

static int
spread_copy(
	struct vm_realm *realm,
	struct vm_object *target,
	vm_value source,
	vm_value excluded)
{
	struct vm_descriptor descriptor;
	struct vm_object *object;
	struct vm_cell *roots[5];
	struct wb_vector keys;
	vm_value key;
	vm_value value;
	size_t index;
	unsigned slot;
	unsigned registered;
	int is_cell;
	int traced;
	int present;
	int found;
	int accepted;
	int status;

	/* Nullish sources have no keys and perform no allocation or target operation. */
	if (source == VM_VALUE_UNDEFINED || source == VM_VALUE_NULL)
		return 0;

	/* Empty vector storage and initialized slots make every partial acquisition share one cleanup. */
	wb_vector_init(&keys, sizeof(vm_value));
	memset(roots, 0, sizeof(roots));
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &target->cell;
	is_cell = vm_value_is_cell(source);
	if (is_cell)
		roots[2] = vm_value_as_cell(source);
	is_cell = vm_value_is_cell(excluded);
	if (is_cell)
		roots[3] = vm_value_as_cell(excluded);
	registered = 0;
	traced = 0;
	for (slot = 0; slot < 5U; slot++) {
		status = vm_heap_add_root(realm->heap, &roots[slot]);
		if (status != 0)
			goto cleanup;

		/* Cleanup owns this registry slot only after acquisition succeeds. */
		registered++;
	}

	/* The source's converted box remains live through native key collection and later getter calls. */
	status = vm_to_object(realm, source, &source);
	if (status != 0)
		goto cleanup;
	object = (struct vm_object *)vm_value_as_cell(source);
	roots[2] = &object->cell;

	/* Trace even unvisited fresh Symbols before the actual OwnPropertyKeys method returns its list. */
	status = vm_heap_add_tracer(realm->heap, spread_trace_keys, &keys);
	if (status != 0)
		goto cleanup;

	/* Cleanup must retire the acquired vector tracer before releasing its storage. */
	traced = 1;
	status = vm_own_property_keys(realm, object, &keys);
	if (status != 0)
		goto cleanup;

	/* Descriptor and value reads interleave per key; earlier getters may change later enumerability. */
	for (index = 0; index < keys.count; index++) {
		key = *(vm_value *)wb_vector_at(&keys, index);

		/* A rest key already consumed by the pattern causes no descriptor or value read. */
		status = spread_is_excluded(realm, excluded, key, &found);
		if (status != 0)
			goto cleanup;
		if (found)
			continue;

		/* Only an actual enumerable own property contributes a value at this step. */
		status = vm_get_own_property(realm, object, key, &descriptor, &present);
		if (status != 0)
			goto cleanup;
		if (!present)
			continue;
		if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
			continue;

		/* Retain a fresh getter result independently while target definition can call or collect. */
		status = vm_get(realm, source, key, &value);
		if (status != 0)
			goto cleanup;
		roots[4] = NULL;
		is_cell = vm_value_is_cell(value);
		if (is_cell)
			roots[4] = vm_value_as_cell(value);

		/* CreateDataProperty defines an own default data property without invoking inherited setters. */
		memset(&descriptor, 0, sizeof(descriptor));
		descriptor.has = VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE;
		descriptor.attributes = VM_PROPERTY_DEFAULT;
		descriptor.value = value;
		status = vm_define_own_property(realm, target, key, &descriptor, &accepted);
		if (status != 0)
			goto cleanup;
		if (!accepted) {
			/* Fresh payload, source and key stay owned through refusal-error allocation. */
			status = vm_throw_type_error(realm, "Cannot create copied data property");
			goto cleanup;
		}
	}

	/* All selected properties were defined without publishing a partial success after an error. */
	status = 0;

	/* Keys and every acquired direct-call root are retired on normal and abrupt paths. */
cleanup:
	if (traced)
		vm_heap_remove_tracer(realm->heap, spread_trace_keys, &keys);
	wb_vector_release(&keys);
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve abrupt property or root-registration errors after releasing native ownership. */
	if (status != 0)
		return status;

	/* Succeeded: each selected own enumerable property has been copied. */
	return 0;
}

static void
spread_trace_keys(
	struct vm_heap *heap,
	void *context)
{
	struct wb_vector *keys;
	vm_value key;
	size_t index;

	/* The caller owns vector storage; only its published count contains valid values. */
	keys = context;
	for (index = 0; index < keys->count; index++) {
		key = *(vm_value *)wb_vector_at(keys, index);
		vm_heap_mark_value(heap, key);
	}
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* The parser probe reaches the unchanged production allocation threshold without editing heap policy. */
	status = js_builtin_method(page->realm, page->realm->global, "pressureReadProxy", 0, proxy_parse_pressure);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* Private bridges exercise shared numeric-index and BigInt abstract operations without fixture algorithms. */
	status = js_builtin_method(page->realm, page->realm->global, "canonicalReadIndex", 1, proxy_canonical_index);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "toBigIntRead", 1, proxy_to_bigint);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge exposes actual deletion without strict-mode result conversion. */
	status = js_builtin_method(page->realm, page->realm->global, "deleteReadProperty", 2, proxy_delete_property);
	if (status != 0)
		goto cleanup;

	/* Private own-key and weak observation bridges leave product enumeration entry points unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "ownReadKeys", 1, proxy_own_keys);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "noteOwnKey", 1, proxy_note_own_key);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({x:1},{});return makeReadProxy(p,{}).x===1;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Fresh coercion text must survive a later parser allocation after the toString call frame has retired. */
	status = proxy_script(page->realm,
			      "(function(){var before,r=JSON.parse({toString:function(){var text=['{','\"a\":[1,{\"b\":2}]}'].join('');before=pressureReadProxy();return text;}});return r.a[1].b===2&&pressureReadProxy(true)>before;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* Publish only the actual threshold-counter and parsed-value gate after both have passed. */
	puts("native JSON parser threshold collection: passed");

	/* Fixed-buffer TypedArray Set now accepts its actual numeric element operation. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != 0 || !done) {
		status = 1;
		goto cleanup;
	}

	/* A direct CopyDataProperties call must own its bare native inputs and a fresh getter result through target policy. */
	status = spread_copy_pressure(page);
	if (status != 0)
		goto cleanup;
	puts("native object copy collection and reclamation: passed");

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);
	if (status != 0)
		goto cleanup;
	status = numeric_conversion_pressure(page);
	if (status != 0)
		goto cleanup;
	status = typed_storage_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Revoked IsArray errors retain their otherwise unowned realm and native record during real allocation. */
	status = array_identity_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Extensibility retains original participants after reentrant revocation and pure native policy collection. */
	status = extent_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Deletion keeps original participants and a sole fresh Symbol across post-trap and native fallback collections. */
	status = delete_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Prototype operations retain requested inputs and independently release original protocol graphs. */
	status = prototype_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Own-key lists and preserved prefixes survive later getters, native policy collection and error rollback. */
	status = own_keys_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Public Object consumers retain fresh keys through boxing and preserve native errors through actual calls. */
	status = object_consumers_pressure(page);
	if (status != 0)
		goto cleanup;

	/* The direct ordinary-instance API must own its managed caller and inputs before any collecting descriptor policy. */
	status = ordinary_instance_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Object assignments must keep their direct native participants through callbacks and strict error allocation. */
	status = assignment_pressure(page);
	if (status != 0)
		goto cleanup;

	/* Native array shrink must publish its shorter length, collect safely and stop at the first fixed descriptor. */
	status = array_length_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A nested target may revoke its last payload owner before the outer descriptor conversion collects. */
	status = nested_snapshot_pressure(page);
	if (status != 0)
		goto cleanup;

	/* A primitive receiver's temporary source box must survive later depth conversion and then become reclaimable. */
	status = flat_source_pressure(page);
	if (status != 0)
		goto cleanup;

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
spread_copy_value(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	struct vm_object *value;

	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* A foreign page-realm native function supplies no edge to the independent managed caller realm. */
	value = vm_object_create(realm->heap, NULL);
	if (value == NULL)
		return ENOMEM;
	value->internal = vm_value_int32(713);
	spread_copy_case.addresses[3] = (uintptr_t)value;
	*result = vm_value_cell(value);

	/* Succeeded: only the pending Get result owns this fresh payload. */
	return 0;
}

static int
spread_copy_define(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	const struct vm_descriptor *descriptor,
	int *handled,
	int *done)
{
	struct vm_cell *cell;
	struct vm_cell *pressure;
	unsigned index;
	int is_cell;

	UNUSED_PARAMETER(object);
	UNUSED_PARAMETER(key);

	/* Heap-only calls are not the realm-aware CopyDataProperties path under test. */
	*handled = 1;
	*done = 0;
	if (realm == NULL)
		return EINVAL;
	if ((uintptr_t)realm != spread_copy_case.addresses[0])
		return EINVAL;
	if ((descriptor->has & VM_HAS_VALUE) == 0U)
		return EINVAL;
	is_cell = vm_value_is_cell(descriptor->value);
	if (!is_cell)
		return EINVAL;
	cell = vm_value_as_cell(descriptor->value);
	if ((uintptr_t)cell != spread_copy_case.addresses[3])
		return EINVAL;

	/* The caller realm, source, target and fresh getter result must all have production owners now. */
	vm_heap_collect(spread_copy_case.heap);
	for (index = 0; index < 4U; index++) {
		cell = vm_heap_find_cell(spread_copy_case.heap, spread_copy_case.addresses[index]);
		if (cell == NULL)
			return EFAULT;
	}

	/* Count only policies that actually observed every participant during collection. */
	spread_copy_case.calls++;
	if (spread_copy_case.mode == 0U)
		return EACCES;

	/* Refusal leaves pressure for a strictly later collection in the outer TypeError allocation. */
	pressure = vm_heap_alloc(spread_copy_case.heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL)
		return ENOMEM;

	/* Succeeded: the policy refused the property and the caller must report that refusal as an exception. */
	return 0;
}

static int
spread_copy_pressure(
	struct page *page)
{
	struct vm_realm *caller;
	struct vm_object *target;
	struct vm_object *source;
	struct vm_function *getter;
	struct vm_cell *roots[4];
	struct vm_cell *cell;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value marker;
	vm_value key;
	unsigned index;
	unsigned mode;
	unsigned registered;
	int outcome;
	int status;

	/* The marker distinguishes the original payload from any object reusing its weak address. */
	marker = vm_value_int32(713);

	/* Setup roots are registered empty and cleared before the direct production call. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup owns this registry slot only after acquisition succeeds. */
		registered++;
	}

	/* Separate cases distinguish native errno from the later allocation after a Boolean refusal. */
	for (mode = 0; mode < 2U; mode++) {
		memset(&spread_copy_case, 0, sizeof(spread_copy_case));
		spread_copy_case.heap = page->heap;
		spread_copy_case.mode = mode;
		status = vm_realm_create_managed(page->heap, &caller);
		if (status != 0)
			goto cleanup;
		roots[0] = &caller->cell;
		target = vm_object_create(page->heap, NULL);
		if (target == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Neither ordinary object points back to the managed caller realm. */
		roots[1] = &target->cell;
		source = vm_object_create(page->heap, NULL);
		if (source == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Keep the source alive until its accessor and production target policy are installed. */
		roots[2] = &source->cell;

		/* The getter belongs to the page realm, not the managed direct caller being observed. */
		getter = vm_function_create_native(page->realm, "copy-fresh-value", 0, spread_copy_value);
		if (getter == NULL) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Key creation may allocate before source installation takes over getter ownership. */
		roots[3] = &getter->object.cell;
		key = vm_key_from_ascii(page->heap, "x");
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Installing the accessor transfers getter ownership to the source, never to the weak observer. */
		status = vm_define_accessor(page->realm, vm_value_cell(source), key, vm_value_cell(getter), 0);
		if (status != 0)
			goto cleanup;
		target->native_operations = &spread_copy_operations;
		spread_copy_case.addresses[0] = (uintptr_t)caller;
		spread_copy_case.addresses[1] = (uintptr_t)target;
		spread_copy_case.addresses[2] = (uintptr_t)source;

		/* Only production CopyDataProperties retains the managed caller, source and target after setup. */
		for (index = 0; index < 4U; index++)
			roots[index] = NULL;
		vm_heap_stats(page->heap, &before);
		outcome = vm_copy_data_properties(caller, vm_value_cell(target), vm_value_cell(source));
		vm_heap_stats(page->heap, &after);
		if (spread_copy_case.calls != 1U) {
			status = 1;
			goto cleanup;
		}

		/* The policy must perform an actual collection rather than merely refuse a write. */
		if (after.collections <= before.collections) {
			status = 1;
			goto cleanup;
		}

		/* Distinguish a native errno from the exception created after Boolean refusal. */
		if (mode == 0U) {
			if (outcome != EACCES) {
				status = 1;
				goto cleanup;
			}
		} else {
			if (outcome != VM_THROWN) {
				status = 1;
				goto cleanup;
			}

			/* The outer error allocation must collect strictly after the inner target policy retires. */
			if (after.collections < before.collections + 2U) {
				status = 1;
				goto cleanup;
			}
		}

		/* Even the collection after the inner Define frame retires must preserve the outer saved payload. */
		for (index = 0; index < 4U; index++) {
			cell = vm_heap_find_cell(page->heap, spread_copy_case.addresses[index]);
			if (cell == NULL) {
				status = 1;
				goto cleanup;
			}
		}

		/* A live cell at the weak address must still be the original fresh ordinary payload. */
		cell = vm_heap_find_cell(page->heap, spread_copy_case.addresses[3]);
		if (cell->type != &vm_object_type) {
			status = 1;
			goto cleanup;
		}

		/* An object of the right type must retain the fresh payload sentinel as well. */
		if (((struct vm_object *)cell)->internal != marker) {
			status = 1;
			goto cleanup;
		}

		/* No source shape contains a Symbol; all four weakly observed participants must actually retire. */
		vm_heap_collect(page->heap);
		for (index = 0; index < 4U; index++) {
			cell = vm_heap_find_cell(page->heap, spread_copy_case.addresses[index]);
			if (cell != NULL) {
				status = 1;
				goto cleanup;
			}
		}
	}

	/* Both cases completed real collection and subsequent participant reclamation. */
	status = 0;

cleanup:
	memset(&spread_copy_case, 0, sizeof(spread_copy_case));
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve abrupt property or root-registration errors after releasing native ownership. */
	if (status != 0)
		return status;

	/* Succeeded: errno and refusal retained all participants only as long as the API needed them. */
	return 0;
}
