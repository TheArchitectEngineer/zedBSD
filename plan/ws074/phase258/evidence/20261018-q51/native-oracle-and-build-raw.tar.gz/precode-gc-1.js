(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('copy-gc-fresh-values-across-later-descriptors',function(){var p=makeReadProxy({a:1,b:2},{getOwnPropertyDescriptor:function(t,k){collectReadProxy();return Object.getOwnPropertyDescriptor(t,k);},get:function(t,k){return {value:k};}}),r={...p};return r.a.value==='a'&&r.b.value==='b';});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
