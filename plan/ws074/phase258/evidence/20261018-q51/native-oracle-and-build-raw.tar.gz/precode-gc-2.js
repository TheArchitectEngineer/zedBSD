(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('copy-gc-rest-excluded-and-saved-output',function(){var p=makeReadProxy({a:1,b:2,c:3},{get:function(t,k){collectReadProxy();return t[k];},getOwnPropertyDescriptor:function(t,k){collectReadProxy();return Object.getOwnPropertyDescriptor(t,k);}}),{a,...r}=p;return a===1&&r.b===2&&r.c===3;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
