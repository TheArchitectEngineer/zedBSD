(function(){
 var count=0,failed=0;
 function check(name,fn){count++;var ok=false;try{ok=fn()===true;}catch(e){}if(!ok)failed++;console.log('read-proxy '+name+': '+(ok?'PASS':'FAIL'));}
 function raises(fn,kind){try{fn();}catch(e){return e instanceof kind;}return false;}
 check('copy-gc-unvisited-fresh-symbol-key',function(){var p=makeReadProxy({},{ownKeys:function(){return ['x',Symbol('fresh-copy')];},getOwnPropertyDescriptor:function(){collectReadProxy();return {enumerable:true,configurable:true};},get:function(t,k){return typeof k==='symbol'?3:2;}}),r={...p},s=Object.getOwnPropertySymbols(r)[0];return r.x===2&&s.description==='fresh-copy'&&r[s]===3;});
 console.log('read-proxy controls: '+(count-failed)+'/'+count);
 return failed===0;
})()
