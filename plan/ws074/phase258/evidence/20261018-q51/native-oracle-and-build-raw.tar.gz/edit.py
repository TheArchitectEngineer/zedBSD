from pathlib import Path
import re
p=Path('userland/desktop/libbrowser/vm/spread.c');s=p.read_text();Path('build/ws074-20261018/q51/original-spread.c').write_text(s);s=s.replace('Spreading and destructuring (ws074-p079):','Spreading and destructuring:').replace('Iteration follows the iterator protocol (ws074-p087):','Iteration follows the iterator protocol:');decl='static int spread_copy(struct vm_realm *realm, struct vm_object *target, vm_value source, vm_value excluded);\n';s=s.replace(decl,'');pos=s.index('/*\n * Starts iterating');s=s[:pos]+decl+'static void spread_trace_keys(struct vm_heap *heap, void *context);\n\n'+s[pos:]
m=re.search(r'int\nvm_object_rest\(\n.*?\n\}',s,re.S);assert m
f='''int
vm_object_rest(
 struct vm_realm *realm,
 vm_value source,
 vm_value excluded,
 vm_value *result)
{
 struct vm_object *rest;
 struct vm_cell *roots[4];
 unsigned index;
 unsigned registered;
 int is_cell;
 int status;

 /* A direct native caller need not retain the realm or input cells before the first allocation. */
 memset(roots, 0, sizeof(roots));
 if (realm->managed)
  roots[0] = &realm->cell;
 is_cell = vm_value_is_cell(source);
 if (is_cell)
  roots[1] = vm_value_as_cell(source);
 is_cell = vm_value_is_cell(excluded);
 if (is_cell)
  roots[2] = vm_value_as_cell(excluded);
 registered = 0;
 for (index = 0; index < 4U; index++) {
  status = vm_heap_add_root(realm->heap, &roots[index]);
  if (status != 0)
   goto cleanup;
  registered++;
 }

 /* The unpublished result acquires its registered slot before any source trap can run. */
 rest = vm_object_create(realm->heap, realm->object_prototype);
 if (rest == NULL) {
  status = ENOMEM;
  goto cleanup;
 }
 roots[3] = &rest->cell;

 /* Exclusions and source properties follow the shared CopyDataProperties order. */
 status = spread_copy(realm, rest, source, excluded);
 if (status != 0)
  goto cleanup;
 *result = vm_value_cell(rest);

 /* Both partial registration and abrupt source operations retire exactly their acquired roots. */
cleanup:
 while (registered != 0U) {
  registered--;
  vm_heap_remove_root(realm->heap, &roots[registered]);
 }
 if (status != 0)
  return status;

 /* Succeeded: the caller owns the completed object rest value. */
 return 0;
}'''
s=s[:m.start()]+f+s[m.end():]
m=re.search(r'static int\nspread_copy\(\n.*?\n\}',s,re.S);assert m
f='''static int
spread_copy(
 struct vm_realm *realm,
 struct vm_object *target,
 vm_value source,
 vm_value excluded)
{
 struct vm_descriptor descriptor;
 struct vm_object *object;
 struct vm_cell *roots[5];
 struct wb_vector keys;
 vm_value key;
 vm_value value;
 size_t index;
 unsigned slot;
 unsigned registered;
 int is_cell;
 int traced;
 int present;
 int found;
 int accepted;
 int status;

 /* Nullish sources have no keys and perform no allocation or target operation. */
 if (source == VM_VALUE_UNDEFINED || source == VM_VALUE_NULL)
  return 0;

 /* Empty vector storage and initialized slots make every partial acquisition share one cleanup. */
 wb_vector_init(&keys, sizeof(vm_value));
 memset(roots, 0, sizeof(roots));
 if (realm->managed)
  roots[0] = &realm->cell;
 roots[1] = &target->cell;
 is_cell = vm_value_is_cell(source);
 if (is_cell)
  roots[2] = vm_value_as_cell(source);
 is_cell = vm_value_is_cell(excluded);
 if (is_cell)
  roots[3] = vm_value_as_cell(excluded);
 registered = 0;
 traced = 0;
 for (slot = 0; slot < 5U; slot++) {
  status = vm_heap_add_root(realm->heap, &roots[slot]);
  if (status != 0)
   goto cleanup;
  registered++;
 }

 /* The source's converted box remains live through native key collection and later getter calls. */
 status = vm_to_object(realm, source, &source);
 if (status != 0)
  goto cleanup;
 object = (struct vm_object *)vm_value_as_cell(source);
 roots[2] = &object->cell;

 /* Trace even unvisited fresh Symbols before the actual OwnPropertyKeys method returns its list. */
 status = vm_heap_add_tracer(realm->heap, spread_trace_keys, &keys);
 if (status != 0)
  goto cleanup;
 traced = 1;
 status = vm_own_property_keys(realm, object, &keys);
 if (status != 0)
  goto cleanup;

 /* Descriptor and value reads interleave per key; earlier getters may change later enumerability. */
 for (index = 0; index < keys.count; index++) {
  key = *(vm_value *)wb_vector_at(&keys, index);

  /* A rest key already consumed by the pattern causes no descriptor or value read. */
  status = spread_is_excluded(realm, excluded, key, &found);
  if (status != 0)
   goto cleanup;
  if (found)
   continue;

  /* Only an actual enumerable own property contributes a value at this step. */
  status = vm_get_own_property(realm, object, key, &descriptor, &present);
  if (status != 0)
   goto cleanup;
  if (!present)
   continue;
  if ((descriptor.attributes & VM_PROPERTY_ENUMERABLE) == 0U)
   continue;

  /* Retain a fresh getter result independently while target definition can call or collect. */
  status = vm_get(realm, source, key, &value);
  if (status != 0)
   goto cleanup;
  roots[4] = NULL;
  is_cell = vm_value_is_cell(value);
  if (is_cell)
   roots[4] = vm_value_as_cell(value);

  /* CreateDataProperty defines an own default data property without invoking inherited setters. */
  memset(&descriptor, 0, sizeof(descriptor));
  descriptor.has = VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE;
  descriptor.attributes = VM_PROPERTY_DEFAULT;
  descriptor.value = value;
  status = vm_define_own_property(realm, target, key, &descriptor, &accepted);
  if (status != 0)
   goto cleanup;
  if (!accepted) {
   /* Fresh payload, source and key stay owned through refusal-error allocation. */
   status = vm_throw_type_error(realm, "Cannot create copied data property");
   goto cleanup;
  }
 }

 /* All selected properties were defined without publishing a partial success after an error. */
 status = 0;

 /* Keys and every acquired direct-call root are retired on normal and abrupt paths. */
cleanup:
 if (traced)
  vm_heap_remove_tracer(realm->heap, spread_trace_keys, &keys);
 wb_vector_release(&keys);
 while (registered != 0U) {
  registered--;
  vm_heap_remove_root(realm->heap, &roots[registered]);
 }
 if (status != 0)
  return status;

 /* Succeeded: each selected own enumerable property has been copied. */
 return 0;
}'''
s=s[:m.start()]+f+s[m.end():]
pos=s.index('/* Tells whether the array of excluded keys')
s=s[:pos]+'''/* Keep every initialized native key entry live across later descriptor, exclusion and value callbacks. */
static void
spread_trace_keys(
 struct vm_heap *heap,
 void *context)
{
 struct wb_vector *keys;
 vm_value key;
 size_t index;

 /* The caller owns vector storage; only its published count contains valid values. */
 keys = context;
 for (index = 0; index < keys->count; index++) {
  key = *(vm_value *)wb_vector_at(keys, index);
  vm_heap_mark_value(heap, key);
 }
}

'''+s[pos:];p.write_text(s)
