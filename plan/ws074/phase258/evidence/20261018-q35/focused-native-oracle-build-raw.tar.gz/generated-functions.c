int vm_set(struct vm_realm *realm, vm_value base, vm_value key, vm_value value, int strict);
int vm_set_receiver(struct vm_realm *realm, struct vm_object *object, vm_value key, vm_value value, vm_value receiver, int *done);
static int access_set_receiver(struct vm_realm *realm, struct vm_object *object, vm_value key, vm_value value, vm_value receiver, int *done);
static void access_write_trace(struct vm_heap *heap, void *context);
static int access_proxy_set(struct vm_realm *realm, struct vm_proxy *proxy, vm_value key, vm_value value, vm_value receiver, int *done);
int main(int argc, char **argv);
static int proxy_set_receiver(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int proxy_gc_edges(struct page *page);

int
vm_set(
	struct vm_realm *realm,
	vm_value base,
	vm_value key,
	vm_value value,
	int strict)
{
	struct vm_property property;
	struct vm_accessor *accessor;
	struct vm_object *object;
	vm_value ignored;
	vm_value length_key;
	struct vm_descriptor descriptor;
	int handled;
	int is_object;
	int found;
	int done;
	int status;

	/* undefined and null have no properties. */
	if (base == VM_VALUE_UNDEFINED || base == VM_VALUE_NULL) {
		status = access_base_error(realm, base, key, "set", "setting");
		return status;
	}

	/* A primitive takes no property, but its prototype's setter is called with it. */
	is_object = vm_value_is_object(base);
	if (!is_object) {
		status = access_set_primitive(realm, base, key, value, strict);
		return status;
	}

	/* Direct Proxy assignment uses receiver-aware traps and preserves strict versus sloppy refusal. */
	object = (struct vm_object *)vm_value_as_cell(base);
	if (object->kind == VM_KIND_PROXY) {
		status = vm_set_receiver(realm, object, key, value, base, &done);
		if (status != 0)
			return status;
		if (!done) {
			status = access_refuse(realm, strict, "Proxy set trap returned false");
			return status;
		}

		/* Succeeded: the direct Proxy accepted this assignment. */
		return 0;
	}

	/* An accessor on the chain: its setter is called with the value. */
	object = (struct vm_object *)vm_value_as_cell(base);
	found = vm_object_find(object, key, &property);
	if (found < 0)
		return -found;

	/* Present descriptors retain their ordinary accessor and attribute rules. */
	if (found && (property.attributes & VM_PROPERTY_ACCESSOR) != 0U) {
		accessor = (struct vm_accessor *)vm_value_as_cell(*property.value);
		if (accessor->setter == VM_VALUE_UNDEFINED) {
			status = access_refuse(realm, strict, "Cannot set property which has only a getter");
			return status;
		}

		/* The setter, called with the value. */
		status = vm_call(realm, accessor->setter, base, &value, 1, &ignored);
		if (status != 0)
			return status;
		return 0;
	}

	/* A read-only data property refuses. */
	if (found && (property.attributes & VM_PROPERTY_WRITABLE) == 0U) {
		status = access_refuse(realm, strict, "Cannot assign to read only property");
		return status;
	}

	/* An array's own length is set by its rules. */
	length_key = vm_key_from_ascii(realm->heap, "length");
	if (length_key == VM_VALUE_EMPTY)
		return ENOMEM;
	if (found &&
	    property.holder == object &&
	    key == length_key &&
	    (object->flags & VM_OBJECT_ARRAY) != 0U) {
		status = access_set_length(realm, object, value, strict);
		if (status != 0)
			return status;
		return 0;
	}

	/* A typed array converts the value in the realm (a valueOf may run, a wrong BigInt type throws). */
	if (object->kind == VM_KIND_TYPED_ARRAY &&
	    object->native_operations != NULL &&
	    object->native_operations->define != NULL) {
		memset(&descriptor, 0, sizeof(descriptor));
		descriptor.has = VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE;
		descriptor.value = value;
		descriptor.attributes = VM_PROPERTY_DEFAULT;
		handled = 0;
		done = 0;
		status = object->native_operations->define(realm, object, key, &descriptor, &handled, &done);
		if (status != 0)
			return status;
		if (handled)
			return 0;
	}

	/* Otherwise the ordinary assignment; an object that takes no new property refuses. */
	status = vm_object_set(realm->heap, object, key, value, &done);
	if (status != 0)
		return status;
	if (!done) {
		status = access_refuse(realm, strict, "Cannot add property, object is not extensible");
		return status;
	}

	/* Succeeded: the value is put. */
	return 0;
}

int
vm_set_receiver(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	vm_value value,
	vm_value receiver,
	int *done)
{
	struct access_write_roots roots;
	int status;

	/* Retain every input before either an exotic trap or ordinary descriptor callback can collect. */
	*done = 0;
	roots.read.realm = realm;
	roots.read.base = vm_value_cell(object);
	roots.read.key = key;
	roots.read.receiver = receiver;
	roots.value = value;
	status = vm_heap_add_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;
	if (realm->property_depth >= ACCESS_RECURSION_MAX) {
		status = vm_throw_range_error(realm, "Maximum property recursion exceeded");
		vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
		return status;
	}

	/* TypedArray Set must never be silently certified with ordinary fallback rules. */
	if (object->kind == VM_KIND_TYPED_ARRAY) {
		vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
		return ENOTSUP;
	}

	/* One native operation depth covers both Proxy and ordinary dispatch. */
	realm->property_depth++;
	if (object->kind == VM_KIND_PROXY) {
		status = access_proxy_set(realm, (struct vm_proxy *)object, key, value, receiver, done);
	} else {
		status = access_set_receiver(realm, object, key, value, receiver, done);
	}

	/* Neither a thrown trap nor a refused ordinary definition may leak depth or input ownership. */
	realm->property_depth--;
	vm_heap_remove_tracer(realm->heap, access_write_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: done says whether the receiver accepted the property assignment. */
	return 0;
}

static int
access_set_receiver(
	struct vm_realm *realm,
	struct vm_object *object,
	vm_value key,
	vm_value value,
	vm_value receiver,
	int *done)
{
	struct access_descriptor_roots roots;
	struct vm_descriptor current;
	struct vm_descriptor existing;
	struct vm_descriptor change;
	struct vm_object *receiver_object;
	vm_value ignored;
	int present;
	int is_object;
	int status;

	/* A native descriptor may expose a transient accessor that no ordinary heap property owns. */
	memset(&current, 0, sizeof(current));
	roots.realm = realm;
	roots.source = VM_VALUE_UNDEFINED;
	roots.descriptor = &current;
	roots.made = VM_VALUE_UNDEFINED;
	status = vm_heap_add_tracer(realm->heap, access_descriptor_trace, &roots);
	if (status != 0)
		return status;
	status = vm_get_own_property(realm, object, key, &current, &present);
	if (status != 0)
		goto cleanup;
	if (!present) {
		if (object->prototype != NULL) {
			status = vm_set_receiver(realm, object->prototype, key, value, receiver, done);
			goto cleanup;
		}

		/* At the chain's end, an absent property acts as a writable data property. */
		current.has = VM_HAS_VALUE | VM_HAS_WRITABLE;
		current.attributes = VM_PROPERTY_WRITABLE;
		current.value = VM_VALUE_UNDEFINED;
	}

	/* Data descriptors first decide writability, then whether the actual receiver can have properties. */
	if ((current.has & VM_HAS_VALUE) != 0U) {
		if ((current.attributes & VM_PROPERTY_WRITABLE) == 0U) {
			status = 0;
			goto cleanup;
		}

		/* A primitive receiver cannot accept an ordinary data property. */
		is_object = vm_value_is_object(receiver);
		if (!is_object) {
			status = 0;
			goto cleanup;
		}

		/* Receiver reflection is a real internal operation and can run its own Proxy trap. */
		receiver_object = (struct vm_object *)vm_value_as_cell(receiver);
		status = vm_get_own_property(realm, receiver_object, key, &existing, &present);
		if (status != 0)
			goto cleanup;
		if (present) {
			if ((existing.has & VM_HAS_GET) != 0U || (existing.attributes & VM_PROPERTY_WRITABLE) == 0U) {
				status = 0;
				goto cleanup;
			}
		}

		/* Existing writable data changes only its value; new receiver properties receive all default attributes. */
		memset(&change, 0, sizeof(change));
		change.has = VM_HAS_VALUE;
		change.value = value;
		if (!present) {
			change.has |= VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE;
			change.attributes = VM_PROPERTY_DEFAULT;
		}

		/* Array receivers and Proxy receivers apply their actual DefineOwnProperty rules. */
		status = vm_define_own_property(realm, receiver_object, key, &change, done);
		goto cleanup;
	}

	/* Getter-only accessors refuse assignment without observing the receiver's descriptor. */
	if (current.setter == VM_VALUE_UNDEFINED) {
		status = 0;
		goto cleanup;
	}

	/* A setter receives exactly one original value and the original receiver; its return value is ignored. */
	status = vm_call(realm, current.setter, receiver, &value, 1, &ignored);
	if (status != 0)
		goto cleanup;
	*done = 1;

cleanup:
	/* Retire the snapshot tracer before its descriptor storage leaves this native frame. */
	vm_heap_remove_tracer(realm->heap, access_descriptor_trace, &roots);
	if (status != 0)
		return status;

	/* Succeeded: done preserves accepted assignment versus Boolean refusal. */
	return 0;
}

static void
access_write_trace(
	struct vm_heap *heap,
	void *context)
{
	struct access_write_roots *roots;

	/* Reuse the read-frame protocol for the shared input graph. */
	roots = context;
	access_read_trace(heap, &roots->read);
	vm_heap_mark_value(heap, roots->value);

	/* Succeeded: a sole write value remains live even after the script trap has returned. */
	return;
}

static int
access_proxy_set(
	struct vm_realm *realm,
	struct vm_proxy *proxy,
	vm_value key,
	vm_value value,
	vm_value receiver,
	int *done)
{
	struct vm_cell *roots[6];
	struct vm_descriptor current;
	struct vm_string *string;
	vm_value target;
	vm_value handler;
	vm_value method;
	vm_value method_key;
	vm_value trap_key;
	vm_value produced;
	vm_value args[4];
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_symbol;
	int truth;
	int present;
	int same;
	int status;

	/* The surrounding write frame retains key, value and receiver while this frame snapshots protocol participants. */
	target = proxy->target;
	handler = proxy->handler;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &proxy->object.cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(target);
	if (is_cell)
		roots[2] = vm_value_as_cell(target);
	roots[3] = NULL;
	is_cell = vm_value_is_cell(handler);
	if (is_cell)
		roots[3] = vm_value_as_cell(handler);
	roots[4] = NULL;
	roots[5] = NULL;
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* Revocation fails before consulting the handler. */
	if (target == VM_VALUE_NULL) {
		status = vm_throw_type_error(realm, "Cannot set a property of a revoked Proxy");
		goto cleanup;
	}

	/* GetMethod retrieves the current set trap and rejects noncallable values other than null or undefined. */
	method_key = vm_key_from_ascii(realm->heap, "set");
	if (method_key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Fallback delegates with the original receiver rather than substituting the target. */
	status = vm_get_method(realm, handler, method_key, &method);
	if (status != 0)
		goto cleanup;
	if (method == VM_VALUE_UNDEFINED) {
		status = vm_set_receiver(realm, (struct vm_object *)vm_value_as_cell(target), key, value, receiver, done);
		goto cleanup;
	}

	/* Retain a fresh trap and preserve symbol identity while exposing internal integer keys as strings. */
	roots[4] = vm_value_as_cell(method);
	trap_key = key;
	is_symbol = access_is_symbol(key);
	if (!is_symbol) {
		status = vm_to_string(realm, key, &string);
		if (status != 0)
			goto cleanup;
		trap_key = vm_value_cell(string);
		roots[5] = &string->cell;
	}

	/* The handler receives the target, normalized key, original value and original receiver as four arguments. */
	args[0] = target;
	args[1] = trap_key;
	args[2] = value;
	args[3] = receiver;
	status = vm_call(realm, method, handler, args, 4, &produced);
	if (status != 0)
		goto cleanup;
	truth = vm_to_boolean(produced);
	if (!truth) {
		status = 0;
		goto cleanup;
	}

	/* Truthy traps must respect the original target's own descriptor as observed after the trap. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(target), key, &current, &present);
	if (status != 0)
		goto cleanup;
	if (present && (current.attributes & VM_PROPERTY_CONFIGURABLE) == 0U) {
		if ((current.has & VM_HAS_VALUE) != 0U && (current.attributes & VM_PROPERTY_WRITABLE) == 0U) {
			same = vm_same_value(value, current.value);
			if (!same) {
				status = vm_throw_type_error(realm, "Proxy set trap changed a fixed data property");
				goto cleanup;
			}
		}

		/* A fixed accessor without a setter cannot claim successful assignment. */
		if ((current.has & VM_HAS_SET) != 0U && current.setter == VM_VALUE_UNDEFINED) {
			status = vm_throw_type_error(realm, "Proxy set trap accepted a fixed setter-less property");
			goto cleanup;
		}
	}

	/* A truthy result passing the fixed-property invariants accepts the assignment. */
	*done = 1;
	status = 0;

cleanup:
	/* The surrounding write frame remains active until every original protocol snapshot has been retired. */
	while (registered != 0U) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Preserve abrupt completion instead of reporting Boolean success. */
	if (status != 0)
		return status;

	/* Succeeded: done distinguishes accepted assignment from a false trap result. */
	return 0;
}

int
main(
	int argc,
	char **argv)
{
	struct page *page;
	struct wb_buffer source;
	struct wb_units units;
	struct js_syntax_error syntax;
	const char *source_path;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	int status;
	int passed;
	int printed;
	int done;

	/* Keep the shared control input reproducible for historical frozen fixture binaries. */
	source_path = "plan/ws074/tests/proxy-read.js";
	if (argc == 2)
		source_path = argv[1];
	if (argc > 2)
		return 2;

	/* Establish the production Page and builtins before installing fixture-only native bridges. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "makeReadProxy", 2, proxy_make);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "revokeReadProxy", 1, proxy_revoke);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "getReadReceiver", 3, proxy_get_receiver);
	if (status != 0)
		goto cleanup;
	status = js_builtin_method(page->realm, page->realm->global, "collectReadProxy", 0, proxy_collect);
	if (status != 0)
		goto cleanup;

	/* A fixture bridge exercises the shared VM descriptor operations with arbitrary input. */
	status = js_builtin_method(page->realm, page->realm->global, "descriptorRoundtrip", 2, descriptor_roundtrip);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares actual VM definition with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "defineReadProperty", 3, proxy_define_descriptor);
	if (status != 0)
		goto cleanup;

	/* A private Boolean bridge compares receiver-preserving VM Set with genuine Chromium reflection. */
	status = js_builtin_method(page->realm, page->realm->global, "setReadReceiver", 4, proxy_set_receiver);
	if (status != 0)
		goto cleanup;

	/* The same source reaches native Proxy or Chromium's genuine Proxy without API substitution inside the tests. */
	wb_buffer_init(&source);
	status = wb_file_read(source_path, &source);
	if (status != 0) {
		wb_buffer_release(&source);
		goto cleanup;
	}

	/* Convert the retained fixture bytes before executing the normal program. */
	wb_units_init(&units);
	status = wb_utf8_to_units(source.data, source.length, &units);
	wb_buffer_release(&source);
	if (status != 0) {
		wb_units_release(&units);
		goto cleanup;
	}

	/* Every script-selected collection now depends only on actual VM/native ownership. */
	vm_heap_set_stack_base(page->heap, NULL);
	status = js_run_script(page->realm, units.data, units.length, 0, &answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		goto cleanup;
	passed = 0;
	if (answer == VM_VALUE_TRUE)
		passed = 1;
	if (!passed) {
		status = 1;
		goto cleanup;
	}

	/* No partial product constructor may appear during the private foundation stage. */
	status = proxy_script(page->realm, "typeof Proxy==='undefined'&&"
					   "(function(){try{makeReadProxy(function(){},{});}catch(e){return e instanceof TypeError;}return false;})()&&"
					   "(function(){var p=makeReadProxy({},{});try{makeReadProxy(p,{});}catch(e){return e instanceof TypeError;}return false;})()",
			      &answer);
	if (status != 0)
		goto cleanup;
	if (answer != VM_VALUE_TRUE) {
		status = 1;
		goto cleanup;
	}

	/* TypedArray's separate Set contract remains explicitly unsupported in this private receiver-aware stage. */
	status = proxy_script(page->realm, "new Uint8Array(1)", &answer);
	if (status != 0)
		goto cleanup;
	status = vm_set_receiver(page->realm, (struct vm_object *)vm_value_as_cell(answer), vm_value_int32(0), vm_value_int32(1), answer, &done);
	if (status != ENOTSUP || done) {
		status = 1;
		goto cleanup;
	}

	/* Observe actual native graph retention after the shared protocol controls. */
	status = proxy_lifetime(page);
	if (status != 0)
		goto cleanup;

	/* Exercise managed realm and sole-result retention at real native collection points. */
	status = proxy_gc_edges(page);
	if (status != 0)
		goto cleanup;

	/* Direct native partial descriptors must survive real allocation pressure without caller roots. */
	status = descriptor_pressure(page);

cleanup:
	/* Restore ordinary scanning before retiring the complete Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return status;
	printed = printf("native proxy read ownership: passed\n");
	if (printed < 0)
		return 2;

	/* Succeeded: shared controls and native graph lifetime both held. */
	return 0;
}

static int
proxy_set_receiver(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	vm_value object;
	vm_value key;
	vm_value actual_receiver;
	int is_object;
	int done;
	int status;

	UNUSED_PARAMETER(receiver);

	/* Reflection validates its target before coercing the property key. */
	object = js_argument(args, count, 0);
	is_object = vm_value_is_object(object);
	if (!is_object) {
		status = vm_throw_type_error(realm, "Set target must be an object");
		return status;
	}

	/* A missing receiver defaults to the original target while explicit undefined remains unchanged. */
	actual_receiver = object;
	if (count > 3U)
		actual_receiver = args[3];
	status = vm_to_key(realm, js_argument(args, count, 1), &key);
	if (status != 0)
		return status;
	status = vm_set_receiver(realm, (struct vm_object *)vm_value_as_cell(object), key, js_argument(args, count, 2), actual_receiver, &done);
	if (status != 0)
		return status;
	*result = vm_value_boolean(done);

	/* Succeeded: reflection exposes the actual internal operation's Boolean outcome. */
	return 0;
}

static int
proxy_gc_edges(
	struct page *page)
{
	struct vm_realm *realm;
	struct vm_object *target;
	struct vm_object *handler;
	struct vm_cell *roots[6];
	struct vm_cell *pressure;
	struct vm_cell *found;
	struct vm_descriptor own;
	struct vm_descriptor change;
	struct vm_heap_stats before;
	struct vm_heap_stats after;
	vm_value answer;
	vm_value made;
	vm_value key;
	vm_value get_key;
	vm_value descriptor_key;
	vm_value payload;
	vm_value write_value;
	vm_value write_receiver;
	uintptr_t realm_address;
	uintptr_t descriptor_address;
	uintptr_t define_address;
	uintptr_t receiver_address;
	unsigned index;
	unsigned registered;
	int status;
	int same;
	int present;
	int done;

	/* Setup ownership is retired deliberately before each product operation takes responsibility. */
	memset(roots, 0, sizeof(roots));
	registered = 0;
	for (index = 0; index < 6U; index++) {
		status = vm_heap_add_root(page->heap, &roots[index]);
		if (status != 0)
			goto cleanup;
		registered++;
	}

	/* The temporary managed realm has no embedding Document or explicit lifetime. */
	status = vm_realm_create_managed(page->heap, &realm);
	if (status != 0)
		goto cleanup;
	roots[0] = &realm->cell;
	realm_address = (uintptr_t)realm;
	target = vm_object_create(page->heap, NULL);
	if (target == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated target while allocating the remaining protocol participants. */
	roots[1] = &target->cell;
	handler = vm_object_create(page->heap, NULL);
	if (handler == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retain the isolated handler until the private factory takes ownership. */
	roots[2] = &handler->cell;

	/* Intern keys before obtaining a transient function returned only to this native frame. */
	key = vm_key_from_ascii(page->heap, "x");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Intern the trap key before creating a transient method function. */
	get_key = vm_key_from_ascii(page->heap, "get");
	if (get_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Create the ordinary configurable descriptor used by the post-trap invariant read. */
	status = vm_object_define(page->heap, target, key, VM_VALUE_UNDEFINED, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	status = proxy_script(page->realm, "(function(){return {sole:74};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, get_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* A separate fresh descriptor result must cross the same native post-trap collector. */
	descriptor_key = vm_key_from_ascii(page->heap, "getOwnPropertyDescriptor");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* The fixture trap returns a descriptor and object payload with no persistent script owner. */
	status = proxy_script(page->realm, "(function(){return {value:{sole:75},writable:true,enumerable:true,configurable:true};})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, descriptor_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Define's trap erases its argument value before returning, leaving only the original native descriptor owner. */
	descriptor_key = vm_key_from_ascii(page->heap, "defineProperty");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Script collection precedes the separate post-trap native descriptor collection. */
	status = proxy_script(page->realm, "(function(t,k,d){var v=d.value;delete d.value;collectReadProxy();return v!==77;})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, descriptor_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Set's fresh value has no trap or target owner after the call frame returns. */
	descriptor_key = vm_key_from_ascii(page->heap, "set");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* The subsequent native descriptor collection must rely on the production write-frame tracer. */
	status = proxy_script(page->realm, "(function(t,k,v,r){collectReadProxy();return v!==78;})", &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);
	status = vm_object_define(page->heap, handler, descriptor_key, answer, VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	roots[4] = NULL;

	/* Genuine allocation pressure makes the private factory retain all otherwise unrooted inputs. */
	vm_heap_collect(page->heap);
	pressure = vm_heap_alloc(page->heap, &proxy_pressure_type, 8U * 1024U * 1024U);
	if (pressure == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Drop every setup owner before the factory must survive threshold collection. */
	roots[0] = NULL;
	roots[1] = NULL;
	roots[2] = NULL;
	vm_heap_stats(page->heap, &before);
	status = vm_proxy_create(realm, vm_value_cell(target), vm_value_cell(handler), &made);
	if (status != 0)
		goto cleanup;
	roots[3] = vm_value_as_cell(made);
	vm_heap_stats(page->heap, &after);
	if (after.collections <= before.collections) {
		status = 1;
		goto cleanup;
	}

	/* This native descriptor hook may collect but never executes script, preserving the production hook contract. */
	target->native_operations = &proxy_sole_operations;
	sole_heap = page->heap;
	sole_realm_address = realm_address;
	sole_realm_alive = 0;
	status = vm_get_receiver(realm, made, key, VM_VALUE_NULL, &answer);
	if (status != 0)
		goto cleanup;
	roots[4] = vm_value_as_cell(answer);

	/* Has fallback must independently retain the managed realm through the same native descriptor collector. */
	status = vm_has_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &present);
	if (status != 0)
		goto cleanup;
	if (!present) {
		status = 1;
		goto cleanup;
	}

	/* GetOwn retains its managed realm and otherwise unowned trap descriptor during target collection. */
	status = vm_get_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &own, &present);
	if (status != 0)
		goto cleanup;
	if (!present || own.has != (VM_HAS_VALUE | VM_HAS_WRITABLE | VM_HAS_ENUMERABLE | VM_HAS_CONFIGURABLE)) {
		status = 1;
		goto cleanup;
	}

	/* The complete descriptor owns the original fresh object until the embedding takes it. */
	roots[0] = vm_value_as_cell(own.value);
	descriptor_address = (uintptr_t)roots[0];
	descriptor_key = vm_key_from_ascii(page->heap, "sole");
	if (descriptor_key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read a real field from the payload that had no owner during the target policy collection. */
	status = vm_get(page->realm, own.value, descriptor_key, &payload);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(payload, vm_value_int32(75));
	if (!same) {
		status = 1;
		goto cleanup;
	}

	/* Protect setup only while allocating a new object that no target or trap closure will own. */
	roots[1] = &realm->cell;
	found = (struct vm_cell *)vm_object_create(page->heap, NULL);
	if (found == NULL) {
		status = 2;
		goto cleanup;
	}

	/* The temporary setup root is removed immediately before production Define takes responsibility. */
	roots[5] = found;
	define_address = (uintptr_t)found;
	status = vm_object_define(page->heap, (struct vm_object *)found, descriptor_key, vm_value_int32(76), VM_PROPERTY_DEFAULT);
	if (status != 0)
		goto cleanup;
	memset(&change, 0, sizeof(change));
	change.has = VM_HAS_VALUE | VM_HAS_CONFIGURABLE;
	change.attributes = VM_PROPERTY_CONFIGURABLE;
	change.value = vm_value_cell(found);
	roots[1] = NULL;
	roots[5] = NULL;
	status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &change, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		status = 1;
		goto cleanup;
	}

	/* The sole input payload must survive even after the trap deleted its representation field and returned. */
	found = vm_heap_find_cell(page->heap, define_address);
	if (found == NULL) {
		status = 1;
		goto cleanup;
	}

	/* Let the embedding retain the completed result only after the native ownership observation. */
	roots[5] = found;
	status = vm_get(page->realm, vm_value_cell(found), descriptor_key, &payload);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(payload, vm_value_int32(76));
	if (!same) {
		status = 1;
		goto cleanup;
	}

	/* A false trap result must not query the target's native descriptor hook. */
	change.value = vm_value_int32(77);
	status = vm_define_own_property(realm, (struct vm_object *)vm_value_as_cell(made), key, &change, &done);
	if (status != 0)
		goto cleanup;
	if (done || sole_realm_alive != 4U) {
		status = 1;
		goto cleanup;
	}

	/* A separate otherwise unowned receiver must survive the same post-trap native collector. */
	roots[1] = &realm->cell;
	found = (struct vm_cell *)vm_object_create(page->heap, NULL);
	if (found == NULL) {
		status = 2;
		goto cleanup;
	}

	/* Retire all receiver and realm setup ownership before the write frame becomes responsible. */
	roots[2] = found;
	receiver_address = (uintptr_t)found;
	write_receiver = vm_value_cell(found);
	roots[1] = NULL;
	roots[2] = NULL;

	/* Retire the embedding owner before Set must preserve this otherwise unowned original write value. */
	write_value = vm_value_cell(roots[5]);
	roots[5] = NULL;
	status = vm_set_receiver(realm, (struct vm_object *)vm_value_as_cell(made), key, write_value, write_receiver, &done);
	if (status != 0)
		goto cleanup;
	if (!done) {
		status = 1;
		goto cleanup;
	}

	/* The post-trap target hook collected after the script argument frame stopped owning this value. */
	found = vm_heap_find_cell(page->heap, define_address);
	if (found == NULL) {
		status = 1;
		goto cleanup;
	}

	/* Restore value ownership before checking the independent receiver address. */
	roots[5] = found;
	found = vm_heap_find_cell(page->heap, receiver_address);
	if (found == NULL) {
		status = 1;
		goto cleanup;
	}

	/* Restore embedding receiver ownership only after the actual native retention observation. */
	roots[2] = found;
	status = vm_set_receiver(realm, (struct vm_object *)vm_value_as_cell(made), key, vm_value_int32(78), VM_VALUE_NULL, &done);
	if (status != 0)
		goto cleanup;
	if (done || sole_realm_alive != 5U) {
		status = 1;
		goto cleanup;
	}

	/* The sole result from Get must also survive the subsequent Has collection. */
	key = vm_key_from_ascii(page->heap, "sole");
	if (key == VM_VALUE_EMPTY) {
		status = 2;
		goto cleanup;
	}

	/* Read the actual sole-result payload after the native policy collection. */
	status = vm_get(page->realm, answer, key, &answer);
	if (status != 0)
		goto cleanup;
	same = vm_same_value(answer, vm_value_int32(74));
	if (!same ||
	    sole_realm_alive != 5U ||
	    realm->property_depth != 0U) {
		status = 1;
		goto cleanup;
	}

	/* No surviving protocol participant references the temporary realm once the native Get frame ends. */
	roots[0] = NULL;
	roots[2] = NULL;
	roots[3] = NULL;
	roots[4] = NULL;
	roots[5] = NULL;
	vm_heap_collect(page->heap);
	found = vm_heap_find_cell(page->heap, realm_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The fresh descriptor payload must also be actually reclaimed after its last embedding root ends. */
	found = vm_heap_find_cell(page->heap, descriptor_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* The original Define input payload has no owner once the completed embedding root ends. */
	found = vm_heap_find_cell(page->heap, define_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* No trap, snapshot or write-frame root may retain the completed receiver. */
	found = vm_heap_find_cell(page->heap, receiver_address);
	if (found != NULL) {
		status = 1;
		goto cleanup;
	}

	/* Record the successful native ownership observations before releasing setup roots. */
	status = 0;

cleanup:
	/* Fixture observations are not collector roots and never survive the independent case. */
	sole_heap = NULL;
	sole_realm_address = 0;
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(page->heap, &roots[registered]);
	}

	/* Preserve an abrupt outcome after releasing this frame's ownership. */
	if (status != 0)
		return status;

	/* Succeeded: allocation, native descriptor collection and later realm reclamation all used real ownership. */
	return 0;
}
