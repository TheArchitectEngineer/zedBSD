static void expr_delegate(struct js_function_compiler *fc, struct js_node *node, uint32_t target);
static void expr_yield(struct js_function_compiler *fc, struct js_node *node, uint32_t target);
static int generator_step(struct vm_realm *realm, vm_value generator, vm_value value, int how, vm_value *result);
int vm_generator_resume(struct vm_realm *realm, vm_value generator_value, vm_value value, int how, vm_value *result, int *done, int *direct_result);
static struct vm_generator * generator_create(struct vm_realm *realm, struct vm_function *function);
int vm_delegate_start(struct vm_realm *realm, vm_value iterable, vm_value *result);
int vm_delegate_step(struct vm_realm *realm, vm_value record, vm_value sent, int how, vm_value *result, int *outcome);
static void generator_delegate_trace(struct vm_heap *heap, struct vm_cell *cell);
static int interpreter_suspend(struct interpreter *run, const uint32_t *words, vm_value *registers, uint32_t next);
static int interpreter_spread(struct interpreter *run, const uint32_t *words, vm_value *registers);
int main(void);
static int delegation_collect(struct vm_realm *realm, vm_value receiver, const vm_value *args, unsigned count, vm_value *result);
static int delegation_run(struct vm_realm *realm, const char *source, vm_value *answer);

static void
expr_delegate(
	struct js_function_compiler *fc,
	struct js_node *node,
	uint32_t target)
{
	uint32_t value;
	uint32_t state;
	uint32_t sent;
	uint32_t how;
	uint32_t outcome;
	uint32_t test;
	uint32_t loop;
	uint32_t complete;
	uint32_t finished;

	/* Evaluate the operand once and cache the actual iterator and its next method. */
	value = js_temp(fc);
	state = js_temp(fc);
	sent = js_temp(fc);
	how = js_temp(fc);
	outcome = js_temp(fc);
	test = js_temp(fc);
	js_compile_expression(fc, node->first, value);
	js_emit2(fc, VM_OP_DELEGATE_START, state, value);
	js_load_value(fc, sent, VM_VALUE_UNDEFINED);
	js_emit2(fc, VM_OP_LOAD_INT, how, VM_RESUME_NEXT);

	/* Each resumption forwards its completion to the iterator before choosing a suspension or exit. */
	loop = js_label_new(fc);
	complete = js_label_new(fc);
	finished = js_label_new(fc);
	js_label_place(fc, loop);
	js_emit5(fc, VM_OP_DELEGATE_STEP, target, state, sent, how, outcome);
	js_emit2(fc, VM_OP_LOAD_INT, test, -1);
	js_emit3(fc, VM_OP_STRICT_EQ, test, outcome, test);
	js_emit_jump(fc, VM_OP_JUMP_IF_FALSE, test, complete);
	js_emit3(fc, VM_OP_SUSPEND_RESULT, target, sent, how);
	js_emit_jump(fc, VM_OP_JUMP, 0, loop);

	/* A completed return crosses surrounding finally blocks; other completions become the expression value. */
	js_label_place(fc, complete);
	js_emit2(fc, VM_OP_LOAD_INT, test, VM_RESUME_RETURN);
	js_emit3(fc, VM_OP_STRICT_EQ, test, outcome, test);
	js_emit_jump(fc, VM_OP_JUMP_IF_FALSE, test, finished);
	js_emit_return(fc, target);
	js_label_place(fc, finished);
}

static void
expr_yield(
	struct js_function_compiler *fc,
	struct js_node *node,
	uint32_t target)
{
	uint32_t value;
	uint32_t how;
	uint32_t test;
	uint32_t goes_on;
	uint32_t returns;

	/* Delegation has its own completion loop and preserves iterator result identity. */
	if ((node->flags & JS_FLAG_DELEGATE) != 0U) {
		expr_delegate(fc, node, target);
		return;
	}

	/* The value yielded (undefined without one). */
	value = js_temp(fc);
	how = js_temp(fc);
	if (node->first != NULL) {
		js_compile_expression(fc, node->first, value);
	} else {
		js_load_value(fc, value, VM_VALUE_UNDEFINED);
	}

	/* The suspension; resumed, target has what came and how says how it came. */
	js_emit3(fc, VM_OP_SUSPEND, value, target, how);

	/* next goes on with the value (how is 0, which is false). */
	goes_on = js_label_new(fc);
	js_emit_jump(fc, VM_OP_JUMP_IF_FALSE, how, goes_on);

	/* return returns the value; throw throws it. */
	test = js_temp(fc);
	returns = js_label_new(fc);
	js_emit2(fc, VM_OP_LOAD_INT, test, VM_RESUME_RETURN);
	js_emit3(fc, VM_OP_STRICT_EQ, test, how, test);
	js_emit_jump(fc, VM_OP_JUMP_IF_TRUE, test, returns);
	js_emit1(fc, VM_OP_THROW, target);
	js_label_place(fc, returns);
	js_emit_return(fc, target);

	/* The generator goes on here with the value in target. */
	js_label_place(fc, goes_on);
}

static int
generator_step(
	struct vm_realm *realm,
	vm_value generator,
	vm_value value,
	int how,
	vm_value *result)
{
	struct vm_object *object;
	vm_value produced;
	int done;
	int direct_result;
	int status;

	/* The generator's step. */
	*result = VM_VALUE_UNDEFINED;
	status = vm_generator_resume(realm, generator, value, how, &produced, &done, &direct_result);
	if (status != 0)
		return status;

	/* Delegation exposes the original object without invoking its value getter. */
	if (direct_result) {
		*result = produced;
		return 0;
	}

	/* The iterator result. */
	object = vm_object_create(realm->heap, realm->object_prototype);
	if (object == NULL)
		return ENOMEM;
	status = js_builtin_value(realm, object, "value", produced, VM_PROPERTY_DEFAULT);
	if (status == 0)
		status = js_builtin_value(realm, object, "done", vm_value_boolean(done), VM_PROPERTY_DEFAULT);
	if (status != 0)
		return status;

	/* Succeeded: the result. */
	*result = vm_value_cell(object);
	return 0;
}

int
vm_generator_resume(
	struct vm_realm *realm,
	vm_value generator_value,
	vm_value value,
	int how,
	vm_value *result,
	int *done,
	int *direct_result)
{
	struct vm_generator *generator;
	struct vm_object *object;
	vm_value yielded;
	int is_object;
	int suspended;
	int status;

	/* Only a generator object can be resumed. */
	*result = VM_VALUE_UNDEFINED;
	*done = 1;
	*direct_result = 0;
	is_object = vm_value_is_object(generator_value);
	if (!is_object) {
		status = vm_throw_type_error(realm, "next method called on incompatible receiver");
		return status;
	}

	/* An object of another kind is not one either. */
	object = (struct vm_object *)vm_value_as_cell(generator_value);
	if (object->kind != VM_KIND_GENERATOR) {
		status = vm_throw_type_error(realm, "next method called on incompatible receiver");
		return status;
	}

	/* A generator that is running cannot be resumed from inside itself. */
	generator = (struct vm_generator *)vm_value_as_cell(object->internal);
	if (generator->state == VM_GENERATOR_RUNNING) {
		status = vm_throw_type_error(realm, "Generator is already running");
		return status;
	}

	/* A generator not started that is told to throw or return is done without running. */
	if (generator->state == VM_GENERATOR_START && how != VM_RESUME_NEXT)
		generator_end(generator);

	/* A generator done: throw throws the value, return returns it, next has nothing more. */
	if (generator->state == VM_GENERATOR_DONE) {
		if (how == VM_RESUME_THROW) {
			status = vm_throw(realm, value);
			return status;
		}

		/* Return gives the value back as the end. */
		if (how == VM_RESUME_RETURN)
			*result = value;
		return 0;
	}

	/* The run goes on from where it suspended. */
	generator->state = VM_GENERATOR_RUNNING;
	status = vm_interpret_resume(realm, generator, value, how, &yielded, &suspended);
	if (status != 0) {
		generator_end(generator);
		return status;
	}

	/* It yielded: it waits for the next resumption. */
	if (suspended) {
		generator->state = VM_GENERATOR_SUSPENDED;
		*result = yielded;
		*done = 0;
		*direct_result = (int)generator->direct_result;
		return 0;
	}

	/* Succeeded: it returned, and is done. */
	generator_end(generator);
	*result = yielded;
	return 0;
}

static struct vm_generator *
generator_create(
	struct vm_realm *realm,
	struct vm_function *function)
{
	struct vm_generator *generator;

	/* The cell (zeroed: no registers yet). */
	generator = vm_heap_alloc(realm->heap, &vm_generator_type, sizeof(*generator));
	if (generator == NULL)
		return NULL;

	/* Its function; nothing else is known before the run first suspends. */
	generator->function = function;
	generator->this_value = VM_VALUE_UNDEFINED;
	generator->new_target = VM_VALUE_UNDEFINED;
	generator->argument_count = 0;
	generator->promise = VM_VALUE_UNDEFINED;
	generator->state = VM_GENERATOR_RUNNING;
	generator->direct_result = 0;

	/* Succeeded: the cell. */
	return generator;
}

int
vm_delegate_start(
	struct vm_realm *realm,
	vm_value iterable,
	vm_value *result)
{
	struct generator_delegate *state;
	struct vm_cell *roots[4];
	vm_value method;
	vm_value made;
	vm_value key;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_object;
	int callable;
	int status;

	/* Retain the realm, operand, fetched method and unpublished record across user code. */
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = NULL;
	is_cell = vm_value_is_cell(iterable);
	if (is_cell)
		roots[1] = vm_value_as_cell(iterable);
	roots[2] = NULL;
	roots[3] = NULL;
	registered = 0;
	for (index = 0; index < 4U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Only acquired registrations belong to cleanup. */
		registered++;
	}

	/* Use the well-known symbol directly; the mutable global Symbol binding is irrelevant. */
	key = vm_symbol_key(realm, VM_SYMBOL_ITERATOR);
	status = vm_get(realm, iterable, key, &method);
	if (status != 0)
		goto cleanup;
	callable = vm_value_is_callable(method);
	if (!callable) {
		status = vm_throw_type_error(realm, "yield* operand is not iterable");
		goto cleanup;
	}

	/* A getter may have created the method without storing it anywhere else. */
	roots[2] = vm_value_as_cell(method);
	state = vm_heap_alloc(realm->heap, &generator_delegate_type, sizeof(*state));
	if (state == NULL) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Initialize every traced edge before the iterator method can collect. */
	roots[3] = &state->cell;
	state->iterator = VM_VALUE_UNDEFINED;
	state->next = VM_VALUE_UNDEFINED;
	status = vm_call(realm, method, iterable, NULL, 0, &made);
	if (status != 0)
		goto cleanup;
	state->iterator = made;
	is_object = vm_value_is_object(made);
	if (!is_object) {
		status = vm_throw_type_error(realm, "yield* iterator is not an object");
		goto cleanup;
	}

	/* GetIterator caches next without checking callability until the first step. */
	key = vm_key_from_ascii(realm->heap, "next");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Cache the iterator method before exposing the record to compiled code. */
	status = vm_get(realm, made, key, &state->next);
	if (status != 0)
		goto cleanup;

	/* Publish the complete record only after both protocol reads succeeded. */
	*result = vm_value_cell(state);

cleanup:
	/* Release only registrations acquired before a possible failure. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Any failed native operation preserves its original error status. */
	if (status != 0)
		return status;

	/* Succeeded: the generator can retain the record in its registers. */
	return 0;
}

int
vm_delegate_step(
	struct vm_realm *realm,
	vm_value record,
	vm_value sent,
	int how,
	vm_value *result,
	int *outcome)
{
	struct generator_delegate *state;
	struct vm_cell *roots[5];
	vm_value method;
	vm_value made;
	vm_value key;
	vm_value done_value;
	unsigned index;
	unsigned registered;
	int is_cell;
	int is_object;
	int callable;
	int missing_throw;
	int done;
	int status;

	/* Retain all native-only values through getters, callbacks and forced collection. */
	state = (struct generator_delegate *)vm_value_as_cell(record);
	if (state->cell.type != &generator_delegate_type)
		return EINVAL;
	roots[0] = NULL;
	if (realm->managed)
		roots[0] = &realm->cell;
	roots[1] = &state->cell;
	roots[2] = NULL;
	is_cell = vm_value_is_cell(sent);
	if (is_cell)
		roots[2] = vm_value_as_cell(sent);
	roots[3] = NULL;
	roots[4] = NULL;
	registered = 0;
	for (index = 0; index < 5U; index++) {
		status = vm_heap_add_root(realm->heap, &roots[index]);
		if (status != 0)
			goto cleanup;

		/* Cleanup cannot unregister slots that registration never acquired. */
		registered++;
	}

	/* next is cached, while return and throw are fetched afresh on each abrupt resumption. */
	missing_throw = 0;
	method = state->next;
	if (how != VM_RESUME_NEXT) {
		if (how == VM_RESUME_THROW) {
			key = vm_key_from_ascii(realm->heap, "throw");
		} else if (how == VM_RESUME_RETURN) {
			key = vm_key_from_ascii(realm->heap, "return");
		} else {
			status = EINVAL;
			goto cleanup;
		}

		/* A missing property key is allocation failure, not an absent protocol method. */
		if (key == VM_VALUE_EMPTY) {
			status = ENOMEM;
			goto cleanup;
		}

		/* Observe the current abrupt-completion method rather than a cached property. */
		status = vm_get(realm, state->iterator, key, &method);
		if (status != 0)
			goto cleanup;

		/* A missing return preserves the caller's return value without running following statements. */
		if (method == VM_VALUE_UNDEFINED || method == VM_VALUE_NULL) {
			if (how == VM_RESUME_RETURN) {
				*result = sent;
				*outcome = VM_RESUME_RETURN;
				status = 0;
				goto cleanup;
			}

			/* Missing throw first closes normally, so a failing close supersedes the protocol TypeError. */
			missing_throw = 1;
			key = vm_key_from_ascii(realm->heap, "return");
			if (key == VM_VALUE_EMPTY) {
				status = ENOMEM;
				goto cleanup;
			}

			/* Closing uses the iterator's current return method and preserves its failure. */
			status = vm_get(realm, state->iterator, key, &method);
			if (status != 0)
				goto cleanup;
			if (method == VM_VALUE_UNDEFINED || method == VM_VALUE_NULL) {
				status = vm_throw_type_error(realm, "yield* iterator has no throw method");
				goto cleanup;
			}
		}
	}

	/* A fetched method may exist only in this frame while its call runs. */
	is_cell = vm_value_is_cell(method);
	if (is_cell)
		roots[3] = vm_value_as_cell(method);
	callable = vm_value_is_callable(method);
	if (!callable) {
		status = vm_throw_type_error(realm, "yield* iterator method is not callable");
		goto cleanup;
	}

	/* The initial next receives one undefined argument; closing after missing throw receives none. */
	if (missing_throw) {
		status = vm_call(realm, method, state->iterator, NULL, 0, &made);
	} else {
		status = vm_call(realm, method, state->iterator, &sent, 1, &made);
	}

	/* Any failed native operation preserves its original error status. */
	if (status != 0)
		goto cleanup;
	is_object = vm_value_is_object(made);
	if (!is_object) {
		status = vm_throw_type_error(realm, "yield* iterator result is not an object");
		goto cleanup;
	}

	/* IteratorClose checks the object alone; done and value are intentionally not observed. */
	if (missing_throw) {
		status = vm_throw_type_error(realm, "yield* iterator has no throw method");
		goto cleanup;
	}

	/* IteratorComplete may run a getter; the original result must remain alive. */
	roots[4] = vm_value_as_cell(made);
	key = vm_key_from_ascii(realm->heap, "done");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* The result object remains rooted while a done getter executes. */
	status = vm_get(realm, made, key, &done_value);
	if (status != 0)
		goto cleanup;
	done = vm_to_boolean(done_value);
	if (!done) {
		*result = made;
		*outcome = -1;
		status = 0;
		goto cleanup;
	}

	/* A completed result alone reads value; throw-method completion becomes a normal expression value. */
	key = vm_key_from_ascii(realm->heap, "value");
	if (key == VM_VALUE_EMPTY) {
		status = ENOMEM;
		goto cleanup;
	}

	/* Transfer the completed value only after its getter succeeds. */
	status = vm_get(realm, made, key, result);
	if (status != 0)
		goto cleanup;
	*outcome = VM_RESUME_NEXT;
	if (how == VM_RESUME_RETURN)
		*outcome = VM_RESUME_RETURN;

cleanup:
	/* No native-only roots outlive their stack slots. */
	while (registered != 0) {
		registered--;
		vm_heap_remove_root(realm->heap, &roots[registered]);
	}

	/* Any failed native operation preserves its original error status. */
	if (status != 0)
		return status;

	/* Succeeded: the compiler can suspend or propagate the classified completion. */
	return 0;
}

static void
generator_delegate_trace(
	struct vm_heap *heap,
	struct vm_cell *cell)
{
	struct generator_delegate *state;

	/* The actual iterator and the cached next method can be independently collectible. */
	state = (struct generator_delegate *)cell;
	vm_heap_mark_value(heap, state->iterator);
	vm_heap_mark_value(heap, state->next);
}

static int
interpreter_suspend(
	struct interpreter *run,
	const uint32_t *words,
	vm_value *registers,
	uint32_t next)
{
	struct vm_generator *generator;
	vm_value *frame;
	uint32_t count;

	/* Only the entry frame of a generator's run can suspend (the compiler writes the instruction nowhere else). */
	generator = run->generator;
	frame = &run->realm->stack[run->base];
	if (generator == NULL || run->base != run->entry)
		return EINVAL;

	/* The place for the registers, made when the run first suspends. */
	count = run->code->register_count;
	if (generator->registers == NULL) {
		generator->registers = malloc((size_t)count * sizeof(vm_value) + 1U);
		if (generator->registers == NULL)
			return ENOMEM;
		generator->register_count = count;
	}

	/* The frame: its registers, its header's values and where it goes on. */
	memcpy(generator->registers, registers, (size_t)count * sizeof(vm_value));
	generator->this_value = frame[FRAME_THIS];
	generator->argument_count = frame[FRAME_ARGC];
	generator->new_target = frame[FRAME_NEW_TARGET];
	generator->pc = next;
	generator->value_register = words[2];
	generator->how_register = words[3];

	/* Only delegated results bypass the built-in generator method's result wrapper. */
	generator->direct_result = 0;
	if (words[0] == VM_OP_SUSPEND_RESULT)
		generator->direct_result = 1;

	/* The frame is popped, and the run ends with the value. */
	run->result = registers[words[1]];
	run->suspended = 1;
	run->realm->stack_top = run->base;

	/* Succeeded: the run is over until the generator is resumed. */
	return INTERPRETER_DONE;
}

static int
interpreter_spread(
	struct interpreter *run,
	const uint32_t *words,
	vm_value *registers)
{
	struct vm_realm *realm;
	vm_value value;
	int done;
	int outcome;
	int how;
	int status;

	/* Each instruction; one that computes a value writes it only when it succeeds. */
	realm = run->realm;
	switch (words[0]) {
	case VM_OP_DELEGATE_START:
		status = vm_delegate_start(realm, registers[words[2]], &value);
		break;
	case VM_OP_DELEGATE_STEP:
		/* Decode the completion before invoking user iterator methods. */
		how = vm_value_as_int32(registers[words[4]]);
		status = vm_delegate_step(realm, registers[words[2]], registers[words[3]], how, &value, &outcome);
		if (status != 0)
			return status;

		/* Publish both outputs only after callbacks and getters have finished. */
		registers = &realm->stack[run->base + FRAME_HEADER];
		registers[words[5]] = vm_value_int32(outcome);
		break;
	case VM_OP_ITER_START:
		status = vm_iter_start(realm, registers[words[2]], &value);
		break;
	case VM_OP_ITER_NEXT:
		status = vm_iter_next(realm, registers[words[2]], &value, &done);
		break;
	case VM_OP_ITER_REST:
		status = vm_iter_rest(realm, registers[words[2]], &value);
		break;
	case VM_OP_ITER_CLOSE:
		status = vm_iter_close(realm, registers[words[1]], (int)words[2]);
		return status;
	case VM_OP_ARRAY_SPREAD:
		status = vm_array_spread(realm, registers[words[1]], registers[words[2]]);
		return status;
	case VM_OP_COPY_DATA:
		status = vm_copy_data_properties(realm, registers[words[1]], registers[words[2]]);
		return status;
	case VM_OP_OBJECT_REST:
		status = vm_object_rest(realm, registers[words[2]], registers[words[3]], &value);
		break;
	case VM_OP_CALL_ARRAY:
		status = vm_call_array(realm, registers[words[2]], registers[words[3]], registers[words[4]], 0, &value);
		break;
	case VM_OP_CONSTRUCT_ARRAY:
		status = vm_call_array(realm, registers[words[2]], VM_VALUE_UNDEFINED, registers[words[3]], 1, &value);
		break;
	case VM_OP_CHECK_COERCIBLE:
		/* An object pattern cannot take its properties from undefined or null. */
		if (registers[words[1]] == VM_VALUE_UNDEFINED || registers[words[1]] == VM_VALUE_NULL) {
			status = vm_throw_type_error(realm, "Cannot destructure a value that is undefined or null.");
			return status;
		}

		/* Any other value can be destructured. */
		return 0;
	case VM_OP_ARGS_REST:
		status = interpreter_args_rest(realm, registers[words[2]], words[3], &value);
		break;
	default:
		return EINVAL;
	}

	/* A failed instruction writes nothing. */
	if (status != 0)
		return status;

	/* Succeeded: the value in the first operand's register. */
	registers[words[1]] = value;
	return 0;
}

int
main(
	void)
{
	struct page *page;
	static const unsigned char html[] = "<!doctype html><html><body></body></html>";
	vm_value answer;
	unsigned index;
	unsigned passed;
	unsigned total;
	int status;
	int printed;

	/* Initialize the ordinary production Page before disabling conservative stack retention. */
	status = page_create(&page, __builtin_frame_address(0));
	if (status != 0)
		return 2;
	status = page_load_html(page, html, sizeof(html) - 1U);
	if (status != 0) {
		page_destroy(page);
		return 2;
	}

	/* Install only a test-native collector callback; product APIs stay unchanged. */
	status = js_builtin_method(page->realm, page->realm->global, "collectDelegation", 0, delegation_collect);
	if (status != 0) {
		page_destroy(page);
		return 2;
	}

	/* Getters and iterator methods collect during actual native protocol operations. */
	vm_heap_set_stack_base(page->heap, NULL);
	passed = 0;
	total = sizeof(delegation_cases) / sizeof(delegation_cases[0]);
	for (index = 0; index < total; index++) {
		status = delegation_run(page->realm, delegation_cases[index], &answer);
		if (status != 0)
			break;
		if (answer == VM_VALUE_TRUE) {
			passed++;
		} else {
			printed = fprintf(stderr, "FAIL: delegation ownership %u\n", index + 1U);
			if (printed < 0) {
				status = 2;
				break;
			}
		}
	}

	/* Restore ordinary retention before destroying the Page graph. */
	vm_heap_set_stack_base(page->heap, __builtin_frame_address(0));
	page_destroy(page);
	if (status != 0)
		return 2;
	printed = printf("native generator delegation: %u/%u passed\n", passed, total);
	if (printed < 0)
		return 2;
	if (passed != total)
		return 1;

	/* Succeeded: all protocol values survived collection without conservative retention. */
	return 0;
}

static int
delegation_collect(
	struct vm_realm *realm,
	vm_value receiver,
	const vm_value *args,
	unsigned count,
	vm_value *result)
{
	UNUSED_PARAMETER(receiver);
	UNUSED_PARAMETER(args);
	UNUSED_PARAMETER(count);

	/* Explicit engine and VM roots alone retain the running protocol graph. */
	vm_heap_collect(realm->heap);
	*result = VM_VALUE_UNDEFINED;

	/* Succeeded: the real user callback resumes after collection. */
	return 0;
}

static int
delegation_run(
	struct vm_realm *realm,
	const char *source,
	vm_value *answer)
{
	struct wb_units units;
	struct js_syntax_error syntax;
	int status;

	/* Convert source without substituting native product values or behavior. */
	wb_units_init(&units);
	status = wb_utf8_to_units((const unsigned char *)source, strlen(source), &units);
	if (status != 0) {
		wb_units_release(&units);
		return status;
	}

	/* Execute the real program before releasing its temporary UTF-16 source. */
	status = js_run_script(realm, units.data, units.length, 0, answer, &syntax);
	wb_units_release(&units);
	if (status != 0)
		return status;

	/* Succeeded: the actual script supplied the observation. */
	return 0;
}
