from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess,re,collections
q=Path('build/ws074-20261018/q29');v=q/'final';out=Path('plan/ws074/phase257/evidence/20261018-q29');out.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((v/'source-proof.json').read_text());assert all(digest(p)==d for p,d in proof.items())
h=json.loads((q/'harness-outcome-audit.json').read_text());assert not h['whole_pass_losses'] and not h['old_pass_callback_losses'];protocol=json.loads((q/'final-protocol.json').read_text());assert protocol['native_matches'] and protocol['chrome_matches'] and protocol['expected_lines']==38
runs=json.loads((v/'native-runs.json').read_text());assert all(r['returncode']==0 for r in runs if r['label']!='acid');assert '10/10 passed' in (v/'delegation.log').read_text();assert not subprocess.check_output(['git','-C','build/ws074-suites/wpt','status','--porcelain','--untracked-files=no']).strip()
archives={}
def archive(label,paths,base):
 mapping={str(p.resolve().relative_to(base.resolve())):p for p in paths};p=out/(label+'.tar.gz')
 with tarfile.open(p,'w:gz') as tar:
  for name,file in sorted(mapping.items()):tar.add(file,arcname=name,recursive=False)
 with tarfile.open(p,'r:gz') as tar:
  count=0
  for member in tar:
   assert tar.extractfile(member).read()==mapping[member.name].read_bytes();count+=1
 assert count==len(mapping);archives[label]=dict(members=count,sha256=digest(p))
archive('harness-all-raw',[Path(p) for p in json.loads((q/'harness-files.json').read_text())],v/'after-harness')
paths=[p for p in q.rglob('*') if p.is_file() and p.suffix in ['.py','.json','.jsonl','.md','.log','.out','.err','.stderr','.html','.expected','.js','.bin','.png','.txt','.c','.h'] and 'after-harness' not in p.parts and 'engine' not in p.parts and 'target' not in p.parts and not any(a.endswith('-data') or a=='data' for a in p.parts)]
archive('native-oracle-and-build-raw',paths,q)
for src in [q/'approval-snapshot.md',q/'harness-outcome-audit.json',q/'style-generated.log',q/'style-review.json',q/'target-commands-5.json',q/'final-protocol.json',q/'webidl-oracle-proof.json',v/'native-runs.json',v/'source-proof.json',v/'source-commit.txt',v/'shared-input-comparison.json']:
 shutil.copy2(src,out/src.name)
for src in [Path('plan/ws074/tests/dom/generator-delegation.html'),Path('plan/ws074/tests/dom/generator-delegation.expected'),Path('plan/ws074/tests/host-generator-delegation.c')]:shutil.copy2(src,out/src.name)
for f in ['js/compile_expr.c','js/builtin_generator.c','vm/generator.c','vm/interpreter.c','vm/internal.h','vm/vm.h','vm/bytecode.h','vm/code.c']:shutil.copy2(Path('userland/desktop/libbrowser',f),out/f.replace('/','_'))
for src in q.glob('target-*.log'):shutil.copy2(src,out/src.name)
versions={name:subprocess.check_output(command,text=True).splitlines()[0] for name,command in [('host-cc',['cc','--version']),('formatter',['clang-format-19','--version']),('python',['python3','--version']),('target-cc',['build/llvm/bin/clang','--version'])]};versions['chromium']=subprocess.check_output(['chromium','--version'],text=True).strip();(out/'versions.json').write_text(json.dumps(versions,indent=2)+'\n')
summary=dict(source_commit=(v/'source-commit.txt').read_text().strip(),harness=h['counts'],callback_counts=h['callbacks'],whole_pass_gains=h['whole_pass_gains'],whole_pass_losses=h['whole_pass_losses'],old_pass_callback_losses=h['old_pass_callback_losses'],changes=len(h['changes']),protocol38=protocol,native_gc=10,host_target_warning=0,raw_allowed_style_flags=25,other_style_flags=0,archives=archives,static_reused_q28=844,scripted_reused_q28=105,crash_reused_q28=39,old_held=0,current_raw_lower_bound=h['counts'].get('pass',0)+844+105+39,limitations=['static/scripted/crash q28 evidence reused because render/native-script inputs unchanged except sync yield* VM scope; no new capture equality claim','same baseline denominator3805, unattempted275 retained','target5 single-source compile only; target link/runtime/full WS p100 remain unverified','all raw new whole gains require prerequisite audit before certification'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
