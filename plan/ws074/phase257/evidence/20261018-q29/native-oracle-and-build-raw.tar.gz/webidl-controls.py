from pathlib import Path
import os,importlib.util,json,subprocess,re,time
q=Path('build/ws074-20261018/q29');os.environ['WPT_GENERATED_CONTROL_ROOT']=str(q/'webidl-controls');os.environ['WPT_GENERATED_PROGRAM']=str((q/'final/engine/browser').resolve());spec=importlib.util.spec_from_file_location('q29_actual_webidl','plan/ws074/tests/test-interop2025-generated.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
scripts=[('actual-webidl-positive',b'''// META: script=/resources/WebIDLParser.js
test(function(){assert_equals(typeof WebIDL2.parse,'function');},'original WebIDL2 loaded');
test(function(){var defs=WebIDL2.parse('[Exposed=Window] interface Foo { attribute DOMString name; undefined ping(optional long n = 0); };');assert_equals(defs.length,1);assert_equals(defs[0].name,'Foo');assert_equals(defs[0].type,'interface');assert_equals(defs[0].members.length,2);assert_equals(defs[0].members[0].type,'attribute');assert_equals(defs[0].members[1].arguments[0].name,'n');},'original parser executes actual IDL');
test(function(){var defs=WebIDL2.parse('[Exposed=Window] interface Foo { attribute DOMString name; };');var errors=WebIDL2.validate(defs);assert_true(Array.isArray(errors));assert_equals(errors.length,0);},'original validator executes delegated generators');
test(function(){var rejected=false;try{WebIDL2.parse('interface Broken { attribute ; };');}catch(e){rejected=e.name==='WebIDLParseError';}assert_true(rejected);},'invalid IDL is rejected by original parser');'''),('actual-webidl-negative',b'''// META: script=/resources/WebIDLParser.js
test(function(){WebIDL2.parse('[Exposed=Window] interface Foo {};');assert_unreached('intentional assertion after actual original parser');},'parser success does not mask failure');''')]
proof=[]
for label,script in scripts:
 native=m.native(label,'any',script);(q/(label+'-native.json')).write_text(json.dumps(native,indent=2)+'\n');print(label,'native',native['outcome'],native['result_callbacks'],flush=True)
 root,row,server,context,tool,worker=m.fixture(label+'-chrome','any',script);command=['chromium','--headless','--no-sandbox','--disable-gpu','--enable-logging=stderr','--log-level=0','--user-data-dir=/tmp/ws074-q29-webidl-'+str(time.time_ns()),'--virtual-time-budget=5000','--dump-dom','http://127.0.0.1:%d%s'%(server.server_port,row['id'])]
 try:run=subprocess.run(command,capture_output=True,timeout=30)
 finally:m.stop(server,worker)
 (q/(label+'-chrome.html')).write_bytes(run.stdout);(q/(label+'-chrome.err')).write_bytes(run.stderr);messages=[]
 for line in run.stderr.decode('utf8',errors='replace').splitlines():
  match=re.search(r':CONSOLE(?:\(\d+\)|:\d+)\] "(.*)", source: ',line)
  if match:messages.append(match[1])
 chrome=m.RUNNER.classify_output('\n'.join(messages)+'\n',run.returncode);(q/(label+'-chrome.json')).write_text(json.dumps(chrome,indent=2)+'\n');proof.append(dict(label=label,native=native['outcome'],native_callbacks=native['result_callbacks'],chrome=chrome['outcome'],chrome_callbacks=chrome['result_callbacks'],original_source_identical=Path(native['generated']['raw_directory'],'source.js').read_bytes()==script,original_webidl_sha256=m.hashlib.sha256((m.WPT/'resources/webidl2/lib/webidl2.js').read_bytes()).hexdigest() if hasattr(m,'hashlib') else __import__('hashlib').sha256((m.WPT/'resources/webidl2/lib/webidl2.js').read_bytes()).hexdigest()));print(label,'chrome',chrome['outcome'],chrome['result_callbacks'],flush=True)
(q/'webidl-oracle-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
